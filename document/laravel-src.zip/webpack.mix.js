const mix = require("laravel-mix");

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.js('resources/js/app.js', 'public/js')
    .js('resources/js/customs/U0300/set-gas-info.js', 'public/js/U0300')
    .sass('resources/sass/customs/U0300/set-gas-info.scss', 'public/css/U0300')
    .js('resources/js/customs/U0600/output-data.js', 'public/js/U0600')
    .js('resources/js/customs/U0200/set-group.js', 'public/js/U0200')
    .js('resources/js/customs/U0700/coop-man-hour-stop-manual.js', 'public/js/U0700')
    .js("resources/js/customs/U0300/set-work-type.js", "public/js/U0300")
    .js("resources/js/customs/U0200/set-device.js", "public/js/U0200")
    .js('resources/js/customs/U0200/set-attachment.js', 'public/js/U0200')
    .js("resources/js/customs/U0300/set-payment-type.js", "public/js/U0300")
    .js('resources/js/customs/U0200/image-list.js', 'public/js/U0200')
    .js("resources/js/customs/U0200/set-comment.js", "public/js/U0200")
    .js('resources/js/customs/U0300/result-info.js', 'public/js/U0300')
    .js("resources/js/customs/X0600/set-user-info.js", "public/js/X0600")
    .js("resources/js/customs/U0800/mainte-code-class.js", "public/js/U0800")
    .js('resources/js/customs/U0800/mainte-auth.js', 'public/js/U0800')
    .js('resources/js/customs/U0800/set-mainte-auth.js', 'public/js/U0800')
    .js('resources/js/customs/U0800/mainte-user.js', 'public/js/U0800')
    .js('resources/js/customs/U0800/set-mainte-user.js', 'public/js/U0800')
    .js("resources/js/customs/U0400/set-cost.js", "public/js/customs/U0400")
    .js("resources/js/customs/U0300/set-result.js", "public/js/U0300")
    .js("resources/js/customs/U0300/set-man-hour.js", "public/js/U0300")
    .js("resources/js/customs/U0300/set-operation-record.js", "public/js/U0300")
    .js("resources/js/customs/U0300/set-sign.js", "public/js/U0300")
    .js("resources/js/customs/U0300/set-sign-file.js", "public/js/U0300")
    .js("resources/js/customs/U0400/check-cost.js", "public/js/customs/U0400")
    .js("resources/js/customs/U0400/set-quotation.js", "public/js/U0400")
    .sass("resources/sass/app.scss", "public/css")
    .sass('resources/sass/customs/U0200/set-group.scss', 'public/css/U0200')
    .sass('resources/sass/customs/U0600/output-data.scss', 'public/css/U0600')
    .sass("resources/sass/customs/X0600/set-user-info.scss", "public/css/X0600")
    .sass("resources/sass/customs/U0200/set-device.scss", "public/css/U0200")
    .sass('resources/sass/customs/U0200/set-attachment.scss', 'public/css/U0200')
    .sass('resources/sass/customs/U0200/image-list.scss', 'public/css/U0200')
    .sass("resources/sass/customs/U0400/set-cost.scss", "public/css/U0400")
    .sass("resources/sass/customs/U0400/check-cost.scss", "public/css/U0400")
    .sass("resources/sass/customs/U0300/set-sign.scss", "public/css/U0300")
    .sass("resources/sass/customs/U0400/set-quotation.scss", "public/css/U0400")
    .sass('resources/sass/customs/U0300/result-info.scss', 'public/css/U0300')
    .sass('resources/sass/customs/U0800/mainte-user.scss', 'public/css/U0800')
    .sass('resources/sass/customs/U0800/mainte-auth.scss', 'public/css/U0800')
    .sass(
        "resources/sass/customs/U0100/schedule-weekly.scss",
        "public/css/customs/U0100"
    )
    .sass(
        "resources/sass/customs/U0800/mainte-code-class.scss",
        "public/css/U0800"
    )
    .sass(
        "resources/sass/customs/U0300/set-sign-file.scss",
        "public/css/U0300"
    )
    .sass(
        "resources/sass/customs/U0300/set-result.scss",
        "public/css/U0300"
    )
    .sass(
        "resources/sass/customs/U0300/set-man-hour.scss",
        "public/css/U0300"
    )
    .sass(
        "resources/sass/customs/U0300/set-operation-record.scss",
        "public/css/U0300"
    )
    .sourceMaps()
    .version();
