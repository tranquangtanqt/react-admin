# 三谷産業コンストラクション：メンテナンス業務システム

## 環境作成手順(開発)
- `php` をインストールする (`php8.0`以上で、最新PHPの方がよい)
    + MACの場合`brew install php`
    + Windowsの場合[XAMPP](https://www.apachefriends.org/download.html)でインストールする
- `composer` をインストールする
  参照：[Install Composer](https://getcomposer.org/download/)
- NodeJsをインストールする。
  参照：[NodeJs](https://nodejs.org/ja/)
- プロジェクトディレクトリに移動：`cd <projecf_dir>`
- リポジトリをクロンする：` git clone -b develop https://mitani-co.backlog.com/git/CONST_MAINTE/resource.git`
    + ログインIDとパスワードを入力する
    + gitが未インストールの場合インストールする
        - MAC: `brew install git`
        - Windows: [Git インストール](https://git-scm.com/download/win)
    + 基本的に機能追加の時に`develop`ブランチより新ブランチを作成し、開発するというフロー
- `cd resource/laravel-src`
- postgresデータベースを作成する
    + postgresが未インストールの場合インストールする
    + データベース名: `constmainte`
- 環境ファイル作成
    + `.env.example` をベースに`.env`ファイルを作成
    + MACの場合`cp .env.example .env`
- `.env`ファイル内で以下のDBパラメータを作成したDBと合わせて、設定する
    + `DB_CONNECTION=pgsql`
    + `DB_HOST=127.0.0.1`
    + `DB_PORT=5432`
    + `DB_DATABASE=constmainte`
    + `DB_USERNAME=<db_user>` ※`<db_user>`がロカルDBユーザ
    + `DB_PASSWORD=<password>` ※`<password>`がロカルDBユーザパスワード
- 必要なPHPパッケージをインストール：`composer install`
- 必要なnodejsパッケージをインストール：`npm install`
- JavaScriptとCSSをコンパイルする：`npm run dev`
- `composer dump-autoload`
- シムリンクを作成：`php artisan storage:link`
-  テーブル作成及び初期データ設定するために、DBマイグレーションを実施：`php artisan migrate:fresh --seed`
- サーバ起動：`php artisan serve`

## 資産管理・開発フロー
### 資産管理
資産管理はGitを利用し、以下のフローを採用する。参照：[Git Flow](https://nvie.com/posts/a-successful-git-branching-model/)

![Git Flow](https://nvie.com/img/git-model@2x.png)

#### メインブランチ
メインブランチは削除せず、永遠に存在する。

- `master`（ブランチ名：`master`)
    - プロダクトとしてリリースするためのブランチ。リリースしたらタグ付けする。
- `develop`（ブランチ名：`develop`)
    - 開発ブランチ。コードが安定し、リリース準備ができたら master へマージする。

#### サポートブランチ
サポーロブランチは不要の時に削除してもOK。

- 機能(feature)ブランチ
    - 機能の追加。 `develop` から分岐し、 `develop` にマージする。
    - ブランチ名：`feat-add-<機能英字名>`
    - 例：`feat-add-login`
- 修正(hotfix)ブランチ
    - リリース後のクリティカルなバグフィックスなど、 現在のプロダクトのバージョンに対する変更用。
    - `master` から分岐し、 `master` にマージし、タグをつける。次に `develop` にマージする。
    - ブランチ名：`hotfix-<バージョン>`
    - 例：`hotfix-1.1.2`
- リリス(release)ブランチ
    - プロダクトリリースの準備。`develop` ブランチにリリース予定の機能やバグフィックスがほぼ反映した状態で`develop` から分岐する。リリース準備が整ったら, `master` にマージし、タグをつける。次に develop にマージする。
    - ブランチ名：`release-<バージョン>`
    - 例：`release-1.1.2`

### 導入前開発フロー
#### 機能追加
- `develop`ブランチに移動：`git checkout develop	`
- 最新資産取得：`git pull origin develop --rebase`
- 新ブランチ作成・移動：`git checkout -b <新ブランチ名>`
    - ブランチ名は`feat-add-<機能英字名>`
    - 例：`git checkout -b feat-add-dashboard`
- 資産修正及びテストを行う
- 修正毎をコミット
    - `git add <修正済ファイル名>`
    - `git commit -m 'コミットメッセージ'`　（必ずコミットメッセージを追記）
- 機能追加を完了したら、リモートリポジトリにアップロードする
    - アップロードする前に`develop`ブランチより最新資産を取得：`git pull origin develop --rebase`
    - コンフリクトが発生する場合、ローカルで解決する
    - アップロード（プッシュ）するのには：`git push -u origin <新ブランチ名>`
- リモートリポジトリの`develop`ブランチにマージするためにプルリクエストを行う
    - プルリクエストはBacklogの画面上にて行う。参照：[Backlogプルリクエスト](https://backlog.com/ja/git-tutorial/pull-request/06/)
- レビューアーはプルリクエストをレビューし、OKであればマージを行い、リモートの新ブランチを削除する。
- レビュー結果はNGであれば修正を行い、コミットし、再度リモートリポジトリにアップロード(プッシュ)する。
- 検証環境(APとDBサーバ)で動作を確認する
    - `cd /var/www/m3-test/resource/laravel-src/`
    - `git checkout .`
    - `git checkout develop`
    - `git pull origin develop --rebase`
    - `composer install`
    - `composer dump-autoload`
    - `php artisan view:clear`
    - `npm install`
    - `npm run prod`

#### developブランチからの修正
- 機能追加のフローと同様ですが、ブランチ名は`feat-edit-<機能英字名>`にしてください。


### 導入後開発フロー
#### 機能追加
- 導入前の機能追加のフローと同様

#### 追加機能リリース
- `develop`ブランチに移動：`git checkout develop	`
- 最新資産取得：`git pull origin develop --rebase`
- 新ブランチ作成・移動：`git checkout -b <新ブランチ名>`
    - 新ブランチ名は`release-<バージョン>`
    - 例：`git checkout -b release-1.1.2`
- テスト、修正、準備などを行う
- 修正毎をコミット
    - `git add <修正済ファイル名>`
    - `git commit -m 'コミットメッセージ'`　（必ずコミットメッセージを追記）
- 完了したら、リモートリポジトリにアップロードする
    - アップロードする前に`develop`ブランチより最新資産を取得：`git pull origin develop --rebase`
    - コンフリクトが発生する場合、ローカルで解決する
    - アップロード（プッシュ）するのには：`git push -u origin <新ブランチ名>`
- リモートリポジトリの`develop`ブランチにマージするためにプルリクエストを行う
    - プルリクエストはBacklogの画面上にて行う。参照：[Backlogプルリクエスト](https://backlog.com/ja/git-tutorial/pull-request/06/)
- レビューアーはプルリクエストをレビューし、OKであればマージを行い、リモートの新ブランチを削除する。
- レビュー結果はNGであれば修正を行い、コミットし、再度リモートリポジトリにアップロード(プッシュ)する。
- `master`ブランチに移動：`git checkout master`
- `git pull origin master --rebase`
- リリースブランチをマージする：`git merge --no-ff <新ブランチ名>`
    - 例：`git merge --no-ff release-1.1.2`
- タグをつける：`git tag -a <バージョン>`
    - 例：`git tag 1.1.2`
- リモートリポジトリの`master`にアップロードする：`git push origin master`
- タグもリモートリポジトリにプッシュする：`git push origin <タグ名>`
    - 例：`git push origin 1.1.2`
- 本番環境(APとDBサーバ）に資産を適用する
    - `cd /var/www/m3/resource/laravel-src/`
    - `git checkout .`
    - `git checkout master`
    - `git pull origin master --rebase`
    - `composer install`
    - `composer dump-autoload`
    - `php artisan view:clear`
    - `npm install`
    - `npm run prod`

#### 本番資産にてのバッグの修正手順
- `master`ブランチに移動：`git checkout master`
- 最新資産取得：`git pull origin master --rebase`
- 新ブランチ作成・移動：`git checkout -b <新ブランチ名>`
    - ブランチ名は`hotfix-<リリースバージョン>`
    - 例：`git checkout -b hotfix-1.1.2`
- 資産修正及びテストを行う
- 修正毎をコミット
    - `git add <修正済ファイル名>`
    - `git commit -m 'コミットメッセージ'`（必ずコミットメッセージを追記）
- 修正完了したら、リモートリポジトリにアップロードする
    - `git push -u origin <新ブランチ名>`
- 検証環境(APとDBサーバ)で動作を確認する
    - `cd /var/www/m3-test/resource/laravel-src/`
    - `git checkout .`
    - `git checkout origin/<新ブランチ名>`
    - `composer install`
    - `composer dump-autoload`
    - `php artisan view:clear`
    - `npm install`
    - `npm run prod`
    - 動作確認を行う
- 確認結果がOK場合リモートリポジトリの`master`と`develop`ブランチにマージする（プルリクエストを行う）
    - プルリクエストはBacklogの画面上にて行う。参照：[Backlogプルリクエスト](https://backlog.com/ja/git-tutorial/pull-request/06/)
- レビューアーはプルリクエストをレビューし、OKであればマージを行い、リモートの新ブランチを削除する。
- レビュー結果はNGであれば修正を行い、コミットし、再度リモートリポジトリにアップロード(プッシュ)する。
- タグを更新するため、`master`ブランチに移動：`git checkout master`
- タグをつける(更新)：`git tag -a <バージョン>`
    - 例：`git tag 1.1.2`
- タグもリモートリポジトリにプッシュする：`git push origin <タグ名>`
    - 例：`git push origin 1.1.2`
- 本番環境(APとDBサーバ）に資産を適用する
    - `cd /var/www/m3/resource/laravel-src/`
    - `git checkout .`
    - `git checkout master`
    - `git pull origin master --rebase`
    - `composer install`
    - `composer dump-autoload`
    - `php artisan view:clear`
    - `npm install`
    - `npm run prod`
- 検証環境(APとDBサーバ)で動作を確認する
    - `cd /var/www/m3-test/resource/laravel-src/`
    - `git checkout .`
    - `git checkout develop`
    - `git pull origin develop --rebase`
    - `composer install`
    - `composer dump-autoload`
    - `php artisan view:clear`
    - `npm install`
    - `npm run prod`

## バージョニング
- バージョンパターン：`X.Y.Z`
    - `X`: MAJORバージョン
    - `Y`: MINORバージョン
    - `Z`: PATCHバージョン
- 参照：[SEMVER:セマンティック バージョニング](https://semver.org/lang/ja/)