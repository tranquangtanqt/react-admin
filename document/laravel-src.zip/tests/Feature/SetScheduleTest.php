<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class SetScheduleTest extends TestCase
{
    /** @test */
    public function cannot_add_schedule_when_not_logged_in()
    {
        return true;
    }

    /** @test */
    public function cannot_add_schedule_when_logged_in()
    {
        return true;
    }

    /**
     * 初期値データ作成
     *
     * @return void
     */
    private function createInitialData()
    {
        return true;
    }
}
