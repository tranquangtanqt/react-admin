<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\IdentifierCode;

class LoginTest extends TestCase
{

    /** @test */
    public function can_access_login_page()
    {

        $response = $this->get(route('login'));

        $response->assertStatus(200);
    }

    /** @test */
    public function can_login_with_correct_login_id_and_password()
    {
        // ユーザ作成
        $user = User::factory()->create([
            'login_id' => 'const',
            'password' => $password = 'secret',
        ]);

        // ログイン
        $this->post(route('login'), [
            'login_id' => $user->login_id,
            'password' => $password,
        ]);

        $this->assertAuthenticatedAs($user);
    }

    /** @test */
    public function redirected_to_dashboard_when_password_expiration_is_not_set()
    {
        // ユーザ作成
        $user = User::factory()->create([
            'login_id' => 'const',
            'password' => $password = 'secret',
        ]);

        // 識別コード作成
        $identifierCode = IdentifierCode::create([
            'code' => config('constants.codes.password'),
            'name' => 'パスワードポリシー',
        ]);

        // コード区分作成
        $identifierCode->codeClasses()->create([
            'key' => config('constants.password.exp_days'),
            'number1' => $passwordExpDays = 0,
        ]);

        // パスワード更新日変更
        $user->password_updated_at = now()->subDay($passwordExpDays + 1)->startOfDay();
        $user->save();

        // ログイン
        $response = $this->post(route('login'), [
            'login_id' => $user->login_id,
            'password' => $password,
        ]);

        $this->assertAuthenticatedAs($user);
        $response->assertRedirect(route('dashboard'));
    }

    /** @test */
    public function redirected_to_dashboard_when_password_not_expired()
    {
        // ユーザ作成
        $user = User::factory()->create([
            'login_id' => 'const',
            'password' => $password = 'secret',
        ]);

        // 識別コード作成
        $identifierCode = IdentifierCode::create([
            'code' => config('constants.codes.password'),
            'name' => 'パスワードポリシー',
        ]);

        // コード区分作成
        $identifierCode->codeClasses()->create([
            'key' => config('constants.password.exp_days'),
            'number1' => $passwordExpDays = 30,
        ]);

        // パスワード更新日変更
        $user->password_updated_at = now()->subDay($passwordExpDays - 1)->startOfDay();
        $user->save();

        // ログイン
        $response = $this->post(route('login'), [
            'login_id' => $user->login_id,
            'password' => $password,
        ]);

        $this->assertAuthenticatedAs($user);
        $response->assertRedirect(route('dashboard'));
    }

    /** @test */
    public function redirected_to_dashboard_when_password_expired()
    {
        // ユーザ作成
        $user = User::factory()->create([
            'login_id' => 'const',
            'password' => $password = 'secret',
        ]);

        // 識別コード作成
        $identifierCode = IdentifierCode::create([
            'code' => config('constants.codes.password'),
            'name' => 'パスワードポリシー',
        ]);

        // コード区分作成
        $identifierCode->codeClasses()->create([
            'key' => config('constants.password.exp_days'),
            'number1' => $passwordExpDays = 30,
        ]);

        // パスワード更新日変更
        $user->password_updated_at = now()->subDay($passwordExpDays)->startOfDay();
        $user->save();

        // ログイン
        $response = $this->post(route('login'), [
            'login_id' => $user->login_id,
            'password' => $password,
        ]);

        $this->assertAuthenticatedAs($user);
        $response->assertRedirect(route('set-password.edit'));
    }

    /** @test */
    public function login_id_is_required()
    {
        // ログイン
        $response = $this->from(route('login'))
            ->post(route('login'), [
                'login_id' => null,
                'password' => 'password',
            ]);

        $response->assertRedirect(route('login'));
        $response->assertSessionHasErrors('login_id');
    }

    /** @test */
    public function password_is_required()
    {
        // ログイン
        $response = $this->from(route('login'))
            ->post(route('login'), [
                'login_id' => 'const',
                'password' => null,
            ]);

        $response->assertRedirect(route('login'));
        $response->assertSessionHasErrors('password');
    }

    /** @test */
    public function cannot_login_with_incorrect_login_id()
    {
        // ユーザ作成
        $user = User::factory()->create([
            'login_id' => $loginId = 'const',
            'password' => $password = 'secret',
        ]);

        // ログイン
        $response = $this->from(route('login'))
            ->post(route('login'), [
                'login_id' => 'incorrect_login_id',
                'password' => $password
            ]);

        $response->assertRedirect(route('login'));
        $response->assertSessionHasErrors('login');
    }

    /** @test */
    public function cannot_login_with_incorrect_password()
    {
        // ユーザ作成
        $user = User::factory()->create([
            'login_id' => $loginId = 'const',
            'password' => $password = 'secret',
        ]);

        // ログイン
        $response = $this->from(route('login'))
            ->post(route('login'), [
                'login_id' => $loginId,
                'password' => 'invalid_password'
            ]);

        $response->assertRedirect(route('login'));
        $response->assertSessionHasErrors('login');
    }

}
