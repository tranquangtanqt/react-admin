<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class LoggerTest extends TestCase
{
    /** @test */
    public function can_log_to_db_an_action()
    {
        $this->assertTrue(true);
    }
}
