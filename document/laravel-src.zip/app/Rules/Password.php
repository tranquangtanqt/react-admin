<?php

namespace App\Rules;

use Illuminate\Validation\Rules\Password as RulePassword;
use Illuminate\Support\Facades\Validator;

class Password extends RulePassword
{

    /**
     * If the password containes only valid characters
     *
     * @var bool
     */
    protected $validChars = false;

    /**
     * Only valid chars are allowed
     *
     * @return $this
     */
    public function validChars()
    {
        $this->validChars = true;

        return $this;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $this->messages = [];

        $validator = Validator::make($this->data, [
            $attribute => 'string|min:' . $this->min,
        ], $this->validator->customMessages, $this->validator->customAttributes);

        if ($validator->fails()) {
            return $this->fail($validator->messages()->all());
        }

        $value = (string) $value;

        if ($this->validChars && preg_match('/[^a-zA-Z0-9!#$%()*+,-.:;=?@\\\^_`{|}~\]\[]/', $value)) {
            $this->fail(':attributeの形式が正しくありません。');
        }

        if ($this->mixedCase && !preg_match('/(\p{Ll}+.*\p{Lu})|(\p{Lu}+.*\p{Ll})/u', $value)) {
            $this->fail(':attributeは大文字小文字混在して入力してください。');
        }

        if ($this->letters && !preg_match('/\pL/u', $value)) {
            $this->fail(':attributeは英字を含めて入力してください。');
        }

        if ($this->symbols && !preg_match('/\p{Z}|\p{S}|\p{P}/u', $value)) {
            $this->fail(':attributeは記号を含めて入力してください。');
        }

        if ($this->numbers && !preg_match('/\pN/u', $value)) {
            $this->fail(':attributeは数字を含めて入力してください。');
        }

        if (!empty($this->messages)) {
            return false;
        }

        return true;
    }
}
