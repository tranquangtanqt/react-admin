<?php

namespace App\Http\Controllers\X0000;

use App\Models\File;
use App\Http\Controllers\Controller;
use Intervention\Image\Facades\Image;

class ImageController extends Controller
{
    /**
     * 画像表示
     *
     */
    public function show(File $file)
    {
        // 非公開かつ外部社員
        if (
            !$file->public_flag &&
            userHasAuth(config('constants.auth.pic_external'))
        ) {
            return abort(403);
        }

        $image = Image::cache(function ($image) use ($file) {
            $image->make(stream_get_contents($file->file));
        }, 10, true);

        ob_end_clean();

        return $image->response();
    }
}
