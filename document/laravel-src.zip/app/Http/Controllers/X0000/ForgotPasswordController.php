<?php

namespace App\Http\Controllers\X0000;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\OneTimeKey;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Commons\Logger;
use App\Models\CodeClass;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * パスワード再設定
 */
class ForgotPasswordController extends Controller
{
    /**
     * 該当するパスワード再設定情報を表示します。
     */
    public function show($key)
    {
        $onTimeKey = OneTimeKey::where('key', $key)->first();
        $current = Carbon::now();

        if (($onTimeKey == null) || ($onTimeKey->expiration_date < $current)) {
            return view('X0000.ForgotPasswordNG');
        }

        return view('X0000.ForgotPassword', compact('key'));
    }

    /**
     * 該当するAA情報を変更します。
     */
    public function update(Request $request)
    {
        // ン情報バリデーション
        $onTimeKey = OneTimeKey::where('key', $request->key)->first();
        // Check one time key is exactly
        if ($onTimeKey == null) {
            return view('X0000.ForgotPasswordNG');
        }

        $password = $request->password;
        $password_confirm = $request->password_confirm;
        $passwordErrMsg = array();
        $pwdPasses = true;

        // Check type password required
        $alphanumericPasses = ((bool)preg_match("/^[A-Za-z0-9_! \"#?!@$%^&*-]+$/", $password));
        if ($password ==  null) {
            $pwdPasses = false;
            array_push($passwordErrMsg, 'パスワードを入力してください。');
        } else {
            if (!$alphanumericPasses) {
                $pwdPasses = false;
                array_push($passwordErrMsg, 'パスワードの形式が正しくありません。');
            }
        }
        $policy = CodeClass::whereIdentifierCode(config('constants.codes.password'))->get();

        // 長さチェック
        $lengthPolicy = $policy->where('key', config('constants.password.min'))->first();
        $length = intval($lengthPolicy->number1);
        if ($length > 0) {
            if (!(bool)(Str::length($password) >= $length)) {
                $pwdPasses = false;
                array_push($passwordErrMsg, 'パスワードは' . $length . '文字以上入力してください。');
            }
        }
        // 大文字小文字
        $mixedCasePolicy = $policy->where('key', config('constants.password.mixed_case'))->first();
        if ($mixedCasePolicy->number1 > 0) {
            if (!preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password)) {
                $pwdPasses = false;
                array_push($passwordErrMsg, 'パスワードは大文字小文字混在して入力してください。');
            }
        }

        // 英字
        $lettersPolicy = $policy->where('key', config('constants.password.letters'))->first();
        if ($lettersPolicy->number1 > 0) {
            if (!preg_match('/\pL/u', $password)) {
                $pwdPasses = false;
                array_push($passwordErrMsg, 'パスワードは英字を含めて入力してください。');
            }
        }

        // 数字
        $numbersPolicy = $policy->where('key', config('constants.password.numbers'))->first();
        if ($numbersPolicy->number1 > 0) {
            if (!(bool)preg_match('/\pN/u', $password)) {
                $pwdPasses = false;
                array_push($passwordErrMsg, 'パスワードは数字を含めて入力してください。');
            }
        }

        // 記号
        $symbolsPolicy = $policy->where('key', config('constants.password.symbols'))->first();
        if ($symbolsPolicy->number1 > 0) {
            if (!preg_match('/\p{Z}|\p{S}|\p{P}/u', $password)) {
                $pwdPasses = false;
                array_push($passwordErrMsg, 'パスワードは記号を含めて入力してください。');
            }
        }

        $user = User::where('id', $onTimeKey->user_id)->first();
        $pwdNewPolicy = $policy->where('key', config('constants.password.new'))->first();
        if ($pwdNewPolicy->number1 > 0) {
            if (Hash::check($request->password, $user->password)) {
                $pwdPasses = false;
                array_push($passwordErrMsg, 'パスワードは前回のパスワードと異なるパスワードとしてください。');
            }
        }

        $confirmPwdPassed = true;
        if (!($password == $password_confirm)) {
            $confirmPwdPassed = false;
        }

        if (!$confirmPwdPassed && !$pwdPasses) {
            return back()->withErrors(['password' => $passwordErrMsg, 'password_confirm' => 'パスワードが確認用パスワードと一致しません。']);
        }
        if (!$pwdPasses) {
            return back()->withErrors(['password' => $passwordErrMsg]);
        }
        if (!$confirmPwdPassed) {
            return back()->withErrors(['password_confirm' => 'パスワードが確認用パスワードと一致しません。']);
        }

        // Update expiration_date of one time key
        $onTimeKey->expiration_date = Carbon::now();
        $onTimeKey->save();

        // Update password
        $user->password = $request->password;
        $user->password_updated_at = Carbon::now();
        $user->save();

        $credentials = [
            'login_id' => $user->login_id,
            'password' => $request->password,
        ];

        // 自動ログイン
        if (Auth::attempt($credentials)) {

            // セッションを再生成
            $request->session()->regenerate();

            // ログインユーザ
            $user = Auth::user();

            // ログ登録
            Logger::create([
                'user_id' => $user->id,
                'process_type' => config('constants.logs.login'),
                'process_name' => 'パスワード再設定',
                'content' => "ユーザがログインしました。",
            ]);

            // セッション設定
            $this->addToSession();
            return view('X0000.ForgotPasswordOK');
        }

        return view('X0000.ForgotPasswordNG');
    }

    /**
     * セッションにデータ追加
     *
     * @return void
     */
    private function addToSession()
    {
        // 権限追加
        session(['auths' => auth()->user()->auths]);
    }
}
