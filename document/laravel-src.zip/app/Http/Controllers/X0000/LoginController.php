<?php

namespace App\Http\Controllers\X0000;

use App\Commons\Logger;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\X000\LoginRequest;

class LoginController extends Controller
{

    /**
     * ログイン画面を表示
     *
     * @return \Illuminate\View\View
     */
    public function show()
    {
        return view('X0000.Login');
    }

    /**
     * ログイン処理行う
     * パスワード切れた場合パスワード設定画面へ遷移
     * パスワード切れない場合ダッシュボードへ遷移
     *
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function store(LoginRequest $request)
    {

        // ログイン情報バリデーション
        $credentials = $request->validated();

        // ログインする
        if (Auth::attempt($credentials)) {

            // セッションを再生成
            $request->session()->regenerate();

            // ログインユーザ
            $user = Auth::user();

            // ログ登録
            Logger::create([
                'user_id' => $user->id,
                'process_type' => config('constants.logs.login'),
                'process_name' => 'ログイン',
                'content' => "ユーザがログインしました。",
            ]);

            // セッション設定
            $this->addToSession();

            // パスワードポリシーのパスワード更新期限の制御
            if ($user->passwordIsExpired()) {
                session(['password_expired' => true]);
                session()->flash('from_login', true);
                return redirect()->route('set-password.edit');
            }

            // ダッシュボードに遷移
            return redirect()->route('dashboard');
        }

        // ログイン失敗の時に戻る
        return back()->withInput()->withErrors(['login' => 'ユーザーID、またはパスワードに誤りがあります']);
    }

    /**
     * ログアウト処理　
     *
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function destroy(Request $request)
    {
        // ログ登録
        Logger::create([
            'user_id' => Auth::user()->id,
            'process_type' => config('constants.logs.logout'),
            'process_name' => 'ログアウト',
            'content' => "ユーザがログアウトしました。",
        ]);

        // ログアウト
        Auth::logout();

        // セッションリセット
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('login');
    }

    /**
     * セッションにデータ追加
     *
     * @return void
     */
    private function addToSession()
    {
        // 権限追加
        session(['auths' => auth()->user()->auths]);

        // データ追加の場合以下に記載
    }
}
