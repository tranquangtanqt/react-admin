<?php

namespace App\Http\Controllers\X0000;

use App\Models\File;
use App\Http\Controllers\Controller;
use Barryvdh\Debugbar\Facade as Debugbar;

class FileController extends Controller
{

    public function download(File $file)
    {

        // デバッグバー無効にする
        Debugbar::disable();

        // 非公開かつ外部社員
        if (
            !$file->public_flag &&
            userHasAuth(config('constants.auth.pic_external'))
        ) {
            return abort(403);
        }

        // ファイル内量取得
        $fileContent = stream_get_contents($file->file);

        ob_end_clean();

        return response($fileContent)
            ->header('Content-Type', 'application/octet-stream')
            ->header('Cache-Control', 'no-cache private')
            ->header('Content-Description', 'File Transfer')
            ->header('Content-Disposition', 'attachment; filename=' . $file->name)
            ->header('Content-Transfer-Encoding', 'binary');
    }
}
