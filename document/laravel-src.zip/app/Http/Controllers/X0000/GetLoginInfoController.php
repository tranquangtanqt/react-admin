<?php

namespace App\Http\Controllers\X0000;

use App\Http\Controllers\Controller;
use App\Http\Requests\X0000\EmailRequest;
use App\Models\User;
use App\Models\OneTimeKey;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Mail\ForgotPasswordMail;
use App\Commons\Logger;

class GetLoginInfoController extends Controller
{
    public function index()
    {
        return view('X0000.GetLoginInfo');
    }

    public function store(EmailRequest $request)
    {
        // ログイン情報バリデーション
        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return back()->withInput()->withErrors(['email' => 'メールアドレスに誤りがあります。']);
        }

        $onTimeByUserID = OneTimeKey::where('user_id', $user->id)->first();
        $generateKey = Str::random(32);
        if ($onTimeByUserID == null) {
            OneTimeKey::create([
                'key' => $generateKey,
                'user_id' => $user->id,
                'expiration_date' => Carbon::now()->addDay(),
                'created_at' => Carbon::now()
            ]);
        } else {
            $onTimeByUserID->key = $generateKey;
            $onTimeByUserID->expiration_date = Carbon::now()->addDay();
            $onTimeByUserID->save();
        }
        
        try {
            $resetLink = route('password-reset.show', $generateKey);
            $details = array();
            $bodyFlag = false;
            foreach (file(storage_path('app/mail/ForgotPassword.txt')) as $line) {
                $editLine = mb_convert_encoding($line, "UTF-8", "SJIS"); // Shift-JISをUTF8に変換
                if($bodyFlag){
                    $editLine = str_replace("\r\n", "<br>", $editLine);
                    $editLine = str_replace("\r", "<br>", $editLine);
                    $editLine = str_replace("\n", "<br>", $editLine);
                }
                $editLine = str_replace("{\$targetuserid}", $user->login_id, $editLine);
                $editLine = str_replace("{\$passwordurl}", $resetLink, $editLine);
                array_push($details, $editLine);
                $bodyFlag = true;
            }

            Mail::to($user->email)->send(new ForgotPasswordMail($details));
            return view('X0000.EmailSent');
        } catch (\Exception $e) {
            // ログ登録
            Logger::create([
                'user_id' => $user->id,
                'process_type' => config('constants.logs.login'),
                'process_name' => 'パスワード再設定',
                'content' => 'メール送信でエラーが発生しました',
                'content_detail' => $e,
            ]);

            return back()->withInput()->withErrors(['email' => 'メール送信でエラーが発生しました。']);
        }
    }
}
