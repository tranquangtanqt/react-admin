<?php

namespace App\Http\Controllers\U0800;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

/**
 * ユーザー情報マスタメンテナンス
 */
class MainteUserController extends Controller
{
    /**
     * 1ページで件数
     *
     * @var int
     */
    private $perPage = 20;

    /**
     * 初期処理
     */
    public function index($page = null){
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);

        $externalCompanyName = config('constants.item_display_name.external_company_code');
        $externalUserName = config('constants.item_display_name.external_user_code');

        $users = DB::table('users')
            ->whereNull('deleted_at')
            ->orderBy('id', 'ASC')
            ->paginate($this->perPage);


        // ログ出力
        $this->outputLog('ユーザー情報マスタメンテナンスアクセス',
                        config('constants.logs.page_access'),
                        'ユーザー情報マスタメンテナンスにアクセスしました。');

        return view('U0800.MainteUser', compact([
            'users', 'externalCompanyName', 'externalUserName', 'page'
        ]));
    }

    /**
     * 該当するユーザー情報を削除します。
     */
    public function delete($id, $page = null){
        $user = User::findOrFail($id);
        $user->delete();

        if ($page != null) {
            $currentPage = $page;
            Paginator::currentPageResolver(function () use ($currentPage) {
                return $currentPage;
            });

            $users = DB::table('users')
            ->whereNull('deleted_at')
            ->orderBy('id', 'ASC')
            ->paginate($this->perPage);

            if ($users->count() == 0) {
                if ($page != 1) {
                    $page = $page - 1;
                }
            }
        }

        // ログ出力
        $this->outputLog('ユーザー情報マスタメンテナンス削除',
                        config('constants.logs.data_delete'),
                        'ユーザー情報マスタメンテナンスを削除しました。');

        return redirect()->route('mainte-user.index', ['page' => $page])->with("message", "正常に削除しました。");
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
