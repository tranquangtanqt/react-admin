<?php

namespace App\Http\Controllers\U0800;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
/**
 * 権限マスタメンテナンス
 */
class MainteAuthController extends Controller
{
    /**
     * 1ページで件数
     *
     * @var int
     */
    private $perPage = 20;

    /**
     * 全ての権限のデータを表示します。
     */
    public function index($page = null)
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $codeclass = DB::table('code_classes')
            ->where('identifier_code', config('constants.codes.auth'))
            ->whereNull('deleted_at')
            ->select('key', 'value')
            ->get();

        $users = DB::table('users')
            ->leftJoin('auths',  function ($join) {
                $join->on('users.id', 'auths.user_id')
                    ->whereNull('auths.deleted_at');
            })
            ->select('users.id', 'users.login_id', 'users.name',
                DB::raw("string_agg(auths.auth_class, ',' order by auths.auth_class) as auth_class"))
            ->whereNull('users.deleted_at')
            ->groupBy('users.id')
            ->orderBy('users.id', 'ASC')
            ->paginate($this->perPage);

       // ログ出力
       $this->outputLog('権限マスタメンテナンスアクセス',
                        config('constants.logs.page_access'),
                        '権限マスタメンテナンスアクセスにアクセスしました。');

        return view('U0800.MainteAuth', compact([
            'users', 'codeclass', 'page'
        ]));
    }

    /**
     * 該当する権限情報を削除します。
     */
    public function delete($id, $page = null)
    {
        try {
            DB::beginTransaction();
            DB::table("auths")
                ->where('user_id', $id)
                ->update([
                    'updated_at' => now(),
                    'updated_by' => auth()->user()->id,
                    'deleted_at' => now()
                ]);

            // ログ出力
            $this->outputLog(
                '権限マスタメンテナンス削除',
                config('constants.logs.data_delete'),
                '権限マスタメンテナンスを削除しました。'
            );
            DB::commit();
        } catch (\Exception $e){
            $this->outputLog(
                '権限マスタメンテナンス削除',
                config('constants.logs.data_update'),
                '権限マスタメンテナンス画面削除エラー',
                $e
            );
        }

        return redirect()->route('mainte-auth.index', ['page' => $page])->with("message", "正常に削除しました。");
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
