<?php

namespace App\Http\Controllers\U0800;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0800\MainteCodeClassRequest;
use App\Models\CodeClass;
use App\Models\IdentifierCode;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;

/**
 * コード区分マスタメンテナンス設定
 */
class SetMainteCodeClassController extends Controller
{
    /**
     * 1ページで件数
     *
     * @var int
     */
    private $perPage = 20;

    /**
     * 該当するコード区分情報を表示します。
     */
    public function showCodeClass($code, Request $request, $id = null)
    {
        $identifierCodes = IdentifierCode::findOrFail($code);
        $page = $request->page ?: (Paginator::resolveCurrentPage() ?: 1);
        $flgProcess = 0;

        if(!$id){
            $codeClass = new CodeClass();
            $action = URL::route('set-mainte-code-class.store', ['code' => $code]);
            $flgProcess = 1;
        } else {
            $codeClass = CodeClass::findOrFail($id);
            $action = URL::route('set-mainte-code-class.update', ['code' => $code, 'id' => $id]);
            $flgProcess = 2;
        }

        // ログ出力
        $this->outputLog('コード区分マスタメンテナンス設定アクセス',
                    config('constants.logs.page_access'),
                    'コード区分マスタメンテナンス設定にアクセスしました。');

        return view('U0800.SetMainteCodeClass', compact([
            'code', 'codeClass', 'action', 'flgProcess', 'identifierCodes', 'page'
        ]));
    }

    /**
     * 新規でコード区分情報を登録します。
     */
    public function store(MainteCodeClassRequest $request, $code){
        $checkCodeClass = CodeClass::where('key', $request->key)->where('identifier_code', $code)->exists();
        if($checkCodeClass){
            return redirect()
                ->back()
                ->withInput($request->all())
                ->with("messageErr", "既に登録されているキーと重複します。");
        }

        $codeClass = new CodeClass();
        $codeClass->identifier_code = $code;
        $codeClass->key = $request->key;
        $codeClass->value = $request->value;
        $codeClass->display_order = $request->display_order;
        $codeClass->number1 = $request->number1;
        $codeClass->number2 = $request->number2;
        $codeClass->number3 = $request->number3;
        $codeClass->string1 = $request->string1;
        $codeClass->string2 = $request->string2;
        $codeClass->string3 = $request->string3;
        $codeClass->save();

        $codeClasses = DB::table('code_classes')
                ->where('identifier_code', $code)
                ->whereNull('deleted_at')
                ->orderBy('id', 'ASC')
                ->paginate($this->perPage);

        $page = intval(ceil($codeClasses->total()/$this->perPage));
        // ログ出力
        $this->outputLog('コード区分マスタメンテナンス登録',
                    config('constants.logs.data_insert'),
                    'コード区分マスタメンテナンスを登録しました。');

        return redirect()->route('mainte-code-class.show-identifier', ['code' => $code, 'page' => $page])->with("message", "正常に登録しました。");
    }

    /**
     * 該当するコード区分情報を変更します。
     */
    public function update(MainteCodeClassRequest $request, $id){
        $codeClass = CodeClass::findOrFail($id);

        if($codeClass->key != $request->key){
            $checkCodeClass = CodeClass::where('key', $request->key)->where('identifier_code', $codeClass->identifier_code)->exists();
            if($checkCodeClass){
                return redirect()
                    ->back()
                    ->withInput($request->all())
                    ->with("messageErr", "既に登録されているキーと重複します。");
            }
        }

        $codeClass->key = $request->key;
        $codeClass->value = $request->value;
        $codeClass->display_order = $request->display_order;
        $codeClass->number1 = $request->number1;
        $codeClass->number2 = $request->number2;
        $codeClass->number3 = $request->number3;
        $codeClass->string1 = $request->string1;
        $codeClass->string2 = $request->string2;
        $codeClass->string3 = $request->string3;
        $codeClass->save();

        $page = $request->page ?: (Paginator::resolveCurrentPage() ?: 1);

        // ログ出力
        $this->outputLog('コード区分マスタメンテナンス入替',
                        config('constants.logs.data_update'),
                        'ユコード区分マスタメンテナンスを入替しました。');

        return redirect()->route('mainte-code-class.show-identifier', ['code' => $codeClass->identifier_code, 'page' => $page])->with("message", "正常に修正しました。");
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
