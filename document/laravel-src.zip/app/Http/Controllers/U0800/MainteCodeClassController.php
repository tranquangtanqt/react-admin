<?php

namespace App\Http\Controllers\U0800;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\CodeClass;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

/**
 * コード区分マスタメンテナンス
 */
class MainteCodeClassController extends Controller
{
    /**
     * 1ページで件数
     *
     * @var int
     */
    private $perPage = 20;

    /**
     * 全てのコード区分のデータを表示します。
     */
    public function index($page = null)
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);

        $identifierCodes = DB::table('identifier_codes')
            ->whereNull('deleted_at')
            ->get();

        if ($identifierCodes) {
            $identifierCodesFirst = $identifierCodes->first();

            $codeClass = DB::table('code_classes')
                ->where('identifier_code', $identifierCodesFirst->code)
                ->whereNull('deleted_at')
                ->orderBy('id', 'ASC')
                ->paginate($this->perPage);
        }

        // ログ出力
        $this->outputLog(
            'コード区分マスタメンテナンスアクセス',
            config('constants.logs.page_access'),
            'コード区分マスタメンテナンスにアクセスしました。'
        );

        return view('U0800.MainteCodeClass', compact([
            'identifierCodes', 'codeClass', 'identifierCodesFirst', 'page'
        ]));
    }

    /**
     * 該当するコード区分情報を表示します。
     */
    public function showIdentifier($code, Request $request)
    {
        $page = $request->page ?: (Paginator::resolveCurrentPage() ?: 1);

        $identifierCodes = DB::table('identifier_codes')
            ->whereNull('deleted_at')
            ->get();

        if ($identifierCodes) {
            $identifierCodesFirst = $identifierCodes->where('code', $code)->first();

            $codeClass = DB::table('code_classes')
                ->where('identifier_code', $identifierCodesFirst->code)
                ->whereNull('deleted_at')
                ->orderBy('id', 'ASC')
                ->paginate($this->perPage);
        }

        // ログ出力
        $this->outputLog(
            'コード区分マスタメンテナンスアクセス',
            config('constants.logs.page_access'),
            'コード区分マスタメンテナンスにアクセスしました。'
        );

        return view('U0800.MainteCodeClass', compact([
            'identifierCodes', 'codeClass', 'identifierCodesFirst', 'page'
        ]));
    }

    /**
     * 該当するコード区分情報を削除します。
     */
    public function delete($id, $page = null)
    {
        $codeClass = CodeClass::findOrFail($id);
        $codeClass->deleted_at = now();
        $codeClass->updated_at = now();
        $codeClass->updated_by = auth()->user()->id;
        $codeClass->save();

        if ($page != null) {
            $currentPage = $page;
            Paginator::currentPageResolver(function () use ($currentPage) {
                return $currentPage;
            });

            $codeClasses = DB::table('code_classes')
                ->where('identifier_code', $codeClass->identifier_code)
                ->whereNull('deleted_at')
                ->orderBy('id', 'ASC')
                ->paginate($this->perPage);

            if ($codeClasses->count() == 0) {
                if ($page != 1) {
                    $page = $page - 1;
                }
            }
        }

        // ログ出力
        $this->outputLog(
            'コード区分マスタメンテナンス削除',
            config('constants.logs.data_delete'),
            'コード区分マスタメンテナンスを削除しました。'
        );

        return redirect()->route('mainte-code-class.show-identifier', ['code' => $codeClass->identifier_code, 'page' => $page])->with("message", "正常に削除しました。");
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
