<?php

namespace App\Http\Controllers\U0800;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

/**
 * 権限マスタメンテナンス設定
 */
class SetMainteAuthController extends Controller
{
    /**
     * 該当する権限情報を表示します。
    */
    public function show($id, Request $request)
    {
        $page = $request->page ?: (Paginator::resolveCurrentPage() ?: 1);

        try {
            $user = DB::table('users')
                ->leftJoin('auths', function ($join) { // 受付情報担当者ユーザのジョイン
                    $join->on('users.id', '=', 'auths.user_id')
                        ->whereNull('auths.deleted_at');
                })
                ->select('users.id as user_id', 'users.login_id', 'users.name',
                    DB::raw("string_agg(auths.auth_class, ',' order by auths.auth_class) as auth_class"))
                ->where('users.id', $id)
                ->whereNull('users.deleted_at')
                ->groupBy('users.id')
                ->orderBy('users.id')
                ->first();

            $authClass = explode(',', $user->auth_class);

            $codeClasses = DB::table('code_classes')
                ->whereIdentifierCode(config('constants.codes.auth'))
                ->whereNull('deleted_at')
                ->orderBy('display_order', 'ASC')
                ->get();

            $codeClassArr = array();
            foreach ($codeClasses as $codeClass) {
                $flag = false;
                if(in_array($codeClass->key, $authClass)){
                    $flag = true;
                }

                $arrElement = array(
                    "key" => $codeClass->key,
                    "value" => $codeClass->value,
                    "flag" => $flag
                );
                array_push($codeClassArr, $arrElement);
            }

            // ログ出力
            $this->outputLog('権限マスタメンテナンス設定アクセス',
                            config('constants.logs.page_access'),
                            '権限マスタメンテナンス設定にアクセスしました。');

            return view('U0800.SetMainteAuth', compact([
                'user', 'codeClassArr', 'page'
            ]));
        } catch (\Exception $e){
            // ログ登録
            $this->outputLog('権限マスタメンテナンス設定', config('constants.logs.data_insert'),
                            '権限マスタメンテナンス設定の日程のアクセスに失敗しました。',$e);
            return abort(500);
        }
    }

    /**
     * 該当する新規/修正情報を変更します
     */
    public function update(Request $request)
    {
        $page = $request->page ?: (Paginator::resolveCurrentPage() ?: 1);

        $codeClass = $request->code_classes;

        try {
            DB::table('auths')
                ->where('user_id', $request->user_id)
                ->update([
                    'updated_at' => Carbon::now(),
                    'updated_by' => auth()->user()->id,
                    'deleted_at' => Carbon::now()
                ]);

            $data = array();
            if($codeClass != null){
                for($i = 0; $i  < count($codeClass); $i++) {
                    $checkAuth = DB::table('auths')
                        ->where('user_id', $request->user_id)
                        ->where('auth_class', $codeClass[$i])
                        ->exists();

                    if($checkAuth){
                        DB::table('auths')
                        ->where('user_id', $request->user_id)
                        ->where('auth_class', $codeClass[$i])
                        ->update([
                            'user_id' => $request->user_id,
                            'auth_class' => $codeClass[$i],
                            'updated_at' => Carbon::now(),
                            'updated_by' => auth()->user()->id,
                            'deleted_at' => null
                        ]);
                    } else {
                        $row = array(
                            'user_id' => $request->user_id,
                            'auth_class' => $codeClass[$i],
                            'created_at' => Carbon::now(),
                            'created_by' => auth()->user()->id,
                            'updated_at' => Carbon::now(),
                            'updated_by' => auth()->user()->id,
                            'deleted_at' => null
                        );
                        array_push($data, $row);
                    }
                }

                DB::table('auths')->insert($data);
                DB::commit();
            }
        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog(
                '権限マスタメンテナンス登録',
                config('constants.logs.data_update'),
                '権限マスタメンテナンス画面登録エラー',
                $e
            );
        }

        $this->outputLog(
            '権限マスタメンテナンス登録',
            config('constants.logs.data_insert'),
            '権限マスタメンテナンスを登録しました。'
        );

        return redirect()->route('mainte-auth.index', ['page' => $page])->with("message", "正常に修正しました。");
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
