<?php

namespace App\Http\Controllers\U0800;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0800\MainteUserRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

/**
 * ユーザー情報マスタメンテナンス設定
 */
class SetMainteUserController extends Controller
{
    /**
     * 1ページで件数
     *
     * @var int
     */
    private $perPage = 20;

    /**
     * 該当するユーザー情報を表示します
     */
    public function show(Request $request, $id = null)
    {
        $page = $request->page ?: (Paginator::resolveCurrentPage() ?: 1);
        $flgProcess = 0;
        if(!$id) {
            $user = new User();
            $action = URL::route('set-mainte-user.store');
            $flgProcess = 1;
        } else {
            $user = User::findOrFail($id);
            $action = URL::route('set-mainte-user.update', ['id' => $id]);
            $flgProcess = 2;
        }

        $externalCompanyName = config('constants.item_display_name.external_company_code');
        $externalUserName = config('constants.item_display_name.external_user_code');

        // ログ出力
        $this->outputLog(
            'ユーザー情報マスタメンテナンス設定アクセス',
            config('constants.logs.page_access'),
            'ユーザー情報マスタメンテナンス設定にアクセスしました。'
        );

        return view('U0800.SetMainteUser', compact([
            'user', 'action', 'flgProcess', 'externalCompanyName', 'externalUserName', 'page'
        ]));
    }

    /**
     * 新規でユーザー情報を登録します。
     */
    public function store(MainteUserRequest $request)
    {
        $messages = [
            'login_id.unique' => '入力されたログインIDは既に登録されています。',
            'email.unique' => '入力されたメールアドレスは既に登録されています。'
        ];

        $validator = Validator::make($request->all(), [
            'login_id' =>  "unique:users,login_id",
            'email' =>  "unique:users,email"
        ], $messages);

        $checkExist = false;
        if($request->external_company_id != null || $request->external_user_id != null) {
            $checkExist = DB::table('users')
                ->where('external_company_id', $request->external_company_id)
                ->where('external_user_id', $request->external_user_id)
                ->exists();
        }

        if ($validator->fails() || $checkExist) {
            if($checkExist){
                return redirect()
                ->back()
                ->withErrors($validator)
                ->withInput($request->all())
                ->with("messageErr", "入力された会社コード、ユーザーコードの組み合わせは既に登録されています。");
            } else {
                return redirect()
                ->back()
                ->withErrors($validator)
                ->withInput($request->all());
            }
        }

        $user = new User();
        $user->login_id = $request->login_id;
        $user->name = $request->name;
        $user->short_name = $request->short_name;
        $user->email = $request->email;
        $user->external_company_id = $request->external_company_id;
        $user->external_user_id = $request->external_user_id;
        $user->password = Hash::make(Str::random(8));
        $user->save();

        $users = DB::table('users')
            ->whereNull('deleted_at')
            ->orderBy('id', 'ASC')
            ->paginate($this->perPage);

        $page = intval(ceil($users->total()/$this->perPage));

        // ログ出力
        $this->outputLog('ユーザー情報マスタメンテナンス登録',
                        config('constants.logs.data_insert'),
                        'ユーザー情報マスタメンテナンスを登録しました。');

        return redirect()->route('mainte-user.index', ['page' => $page])->with("message", "正常に登録しました。");
    }

    /**
     * 該当するユーザー情報を変更します
     */
    public function update(MainteUserRequest $request, $id)
    {
        $user = User::findOrFail($id);

        $messages = [
            'login_id.unique' => '入力されたログインIDは既に登録されています。',
            'email.unique' => '入力されたメールアドレスは既に登録されています。'
        ];

        $validator = Validator::make($request->all(), [
            'login_id' =>  "unique:users,login_id,$id,id",
            'email' =>  "unique:users,email,$id,id"
        ], $messages);

        $checkExist = false;
        if($user->external_company_id != $request->external_company_id || $user->external_user_id != $request->external_user_id){
            $checkExist = DB::table('users')->where('external_company_id', $request->external_company_id)
                ->where('external_user_id', $request->external_user_id)
                ->exists();
        }

        if ($validator->fails() || $checkExist) {
            if($checkExist){
                return redirect()
                ->back()
                ->withErrors($validator)
                ->withInput($request->all())
                ->with("messageErr", "入力された会社コード、ユーザーコードの組み合わせは既に登録されています。");
            } else {
                return redirect()
                ->back()
                ->withErrors($validator)
                ->withInput($request->all());
            }
        }

        $user->login_id = $request->login_id;
        $user->name = $request->name;
        $user->short_name = $request->short_name;
        $user->email = $request->email;
        $user->external_company_id = $request->external_company_id;
        $user->external_user_id = $request->external_user_id;
        $user->save();

        $page = $request->page ?: (Paginator::resolveCurrentPage() ?: 1);

        // ログ出力
        $this->outputLog(
            'ユーザー情報マスタメンテナンス入替',
            config('constants.logs.data_update'),
            'ユーザー情報マスタメンテナンスを入替しました。'
        );

        return redirect()->route('mainte-user.index', ['page' => $page])->with("message", "正常に修正しました。");
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
