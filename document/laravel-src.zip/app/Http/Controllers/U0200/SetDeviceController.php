<?php

namespace App\Http\Controllers\U0200;

use Exception;
use Carbon\Carbon;
use App\Models\UGroup;
use App\Commons\Logger;
use App\Models\UDevice;
use App\Models\L2Reception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

/**
 * 機器情報設定
 *
 * @author  donlq
 * @create_date  2021-10-22
 */
class SetDeviceController extends Controller
{
    /**
     * 該当する機器情報情報を表示します。
     *
     * @param  string  $receptionNo
     * @return \Illuminate\Http\Controller
     */
    public function show($receptionNo)
    {
        $receptionNoCheck = L2Reception::where('no', $receptionNo)->first();

        if (empty($receptionNoCheck)) {
            abort(404);
        }

        // 権限チェック
        $this->authorize('updateGroup', $receptionNoCheck->reception);

        try {
            $this->outputLog("機器情報アクセス", config('constants.logs.page_access'), '機器情報にアクセスしました');
            $setDevice = UDevice::select(
                'u_devices.id',
                'u_devices.represent_flag',
                'u_devices.group_id',
                'u_devices.device_type',
                'u_devices.device_no',
                'u_devices.updated_at'
            )
                ->leftjoin('u_groups', function ($join) {
                    $join->on('u_groups.id', '=', 'u_devices.group_id')
                        ->whereNull('u_groups.deleted_at');
                })
                ->where('u_devices.reception_no', $receptionNo)
                ->orderBy('name')
                ->orderBy('device_type')
                ->orderBy('device_no')
                ->get();

            $countRow = $setDevice->count();
            $updateAt = $setDevice->max('updated_at');
            $setGroup = UGroup::where('reception_no', $receptionNo)->orderBy('name')->get();

            return view('U0200.SetDevice')->with([
                'setDevices' => $setDevice,
                'receptionNo' => $receptionNo,
                'setGroups' => $setGroup,
                'updatedAt' => $updateAt,
                'countRow' => $countRow,
            ]);
        } catch (Exception $e) {
            $this->outputLog('機器情報', config('constants.logs.data_insert'), '機器情報にアクセスに失敗しました。', $e);
            abort(500);
        }
    }

    /**
     * 該当する機器情報情報を変更します。
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function store(Request $request)
    {
        // インプットデータを確実する !#$%‘()*+,.:;=?@\[\]^_`{|}\\\~-
        $validator = Validator::make(
            $request->all(),
            [
                'deviceType.*' => ["nullable","regex:/^[a-zA-Z0-9!#$%'()*+,.:;=?@\[\]^_`{|}\\\~-]*$/","required_if:deviceNo.*,NULL","max:20"],
                'deviceNo.*' => ["nullable","regex:/^[a-zA-Z0-9!#$%'()*+,.:;=?@\[\]^_`{|}\\\~-]*$/","required_if:deviceType.*,NULL","max:20"],
                'groupId.*' => 'nullable|integer',
                'receptionNo' => 'required|integer',
                'representFlag' => 'integer',
                'deviceTypeNew.*' => ["nullable","regex:/^[a-zA-Z0-9!#$%'()*+,.:;=?@\[\]^_`{|}\\\~-]*$/","required_if:deviceNoNew.*,NULL","max:20"],
                'deviceNoNew.*' => ["nullable","regex:/^[a-zA-Z0-9!#$%'()*+,.:;=?@\[\]^_`{|}\\\~-]*$/","required_if:deviceTypeNew.*,NULL","max:20"],
            ],
            [
                'deviceType.*.regex' => ':attribute|機種に英数記号以外が含まれています。',
                'deviceTypeNew.*.regex' => ':attribute|機種に英数記号以外が含まれています。',
                'deviceNo.*.regex' => ':attribute|機番に英数記号以外が含まれています。',
                'deviceNoNew.*.regex' => ':attribute|機番に英数記号以外が含まれています。',
                'required_if' => ':attribute|機種、機番のどちらかを入力してください。',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'status' => 'NG',
                'message' => $validator->errors()->all(),
                'data' => [],
            ], 422);
        }
        DB::beginTransaction();
        try {
            $deviceUpdatedAt = UDevice::where('reception_no', $request->receptionNo)->max('updated_at');
            $deviceRowNow = UDevice::where('reception_no', $request->receptionNo)->count();
            if (Carbon::create($deviceUpdatedAt)?->notEqualTo(Carbon::create($request->updatedAt)) || $deviceRowNow < $request->countRow) {
                return response()->json([
                    'status' => 'NG',
                    'message' => '別のユーザーにて既に更新されています。',
                    'data' => [],
                ], 500);
            }

            $meargeArray = array_merge(
                $request->deviceNo != null ? $request->deviceNo : [],
                $request->deviceNoNew != null ? $request->deviceNoNew : []
            );

            $countRemoveDuplicate = count(array_filter(array_unique($meargeArray)));

            $countDeviceno = count(array_filter($meargeArray));

            if ($countRemoveDuplicate != $countDeviceno && $countRemoveDuplicate != 0) {
                return response()->json([
                    'status' => 'NG',
                    'message' => '機番が重複しています。見直してください。',
                    'data' => [],
                ], 500);
            }

            //機器情報を修正する
            if (!empty($request->idUpdate)) {
                $flagCheckLog = 0;
                foreach ($request->idUpdate as $key => $value) {
                    $deviceData = UDevice::where('id', $value)
                        ->where('reception_no', $request->receptionNo)
                        ->first();
                    if (
                        $deviceData->group_id != $request->groupId[$key]
                        || $deviceData->device_type != $request->deviceType[$key]
                        || $deviceData->device_no != $request->deviceNo[$key]
                    ) {
                        if ($flagCheckLog == 0) {
                            $this->outputLog('機器情報入替', config('constants.logs.data_update'), '機器情報を入替しました。');
                            $flagCheckLog = 1;
                        }
                        $deviceData->group_id = $request->groupId[$key];
                        $deviceData->device_type = $request->deviceType[$key];
                        $deviceData->device_no = $request->deviceNo[$key];
                        $deviceData->save();
                    }

                    if ($request->representFlag == $key) {
                        if ($deviceData->represent_flag == false) {
                            if ($flagCheckLog == 0) {
                                $this->outputLog('機器情報入替', config('constants.logs.data_update'), '機器情報を入替しました。');
                                $flagCheckLog = 1;
                            }

                            $checkRepresentFlag = UDevice::where('represent_flag', true)
                                ->where('reception_no', $request->receptionNo)
                                ->first();

                            if ($checkRepresentFlag != null) {
                                $checkRepresentFlag->represent_flag = false;
                                $checkRepresentFlag->save();
                            }
                            $deviceData->represent_flag = true;
                            $deviceData->save();
                        }
                    }
                }
            }

            //機器情報を削除する
            if (!empty($request->idDelete)) {
                DB::table('u_operation_records')
                    ->whereIn('device_id', explode(",", $request->idDelete))
                    ->delete();

                DB::table('u_work_result_details')
                    ->whereIn('device_id', explode(",", $request->idDelete))
                    ->delete();

                DB::table('u_devices')
                    ->where('reception_no', $request->receptionNo)
                    ->whereIn('id', explode(",", $request->idDelete))
                    ->delete();

                $this->outputLog('機器情報削除', config('constants.logs.data_delete'), '機器情報を削除しました。');
            }

            //機器情報を追加する
            if (!empty($request->deviceNoNew)) {
                $data = [];
                foreach ($request->deviceNoNew as $key => $value) {
                    $flagRepresent = false;
                    if ($request->representFlag == $key) {
                        $checkRepresentFlag = UDevice::where('represent_flag', true)
                            ->where('reception_no', $request->receptionNo)
                            ->first();

                        if ($checkRepresentFlag != null) {
                            $checkRepresentFlag->represent_flag = false;
                            $checkRepresentFlag->save();
                        }
                        $flagRepresent = true;
                    }

                    $device = [
                        'reception_no' => $request->receptionNo,
                        'group_id' => $request->groupIdNew[$key],
                        'represent_flag' => $flagRepresent,
                        'device_type' => $request->deviceTypeNew[$key],
                        'device_no' => $value,
                        'created_at' => Carbon::now(),
                        'created_by' => Auth::id(),
                        'updated_at' => Carbon::now(),
                        'updated_by' => Auth::id(),
                    ];
                    array_push($data, $device);
                }

                UDevice::insert($data);
                $this->outputLog('機器情報登録', config('constants.logs.data_insert'), '機器情報を登録しました');
            }
            DB::commit();
            session()->flash('success', '機器情報を正常に更新しました。');
        } catch (Exception $e) {
            DB::rollBack();
            $this->outputLog('機器情報', config('constants.logs.data_insert'), '機器情報画面登録エラー', $e);
            abort(500);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
