<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\L2Reception;

/**
 * 受付基本情報
 * @author  donlq
 * @create_date  2021-10-19
 */
class MainInfoController extends Controller
{
    /**
     * 該当する受付基本情報情報を表示します
     *
     * @param  int  $id
     * @return \Illuminate\Http\Controller
     */
    public function show($no)
    {
        $this->outputLog("受付基本アクセス", config('constants.logs.page_access'), '受付基本にアクセスしました');
        $reception = L2Reception::leftjoin('users', 'users.external_user_id', 'l2_receptions.emp_code')
            ->where('l2_receptions.no', $no)
            ->first();

        if ($reception == null) {
            $this->outputLog('受付基本', config('constants.logs.data_insert'), '受付基本にアクセスに失敗しました。');
            abort(404);
        }

        // 権限チェック
        $this->authorize('view', $reception->reception);

        return view('U0200.MainInfo')->with(['reception' => $reception]);
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
