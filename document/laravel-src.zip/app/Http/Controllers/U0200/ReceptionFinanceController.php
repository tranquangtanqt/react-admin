<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Models\UReception;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ReceptionFinanceController extends Controller
{
    public function show(Request $request, UReception $reception)
    {

        // ログ登録
        $this->createLog();

        // 受付が存在しない時に
        if (!$reception) {
            return abort(404);
        }

        // 権限チェック
        $this->authorize('viewFinance', $reception);

        // 作業報告を取得
        $workReport = $reception->workReport;

        // ADD START 20220414 Ishino OT-016 工数合計を表示する対応
        // 工数合計を取得
        $manHourTotal = $reception?->getTotalManHour() ?? 0;
        // ADD E N D 20220414 Ishino OT-016 工数合計を表示する対応

        // ADD START 20220414 Ishino OT-017 原価合計を表示する対応
        // 原価明細合計を取得
        $costsSum = $reception->costs()->sum('amount');
        // ADD E N D 20220414 Ishino OT-017 原価合計を表示する対応

        // 原価明細を取得
        $costs = $reception->costs()
        ->leftJoin('code_classes', function ($join) {
            $join->on('u_costs.type', 'code_classes.key')
                ->where('code_classes.identifier_code', config('constants.codes.cost'))
                ->whereNull('code_classes.deleted_at');
        })
        ->select('u_costs.*', 'code_classes.value as type_name')
        ->orderby('u_costs.type','asc')
        ->orderby('u_costs.registered_class','asc')
        ->orderby('u_costs.serial_no','asc')
        ->get();

        // 見積明細を取得
        $quotations = $reception->quotations()
        ->get();

        // 見積明細合計を取得
        $quotationSum = $reception->quotations()->sum('amount');

        // モーダル情報をセッションに保存、viewが初期にモーダル表示
        $this->addActiveModalToFlashSession($request);

        return view('U0200.ReceptionFinance', compact([
            'reception',
            'workReport', // 作業報告
            // ADD START 20220414 Ishino OT-016 工数合計を表示する対応
            'manHourTotal', // 工数合計
            // ADD E N D 20220414 Ishino OT-016 工数合計を表示する対応
            // ADD START 20220414 Ishino OT-017 原価明細合計を表示する対応
            'costsSum', // 原価明細合計
            // ADD E N D 20220414 Ishino OT-017 原価明細合計を表示する対応
            'costs', // 原価明細
            'quotations', // 見積明細
            'quotationSum', // 見積明細合計
        ]));
    }

    /**
     * アクティブモーダルIDをセッションに埋め込む
     * @param Request
     * @return void
     */
    private function addActiveModalToFlashSession(Request $request)
    {
        if ($request->isMethod('post') && $request->has('active_modal_id')) {
            session()->flash('active_modal_id', $request->input('active_modal_id'));
        }
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => '受付情報（金額情報タブ）画面アクセス',
            'content' => '受付情報（金額情報タブ）画面をアクセスしました。',
        ]);
    }
}
