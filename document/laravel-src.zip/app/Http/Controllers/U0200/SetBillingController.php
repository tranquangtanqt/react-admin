<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0200\UpdateBillingRequest;
use App\Models\UReception;
use Carbon\Carbon;
use Illuminate\Http\Request;

class SetBillingController extends Controller
{
    public function update(UpdateBillingRequest $request, UReception $reception)
    {

        // 入力バリデーション
        $validated = $request->validated();

        // 別のユーザが更新した場合の制御
        $updateAtFromInput = $validated['updated_at'];
        if (
            $updateAtFromInput &&
            $reception->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))
        ) {
            session()->flash('active_modal_id', 'billing-modal');
            session()->flash('billing_update_error', '別のユーザーにて既に更新されています。');
            return back();
        }

        // 受付情報の請求先更新
        $reception->billing_name = $validated['billing_name'];
        $reception->billing_tel = $validated['billing_tel'];
        $reception->billing_fax = $validated['billing_fax'];
        $reception->save();

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.data_update'),
            'process_name' => '請求先更新',
            'content' => "受付{$reception->no}の請求先を更新しました。",
        ]);

        // 受付情報画面に戻る
        return back();
    }
}
