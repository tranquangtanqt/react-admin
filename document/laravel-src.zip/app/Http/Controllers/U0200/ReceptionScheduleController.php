<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Models\UManHour;
use App\Models\CodeClass;
use App\Models\UReception;
use App\Models\USignature;
use App\Models\UWorkResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class ReceptionScheduleController extends Controller
{
    public function show(Request $request, UReception $reception)
    {
        // アクセスログ登録
        $this->createLog();

        // 権限チェック
        $this->authorize('view', $reception);

        // 受付状態
        $status = $reception->status->status_type;

        // 機器情報,運転記録を取得
        $devices = $reception->devices()
            ->leftjoin('u_operation_records', function ($join) {
                $join->on('u_devices.id', 'u_operation_records.device_id')
                    ->whereNull('u_operation_records.deleted_at');
            })
            ->select('u_operation_records.id as op_record_id')
            ->get();
        $device_cnt = 0;
        $op_record_cnt = 0;
        foreach ($devices as $device) {
            ++$device_cnt;
            if ($device->op_record_id) {
                ++$op_record_cnt;
            }
        }

        // モーダル情報をセッションに保存、viewが初期にモーダル表示
        $this->addActiveModalToFlashSession($request);

        // 訪問予定設定 start --------------------

        // 日程関連のサブクエリ作成
        $scheResultSubQuery = UWorkResult::distinct()->selectRaw("schedule_id, 'あり' as has_result"); // 作業実績の存在
        $scheManHourSubQuery = UManHour::distinct()->selectRaw("schedule_id, 'あり' as has_manhour"); // 工数の存在
        $scheSignSubQuery = USignature::distinct()->selectRaw("schedule_id, 'あり' as has_sign"); // 署名の存在

        // 日程リスト取得
        $schedules = $reception->schedules() // 日程クエリ
            ->leftJoinSub($scheResultSubQuery, 'result', function ($join) {
                $join->on('u_schedules.id', 'result.schedule_id');
            }) // 作業実績の存在
            ->leftJoinSub($scheManHourSubQuery, 'manhour', function ($join) {
                $join->on('u_schedules.id', 'manhour.schedule_id');
            }) // 工数の存在
            ->leftJoinSub($scheSignSubQuery, 'sign', function ($join) {
                $join->on('u_schedules.id', 'sign.schedule_id');
            }) // 署名の存在
            ->select(['u_schedules.id', 'date', 'reception_no', 'content', 'has_result', 'has_manhour', 'has_sign'])
            ->orderBy('date')
            ->with('namedUsers') // ユーザ名含めて
            ->with('labeledSlots') // 時間帯ラベル
            ->get();

        // 訪問予定編集可能か
        $canEditSchedule = $request->user()->can('createOrUpdateSchedule', $reception);

        // 訪問予定設定 end --------------------

        // 充填情報を取得
        $gasIn = $reception->gasIn()
        ->select('u_gas_in_info.*')
        ->leftJoin('code_classes as in_type', function ($join) {
            $join->on('u_gas_in_info.type', 'in_type.key')
                ->where('in_type.identifier_code', config('constants.codes.fill'));
        })
        ->addselect('in_type.value as in_type_name')
        ->leftJoin('code_classes as g_type', function ($join) {
            $join->on('u_gas_in_info.gas_type', 'g_type.key')
                ->where('g_type.identifier_code', config('constants.codes.fill_type'));
        })
        ->addSelect(DB::raw('case u_gas_in_info.gas_type = \'' . config('constants.fill_type.others') . '\' '
            .'when true then u_gas_in_info.gas_type_name else g_type.value end as gas_type_name_edit')) // 充填種類名編集
        ->first();

        // 回収情報を取得
        $gasOut = $reception->gasOut()
        ->select('u_gas_out_info.*')
        ->leftJoin('code_classes as out_type', function ($join) {
            $join->on('u_gas_out_info.type', 'out_type.key')
                ->where('out_type.identifier_code', config('constants.codes.collect'));
        })
        ->addselect('out_type.value as out_type_name')
        ->leftJoin('code_classes as g_type', function ($join) {
            $join->on('u_gas_out_info.gas_type', 'g_type.key')
                ->where('g_type.identifier_code', config('constants.codes.collect_type'));
        })
        ->addSelect(DB::raw('case u_gas_out_info.gas_type = \'' . config('constants.collect_type.others') . '\' '
            .'when true then u_gas_out_info.gas_type_name else g_type.value end as gas_type_name_edit')) // 充填種類名編集
        ->first();

        // 作業報告を取得
        $workReport = $reception->workReport()
            ->select('u_work_reports.*')
            ->leftJoin('code_classes as p_type', function ($join) {
                $join->on('u_work_reports.payment_type', 'p_type.key')
                    ->where('p_type.identifier_code', config('constants.codes.payment'))
                    ->whereNull('p_type.deleted_at');
            })
            ->addselect('p_type.value as payment_type_name')
            ->leftJoin('code_classes as w_type', function ($join) {
                $join->on('u_work_reports.work_type', 'w_type.key')
                    ->where('w_type.identifier_code', config('constants.codes.work'))
                    ->whereNull('w_type.deleted_at');
            })
            ->addselect('w_type.value as work_type_name')
            ->first();

        // 時間帯色取得
        $slotColors = CodeClass::getSlotColors();

        // 時間帯タイトル取得
        $slotTitles = CodeClass::getSlotTitles();

        return view('U0200.ReceptionSchedule', compact([
            'reception', // 受付情報
            'status', // 受付状態
            'device_cnt', // 機器情報カウント
            'op_record_cnt', // 運転記録カウント
            'schedules', // 日程一覧
            'canEditSchedule', // 訪問予定の編集可能か
            'gasIn', // 充填情報
            'gasOut', // 回収情報
            'workReport', // 作業報告
            'slotTitles', // 時間たいタイトル
            'slotColors', // 時間帯色
        ]));
    }

    private function addActiveModalToFlashSession(Request $request)
    {
        if ($request->isMethod('post') && $request->has('active_modal_id')) {
            session()->flash('active_modal_id', $request->input('active_modal_id'));
        }
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => '受付情報（訪問予定・実績）画面アクセス',
            'content' => '受付情報（訪問予定・実績）画面をアクセスしました。',
        ]);
    }
}
