<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\UComment;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Rules\NotInvalidChars;
use Illuminate\Http\JsonResponse;

/**
 * コメント設定
 *
 * @author  donlq
 * @create_date  2021-10-19
 */
class SetCommentController extends Controller
{

    /**
     *  コメントテーブルに変更・新規追加する
     *
     * @param  Request  $request
     * @return JsonResponse
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'comment'              => ['required', new NotInvalidChars(), 'string', 'max:512'],
            'receptionNo'          => 'required_if:id,null',
        ], [
            'required' => ' コメントを入力してください。'
        ], [
            'comment' => 'コメント'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  $validator->errors()->all(),
                'data'      =>  []
            ], 422);
        }

        try {
            if ($request->id == "") {
                //新規でコメント情報を登録します。
                $comment = UComment::create([
                    'reception_no' => $request->receptionNo,
                    'comment' => $request->comment
                ]);
                $comment->save();
                $this->outputLog('コメント登録', config('constants.logs.data_insert'), 'コメントを登録しました');
                session()->flash('success', 'コメントを正常に登録しました。');
            } else {
                //該当するコメント情報を変更します。
                $commentData = UComment::where('id', $request->id)->firstOrFail();
                $commentData->comment = $request->comment;
                $commentData->save();
                $this->outputLog('コメント入替', config('constants.logs.data_update'), 'コメントを入替しました。');
                session()->flash('success', 'コメントを正常に更新しました。');
            }
        } catch (\Exception $e) {
            $this->outputLog('コメント入替', config('constants.logs.data_insert'), 'コメント入替に失敗しました。', $e);
            return response()->json(
                [
                    'status' => 'NG',
                    'message' => '予期せぬエラーが発生しました。',
                    'data' => []
                ],
                500
            );
        }
    }

    /**
     * 該当するコメントを表示します。
     * @param  int  $id
     * @return JsonResponse
     */
    public function show($id)
    {
        try {
            $data = UComment::where('id', $id)->firstOrFail();
            $this->outputLog("コメント画面アクセス", config('constants.logs.page_access'), 'コメント画面にアクセスしました。');
            return response()->json($data->comment);
        } catch (\Exception $e) {
            $this->outputLog('コメント画面アクセス', config('constants.logs.page_access'), 'コメント画面にアクセスさにエラーが発生しました。', $e);
            return response()->json(
                [
                    'status' => 'NG',
                    'message' => '予期せぬエラーが発生しました。',
                    'data' => []
                ],
                500
            );
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
