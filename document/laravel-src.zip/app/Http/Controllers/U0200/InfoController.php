<?php

namespace App\Http\Controllers\U0200;

use App\Models\File;
use App\Models\UPhoto;
use App\Commons\Logger;
use App\Models\UStatus;
use App\Models\UComment;
use App\Models\UReception;
use App\Models\UAttachment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class InfoController extends Controller
{

    /**
     * 受付情報画面表示
     *
     * @return \Illuminate\View\View
     */
    public function show(Request $request, $reception)
    {


        // ログ登録
        $this->outputLog('受付情報（基本情報タブ）画面アクセス', config('constants.logs.page_access'), '受付情報（基本情報タブ）画面をアクセスしました。');

        // 受付情報を取得
        $reception = $this->getReception($reception);

        $pjmgrName = ($reception->person_emp_code) ? $reception->l2_pjmgr_name : $reception->rec_pjmgr_name;
        $pjmgrFileId = $reception->l2_pjmgr_file_id ?? $reception->rec_pjmgr_file_id;

        // 受付が存在しない時に
        if (!$reception) {
            abort(404);
        }

        // 権限チェック
        $this->authorize('view', $reception);

        // L2受付を取得
        $l2Reception = $reception->l2Reception;
        // L2物件を取得
        $l2Object = $reception->l2Object;
        // 受付状態を取得
        $status = $this->getStatus($reception->no);
        // 状態の画像パース
        $statusImagePath = $this->getStatusImagePath($status);

        // 警告状態判定
        $warning = true;
        if ($status->status_type == config('constants.status.completed')) {
            $warning = false; // 受付状態完了の場合は警告なし
        } elseif (!$l2Object) {
            $warning = false; // 物件情報なしの場合は警告なし
        } elseif (!$l2Object->order_cancellation_flag) {
            $warning = false; // 物件情報の受注取消フラグnullの場合は警告なし
        } elseif ($l2Object->order_cancellation_flag == '0') {
            $warning = false; // 物件情報の受注取消フラグが0の場合は警告なし
        }

        // コメントを取得
        $comments = $reception->comments()
            ->select('u_comments.*', 'users.file_id as user_file_id', 'users.name', 'users.short_name')
            ->join('users', function ($join) {
                $join->on('u_comments.created_by', 'users.id')
                    ->whereNull('users.deleted_at');
            })
            ->orderby('id', 'asc')->get();
        // 系統を取得
        $groups = $reception->groups()->orderby('name', 'asc')->get();
        // 機器情報を取得
        $devices = $reception->devices()
            ->select('u_devices.*')
            ->leftjoin('u_groups', function ($join) {
                $join->on('u_devices.group_id', 'u_groups.id')
                    ->whereNull('u_groups.deleted_at');
            })
            ->addselect('u_groups.name as group_name')
            ->orderByRaw(DB::raw('u_groups.name asc nulls first'))
            ->orderby('u_devices.device_no', 'asc')
            ->get();
        //->tosql();
        //dd($devices);
        // 作業報告を取得
        $workReport = $reception->workReport;
        // 添付を取得
        $attachments = $reception->attachments()
            ->join('files', 'files.id', 'u_attachments.file_id')
            ->join('u_receptions', 'u_receptions.no', 'u_attachments.reception_no')
            ->select('u_attachments.*', 'files.title', 'files.public_flag')
            ->where('u_attachments.deleted_at', null)
            ->where('u_receptions.deleted_at', null)
            ->where('files.deleted_at', null)
            ->orderBy('u_attachments.id', 'ASC');
        if (userIsPicExternal()) {
            // $attachments
            $attachments = $attachments->where('files.public_flag', 'true');
        }
        $attachments = $attachments->get();
        // 写真を取得
        $photos = $reception->photos()
            ->join('files', 'files.id', 'u_photos.file_id')
            ->join('u_receptions', 'u_receptions.no', 'u_photos.reception_no')
            ->select('u_photos.*', 'files.thumbnail', 'files.public_flag')
            ->where('u_photos.reception_no', $reception->no)
            ->where('u_photos.deleted_at', null)
            ->where('u_receptions.deleted_at', null)
            ->where('files.deleted_at', null)
            ->orderBy('u_photos.id', 'ASC')
            ->get();

        // 写真最大アップロードサイズ
        $maxFileSize = config('constants.upload_max_size.photo_file');

        // モーダル情報をセッションに保存、viewが初期にモーダル表示
        $this->addActiveModalToFlashSession($request);

        return view('U0200.Info', compact([
            'reception', // 受付情報
            'l2Reception', // L2受付
            'warning', // 警告情報
            'status', // 受付状態
            'statusImagePath', // 状態の画像パース
            'comments', // コメント
            'groups', // 系統
            'devices', // 機器情報
            'workReport', // 作業報告
            'attachments', // 添付
            'photos', // 写真
            'maxFileSize', // 写真最大アップロードサイズ
            'pjmgrName', // 計上担当名
            'pjmgrFileId', // 計上担当ファイルID（プロフィール画像）
        ]));
    }

    /**
     * コメント削除
     */
    public function destroyComment(Request $request, UComment $comment)
    {
        if (!$comment) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  '対象のコメントは存在しません。',
                'data'      =>  []
            ], 404);
        }

        if ($comment->created_by != auth()->user()->id) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  '対象のコメントに対する削除権限がありません。',
                'data'      =>  []
            ], 404);
        }

        DB::beginTransaction();
        try {
            $comment->delete();
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog('コメント削除', config('constants.logs.data_delete'), 'コメントの削除に失敗しました。', $e);
            return response()->json(
                [
                    'status' => 'NG',
                    'message' => '予期せぬエラーが発生しました。',
                    'data' => []
                ],
                500
            );
        }

        // ログ出力
        $this->outputLog('コメント削除', config('constants.logs.data_delete'), 'コメント(' . $comment->id . ')を削除しました。');
        session()->flash('success', 'コメントを正常に削除しました。');
    }

    /**
     * 画像削除
     */
    public function destroyPhoto(Request $request, UPhoto $photo)
    {
        if (!$photo) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  '対象の画像は存在しません。',
                'data'      =>  []
            ], 404);
        }

        DB::beginTransaction();
        try {
            $file = File::findOrFail($photo->file_id);
            $file->forceDelete();

            $photo->forceDelete();
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog('画像削除', config('constants.logs.data_delete'), '画像の削除に失敗しました。', $e);
            return response()->json(
                [
                    'status' => 'NG',
                    'message' => '予期せぬエラーが発生しました。',
                    'data' => []
                ],
                500
            );
        }

        // ログ出力
        $this->outputLog('画像削除', config('constants.logs.data_delete'), '画像(' . $photo->id . ')を削除しました。');
        session()->flash('success', '画像を正常に削除しました。');
    }

    /**
     * 添付ファイル削除
     */
    public function destroyAttachment(Request $request, UAttachment $attachment)
    {
        if (!$attachment) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  '対象の添付ファイルは存在しません。',
                'data'      =>  []
            ], 404);
        }

        DB::beginTransaction();
        try {
            $file = File::findOrFail($attachment->file_id);
            $file->forceDelete();

            $attachment->forceDelete();
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog('添付ファイル削除', config('constants.logs.data_delete'), '添付ファイルの削除に失敗しました。', $e);
            return response()->json(
                [
                    'status' => 'NG',
                    'message' => '予期せぬエラーが発生しました。',
                    'data' => []
                ],
                500
            );
        }

        // ログ出力
        $this->outputLog('添付ファイル削除', config('constants.logs.data_delete'), '添付ファイル(' . $attachment->id . ')を削除しました。');
        session()->flash('success', '添付ファイルを正常に削除しました。');
    }

    /**
     * 添付ファイル更新（公開・非公開）
     */
    public function updateAttachment(Request $request, UAttachment $attachment)
    {
        if (!$attachment) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  '対象の添付ファイルは存在しません。',
                'data'      =>  []
            ], 404);
        }

        // 協力会社の場合
        if (userIsPicExternal()) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  '対象の添付ファイルに対する更新権限がありません。',
                'data'      =>  []
            ], 404);
        }

        DB::beginTransaction();
        try {
            $file = File::findOrFail($attachment->file_id);
            $file->public_flag = !($file->public_flag);
            $file->save();

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog('添付ファイル入替（公開フラグ）', config('constants.logs.data_update'), '添付ファイルの入替に失敗しました。', $e);
            return response()->json(
                [
                    'status' => 'NG',
                    'message' => '予期せぬエラーが発生しました。',
                    'data' => []
                ],
                500
            );
        }

        // ログ出力
        $this->outputLog('添付ファイル入替（公開フラグ）', config('constants.logs.data_update'), '添付ファイル(' . $attachment->id . ')を入替しました。');
        session()->flash('success', '添付ファイルを正常に更新しました。');
    }

    /**
     * 受付情報を取得する
     *
     * @param string $receptionNo
     * @return UReception
     */
    private function getReception(string $receptionNo)
    {
        $reception = UReception::select([
            'u_receptions.no',
            'l2.related_pj_no',
            'pjmgr_user_id',
            'display_user_id',
            'l2.person_emp_code',
            'l2.field_name',
            'l2.field_tel',
            'l2.field_mobile_tel',
            'l2.client_name',
            'l2_pjmgr.name as l2_pjmgr_name', //  L2受付情報の計上担当名
            'rec_pjmgr.name as rec_pjmgr_name', // 受付情報の計上担当名
            'disp_user.name as disp_name',
            'l2_pjmgr.file_id as l2_pjmgr_file_id', //  L2受付情報の計上担当ファイルID
            'rec_pjmgr.file_id as rec_pjmgr_file_id', // 受付情報の計上担当ファイルID
            'disp_user.file_id as disp_file_id',
            'u_receptions.billing_name',
            'u_receptions.billing_tel',
            'u_receptions.billing_fax',
        ])
            ->join('l2_receptions as l2', 'l2.no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->leftJoin('users as rec_pjmgr', function ($join) { // 受付情報担当者ユーザのジョイン
                $join->on('pjmgr_user_id', '=', 'rec_pjmgr.id')
                    ->whereNull('rec_pjmgr.deleted_at');
            })
            ->leftjoin('users as l2_pjmgr', function ($join) { // L2計上担当のジョイン
                $join->on('l2_pjmgr.external_user_id', '=', 'l2.person_emp_code')
                    ->whereNull('l2_pjmgr.deleted_at');
            })
            ->leftJoin('users as disp_user', function ($join) { // ダッシュボード表示ユーザのジョイン
                $join->on('display_user_id', '=', 'disp_user.id')
                    ->whereNull('disp_user.deleted_at');
            })
            ->where('u_receptions.no', $receptionNo)->first();

        return $reception;
    }

    /**
     * 受付状態を取得する
     *
     * @param string $receptionNo
     * @return UStatus
     */
    private function getStatus(string $receptionNo)
    {
        return UStatus::select([
            'reception_no',
            'status_type',
            'status_detail_type',
            'remind_date',
            'remind_memo',
            'canceled_at', // キャンセル状態
            'cc.value as label',
            'ccd.value as detail_label',
        ])
            ->leftJoin('code_classes as cc', function ($join) {
                $join->on('status_type', 'cc.key')
                    ->where('cc.identifier_code', config('constants.codes.status'))
                    ->whereNull('cc.deleted_at');
            })
            ->leftJoin('code_classes as ccd', function ($join) {
                $join->on('status_detail_type', 'ccd.key')
                    ->where('ccd.identifier_code', config('constants.codes.status_detail'))
                    ->whereNull('ccd.deleted_at');
            })
            ->where('reception_no', $receptionNo)->first();
    }

    /**
     * アクティブモーダルIDをセッションに埋め込む
     * @param Request
     * @return void
     */
    private function addActiveModalToFlashSession(Request $request)
    {
        if ($request->isMethod('post') && $request->has('active_modal_id')) {
            session()->flash('active_modal_id', $request->input('active_modal_id'));
        }
    }

    /**
     * 状態の画像パースを取得
     *
     * @param UStatus $status
     * @return string image path
     */
    private function getStatusImagePath(UStatus $status) {

        $imagePaths = [
            config('constants.status.new') =>  asset('/storage/default/status_new.svg'),
            config('constants.status.will_visit') =>  asset('/storage/default/status_will_visit.svg'),
            config('constants.status.visited') =>  asset('/storage/default/status_visited.svg'),
            config('constants.status.on_hold') =>  asset('/storage/default/status_on_hold.svg'),
            config('constants.status.work_done') =>  asset('/storage/default/status_work_done.svg'),
            config('constants.status.checked') =>  asset('/storage/default/status_checked.svg'),
            config('constants.status.completed') =>  asset('/storage/default/status_completed.svg'),
        ];

        return $imagePaths[$status->status_type] ?? '';
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
