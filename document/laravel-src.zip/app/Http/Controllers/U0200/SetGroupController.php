<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\L2Reception;
use App\Models\UDevice;
use App\Models\UGroup;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

/**
 * 系統設定
 *
 * @author  donlq
 * @create_date  2021-10-20
 */
class SetGroupController extends Controller
{
    /**
     * 該当する系統情報を表示します。
     *
     * @param  string  $receptionNo
     * @return \Illuminate\Http\Controller
     */
    public function show($receptionNo)
    {
        $receptionNoCheck = L2Reception::where('no', $receptionNo)->first();
        if (empty($receptionNoCheck)) {
            abort(404);
        }

        // 権限チェック
        $this->authorize('updateGroup', $receptionNoCheck->reception);

        try {
            $setGroup = UGroup::where('reception_no', $receptionNo)->orderBy('name')->get();
            $deliveryDate = L2Reception::where('no', $receptionNo)->first();
            $countRow = $setGroup->count();
            $updateAt = $setGroup->max('updated_at');

            $this->outputLog("系統設定アクセス", config('constants.logs.page_access'), '系統設定にアクセスしました');

            return view('U0200.SetGroup')->with(
                [
                    'setGroups' => $setGroup,
                    'receptionNo' => $receptionNo,
                    'updatedAt' => $updateAt,
                    'countRow' => $countRow,
                    'deliveryDate' => $deliveryDate->delivery_date
                ]
            );
        } catch (\Exception $e) {
            $this->outputLog('系統設定', config('constants.logs.page_access'), '系統設定画面登録エラー', $e);
            abort(500);
        }
    }

    /**
     *該当する系統情報を変更します。
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function store(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name.*' => 'required|max:20',
                'nameNew.*' => 'required|max:20',
                'deliveryDate.*' => 'nullable|date_format:Y/m/d',
                'deliveryDateNew.*' => 'nullable|date_format:Y/m/d'
            ],
            [
                'required' => ':attribute|系統を入力してください。',
                'deliveryDate.*.date_format' => ':attribute|納品日の値が日付として扱えません。',
                'deliveryDateNew.*.date_format' => ':attribute|納品日の値が日付として扱えません。'
            ]
        );

        if ($validator->fails()) {
            return response()
                ->json([
                    'status' => 'NG',
                    'message' => $validator->errors()->all(),
                    'data' => [],
                ], 422);
        }

        DB::beginTransaction();
        try {
            $groupUpdatedAt = UGroup::where('reception_no', $request->receptionNo)->max('updated_at');
            $groupRowNow = UGroup::where('reception_no', $request->receptionNo)->count();

            if (Carbon::create($groupUpdatedAt)?->notEqualTo(Carbon::create($request->updatedAt)) || $groupRowNow < $request->countRow) {
                return response()->json(['status' => 'NG', 'message' => '別のユーザーにて既に更新されています。', 'data' => []], 500);
            }

            if (!empty($request->idUpdate)) {
                $flagCheckLog = 0;
                foreach ($request->idUpdate as $key => $value) {
                    $groupData = UGroup::where('id', $value)->first();

                    $deliveryDateTime = $groupData->delivery_date != null ? date('Y/m/d', strtotime($groupData->delivery_date)) : null;

                    if ($groupData->name != $request->name[$key] || $deliveryDateTime != $request->deliveryDate[$key]) {
                        if ($flagCheckLog == 0) {
                            $this->outputLog('系統設定入替', config('constants.logs.data_update'), '系統設定を入替しました。');
                            $flagCheckLog = 1;
                        }
                        $groupData->name = $request->name[$key];
                        $groupData->delivery_date = $request->deliveryDate[$key];
                        $groupData->save();
                    }
                }
            }

            if (!empty($request->idDelete)) {
                UDevice::where('reception_no', $request->receptionNo)
                    ->whereIn('group_id', explode(",", $request->idDelete))
                    ->update(['group_id' => NULL]);

                DB::table('u_groups')
                    ->where('reception_no', $request->receptionNo)
                    ->whereIn('id', explode(",", $request->idDelete))
                    ->delete();
                $this->outputLog('系統設定削除', config('constants.logs.data_delete'), '系統設定を削除しました。');
            }
            if (!empty($request->nameNew)) {
                $data = [];
                foreach ($request->nameNew as $key => $value) {
                    $group = [
                        'reception_no' => $request->receptionNo,
                        'name' => $value,
                        'delivery_date' => $request->deliveryDateNew[$key],
                        'created_at' => Carbon::now(),
                        'created_by' => Auth::id(),
                        'updated_at' => Carbon::now(),
                        'updated_by' => Auth::id(),
                    ];
                    array_push($data, $group);
                }

                UGroup::insert($data);

                $this->outputLog('系統設定登録', config('constants.logs.data_insert'), '系統設定を登録しました');
            }

            DB::commit();

            session()->flash('success', '系統を正常に設定しました。'); // 成功メッセージ

        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog('系統設定', config('constants.logs.data_insert'), '系統設定画面登録エラー', $e);
            return response()->json([
                'status' => 'NG',
                'message' => '予期せぬエラーが発生しました。',
                'date' => [],
            ], 500);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
