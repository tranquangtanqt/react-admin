<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Models\UReception;
use App\Models\UWorkReport;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0200\UpdateRemarkRequest;
use Illuminate\Support\Carbon;

class SetRemarkController extends Controller
{
    public function updateRemark(UpdateRemarkRequest $request, UReception $reception)
    {

        // 入力バリデーション
        $validated = $request->validated();

        if (!$reception->workReport) {
            // 作業報告は存在しない場合、し登録
            UWorkReport::create([
                'reception_no' => $reception->no,
                'remark' => $validated['remark'],
            ]);

            // ログ登録
            Logger::create([
                'user_id' => auth()->user()->id,
                'process_type' => config('constants.logs.data_insert'),
                'process_name' => '備考登録',
                'content' => "受付{$reception->no}のお客様向け備考を登録しました。",
            ]);
        } else {

            $workReport = $reception->workReport;

            // 別のユーザが更新した場合の制御
            $updateAtFromInput = $validated['updated_at'];
            if (
                $updateAtFromInput &&
                $workReport->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))
            ) {
                session()->flash('active_modal_id', 'remark-modal');
                session()->flash('remark_update_error', '別のユーザーにて既に更新されています。');
                return back();
            }

            // 作業報告の備考更新
            $workReport->remark = $validated['remark'];
            $workReport->save();

            // ログ登録
            Logger::create([
                'user_id' => auth()->user()->id,
                'process_type' => config('constants.logs.data_update'),
                'process_name' => '備考更新',
                'content' => "受付{$reception->no}のお客様向け備考を更新しました。",
            ]);
        }

        // 受付情報画面に戻る
        return back();
    }
}
