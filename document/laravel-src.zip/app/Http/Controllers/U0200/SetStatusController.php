<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0200\UpdateStatusRequest;
use App\Models\CodeClass;
use App\Models\UReception;
use App\Models\USchedule;
use App\Models\User;
use App\Models\UStatus;
use App\Traits\StatusChange;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class SetStatusController extends Controller
{

    use StatusChange;

    /**
     * 受付状態変更画面表示
     *
     * @return \Illuminate\View\View
     */
    public function edit(Request $request, UStatus $status)
    {
        // ログ登録
        $this->createLog($status->reception_no, 'access');

        // 更新権限
        $canUpdate = $request->user()->can('update', $status);

        // 引き戻し権限
        $canRestore = $request->user()->can('restore', $status);

        // 更新または引き戻し権限がない場合
        if (!$canUpdate && !$canRestore) {
            // ログ登録
            $this->createLog($status->reception_no, 'access', 'error', ['content_detail' => '更新または引き戻し権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        // 変更可能な受付状態パターンを取得
        $mutableStates = $this->getMutationStates($status);

        // 受付状態区分(変更可能な区分)
        $statuses = CodeClass::getStatuses($mutableStates->toArray());

        // 保留あるか
        $containsOnHold = $statuses->where('key', config('constants.status.on_hold'))->count() > 0;

        // 作業完了あるか
        $containsWorkDone = $statuses->where('key', config('constants.status.work_done'))->count() > 0;

        // キャンセルinputを有効にするか (作業完了状態が選択肢に入りかつ現場の状態は作業完了じゃない)
        $activateCancelInput = $containsWorkDone && $status->status_type != config('constants.status.work_done');

        // キャンセルされたか
        $isCanceled = !empty($status->canceled_at);

        // 受付状態詳細区分(全て)
        $statusDetails = CodeClass::getStatusDetails();

        // ビューためのネイミング
        $currentStatus = $status;

        return view('U0200.SetStatus', compact([
            'currentStatus', // 受付情報の状態
            'statuses', // 受付状態区分（変更可能な区分）
            'statusDetails', // 受付状態詳細区分（全て）
            'canUpdate', // 更新権限
            'canRestore', // 引き戻し権限
            'containsOnHold', // 保留選択肢があるか
            'containsWorkDone', // 作業完了選択肢があるか
            'activateCancelInput', // キャンセルinputを有効にするか
            'isCanceled', // キャンセルされたか
        ]));
    }

    /**
     * 受付状態更新
     *
     * @return json
     */
    public function update(UpdateStatusRequest $request, UStatus $status)
    {
        // 更新権限
        $canUpdate = $request->user()->can('update', $status);

        // 更新権限がない場合
        if (!$canUpdate) {
            // ログ登録
            $this->createLog($status->reception_no, 'update', 'error', ['content_detail' => '更新権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '更新権限がありません。']), 403);
        }

        // バリデーション結果
        $validData = $request->validated();

        // 別のユーザが更新した場合
        $updateAtFromInput = $validData['updated_at'];
        if (
            $updateAtFromInput &&
            $status->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))
        ) {
            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '別のユーザにて既に更新されています。']), 422);
        }

        // トランザクション開始
        DB::beginTransaction();
        try {

            // 現在の状態
            $currentStatusType = $status->status_type;
            // 新状態（画面より）
            $newStatusType = $validData['status_type'];

            // 訪問予定から作業完了の時、訪問予定をクリアする
            if (
                $currentStatusType === config('constants.status.will_visit') &&
                $newStatusType === config('constants.status.work_done')
            ) {
                // 入力チェック済以外の日程を取得し、削除する
                $schedules = $status->reception->incompleteSchedules;
                if ($schedules->isNotEmpty()) {
                    USchedule::whereIn('id', $schedules->pluck('id'))->delete();
                }
            }

            // 状態が変更されるか？
            $statusIsChanged = $currentStatusType != $newStatusType;

            // 受付状態が変わる場合履歴を作成
            if ($statusIsChanged) {
                $status->addToHistory();
            }

            // 状態区分
            $status->status_type = $newStatusType;

            // 作業完了に変更されて、かつキャンセルがチェックされる場合
            if ($statusIsChanged &&
                $newStatusType === config('constants.status.work_done')
                && isset($validData['cancel'])
            ) {

                $reception = $status->reception;

                // 計上担当をチェック
                $effPjMgr = $reception->eff_pjmgr_id;

                // 計上担当が未設定の場合設定する
                if (!$effPjMgr) {

                    // コード区分よりデフォルトキャンセル計上担当のログインIDを取得
                    $defautlPjMgrLoginId = CodeClass::getDefaultCancelPjMgrLoginId();

                    // デフォルトの計上担当ユーザを取得
                    $defautlPjMgrUser = $defautlPjMgrLoginId ? User::firstWhere('login_id', $defautlPjMgrLoginId) : null;

                    // 受付計上担当を更新する
                    if ($defautlPjMgrUser) {
                        $reception->pjmgr_user_id = $defautlPjMgrUser->id;
                        $reception->save();
                    }
                }

                $status->canceled_at = now();
            }

            //保留なのか？
            $inOnHold = $status->status_type === config('constants.status.on_hold');

            // 状態詳細区分
            $status->status_detail_type = $inOnHold ? $validData['status_detail_type'] : null;

            // リマインド日付
            $status->remind_date = $inOnHold ? $validData['remind_date'] : null;

            // リマインドメモ
            $status->remind_memo = $inOnHold ? $validData['remind_memo'] : null;

            // 保存
            $status->save();

            // コミット
            DB::commit();

            // ログ登録
            $this->createLog($status->reception_no, 'update');

            // 成功メッセージ
            session()->flash('success', '受付状態を正常に更新しました。');
            session()->reflash(); // 次のリクエストにてフラッシュメッセージが残るように

            // 成功メッセージ返す
            return response()->json(['success' => '受付状態を正常に更新しました。'], 200);
        } catch (Exception $e) {

            // ロルバック
            DB::rollBack();

            // ログ登録
            $this->createLog($status->reception_no, 'update', 'error', ['content_detail' => $e]);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '受付状態の更新に失敗しました。再度更新してください。']), 500);
        }
    }

    /**
     * 受付状態引き戻し
     *
     * @return json
     */
    public function restore(Request $request, UStatus $status)
    {
        // 引き戻し権限
        $canRestore = $request->user()->can('restore', $status);

        // 引き戻し権限がない場合
        if (!$canRestore) {
            // ログ登録
            $this->createLog($status->reception_no, 'update', 'error', ['content_detail' => '引き戻し権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '引き戻し権限がありません。']), 403);
        }

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'updated_at' => 'required|date',
        ], );

        // バリデーション失敗の時
        if ($validator->fails()) {
            return response()->json(addMessages(['general_error_message' => '予期せぬエラーが発生しました。']), 422);
        }

        // バリデーション結果
        $validData = $validator->validated();

        // 別のユーザが更新した場合の制御
        $updateAtFromInput = $validData['updated_at'];
        if (
            $updateAtFromInput &&
            $status->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))
        ) {
            return response()->json(addMessages(['general_error_message' => '別のユーザーにて既に更新されています。']), 500);
        }

        // トランザクション開始
        DB::beginTransaction();
        try {

            // 現在の状態
            $currentStatusType = $status->status_type;
            // 最新履歴状態
            $lastStatusType = $status->latestHistory->status_type;

            // 履歴より復活する
            $status = $status->restoreFromHistory();

            //作業完了から訪問予定への時、保留にする
            if (
                $currentStatusType === config('constants.status.work_done') &&
                $lastStatusType === config('constants.status.will_visit')
            ) {
                // 状態区分を保留にする
                $status->status_type = config('constants.status.on_hold');

                // 状態詳細区分
                $status->status_detail_type = config('constants.status_detail.self_scheduling');

                // リマインド日付
                $status->remind_date = null;

                // リマインドメモ
                $status->remind_memo = null;

                // テーブルに保存
                $status->save();
            }

            // コミット
            DB::commit();

            // 成功メッセージ
            session()->flash('success', '受付状態を正常に引き戻ししました。');
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // ログ登録
            $this->createLog($status->reception_no, 'update');

            // 成功メッセージ返す
            return response()->json(['success' => '受付状態を正常に引き戻ししました。'], 200);
        } catch (Exception $e) {

            // ロルバック
            DB::rollBack();

            // ログ登録
            $this->createLog($status->reception_no, 'update', 'error', ['content_detail' => $e]);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '受付状態の引き戻しに失敗しました。再度更新してください。']), 500);
        }
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $receptionNo,
        string $mode,
        string $status = 'success',
        array $options = ['content_detail' => null]
    ) {
        // $modeは'access', 'update'のみ
        if (!collect(['access', 'update'])->contains($mode)) {
            throw new Exception("Only 'access' or 'update' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        // ログタイプ
        $types = [
            'access' => config('constants.logs.page_access'),
            'update' => config('constants.logs.data_update'),
        ];

        // 処理名
        $names = [
            'access' => '受付状態設定画面アクセス',
            'update' => '受付状態更新',
        ];

        // 内容
        $contents = [
            'access' => [
                'success' => "受付{$receptionNo}の状態設定画面をアクセスしました。",
                'error' => "受付{$receptionNo}の状態設定画面のアクセスに失敗しました。",
            ],
            'update' => [
                'success' => "受付{$receptionNo}の状態更新に成功しました。",
                'error' => "受付{$receptionNo}の状態更新に失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'],
        ]);
    }
}
