<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\File;
use App\Models\UPhoto;
use App\Models\UReception;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
/**
 * 画像一覧画面
 */
class ImageListController extends Controller
{
    /**
     * 画像一覧画面を表示する
     */
    public function index($receptionNo){
        $reception = UReception::findOrFail($receptionNo);

        // 権限チェック
        $this->authorize('view', $reception);

        $photos = DB::table('u_photos')
            ->join('files', 'files.id', 'u_photos.file_id')
            ->join('u_receptions', 'u_receptions.no', 'u_photos.reception_no')
            ->select('u_photos.*', 'files.thumbnail', 'files.public_flag')
            ->where('u_photos.reception_no', $receptionNo)
            ->where('u_photos.deleted_at', null)
            ->where('u_receptions.deleted_at', null)
            ->where('files.deleted_at', null)
            ->orderBy('u_photos.id', 'DESC')
            ->get();

        $maxFileSize = config('constants.upload_max_size.photo_file');

        // ログ出力
        $this->outputLog('画像一覧画面アクセス',
                        config('constants.logs.page_access'),
                        '画像一覧画面にアクセスしました。');

        return view('U0200.ImageList', compact([
            'photos', 'receptionNo', 'maxFileSize', 'reception',
        ]));
    }

    /**
     * 新規で画像情報を登録します。
     */
    public function store(Request $request){
        $receptionNo = $request->u0208ReceptionNo;
        $backUrl = $request->u0208BackUrl;
        $flash="success";
        if($backUrl==""){
            $backUrl=route('image-list.index', ['reception' => $receptionNo]);
            $flash="message";
        }

        try {
            DB::beginTransaction();
            $fileRequest = $request->file('u0208File');

            $filename = $fileRequest->getClientOriginalName();
            $imageResize = Image::make($fileRequest->getRealPath());
            $imageResize->resize(300, 300)->orientate();
            $strImageResize = (string) $imageResize->encode('data-url');
            $strImageResize = preg_replace('/^data:image\/\w+;base64,/', '', $strImageResize);

            //$fileContent = base64_encode(file_get_contents($fileRequest->getRealPath()));
            $fileBase = Image::make($fileRequest->getRealPath());
            $fileBase->orientate();
            $strFileBase = (string) $fileBase->encode('data-url');
            $fileContent = preg_replace('/^data:image\/\w+;base64,/', '', $strFileBase);

            $file = new File();
            $file->name = $filename;
            $file->file = $fileContent;
            $file->thumbnail = $strImageResize;
            $file->public_flag = true;
            $file->save();

            $attachment = new UPhoto();
            $attachment->reception_no = $receptionNo;
            $attachment->file_id = $file->id;
            $attachment->save();

            // ログ出力
            $this->outputLog('画像情報登録',
                            config('constants.logs.data_insert'),
                            '画像情報を登録しました。');

            DB::commit();
            $request->session()->flash($flash, '正常に登録しました。');
            return redirect($backUrl);
        } catch (\Exception $e) {
            DB::rollBack(); // ロールバック
            // ログ登録
            $this->outputLog('画像情報',
                            config('constants.logs.data_insert'),
                            '画像情報の登録に失敗しました。',
                            $e);
        }
    }

    /**
     *  該当する画像情報を削除します。
     */
    public function delete($reception, $id){
        try {
            DB::beginTransaction();
            $photo = UPhoto::findOrFail($id);
            $photo->delete();

            $file = File::findOrFail($photo->file_id);
            $file->delete();

            // ログ出力
            $this->outputLog('画像情報削除',
                            config('constants.logs.data_delete'),
                            '画像情報を削除しました。');

            DB::commit();
            return redirect()->route('image-list.index', ['reception' => $reception])->with("message", "正常に削除しました。");
        } catch (\Exception $e) {
            DB::rollBack(); // ロールバック
            // ログ登録
            $this->outputLog('画像情報',
                            config('constants.logs.data_delete'),
                            '画像情報の削除に失敗しました。',
                            $e);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
