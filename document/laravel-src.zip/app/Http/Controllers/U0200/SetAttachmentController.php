<?php

namespace App\Http\Controllers\U0200;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\File;
use App\Models\UAttachment;
use App\Models\UReception;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * 添付ファイル設定
 */
class SetAttachmentController extends Controller
{
    /**
     *  該当する添付情報を表示します。
     */
    public function create($receptionNo){
        $reception = UReception::findOrFail($receptionNo);

        // 権限チェック
        $this->authorize('updateAttachment', $reception);

        $file = new File();

        $maxFileSize = config('constants.upload_max_size.attached_file');

        // ログ出力
        $this->outputLog('添付ファイル設定',
                        config('constants.logs.page_access'),
                        '添付ファイル設定にアクセスしました。');

        return view('U0200.SetAttachment', compact([
            'file', 'receptionNo', 'maxFileSize'
        ]));
    }

    /**
     * 新規で添付情報を登録します。
     */
    public function store(Request $request){
        $receptionNo = $request->receptionNo;

        try {
            DB::beginTransaction();

            $fileRequest = $request->file('file');
            $filename = $fileRequest->getClientOriginalName();
            /*
            $fileContent = base64_encode(file_get_contents($fileRequest->getRealPath()));

            $file = new File();
            $file->title = $request->title;
            $file->name = $filename;
            $file->file = $fileContent;
            $file->public_flag = false;
            $file->save();
            */

            $tmp_path = $fileRequest->getRealPath(); // 実画像のパスを取得
            $fp = fopen($tmp_path, 'rb'); // 画像ファイルのファイルポインタ取得
            $db = DB::getPdo();
            $title=$request->title;
            $userid=Auth::id();
            $date=Carbon::now();
            $publicFlag = userIsPicExternal() ? 1 : 0; // 協力会社の場合公開する
            $stmt = $db->prepare("INSERT INTO files (file,name,title,public_flag,created_by,updated_by,created_at,updated_at) VALUES (:file,:name,:title,:publicFlag,:userid,:userid,:date,:date)");
            $stmt->bindParam(':file', $fp, $db::PARAM_LOB);
            $stmt->bindParam(':name', $filename);
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':publicFlag', $publicFlag);
            $stmt->bindParam(':userid', $userid);
            $stmt->bindParam(':date', $date);
            $stmt->execute();
            $file_id=$db->lastInsertId();
            unset($db);

            $attachment = new UAttachment();
            $attachment->reception_no = $receptionNo;
            //$attachment->file_id = $file->id;
            $attachment->file_id = $file_id;
            $attachment->save();

            // ログ出力
            $this->outputLog('添付ファイル登録',
                            config('constants.logs.data_insert'),
                            '添付ファイルを登録しました。');

            DB::commit();
            return redirect()->route('receptions.show', ['reception' => $receptionNo])->with("message", "正常に登録しました。");
        } catch (\Exception $e) {
            DB::rollBack(); // ロールバック
            // ログ登録
            $this->outputLog('添付ファイル', config('constants.logs.data_insert'),
                            '添付ファイルの登録に失敗しました。',$e);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
