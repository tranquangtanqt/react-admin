<?php

namespace App\Http\Controllers\U0200;

use Exception;
use App\Models\User;
use App\Commons\Logger;
use App\Models\UReception;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class SetProjectManagerController extends Controller
{

    /**
     * 計上担当者設定画面表示
     *
     * @return \Illuminate\View\View
     */
    public function edit(Request $request, string $reception)
    {
        // ログ登録
        $this->createLog($reception, 'access');

        // 受付情報を取得
        $reception = $this->getReception($reception);

        // 受付が存在しない時
        if (!$reception) {
            // ログ登録
            $this->createLog($reception, 'access', 'error');
            abort(404);
        }

        // 更新権限
        $canUpdate = request()->user()->can('updateProjectManager', $reception);

        // 更新または引き戻し権限がない場合
        if (!$canUpdate) {
            // ログ登録
            $this->createLog($reception, 'access', 'error', ['content_detail' => '更新権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general-message' => '更新権限がありません。']), 403);
        }

        // 計上担当者ユーザ
        $pjmgrUsers = $this->getPjmgrUsers();

        // ダッシュボード表示ユーザ
        $displayUsers = $this->getDisplayUsers();

        // 計上担当設定済か
        $existPjmgr = false;
        // L2計上担当設定済か
        $existL2Pjmgr = false;
        // 計上担当者ユーザID
        $pjmgrId = $reception->pjmgr_user_id;
        $pjmgrFileId = $reception->rec_pjmgr_file_id;

        // 受付情報およびL２受付情報の計上担当が未設定の場合
        if (!$reception->pjmgr_user_id && !$reception->person_emp_code) {
            $pjmgrName = '計上担当未定';
            $pjmgrShortName = '未定';
        } else {
            $existPjmgr = true; // 計上担当設定済か

            // L２受付情報の計上担当が設定済の場合
            if ($reception->person_emp_code) {
                $existL2Pjmgr = true; // L2計上担当設定済か
                $pjmgrId = $reception->person_emp_code;
                $pjmgrName = $reception->l2_pjmgr_name ?? 'ー';
                $pjmgrShortName = $reception->l2_pjmgr_short_name ?? 'ー';
                $pjmgrFileId = $reception->l2_pjmgr_file_id;
            } elseif ($reception->pjmgr_user_id) { // 受付情報の計上担当が設定済の場合
                $pjmgrName = $reception->rec_pjmgr_name ?? 'ー';
                $pjmgrShortName = $reception->rec_pjmgr_short_name ?? 'ー';
            }
        }


        return view('U0200.SetProjectManager', compact([
            'reception', // 受付情報
            'pjmgrUsers', // 計上担当者ユーザ
            'displayUsers', // ダッシュボード表示ユーザ
            'existPjmgr', // 計上担当設定済か
            'pjmgrName', // 計上担当者名
            'pjmgrShortName', // 計上担当者名
            'existL2Pjmgr', // L2計上担当設定済
            'pjmgrId', // 計上担当者のユーザID（L2設定の場合'l2'に)
            'pjmgrFileId', // 計上担当者のFileID
        ]));
    }

    /**
     * 計上担当者設定処理
     *
     * @return \Illuminate\View\View
     */
    public function update(Request $request, UReception $reception)
    {

        // 更新権限
        $canUpdate = request()->user()->can('updateProjectManager', $reception);

        // 更新または引き戻し権限がない場合
        if (!$canUpdate) {
            // ログ登録
            $this->createLog($reception, 'update', 'error', ['content_detail' => '更新権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general-message' => '更新権限がありません。']), 403);
        }

        // 受付状態
        $status = $reception->status->status_type;

        // 新規の場合のみpjmgr-user-isを未設定に可能
        $pjMgrUserIdRule = $status == config('constants.status.new') ? 'nullable' : 'required';

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'pjmgr-user-id' => $pjMgrUserIdRule,
            'display-user-id' => '',
            'updated_at' => 'required|date',
        ], [
            'pjmgr-user-id.required' => '計上担当を設定してください。',
            'updated_at.required' => '予期せぬエラーが発生しました。',
            'updated_at.date' => '予期せぬエラーが発生しました。',
        ]);

        // バリデーション失敗の時
        if ($validator->fails()) {
            return response()->json(
                $validator->errors(),
                422
            );
        }

        // バリデーション結果
        $validData = $validator->validated();

        // 別のユーザが更新した場合の制御
        $updateAtFromInput = $validData['updated_at'];
        if (
            $updateAtFromInput &&
            $reception->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))
        ) {
            return response()->json(['general-message' => '別のユーザーにて既に更新されています。'], 500);
        }

        // 計上担当者更新
        if (!$reception->l2Reception->person_emp_code) {
            $reception->pjmgr_user_id = $validData['pjmgr-user-id'];
        }

        // ダッシュボード表示ユーザ更新
        $reception->display_user_id = $validData['display-user-id'];

        try {
            // DB更新
            $reception->save();

            // ログ登録
            $this->createLog($reception->no, 'update');

            // 成功メッセージ
            session()->flash('success', '計上担当者を正常に更新しました。');
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // 成功メッセージ返す
            return response()->json(['success' => '計上担当者を正常に更新しました。'], 200);
        } catch (Exception $e) {

            // ログ登録
            $this->createLog($reception->no, 'update', 'error', ['content_detail' => $e]);

            // エラーメッセージ返す
            return response()->json(['general-message' => '計上担当者の更新に失敗しました。再度更新してください。'], 500);
        }
    }

    /**
     * 計上担当ユーザ取得
     *
     * @return User
     */
    private function getPjmgrUsers()
    {
        return User::whereHas('auths', function ($query) { // 担当権限持っている
            $query->whereIn('auth_class', [
                config('constants.auth.pic'),
            ]);
        })
            ->orderBy('short_name')
            ->get();
    }

    /**
     * ダッシュボード表示ユーザ取得
     *
     * @return User
     */
    private function getDisplayUsers()
    {
        return User::whereHas('auths', function ($query) { // 入力支援権限持っている
            $query->whereIn('auth_class', [
                config('constants.auth.input_support'),
            ]);
        })
            ->orderBy('short_name')
            ->get();
    }

    /**
     * 受付情報を取得する
     *
     * @param string $receptionNo
     * @return UReception
     */
    private function getReception(string $receptionNo)
    {
        return UReception::select([
            'u_receptions.no',
            'pjmgr_user_id', // 計上担当者ユーザID
            'display_user_id', // ダッシュボード表示ユーザID
            'l2.person_emp_code', // L2計上担当ユーザコード
            'l2_pjmgr.name as l2_pjmgr_name', //  L2受付情報の計上担当名
            'l2_pjmgr.short_name as l2_pjmgr_short_name', //  L2受付情報の計上担当省略名
            'rec_pjmgr.name as rec_pjmgr_name', // 受付情報の計上担当名
            'rec_pjmgr.short_name as rec_pjmgr_short_name', // 受付情報の計上担当省略名
            'disp_user.name as disp_name', // ダッシュボード表示ユーザ名
            'disp_user.short_name as disp_short_name', // ダッシュボード表示ユーザ省略名
            'l2_pjmgr.file_id as l2_pjmgr_file_id', //  L2受付情報の計上担当省ファイルID
            'rec_pjmgr.file_id as rec_pjmgr_file_id', // 受付情報の計上担当ファイルID
            'disp_user.file_id as disp_file_id', // ダッシュボード表示ユーザ省ファイルID
            'u_receptions.updated_at', // 更新日時
        ])
            ->join('l2_receptions as l2', 'l2.no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->leftJoin('users as rec_pjmgr', function ($join) { // 受付情報担当者ユーザのジョイン
                $join->on('pjmgr_user_id', '=', 'rec_pjmgr.id')
                    ->whereNull('rec_pjmgr.deleted_at');
            })
            ->leftjoin('users as l2_pjmgr', function ($join) { // L2計上担当のジョイン
                $join->on('l2_pjmgr.external_user_id', '=', 'l2.person_emp_code')
                    ->whereNull('l2_pjmgr.deleted_at');
            })
            ->leftJoin('users as disp_user', function ($join) { // ダッシュボード表示ユーザのジョイン
                $join->on('display_user_id', '=', 'disp_user.id')
                    ->whereNull('disp_user.deleted_at');
            })
            ->where('u_receptions.no', $receptionNo)->first();
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $receptionNo,
        string $mode,
        string $status = 'success',
        array $options = ['content_detail' => null]
    ) {
        // $modeは'access', 'update'のみ
        if (!collect(['access', 'update',])->contains($mode)) {
            throw new Exception("Only 'access', 'update', or 'insert' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        $types = [
            'access' => config('constants.logs.page_access'),
            'update' => config('constants.logs.data_update'),
        ];

        $names = [
            'access' => '受付計上担当設定画面アクセス',
            'update' => '受付計上担当更新',
        ];

        $contents = [
            'access' => [
                'success' => "受付{$receptionNo}の計上担当設定画面をアクセスしました。",
                'error' => "受付{$receptionNo}の計上担当設定画面のアクセスに失敗しました。",
            ],
            'update' => [
                'success' => "受付{$receptionNo}の計上担当更新に成功しました。",
                'error' => "受付{$receptionNo}の計上担当更新に失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'],
        ]);
    }
}
