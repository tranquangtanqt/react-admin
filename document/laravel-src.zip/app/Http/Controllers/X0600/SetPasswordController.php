<?php

namespace App\Http\Controllers\X0600;

use Exception;
use App\Commons\Logger;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\X0600\UpdatePasswordRequest;

class SetPasswordController extends Controller
{
    /**
     * パスワード設定画面表示
     *
     * @return view
     */
    public function edit()
    {
        $this->createLog('access');

        return view('X0600.SetPassword');
    }

    /**
     * パスワード設定処理
     *
     * @return view
     */
    public function update(UpdatePasswordRequest $request)
    {
        $validVata = $request->validated();

        $user = auth()->user();
        $user->password = $validVata['new_password'];

        try {
            $user->save();

            session()->flash('success', 'パスワードを正常に変更しました。');

            $this->createLog('update', 'success');

            return redirect()->route('dashboard');

        } catch (Exception $e) {

            $this->createLog('update', 'error', ['content_detail' => $e]);

            return back();
        }
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $mode,
        string $status = 'success',
        array $options = ['content_detail' => null]
    ) {

        // $modeは'access'のみ
        if (!collect(['access', 'update'])->contains($mode)) {
            throw new Exception("Only 'access' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        $types = [
            'access' => config('constants.logs.page_access'),
            'update' => config('constants.logs.data_update'),
        ];

        $names = [
            'access' => 'パスワード変更画面アクセス',
            'update' => 'パスワード更新',
        ];

        $contents = [
            'access' => [
                'success' => "パスワード変更画面にアクセスしました。",
                'error' => "パスワード変更画面のアクセスに失敗しました。",
            ],
            'update' => [
                'success' => "パスワード更新に成功しました。",
                'error' => "パスワード更新に失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'] ?? null,
        ]);
    }
}
