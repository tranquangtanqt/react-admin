<?php

namespace App\Http\Controllers\X0600;

use App\Http\Controllers\Controller;
use App\Http\Requests\X0600\ImageUploadRequest;
use App\Models\File;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Commons\Logger;
use Illuminate\Support\Facades\DB;

class SetUserInfoController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = 'ユーザー情報処理';

    /**
     * ユーザー情報設定画面表示
     *
     * @return view
     */
    public function edit()
    {
        // ログ出力
        $this->outputLog(config('constants.logs.page_access'),'ユーザー情報設定画面にアクセスしました。');

        $id = Auth::user()->id;
        $user = User::join('files','files.id','=','users.file_id')
                    ->where('users.id',$id) -> first();
        return view('X0600.SetUserInfo',compact('user')) ;
    }

    /**
     * 該当するユーザー情報を変更します。
     *
     */
    public function update(ImageUploadRequest $request)
    {
        $file = $request->file('file');
        // MBをBytesに変換する。
        $maxUploadSize = config('constants.upload_max_size.photo_file')*1048576;
        $fileSize = filesize($file);

        if( $fileSize <= 0){
            return back()->withInput()->withErrors(['file'=>"ファイルサイズが0バイトのファイルはアップロードできません。"]);
        }
        // 最大サイズのアップロードファイルを確認してください
        if($fileSize > $maxUploadSize){
           $message = "アップロードファイルの上限を超えるため、登録できません。（最大".config('constants.upload_max_size.photo_file')."MB）";
           return back()->withErrors(['file'=>$message]);
        }

        // アップロードファイル情報を取得する
        $filename = $file->getClientOriginalName();
        $data = file_get_contents($file->getRealPath());
        $base64 = base64_encode($data);

        DB::beginTransaction();
        try{
            $this->processName = 'プロフィール画像を登録';
            // 新しいファイルを作成する
            $newFile = File::create([
                'file' => $base64,
                'name' => $filename,
                'public_flag'=> true,
            ]);
            // ログ出力
            $this->outputLog(config('constants.logs.data_insert'),'プロフィール画像を登録しました。');

            $this->processName = 'プロフィール画像を入替';
            // アイコンを変更
            $user =  User::where("id",Auth::user()->id)->first();
            $oldFileId =  $user->file_id;
            $user->file_id = $newFile->id;
            $user->save();

            DB::table('files')->where('id', $oldFileId)->delete();
            // ログ出力
            $this->outputLog(config('constants.logs.data_update'),'プロフィール画像を入替しました。');
            DB::commit();
            return back()->with('success','プロフィール画像を変更しました。');
        } catch (\Exception $e) {
            // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_update'),'プロフィール画像をの入替に失敗しました。', $e);
            // 作業実績情報画面に遷移する
            return back();
        }
    }

    /**
     *該当するアイコン情報を削除します。
     *
     */
    public function delete()
    {
        DB::beginTransaction();
        try{
            $id = Auth::user()->id;
            $user =  User::where("id",$id)->first();
            if($user->file_id == null){
               return response()->json(['status' => 'NG'], 422);
            }
            $this->processName = "プロフィール画像を削除";
            $oldFileId =  $user->file_id;
            $user->file_id = null;
            $user->save();
            // アイコンを変更
            DB::table('files')->where('id', $oldFileId)->delete();
            // ログ出力
            $this->outputLog(config('constants.logs.data_delete'),'プロフィール画像を削除しました。。');
            DB::commit();
            session()->flash('success', 'プロフィール画像を削除しました。');
            return response()->json();
        } catch (\Exception $e) {
            // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_delete'),'プロフィール画像をの削除に失敗しました。', $e);
            // 作業実績情報画面に遷移する
            return response()->json( $e);
        }

    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $this->processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
