<?php

namespace App\Http\Controllers\U0500;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\CodeClass;
use App\Models\L2Reception;
use App\Models\UGasInInfo;
use App\Models\UGasOutInfo;
use App\Models\UReception;
use App\Models\USchedule;
use App\Models\USignature;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckCertificateCustomerController extends Controller
{
    public function show(Request $request, USchedule $schedule)
    {
        // ログ登録
        $this->createLog();

        // L2受付取得
        $reception = $schedule->reception()->first();
        $l2reception = L2Reception::find($reception->no);

        // 機器情報、作業内容
        $device = UReception::select('no')->where('no', $reception->no)
            ->leftjoin('u_devices', function ($join) {
                $join->on('u_devices.reception_no', 'u_receptions.no')
                    ->where('represent_flag', 'true')
                    ->whereNull('u_devices.deleted_at');
            })
            ->addselect('u_devices.*')
            ->leftjoin('u_groups', function ($join) {
                $join->on('u_groups.id', 'u_devices.group_id')
                    ->whereNull('u_groups.deleted_at');
            })
            ->addselect('u_groups.name as groupname', 'delivery_date')

            ->leftjoin('u_work_result_details', function ($join) use ($schedule) {
                $join->where('u_work_result_details.schedule_id', $schedule->id)
                    ->on('u_work_result_details.device_id', 'u_devices.id')
                    ->whereNull('u_work_result_details.deleted_at');
            })
            ->addselect('u_work_result_details.work_detail')
            ->first();

        // 作業報告
        $workreport = UReception::select('no')->where('no', $reception->no)
            ->leftjoin('u_work_reports', function ($join) {
                $join->on('u_work_reports.reception_no', 'u_receptions.no')
                    ->whereNull('u_work_reports.deleted_at');
            })
            ->addselect('u_work_reports.remark as remark')
            ->leftjoin('code_classes', function ($join) {
                $join->where('code_classes.identifier_code', config('constants.codes.payment'))
                    ->on('code_classes.key', 'u_work_reports.payment_type')
                    ->whereNull('code_classes.deleted_at');
            })
            ->addselect(DB::raw('CASE WHEN u_work_reports.payment_type = \'' . config('constants.payment.none') . '\' THEN NULL ELSE \'【\' || code_classes.value || \'】\' END as payment_type_name'))
            ->first();

        // 充填情報
        $gasininfo = UGasInInfo::where('reception_no', $reception->no)->whereNull('u_gas_in_info.deleted_at')
            ->select('u_gas_in_info.*')
            ->leftjoin('code_classes as cc1', function ($join) {
                $join->where('cc1.identifier_code', config('constants.codes.fill'))
                    ->on('cc1.key', 'u_gas_in_info.type')
                    ->whereNull('cc1.deleted_at');
            })
            ->addselect('cc1.value as type_name')
            ->leftjoin('code_classes as cc2', function ($join) {
                $join->where('cc2.identifier_code', config('constants.codes.fill_type'))
                    ->on('cc2.key', 'u_gas_in_info.gas_type')
                    ->whereNull('cc2.deleted_at');
            })
            ->addselect(DB::raw('CASE WHEN u_gas_in_info.gas_type = \'' . config('constants.fill_type.others') . '\' THEN u_gas_in_info.gas_type_name ELSE cc2.value END as gas_type_name_view'))
            ->first();

        // 回収情報
        $gasoutinfo = UGasOutInfo::where('reception_no', $reception->no)->whereNull('u_gas_out_info.deleted_at')
            ->select('u_gas_out_info.*')
            ->leftjoin('code_classes as cc1', function ($join) {
                $join->where('cc1.identifier_code', config('constants.codes.collect'))
                    ->on('cc1.key', 'u_gas_out_info.type')
                    ->whereNull('cc1.deleted_at');
            })
            ->addselect('cc1.value as type_name')
            ->leftjoin('code_classes as cc2', function ($join) {
                $join->where('cc2.identifier_code', config('constants.codes.collect_type'))
                    ->on('cc2.key', 'u_gas_out_info.gas_type')
                    ->whereNull('cc2.deleted_at');
            })
            ->addselect(DB::raw('CASE WHEN u_gas_out_info.gas_type = \'' . config('constants.collect_type.others') . '\' THEN u_gas_out_info.gas_type_name ELSE cc2.value END as gas_type_name_view'))
            ->first();

        // QRコードURL
        $qrcodeurl = CodeClass::codeKey(config('constants.codes.url'), config('constants.url.qrcode'))->first();

        return view('U0500.CheckCertificateCustomer', compact(['l2reception', 'reception', 'device', 'schedule', 'workreport', 'gasininfo', 'gasoutinfo', 'qrcodeurl']));
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => '作業完了証明書（お客様控）確認アクセス',
            'content' => '作業完了証明書（お客様控）確認をアクセスしました。',
        ]);
    }
}
