<?php

namespace App\Http\Controllers\U0500;

use Exception;
use App\Commons\Logger;
use App\Models\L2Reception;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\User;

// use SimpleSoftwareIO\QrCode\Facades\QrCode as QRcode;

class CertificateInternalController extends Controller
{
    public function index($receptionNo)
    {
        $l2Reception = L2Reception::findOrFail($receptionNo);
        try {
            // データ値
            $dataHeader = $this->selectHeader($receptionNo);
            $dataHeadeMain = $this->makeHeaderMain($receptionNo);
            $dataBody = $this->makeBody($receptionNo);
            $dataQuotation = $this->makeQuotation($receptionNo);
            $dataOperation = $this->makeOperation($receptionNo);
            $qrcodeDb = $this->makeQRcode();
            $qrcode = !empty($qrcodeDb) ? $qrcodeDb[0]?->string1 : '';
            $uReception = $l2Reception->reception;
            $manHourTotal = $uReception?->getTotalManHour() ?? 0;
            $pjMgrName = $this->getPjMgr($l2Reception);

            // return view('U0500.CertificateInternal', ['receptionNo' => $receptionNo, 'dataheader' => $dataHeader[0], 'dataheadermain' => $dataHeadeMain, 'dataBody' => $dataBody, 'dataOperation' => $dataOperation, 'dataQuotation' => $dataQuotation, 'qrcode' => $qrcode]);
            $pdf = PDF::loadView('U0500.CertificateInternal', [
                'receptionNo' => $receptionNo,
                'dataheader' => $dataHeader[0],
                'dataheadermain' => $dataHeadeMain,
                'dataBody' => $dataBody,
                'dataOperation' => $dataOperation,
                'dataQuotation' => $dataQuotation,
                'qrcode' => $qrcode,
                'manHourTotal' => $manHourTotal,
                'pjMgrName' => $pjMgrName,
            ]);
            $dom_pdf = $pdf->getDomPDF();
            $dom_pdf->set_option("enable_php", true);
            $dom_pdf->set_option('isFontSubsettingEnabled', true);
            $canvas = $dom_pdf->get_canvas();
            $canvas->page_text(560, 25, "{PAGE_NUM}/{PAGE_COUNT}", null, 8, array(0, 0, 0));

            $this->outputLog(
                '作業完了証明書（社内確認）ダウンロード',
                config('constants.logs.download'),
                "作業完了証明書（社内確認）をダウンロードしました。"
            );

            return $pdf->download('【関係者外秘】作業完了報告書兼フロン類充塡・回収証明書（社内確認）_' . time() . '.pdf');
        } catch (Exception $e) {
            // ログ出力
            $this->outputLog(
                '作業完了証明書（社内確認）ダウンロード',
                config('constants.logs.download'),
                "作業完了証明書（社内確認）ダウンロードは異常終了しました。",
                $e
            );
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }

    /**
     *
     */
    public function makeQRcode()
    {
        $qrcodeurl = DB::select('SELECT * FROM code_classes WHERE key = \'qrcode\' limit 1;');
        return $qrcodeurl;
    }

    /**
     * 計上担当を取得する
     */
    private function getPjMgr($l2Reception){
        $res='-';
        $pjMgrId = $l2Reception->reception->eff_pjmgr_id;
        if ( $pjMgrId != null ){
            $res= User::find($pjMgrId)?->name ?? '-';
        }

        return $res;
    }

    /**
     *
     */
    private function selectHeader($receptionNo)
    {
        $dataheader = DB::select("SELECT DISTINCT
        L2.no
        ,L2.related_pj_no
        ,to_char(L2.date , 'yyyy/MM/dd') AS receptions_date
        ,A.name AS emp_name
        ,L2.content AS receptions_content
        ,L2.field_address
        ,L2.field_name
        ,L2.field_tel
        ,L2.field_mobile_tel
        ,L2.field_person_name
        ,L2.client_address
        ,L2.client_name
        ,L2.client_tel
        ,L2.client_fax
        ,L2.client_billing_deadline
        ,L2.client_person_name
        ,L2.dealer_name
        ,L2.dealer_tel
        ,L2.dealer_fax
        , REC.billing_name
        , REC.billing_tel
        , REC.billing_fax
        ,C10.value AS type_in
        ,to_char(GIn.date , 'yyyy/MM/dd') AS gin_date
        ,C12.value AS gas_type_in
        ,GIn.quantity AS quantity_in
        ,GIn.gas_type_name AS gas_in_name
        ,C11.value AS type_out
        ,to_char(GOut.date , 'yyyy/MM/dd') AS gout_date
        ,C13.value AS gas_type_out
        ,GOut.quantity AS quantity_out
        ,GOut.gas_type_name AS gas_out_name
        ,R.remark
        ,C17.value AS reports_work_type
        ,C05.value AS payment_type
        From
            l2_receptions AS L2
            INNER JOIN u_receptions AS REC
                ON L2.no = REC.no
                AND REC.deleted_at IS NULL
            LEFT JOIN u_gas_in_info AS GIn
                ON L2.no = GIn.reception_no
                AND GIn.deleted_at IS NULL
            LEFT JOIN u_gas_out_info AS GOut
                ON L2.no = GOut.reception_no
                AND GOut.deleted_at IS NULL
            INNER JOIN u_statuses AS S
                ON L2.no = S.reception_no
            LEFT JOIN u_work_reports AS R
                ON L2.no = R.reception_no
                AND R.deleted_at IS NULL
            LEFT JOIN u_schedules AS SH
                ON L2.no = SH.reception_no
                AND SH.deleted_at IS NULL
            LEFT JOIN u_work_results AS WR
                ON SH.id = WR.schedule_id
                AND WR.deleted_at IS NULL
            LEFT JOIN u_schedule_users AS SU
                ON SH.id = SU.schedule_id
                AND SU.deleted_at IS NULL
            LEFT JOIN users AS A
                ON A.external_user_id = L2.emp_code
            LEFT JOIN code_classes AS C10
                ON C10.identifier_code = '" . config('constants.codes.fill') . "'
                AND C10.key = GIn.type
                AND C10.deleted_at IS NULL
            LEFT JOIN code_classes AS C12
                ON C12.identifier_code = '" . config('constants.codes.fill_type') . "'
                AND C12.key = GIn.gas_type
                AND C12.deleted_at IS NULL
            LEFT JOIN code_classes AS C11
                ON C11.identifier_code = '" . config('constants.codes.collect') . "'
                AND C11.key = GOut.type
                AND C11.deleted_at IS NULL
            LEFT JOIN code_classes AS C13
                ON C13.identifier_code = '" . config('constants.codes.collect_type') . "'
                AND C13.key = GOut.gas_type
                AND C13.deleted_at IS NULL
            LEFT JOIN code_classes AS C17
                ON C17.identifier_code = '" . config('constants.codes.work') . "'
                AND C17.key = R.work_type
                AND C17.deleted_at IS NULL
            LEFT JOIN code_classes AS C05
                ON C05.identifier_code = '" . config('constants.codes.payment') . "'
                AND C05.key = R.payment_type
                AND C05.deleted_at IS NULL
            LEFT JOIN users AS U
                ON U.id = SU.user_id
        WHERE
            L2.no =  ?
            AND S.deleted_at IS NULL
            AND SU.deleted_at IS NULL", [$receptionNo]);
        return $dataheader;
    }

    /**
     * ボディ部にデータを取得する。
     */
    private function makeBody($receptionNo)
    {
        $dataBody = DB::select(
            "SELECT
        SCD.id AS schedule_id
        , TO_CHAR(SCD.date, 'yyyy/MM/dd') AS schedule_date
        , CC1.value AS ky_point_type
        , WRS.one_point
        , STRING_AGG(U.short_name, '、') AS user_name
        , TO_CHAR(SNT.signed_at, 'yyyy/MM/dd') AS signed_at
        , SNT.digital_flag
        , FILE.file
        , GRP.name AS group_name
        , DEV.id AS device_id
        , DEV.device_type
        , DEV.device_no
        , WS.work_detail
    FROM
        l2_receptions AS L2
        INNER JOIN u_receptions AS REC
            ON L2.no = REC.no
        INNER JOIN u_schedules AS SCD
            ON REC.no = SCD.reception_no
        INNER JOIN u_work_results AS WRS
            ON SCD.id = WRS.schedule_id
        LEFT JOIN code_classes AS CC1
            ON WRS.ky_point_type = CC1.key
            AND CC1.deleted_at IS NULL
            AND CC1.identifier_code = '" . config('constants.codes.ky') . "'
        LEFT JOIN u_work_result_details AS WS
            ON WS.schedule_id = SCD.id
        LEFT JOIN u_devices AS DEV
            ON DEV.id = WS.device_id
            AND DEV.deleted_at IS NULL
        LEFT JOIN u_groups AS GRP
            ON GRP.id = DEV.group_id
            AND GRP.deleted_at IS NULL
        INNER JOIN u_schedule_users AS SU
            ON SCD.id = SU.schedule_id
            AND SU.deleted_at IS NULL
        LEFT JOIN users AS U
            ON U.id = SU.user_id
        LEFT JOIN u_signatures AS SNT
            ON SCD.id = SNT.schedule_id
            AND SNT.deleted_at IS NULL
        LEFT JOIN files AS FILE
            ON FILE.id = SNT.file_id
    WHERE
        L2.no = ?
        AND SCD.deleted_at IS NULL
        AND CC1.deleted_at IS NULL
        AND WRS.deleted_at IS NULL
        AND WS.deleted_at IS NULL
        AND DEV.deleted_at IS NULL
        AND SU.deleted_at IS NULL
        AND SNT.deleted_at IS NULL
        AND FILE.deleted_at IS NULL
    GROUP BY
        SCD.id
        , CC1.value
        , WRS.one_point
        , SNT.signed_at
        , SNT.digital_flag
        , FILE.file
        , GRP.name
        , DEV.id
        , DEV.device_type
        , DEV.device_no
        , WS.work_detail
        , GRP.id
    ORDER BY
        SCD.date desc
        , GRP.id NULLS FIRST
        , DEV.group_id asc
        , DEV.device_type
        , DEV.device_no",
            [$receptionNo]
        );
        return $dataBody;
    }

    /**
     * 見積明細にデータを取得する。
     */
    private function makeQuotation($receptionNo)
    {
        $quotation = DB::select(" SELECT
                u_quotations.work_no
                , u_quotations.quantity
                , u_quotations.unit
                , u_quotations.amount
                , u_quotations.name
                , CASE
                WHEN u_work_reports.tax_included_flag = TRUE
                    THEN '消費税込'
                ELSE '消費税抜'
                END AS tax_included_flag_name
            FROM
                l2_receptions AS L2
                INNER JOIN u_quotations u_quotations
                ON L2.no = u_quotations.reception_no
                INNER JOIN u_work_reports u_work_reports
                ON L2.no = u_work_reports.reception_no
            WHERE
                L2.no = ?
            GROUP BY
                u_quotations.id
                , u_quotations.work_no
                , u_quotations.quantity
                , u_quotations.unit
                , u_quotations.amount
                , u_quotations.name
                , u_work_reports.tax_included_flag
            ORDER BY
                u_quotations.id", [$receptionNo]);
        return $quotation;
    }

    /**
     * ッター部にデータを取得する。
     */
    private function makeOperation($receptionNo)
    {
        $dataOperation = DB::select("  SELECT
        G.name AS group_name
        , O.id AS records_id
        , DEV.id
        , DEV.device_type
        , DEV.device_no
        , O.record01
        , O.record02
        , O.record03
        , O.record04
        , O.record05
        , O.record06
        , O.record07
        , O.record08
        , O.record09
        , O.record10
    FROM l2_receptions AS L2
        INNER JOIN u_receptions AS REC
        ON L2.no = REC.no
        INNER JOIN u_schedules AS SCD
        ON REC.no = SCD.reception_no
        INNER JOIN u_devices AS DEV
        ON DEV.reception_no = REC.no
        INNER JOIN u_operation_records as O
            ON DEV.id = O.device_id
        LEFT JOIN u_groups AS G
            ON G.id = DEV.group_id
            AND G.deleted_at IS NULL
    WHERE
        L2.no = ?
        AND O.deleted_at IS NULL
        AND DEV.deleted_at IS NULL
    ORDER BY
        G.id NULLS FIRST
        , DEV.device_type
        , DEV.device_no
        , O.record01 NULLS FIRST
        , O.record02 NULLS FIRST
        , O.record03 NULLS FIRST
        , O.record04 NULLS FIRST
        , O.record05 NULLS FIRST
        , O.record06 NULLS FIRST
        , O.record07 NULLS FIRST
        , O.record08 NULLS FIRST
        , O.record09 NULLS FIRST
        , O.record10 NULLS FIRST", [$receptionNo]);

        return $dataOperation;
    }

    private function makeHeaderMain($receptionNo)
    {
        // CHG 202205025 Ishino 見積をベースとしないようにSQLを修正
        $databody = DB::select("SELECT
                 Q.id as quotations_id
                ,Q.work_no
                ,Q.quantity AS quotations_quantity
                ,Q.unit AS quotations_unit
                ,Q.amount AS quotations_amount
                ,Q.name AS quotations_name
                ,R.tax_included_flag
                ,(SELECT SUM(amount) FROM u_quotations WHERE u_quotations.reception_no = ?  AND deleted_at IS NULL) AS total_amount
                ,C.id AS coust_id
                ,C09.value AS type_costs
                ,C.name AS costs_name
                ,C.amount AS costs_amount
            FROM
                u_receptions AS RCP
                LEFT JOIN u_quotations AS Q
                    ON RCP.no = Q.reception_no
                    AND Q.deleted_at IS NULL
                INNER JOIN u_work_reports AS R
                    ON RCP.no = R.reception_no
                    AND R.deleted_at IS NULL
                LEFT JOIN u_costs AS C
                    ON RCP.no = C.reception_no
                    AND C.deleted_at IS NULL
                LEFT join code_classes AS C09
                    ON C09.identifier_code = '" . config('constants.codes.cost') . "'
                    AND C09.key = C.type
                    AND C09.deleted_at IS NULL
                WHERE
                    RCP.no = ?
                ORDER BY Q.id, C.id ", [$receptionNo, $receptionNo]);
        return $databody;
    }
}
