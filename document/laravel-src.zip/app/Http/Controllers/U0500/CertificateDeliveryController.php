<?php

namespace App\Http\Controllers\U0500;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\CodeClass;
use App\Models\L2Reception;
use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * 作業完了証明書（納品書）
 */
class CertificateDeliveryController extends Controller
{
    /**
     * 作業完了証明書（納品書）ダウンロード
     */
    public function index($receptionNo)
    {
        $l2Reception = L2Reception::findOrFail($receptionNo);

        try {
            // キー取得
            $dataHeader = $this->makeHeader($receptionNo);

            $dataBody = $this->makeBody($receptionNo);

            $quotation = $this->makeQuotation($receptionNo);

            $dataFooter = $this->makeFooter($receptionNo);

            $totalAmount = 0;
            foreach($quotation as $quo){
                $totalAmount += $quo->amount;
            }

            $qrcodeurl = CodeClass::where('identifier_code', config('constants.codes.url'))
                ->where('key', config('constants.url.qrcode'))
                ->select('string1')
                ->first();
            /*
            return view('U0500.CertificateDelivery',
                [
                    'dataHeader' => $dataHeader[0] ,
                    'dataBody'=> $dataBody,
                    'quotation' => $quotation,
                    'dataFooter' => $dataFooter,
                    'totalAmount' => $totalAmount,
                    'qrcodeurl' => $qrcodeurl
                ]
            );
            */
            $pjMgrName = $this->getPjMgr($l2Reception);

            $pdf = app('dompdf.wrapper');
            $pdf->getDomPDF()->set_option("enable_php", true);
            $pdf->getDomPDF()->set_option('isFontSubsettingEnabled', true);
            $pdf->loadView('U0500.CertificateDelivery',
                [
                    'dataHeader' => $dataHeader[0] ,
                    'dataBody'=> $dataBody,
                    'quotation' => $quotation,
                    'dataFooter' => $dataFooter,
                    'totalAmount' => $totalAmount,
                    'qrcodeurl' => $qrcodeurl,
                    'pjMgrName' => $pjMgrName,
                ]
            );

            $this->outputLog(
                '作業完了証明書（納品書）ダウンロード',
                config('constants.logs.download'),
                "作業完了証明書（納品書）をダウンロードしました。"
            );

            return $pdf->download('作業完了証明書兼フロン類充填・回収証明書（納品書）_' . time() . '.pdf');
        } catch (\Exception $e) {
            $this->outputLog(
                '作業完了証明書（納品書）ダウンロード' ,
                config('constants.logs.download'),
                "作業完了証明書（納品書）ダウンロードは異常終了しました。", $e
            );
        }
    }

    /**
     * 計上担当を取得する
     */
    private function getPjMgr($l2Reception){
        $res='-';
        $pjMgrId = $l2Reception->reception->eff_pjmgr_id;
        if ( $pjMgrId != null ){
            $res= User::find($pjMgrId)?->name ?? '-';
        }

        return $res;
    }

    /**
     * ヘッダー部にデータを取得する。
     */
    private function makeHeader($receptionNo)
    {
        $dataHeader = DB::select("SELECT
                L2.no
                , L2.related_pj_no AS related_pj_no
                , TO_CHAR(L2.date, 'yyyy/MM/dd') AS l2_date
                , CASE
                    WHEN (us.name = '' OR us.name IS NULL)
                        THEN '-'
                    ELSE us.name
                    END AS emp_name
                , L2.content AS receptions_content
                , L2.field_address
                , L2.field_name
                , L2.field_tel
                , L2.field_mobile_tel
                , L2.field_person_name
                , L2.client_address
                , L2.client_name
                , L2.client_tel
                , L2.client_fax
                , L2.client_billing_deadline
                , L2.client_person_name
                , L2.dealer_name
                , L2.dealer_tel
                , L2.dealer_fax
                , REC.billing_name
                , REC.billing_tel
                , REC.billing_fax
                , CC1.value AS gas_in_type
                , TO_CHAR(GIN.date, 'yyyy/MM/dd') AS gas_in_date
                , CASE
                    WHEN (GIN.gas_type = '0')
                        THEN GIN.gas_type_name
                    ELSE CC2.value
                    END AS gas_in_gas_type
                , GIN.quantity AS gas_in_quantity
                , CC3.value AS gas_out_type
                , TO_CHAR(GOUT.date, 'yyyy/MM/dd') AS gas_out_date
                , CASE
                WHEN (GOUT.gas_type = '0')
                    THEN GOUT.gas_type_name
                ELSE CC4.value
                END AS gas_out_gas_type
                , GOUT.quantity AS gas_out_quantity
                , WRP.remark
                , CC5.value AS work_report_work_type
                , CASE
                    WHEN CC6.key = '0'
                        THEN ''
                    ELSE '(' || CC6.value || ')'
                    END AS work_report_payment_type
            FROM
                l2_receptions AS L2
                INNER JOIN u_receptions AS REC
                    ON L2.no = REC.no
                    AND REC.deleted_at IS NULL
                LEFT JOIN u_gas_in_info AS GIN
                    ON L2.no = GIN.reception_no
                    AND GIN.deleted_at IS NULL
                LEFT JOIN u_gas_out_info AS GOUT
                    ON L2.no = GOUT.reception_no
                    AND GOUT.deleted_at IS NULL
                INNER JOIN u_statuses AS STT
                    ON L2.no = STT.reception_no
                INNER JOIN u_work_reports AS WRP
                    ON L2.no = WRP.reception_no
                LEFT JOIN users AS us
                    ON us.external_user_id = L2.emp_code
                LEFT JOIN code_classes AS CC1
                    ON GIN.type = CC1.key
                    AND CC1.deleted_at IS NULL
                    AND CC1.identifier_code = '" . config('constants.codes.fill') . "'
                LEFT JOIN code_classes AS CC2
                    ON GIN.gas_type = CC2.key
                    AND CC2.deleted_at IS NULL
                    AND CC2.identifier_code = '" . config('constants.codes.fill_type') . "'
                LEFT JOIN code_classes AS CC3
                    ON GOUT.type = CC3.key
                    AND CC3.deleted_at IS NULL
                    AND CC3.identifier_code = '" . config('constants.codes.collect') . "'
                LEFT JOIN code_classes AS CC4
                    ON GOUT.gas_type = CC4.key
                    AND CC4.deleted_at IS NULL
                    AND CC4.identifier_code = '" . config('constants.codes.collect_type') . "'
                LEFT JOIN code_classes AS CC5
                    ON WRP.work_type = CC5.key
                    AND CC5.deleted_at IS NULL
                    AND CC5.identifier_code = '" . config('constants.codes.work') . "'
                LEFT JOIN code_classes AS CC6
                    ON WRP.payment_type = CC6.key
                    AND CC6.deleted_at IS NULL
                    AND CC6.identifier_code = '" . config('constants.codes.payment') . "'
            WHERE
                L2.no = ?
                AND STT.deleted_at IS NULL
                AND WRP.deleted_at IS NULL
      ", [$receptionNo]);
        return $dataHeader;
    }

    /**
     * ボディ部にデータを取得する。
     */
    private function makeBody($receptionNo)
    {
        $dataBody = DB::select("SELECT
                SCD.id AS schedule_id
                , TO_CHAR(SCD.date, 'yyyy/MM/dd') AS schedule_date
                , CC1.value AS ky_point_type
                , WRS.one_point
                , STRING_AGG(USE.short_name, '、' order by USE.short_name) AS user_name
                , TO_CHAR(SNT.signed_at, 'yyyy/MM/dd') AS signed_at
                , SNT.digital_flag
                , FILE.file
                , GRP.name AS group_name
                , DEV.device_type
                , DEV.device_no
                , WD.work_detail
            FROM
                l2_receptions AS L2
                INNER JOIN u_receptions AS REC
                    ON L2.no = REC.no
                INNER JOIN u_schedules AS SCD
                    ON REC.no = SCD.reception_no
                INNER JOIN u_work_results AS WRS
                    ON SCD.id = WRS.schedule_id
                LEFT JOIN code_classes AS CC1
                    ON WRS.ky_point_type = CC1.key
                    AND CC1.deleted_at IS NULL
                    AND CC1.identifier_code = '" . config('constants.codes.ky') . "'
                INNER JOIN u_work_result_details AS WD
                    ON WD.schedule_id = SCD.id
                INNER JOIN u_devices AS DEV
                    ON DEV.id = WD.device_id
                LEFT JOIN u_groups AS GRP
                    ON GRP.id = DEV.group_id
                    AND GRP.deleted_at IS NULL
                INNER JOIN u_schedule_users AS SU
                    ON SCD.id = SU.schedule_id
                LEFT JOIN users AS USE
                    ON USE.id = SU.user_id
                LEFT JOIN u_signatures AS SNT
                    ON SCD.id = SNT.schedule_id
                    AND SNT.deleted_at IS NULL
                LEFT JOIN files AS FILE
                    ON FILE.id = SNT.file_id
            WHERE
               L2.no = ?
                AND SCD.deleted_at IS NULL
                AND WRS.deleted_at IS NULL
                AND SU.deleted_at IS NULL
                AND CC1.deleted_at IS NULL
                AND WD.deleted_at IS NULL
                AND FILE.deleted_at IS NULL
            GROUP BY
                SCD.id
                , CC1.value
                , WRS.one_point
                , SNT.signed_at
                , SNT.digital_flag
                , FILE.file
                , GRP.name
                , DEV.id
                , DEV.device_type
                , DEV.device_no
                , WD.work_detail
                , GRP.id
            ORDER BY
                SCD.date DESC
                , GRP.id NULLS FIRST
                , DEV.device_type
                , DEV.device_no
            " , [$receptionNo]);
        return $dataBody;
    }

    /**
     * 見積明細にデータを取得する。
     */
    private function makeQuotation($receptionNo){
        $quotation = DB::select(" SELECT
                u_quotations.work_no
                , u_quotations.quantity
                , u_quotations.unit
                , u_quotations.amount
                , u_quotations.name
                , CASE
                WHEN u_work_reports.tax_included_flag = TRUE
                    THEN '消費税込'
                ELSE '消費税抜'
                END AS tax_included_flag_name
            FROM
                l2_receptions AS L2
                INNER JOIN u_quotations u_quotations
                    ON L2.no = u_quotations.reception_no
                INNER JOIN u_work_reports u_work_reports
                    ON L2.no = u_work_reports.reception_no
            WHERE
                L2.no = ?
                AND u_quotations.deleted_at IS NULL
                AND u_work_reports.deleted_at IS NULL
            GROUP BY
                u_quotations.id
                , u_quotations.work_no
                , u_quotations.quantity
                , u_quotations.unit
                , u_quotations.amount
                , u_quotations.name
                , u_work_reports.tax_included_flag
            ORDER BY
                u_quotations.id ", [$receptionNo]);

        return $quotation;
    }

    /**
     * ッター部にデータを取得する。
     */
    function makeFooter($receptionNo){
        $dataFooter = DB::select(" SELECT
                u_groups.name AS group_name
                , u_operation_records.id AS records_id
                , u_devices.device_type
                , u_devices.device_no
                , u_operation_records.record01
                , u_operation_records.record02
                , u_operation_records.record03
                , u_operation_records.record04
                , u_operation_records.record05
                , u_operation_records.record06
                , u_operation_records.record07
                , u_operation_records.record08
                , u_operation_records.record09
                , u_operation_records.record10
            FROM l2_receptions
                INNER JOIN u_receptions
                    ON l2_receptions.no = u_receptions.no
                INNER JOIN u_schedules
                    ON u_receptions.no = u_schedules.reception_no
                INNER JOIN u_devices
                    ON u_devices.reception_no = u_receptions.no
                INNER JOIN u_operation_records
                    ON u_devices.id = u_operation_records.device_id
                LEFT JOIN u_groups
                    ON u_groups.id = u_devices.group_id
                    AND u_groups.deleted_at IS NULL
            WHERE
                l2_receptions.no = ?
                AND u_devices.deleted_at IS NULL
                AND u_operation_records.deleted_at IS NULL
                AND u_devices.deleted_at IS NULL
            ORDER BY
                u_groups.id NULLS FIRST
                , u_devices.device_type
                , u_devices.device_no
                , u_operation_records.record01 NULLS FIRST
                , u_operation_records.record02 NULLS FIRST
                , u_operation_records.record03 NULLS FIRST
                , u_operation_records.record04 NULLS FIRST
                , u_operation_records.record05 NULLS FIRST
                , u_operation_records.record06 NULLS FIRST
                , u_operation_records.record07 NULLS FIRST
                , u_operation_records.record08 NULLS FIRST
                , u_operation_records.record09 NULLS FIRST
                , u_operation_records.record10 NULLS FIRST", [$receptionNo]);

        return $dataFooter;
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
