<?php
namespace App\Http\Controllers\U0700;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\SystemSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Redirect;
use PhpParser\Node\Stmt\TryCatch;

/**
 * 工数連携停止・手動出力
 *
 * @author  donlq
 * @create_date  2021-10-20
 */
class CoopManHourStopManualController extends Controller
{

    /**
     * 工数連携停止表示します。
     *
     * @param
     * @return \Illuminate\Http\Controller
     */
    public function index(){
        $this->outputLog("工数連携停止・手動出力アクセス",config('constants.logs.page_access'), '工数連携停止・手動出力にアクセスしました');
        $checkBox=SystemSetting::where('id',"CoopManHourStop")->firstOrFail();
        return view('U0700.CoopManHourStopManual')->with(['checkBox'=> $checkBox->value]);
    }
    /**
     * 
     *
     * @param  request  $request
     * @return \Illuminate\Http\Controller
     */
    public function update(Request $request)
    {
        try{
            $systemSetting=SystemSetting::where('id',"CoopManHourStop")->first();
            $systemSetting->value=$request->check==null?0:1;
            $systemSetting->save();
            $request->session()->flash('messageSuccess', '工数連携状態を正常に更新しました。');
            return Redirect::back();
        }catch(\Exception $e){
            $this->outputLog('工数連携停止',config('constants.logs.data_update'),'例外が発生しました。',$e);
        }
    }
    /**
     * 
     *
     * @param  request  $request
     * @return \Illuminate\Http\Controller
     */
    public function store()
    {
        try{
            $state=Artisan::call('command:CoopManHour');
            switch ($state)
            {
                case 0 :
                    return redirect()->route('coop-man-hour-stop-manual.index')->with("messageSuccess", "工数連携ファイルを正常に出力しました。");
                case 1:
                    return redirect()->route('coop-man-hour-stop-manual.index')->with("messageErr", "工数出力処理が実行中です。");
                case 7:
                    return redirect()->route('coop-man-hour-stop-manual.index')->with("messageErr", "既に工数連携ファイルが出力されています。");
                case 8:
                    return redirect()->route('coop-man-hour-stop-manual.index')->with("messageErr", "前回連携処理が異常終了しています。ダッシュボード画面からエラー内容を確認してください。");
                case 9:
                    return redirect()->route('coop-man-hour-stop-manual.index')->with("messageErr", "工数出力処理が異常終了しました。ダッシュボード画面からエラー内容を確認してください。");
                default:
                    return Redirect::back();
            }
        }catch(\Exception $e){
            $this->outputLog('工数連携停止',config('constants.logs.data_update'),'例外が発生しました。',$e);
        }
    }
        /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName,$processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }

}