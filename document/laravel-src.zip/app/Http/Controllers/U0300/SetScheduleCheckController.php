<?php

namespace App\Http\Controllers\U0300;

use App\Models\Auth;
use App\Models\User;
use App\Commons\Logger;
use App\Models\CodeClass;
use App\Models\USchedule;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Request;
use App\Http\Requests\U0300\SetScheduleCheckRequest;

class SetScheduleCheckController extends Controller
{

    /**
     * 予定確認設定画面
     *
     * @return \Illuminate\View\View
     */
    public function index(SetScheduleCheckRequest $request)
    {

        // アクセスログ登録
        $this->createLog();

        // バリデーション
        $validData = $request->validated();

        // モード
        $mode = $validData['mode'];

        //日付範囲
        $startDate = $validData['start_date'];
        $endDate = $validData['end_date'];
        $dateRange = Carbon::parse($startDate)->toPeriod($endDate);

        // 時間帯
        $slots = CodeClass::getSlots();

        // 選択された時間帯
        $selectedSlots = $slots->whereIn('key', collect($validData['schedule_slots'])?->keys());

        // 指定した社内人数
        $internalPersons = $validData['internal_persons'];

        // 指定した協力会社人数
        $externalPersons = $validData['external_persons'];

        // 選択された担当者ID
        $selectedPersonIDs = collect($validData['schedule_persons'] ?? [])->keys()->toArray();

        // 担当者
        $persons = $this->getPersons($selectedPersonIDs);

        // 選択された担当者
        $selectedPersons = $persons->whereIn('id', $selectedPersonIDs);

        // 協力会社担当者全員人数
        $externalTotal = $persons->where('is_external', true)->count();

        // 社内担当者全員人数
        $internalTotal = $persons->count() - $externalTotal; // 社内担当者以外

        // 検索結果データ
        $searchedData = $this->getSearchedData($startDate, $endDate, $selectedPersonIDs);

        // 配列形式の検索データ
        $searchedDataArray = array();
        foreach ($dateRange as $date) {

            // 日付ごとの検索結果
            $dateData = $searchedData->filter(function ($data) use ($date) {
                return $data->date->format('Y/m/d') === $date->format('Y/m/d');
            });

            // 空枠
            $tempArray = array();
            foreach ($slots as $slot) {

                // 日付ごとの検索結果の時間帯ごと
                $slotData = $dateData->where('slot_type', $slot->key);

                // 日程が入っている協力会社担当者数
                $filledExternal = $slotData->where('is_external', true)->count();

                // 日程が入っている社員担当者数
                $filledInternal = $slotData->count() - $filledExternal;

                // 空いている社内担当者人数
                $availableInternal = $internalTotal - $filledInternal;
                // 空いている協力会社担当者人数
                $availableExternal = $externalTotal - $filledExternal;

                $internalMatched = false;
                // 条件の社内担当者が指定してあり、かつ空いているスケジュールが満たす
                $internalMatched = ($availableInternal >= $internalPersons);

                // 条件の協力会社担当者が指定してあり、かつ空いているスケジュールが満たす
                $externalMatched = ($availableExternal >= $externalPersons);

                // 時間帯が一致するか
                $slotMatched = $selectedSlots->contains($slot);

                foreach ($persons as $person) {

                    // 日程数
                    $count = $dateData->where('user_id', $person->id)
                        ->where('slot_type', $slot->key)
                        ->first()
                    ?->schedule_count ?? 0;

                    // 一致条件：指定した時間帯かつ日程がないかつ社内担当者数が満たすかつ協力会社担当者数が満たすかつ選択された担当者
                    $matched = $slotMatched && !$count && $externalMatched && $internalMatched & $selectedPersons->contains($person);

                    // 担当者(社員）かつ社員人数を設定しない
                    if (!$person->is_external && $internalPersons <= 0) {
                        $matched = false;
                    }

                    // 協力会社担当者かつ協力会社人数を設定しない
                    if ($person->is_external && $externalPersons <= 0) {
                        $matched = false;
                    }

                    array_push($tempArray, [
                        'user_id' => $person->id,
                        'slot_type' => $slot->key,
                        'count' => $count,
                        'matched' => $matched,
                    ]);
                }
            }

            $searchedDataArray[$date->format('Y/m/d')] = collect($tempArray);
        }

        return view('U0300.SetScheduleCheck', compact([
            'mode', // モード
            'startDate', // 日付(開始)
            'endDate', // 日付(終了)
            'dateRange', // 日付範囲
            'slots', // 時間帯
            'selectedSlots', // 選択された時間帯
            'internalPersons', // 社内人数
            'externalPersons', // 協力会社人数
            'persons', // 担当者
            'selectedPersons', // 選択された担当者
            'searchedDataArray', // 検索結果
        ]));
    }

    /**
     * 検索データ抽出
     *
     * @param string $startDate
     * @param string $endDate
     * @param array $personIds
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    private function getSearchedData($startDate, $endDate, array $personIds = [])
    {
        return USchedule::join('u_schedule_details as usd', 'usd.schedule_id', '=', 'u_schedules.id')
            ->select(DB::raw('date::date as date'), 'user_id', 'slot_type', DB::raw('count(*) as schedule_count'))
            ->when($personIds, function ($query) use ($personIds) {
                $query->whereIn('user_id', $personIds);
            })
            ->whereBetween('date', [$startDate, $endDate])
            ->withCasts(['date' => 'date:Y/m/d'])
            ->addSelect([
                'is_external' => Auth::selectRaw('true as is_external')
                    ->whereColumn('auths.user_id', 'usd.user_id')
                    ->where('auth_class', config('constants.auth.pic_external'))
                    ->limit(1),
            ])
            ->groupBy('date', 'user_id', 'slot_type')
            ->get();
    }

    /**
     * 担当者取得
     *
     * @param array $personIds: ユーザIDの配列
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    private function getPersons(array $personIds = [])
    {

        // 訪問担当のリスト
        return User::where(function ($query) {
            $query->whereHas('auths', function ($query) { // 訪問担当権限持っている
                $query->whereIn('auth_class', [
                    config('constants.auth.pic'),
                    config('constants.auth.pic_external'),
                ]);
            });
        })
            ->when($personIds, function ($query) use ($personIds) {
                $query->whereIn('users.id', $personIds);
            })
            ->addSelect([
                'is_external' => Auth::selectRaw('true as is_external')
                    ->whereColumn('user_id', 'users.id')
                    ->where('auth_class', config('constants.auth.pic_external'))
                    ->limit(1),
            ])
            ->orderBy('is_external', 'desc')
            ->get();
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => '予定確認設定画面アクセス',
            'content' => '予定確認設定画面をアクセスしました。',
            'request_url' => substr(Request::fullUrl(), 0, 255),
            'referer_url' => substr(Request::header('referer'), 0, 255),
        ]);
    }
}
