<?php

namespace App\Http\Controllers\U0300;;

use App\Http\Controllers\Controller;
use App\Http\Requests\U0300\SetSignFileRequest;
use App\Models\File;
use App\Models\USignature;
use App\Models\UAttachment;
use App\Models\USchedule;
use Carbon\Carbon;
use App\Commons\Logger;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SetSignFileController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '署名ファイル処理';

    /**
     * 該当する署名ファイル設定情報を表示します。
     *
     */
    public function show($scheduleId)
    {
        $schedule = USchedule::findOrFail($scheduleId);
        // 権限チェック
        $this->authorize('updateSignature', $schedule);

        $this->processName = 'ファイル設定画面アクセス';
        // ログ出力
        $this->outputLog(config('constants.logs.page_access'), '署名ファイル設定画面にアクセスしました。');

        return view('U0300.SetSignFile', compact('scheduleId'));
    }

    /**
     * 新規で署名ファイル情報を登録します。
     * 該当する署名ファイル情報を変更します。
     *
     */
    public function store(SetSignFileRequest $request)
    {
        $file = $request->file('file');

        // MBをBytesに変換する。
        $maxUploadSize = config('constants.upload_max_size.signature_file') * 1048567;
        $fileSize = filesize($file);

        // 最大サイズのアップロードファイルを確認してください
        if ($fileSize <= 0) {
            $message = "ファイルサイズが0バイトのファイルはアップロードできません。";
            return back()->withInput()->withErrors(['file' => $message]);
        }
        // 最大サイズのアップロードファイルを確認してください
        if ($fileSize > $maxUploadSize) {
            $message = "アップロードファイルの上限を超えるため、登録できません。
                        （最大" . config('constants.upload_max_size.signature_file') . "MB)";
            return back()->withInput()->withErrors(['file' => $message]);
        }

        // アップロードファイル情報を取得する
        $filename = $file->getClientOriginalName();
        $data = file_get_contents($file->getRealPath());
        $base64 = base64_encode($data);
        $scheduleId = $request->scheduleId;
        $tmp_path = $file->getRealPath(); // 実画像のパスを取得
        $fp = fopen($tmp_path, 'rb'); // 画像ファイルのファイルポインタ取得
        $db = DB::getPdo();
        $title = $request->title;
        $userid = Auth::id();
        $date = Carbon::now();

        DB::beginTransaction();
        try {
            $userSignature = USignature::where('schedule_id', $scheduleId)->first();
            if ($userSignature == null) {
                $this->processName = "ファイル登録";
                // 新しいファイルを作成する
                /*
                $newFile = File::create([
                    'file' => $base64,
                    'name' => $filename,
                    'title' => $request->title,
                    'public_flag'=> true,
                ]);
                */
                $stmt = $db->prepare("INSERT INTO files (file,name,title,public_flag,created_by,updated_by,created_at,updated_at) VALUES (:file,:name,:title,true,:userid,:userid,:date,:date)");
                $stmt->bindParam(':file', $fp, $db::PARAM_LOB);
                $stmt->bindParam(':name', $filename);
                $stmt->bindParam(':title', $title);
                $stmt->bindParam(':userid', $userid);
                $stmt->bindParam(':date', $date);
                $stmt->execute();
                $file_id = $db->lastInsertId();
                unset($db);
                // ログ出力
                $this->outputLog(config('constants.logs.data_insert'), 'ファイルを登録しました。');

                $this->processName = "署名登録";
                // 電子署名を登録し
                USignature::create([
                    'schedule_id' => $scheduleId,
                    'digital_flag' => false,
                    'signed_at'    => Carbon::now(),
                    //'file_id'=> $newFile->id,
                    'file_id' => $file_id,
                ]);
                // ログ出力
                $this->outputLog(config('constants.logs.data_insert'), '署名を登録しました。');
            } else {
                // Update file content
                $this->processName = "ファイル入替";
                /*
                $oldFile =  File::where('id',$userSignature -> file_id )->first();
                $oldFile -> file = $base64;
                $oldFile -> name = $filename;
                $oldFile -> title = $request->title;
                $oldFile -> public_flag = true;
                $oldFile->save();
                */

                $file_id = $userSignature->file_id;
                $stmt = $db->prepare("UPDATE files set file=:file, name=:name, title=:title, updated_by=:userid, updated_at=:date WHERE id=:id");
                $stmt->bindParam(':file', $fp, $db::PARAM_LOB);
                $stmt->bindParam(':name', $filename);
                $stmt->bindParam(':title', $title);
                $stmt->bindParam(':userid', $userid);
                $stmt->bindParam(':date', $date);
                $stmt->bindParam(':id', $file_id);
                $stmt->execute();
                unset($db);

                $signature =  USignature::where('schedule_id', $scheduleId)->first();
                if ($signature->digital_flag == true) {
                    $signature->digital_flag = false;
                    $signature->save();
                }
                // ログ出力
                $this->outputLog(config('constants.logs.data_update'), 'ファイルを入替しました。');
            }
            DB::commit();
            return redirect()->route('result-info.index', ['scheduleId' => $scheduleId]);
        } catch (\Exception $e) {
            // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_insert'), '登録処理で異常終了しました。', $e);
            // 作業実績情報画面に遷移する
            return back();
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $this->processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
