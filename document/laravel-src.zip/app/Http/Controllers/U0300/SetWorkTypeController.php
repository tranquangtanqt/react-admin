<?php

namespace App\Http\Controllers\U0300;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\CodeClass;
use App\Models\UWorkReport;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

use function PHPUnit\Framework\isEmpty;

/**
 * 作業区分設定
 *
 * @author  donlq
 * @create_date  2021-10-27
 */
class SetWorkTypeController extends Controller
{
    /**
     * 作業報告テーブルに変更・新規追加する
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function update(Request $request){
        $validator = Validator::make($request->all(), [
            'value'              => 'required',
            'updatedDate'         => 'date_format:Y-m-d H:i:s'
        ]);

        if($validator->fails()){
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  $validator->errors()->all(),
                'data'      =>  []
            ], 422);
        }
        $workReport=UWorkReport::where('reception_no',$request->receptionNo)->first();
        if ($workReport!=null&&
            $request->updatedDate &&
            $workReport->updated_at?->notEqualTo(Carbon::create($request->updatedDate))
        ){
            return response()
            ->json(['status' => 'NG',
                    'message' => '別のユーザーにて既に更新されています。',
                    'data' => []], 500);
        }

        try {
            if($workReport==null){
                $workType = UWorkReport::create([
                    'reception_no' => $request->receptionNo,
                    'work_type'=>$request->value,
                    'tax_included_flag'=>false,
                ]);
                $workType->save();
            }else if($workReport->work_type != $request->value){
                $workReport->work_type = $request->value;
                $workReport->save();
                session()->flash('success', '作業区分を正常に更新しました。');
                $this->outputLog('作業区分入替', config('constants.logs.data_update'), '作業区分を入替しました。');
            }

        } catch(\Exception $e){
            $this->outputLog('作業区分', config('constants.logs.data_insert'), '作業区分画面登録エラー', $e);

            return response()->json([
                'status' => 'NG',
                'message' => '予期せぬエラーが発生しました。',
                'data' => []
            ], 500);
        }
    }

    /**
     * 該当する作業報告情報を表示します。
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function show($receptionNo){
        $this->outputLog("作業区分アクセス", config('constants.logs.page_access'), '作業区分にアクセスしました');

        try{
            $data = null;
            if($receptionNo != null){
                $data = UWorkReport::select('work_type','updated_at')->where('reception_no',$receptionNo)->first();
            }
            $codeClass = CodeClass::select('key','value')
                ->where('identifier_code', config('constants.codes.work'))
                ->get();
            return response()->json([
                'workType'=>$data==null?'':$data->work_type,
                'codeClasses'=>$codeClass,
                'updatedDate'=>$data==null?Carbon::now()->toDateTimeString():$data->updated_at->toDateTimeString()
                ]
            );
        } catch(\Exception $e){
            return response()->json([
                'status' => 'NG',
                'message' => '予期せぬエラーが発生しました。',
                'data' => []], 500);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
