<?php

namespace App\Http\Controllers\U0300;

use Exception;
use Carbon\Carbon;
use App\Models\UCost;
use App\Commons\Logger;
use App\Models\CodeClass;
use App\Models\UGasInInfo;
use App\Models\UGasOutInfo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

/**
 * 充塡回収情報設定
 *
 * @author  donlq
 * @create_date  2021-10-19
 */
class SetGasInfoController extends Controller
{
    /**
     *  該当する充塡回収情報設定情報を変更します。
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function store(Request $request)
    {
        if (!empty($request->nameGas)) {
            if ($request->nameGas == 'GasInInfo') {
                $validator = Validator::make($request->all(), [
                    'gasType'               => 'required',
                    'type'                  => 'required',
                    'gastypename'           => 'nullable|required_if:gasType,0|regex:/^[a-zA-Z0-9]*$/|max:7',
                    'receptionNo'           => 'required',
                    'quantity'              => 'required|numeric|regex:/^\d{1,3}(\.\d{1,1})?$/',
                    'date'                  => 'required|date_format:Y/m/d',
                ], [
                    'gastypename.required_if' => ':attribute|充塡種類にその他を選択した場合、その種類を右の欄に設定してください。',
                    'gastypename.regex'     =>  ':attribute|充塡種類名は英数字で入力してください。',
                    'quantity.required'     =>   ':attribute|充塡量を設定してください。',
                    'quantity.regex'              => ':attribute|充塡量は整数3桁小数1桁で入力してください。',
                    'quantity.numeric'          => ':attribute|充塡量は整数3桁小数1桁で入力してください。',
                    'date.required'         =>    ':attribute|交付年月日を設定してください。',
                    'date.date_format'         =>    ':attribute|交付年月日の値が日付として扱えません。',
                ]);

                if ($validator->fails()) {
                    return response()->json([
                        'status'    =>  'NG',
                        'message'   =>  $validator->errors()->all(),
                        'data'      =>  []
                    ], 422);
                }
                $groupUpdatedAt = UGasInInfo::where('reception_no', $request->receptionNo)
                    ->first();
                if (
                    ($request->updatedAt &&
                        $groupUpdatedAt->updated_at?->notEqualTo(Carbon::create($request->updatedAt)) || ($request->updatedAt == null && $groupUpdatedAt != null))
                ) {
                    return response()
                        ->json(['status' => 'NG', 'message' => '別のユーザーにて既に更新されています。', 'data' => []], 500);
                }
            } else {
                $validator = Validator::make($request->all(), [
                    'gasType'               => 'required',
                    'type'                  => 'required',
                    'gastypename'           => 'nullable|required_if:gasType,0|regex:/^[a-zA-Z0-9]*$/',
                    'receptionNo'           => 'required',
                    'quantity'              => 'required|numeric|regex:/^\d{1,3}(\.\d{1,1})?$/',
                    'date'                  => 'required|date_format:Y/m/d',
                ], [
                    'gastypename.required_if' => ':attribute|回収種類にその他を選択した場合、その種類を右の欄に設定してください。',
                    'gastypename.regex'     =>  ':attribute|回収種類名は英数字で入力してください。',
                    'quantity.required'     =>   ':attribute|回収量を設定してください。',
                    'quantity.regex'              => ':attribute|回収量は整数3桁小数1桁で入力してください。',
                    'quantity.numeric'          => ':attribute|回収量は整数3桁小数1桁で入力してください。',
                    'date.required'         =>    ':attribute|交付年月日を設定してください。',
                    'date.date_format'         =>    ':attribute|交付年月日の値が日付として扱えません。',
                ]);
                if ($validator->fails()) {
                    return response()->json([
                        'status'    =>  'NG',
                        'message'   =>  $validator->errors()->all(),
                        'data'      =>  []
                    ], 422);
                }
                $groupUpdatedAt = UGasOutInfo::where('reception_no', $request->receptionNo)
                    ->first();
                if (
                    $request->updatedAt &&
                    $groupUpdatedAt->updated_at?->notEqualTo(Carbon::create($request->updatedAt))
                ) {
                    return response()
                        ->json(['status' => 'NG', 'message' => '別のユーザーにて既に更新されています。', 'data' => []], 500);
                }
            }
        } else {
            abort(500);
        }
        try {
            DB::beginTransaction();
            if (!empty($request->nameGas)) {
                // 充填
                if ($request->nameGas == 'GasInInfo') {
                    $gasin = UGasInInfo::where('reception_no', $request->receptionNo)->first();
                    if (!empty($gasin)) {
                        $date = $gasin->date != null ? date('Y/m/d', strtotime($gasin->date)) : null;
                        if (
                            $gasin->type != $request->type ||
                            $gasin->gas_type != $request->gasType ||
                            $gasin->quantity != $request->quantity ||
                            $date != $request->date ||
                            $gasin->gas_type_name != $request->gastypename
                        ) {
                            $gasin->type = $request->type;
                            $gasin->gas_type = $request->gasType;
                            $gasin->quantity = $request->quantity;
                            $gasin->date = $request->date;
                            $gasin->gas_type_name = null;
                            if ($request->gasType == config('constants.fill_type.others')) {
                                $gasin->gas_type_name = $request->gastypename;
                            } else {
                                $uCost = UCost::where('reception_no', $request->receptionNo)
                                    ->where('registered_class', config('constants.cost_reg.fill'))->first();
                                if (empty($uCost)) {
                                    $code = CodeClass::where('identifier_code', config('constants.codes.fill_type'))->where('key', $request->gasType)->first();
                                    $max = UCost::where('reception_no', $request->receptionNo)->max('serial_no');
                                    $max = empty($max) ? 1 : $max + 1;
                                    $uCost = new UCost();
                                    $uCost->serial_no = $max;
                                    $uCost->reception_no = $request->receptionNo;
                                    $uCost->type = config('constants.cost.material');
                                    $uCost->registered_class = config('constants.cost_reg.fill');
                                    $uCost->checked_flag = false;
                                    $uCost->name = $code->value;
                                    $uCost->amount = round($request->quantity * $code->number1, 2);
                                    $uCost->save();
                                }
                            }
                            $gasin->save();
                            $this->outputLog("充填情報更新", config('constants.logs.data_update'), '充塡情報更新しました');
                            session()->flash('success', '充塡情報を正常に更新しました。');
                        }
                    } else {
                        $gasinNew = new UGasInInfo();
                        $gasinNew->reception_no = $request->receptionNo;
                        $gasinNew->type = $request->type;
                        $gasinNew->gas_type = $request->gasType;
                        $gasinNew->quantity = $request->quantity;
                        $gasinNew->date = $request->date;
                        $gasinNew->gas_type_name = null;
                        if ($request->gasType == config('constants.fill_type.others')) {
                            $gasinNew->gas_type_name = $request->gastypename;
                        } else {
                            $uCost = UCost::where('reception_no', $request->receptionNo)
                                ->where('registered_class', config('constants.cost_reg.fill'))->first();
                            if (empty($uCost)) {
                                $code = CodeClass::where('identifier_code', config('constants.codes.fill_type'))->where('key', $request->gasType)->first();
                                $max = UCost::where('reception_no', $request->receptionNo)->max('serial_no');
                                $max = empty($max) ? 1 : $max + 1;
                                $uCost = new UCost();
                                $uCost->serial_no = $max;
                                $uCost->reception_no = $request->receptionNo;
                                $uCost->type = config('constants.cost.material');
                                $uCost->registered_class = config('constants.cost_reg.fill');
                                $uCost->checked_flag = false;
                                $uCost->name = $code->value;
                                $uCost->amount = round($request->quantity * $code->number1, 2);
                                $uCost->save();
                            }
                        }
                        $gasinNew->save();
                        $this->outputLog('充塡情報登録', config('constants.logs.data_insert'), '充塡情報を登録しました');
                        session()->flash('success', '充塡情報を正常に登録しました。');
                    }
                } else { // 回収
                    $gasout = UGasOutInfo::where('reception_no', $request->receptionNo)->first();
                    if (!empty($gasout)) {
                        $date = $gasout->date != null ? date('Y/m/d', strtotime($gasout->date)) : null;
                        if ($gasout->type != $request->type || $gasout->gas_type != $request->gasType || $gasout->quantity != $request->quantity || $date != $request->date || $gasout->gas_type_name != $request->gastypename) {
                            $gasout->type = $request->type;
                            $gasout->gas_type = $request->gasType;
                            $gasout->quantity = $request->quantity;
                            $gasout->date = $request->date;
                            $gasout->gas_type_name = null;
                            if ($request->gasType == config('constants.collect_type.others')) {
                                $gasout->gas_type_name = $request->gastypename;
                            } else {
                                $uCost = UCost::where('reception_no', $request->receptionNo)
                                    ->where('registered_class', config('constants.cost_reg.collect'))->first();
                                if (empty($uCost)) {
                                    $code = CodeClass::where('identifier_code', config('constants.codes.collect_type'))
                                        ->where('key', $request->gasType)->first();
                                    $max = UCost::where('reception_no', $request->receptionNo)->max('serial_no');
                                    $max = empty($max) ? 1 : $max + 1;
                                    $uCost = new UCost();
                                    $uCost->serial_no = $max;
                                    $uCost->reception_no = $request->receptionNo;
                                    $uCost->type = config('constants.cost.material');
                                    $uCost->registered_class = config('constants.cost_reg.collect');
                                    $uCost->checked_flag = false;
                                    $uCost->name = $code->value;
                                    $uCost->amount = round($request->quantity * $code->number1, 2);
                                    $uCost->save();
                                }
                            }

                            $gasout->save();
                            $this->outputLog("回収情報更新", config('constants.logs.data_update'), '回収情報を更新しました');
                            session()->flash('success', '回収情報を正常に更新しました。');
                        }
                    } else {
                        $gasoutNew = new UGasOutInfo();
                        $gasoutNew->reception_no = $request->receptionNo;
                        $gasoutNew->type = $request->type;
                        $gasoutNew->gas_type = $request->gasType;
                        $gasoutNew->quantity = $request->quantity;
                        $gasoutNew->date = $request->date;
                        $gasoutNew->gas_type_name = null;
                        if ($request->gasType == config('constants.collect_type.others')) {
                            $gasoutNew->gas_type_name = $request->gastypename;
                        } else {
                            $uCost = UCost::where('reception_no', $request->receptionNo)
                                ->where('registered_class', config('constants.cost_reg.collect'))->first();
                            if (empty($uCost)) {
                                $code = CodeClass::where('identifier_code', config('constants.codes.collect_type'))
                                    ->where('key', $request->gasType)->first();
                                $max = UCost::where('reception_no', $request->receptionNo)->max('serial_no');
                                $max = empty($max) ? 1 : $max + 1;
                                $uCost = new UCost();
                                $uCost->serial_no = $max;
                                $uCost->reception_no = $request->receptionNo;
                                $uCost->type = config('constants.cost.material');
                                $uCost->registered_class = config('constants.cost_reg.collect');
                                $uCost->checked_flag = false;
                                $uCost->name = $code->value;
                                $uCost->amount = round($request->quantity * $code->number1, 2);
                                $uCost->save();
                            }
                        }
                        $gasoutNew->save();
                        $this->outputLog('回収情報登録', config('constants.logs.data_insert'), '回収情報を登録しました');
                        session()->flash('success', '回収情報を正常に登録しました。');
                    }
                }
            }
            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            $this->outputLog('充塡回収情報アクセス', config('constants.logs.data_insert'), '予期せぬエラーが発生しました。', $th);
            return response()->json(['status' => 'NG', 'message' => '予期せぬエラーが発生しました。', 'data' => []], 500);
        }
    }
    /**
     * 該当する充塡回収情報設定情報を表示します。
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function show(Request $request)
    {
        $this->outputLog("充塡回収情報アクセス", config('constants.logs.page_access'), '充塡回収情報にアクセスしました');

        try {
            if ($request->nameGasInfo == "GasInInfo") {
                $gasInfo = UGasInInfo::select('gas_type', 'gas_type_name', 'quantity', 'reception_no', 'type', 'date', 'updated_at')->where('reception_no', $request->receptionNo)->first();
                if (!empty($gasInfo)) {
                    $gasInfo->dateConvert = $gasInfo->date->toDateTimeString();
                }
                $codeClassType = CodeClass::select('key', 'value')->where('identifier_code', config('constants.codes.fill'))->orderBy('display_order')->get();
                $codeClassGasType = CodeClass::select('key', 'value')->where('identifier_code', config('constants.codes.fill_type'))->orderBy('display_order')->get();
            } else {
                $gasInfo = UGasOutInfo::select('gas_type', 'gas_type_name', 'quantity', 'reception_no', 'type', 'date', 'updated_at')->where('reception_no', $request->receptionNo)->first();
                if (!empty($gasInfo)) {
                    $gasInfo->dateConvert = $gasInfo->date->toDateTimeString();
                }
                $codeClassType = CodeClass::select('key', 'value')->where('identifier_code', config('constants.codes.collect'))->orderBy('display_order')->get();
                $codeClassGasType = CodeClass::select('key', 'value')->where('identifier_code', config('constants.codes.collect_type'))->orderBy('display_order')->get();
            }

            return response()->json(
                ['gasInfo' => $gasInfo, 'codeClassType' => $codeClassType, 'codeClassGasType' => $codeClassGasType, 'updatedAt' => $gasInfo == null ? '' : $gasInfo->updated_at->toDateTimeString()]
            );
        } catch (\Throwable $th) {
            return response()->json(['status' => 'NG', 'message' => '予期せぬエラーが発生しました。', 'data' => []], 500);
        }
    }
    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
