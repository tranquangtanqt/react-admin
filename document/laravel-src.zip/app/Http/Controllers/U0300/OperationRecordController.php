<?php

namespace App\Http\Controllers\U0300;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\UDevice;
use App\Models\UOperationRecord;
use App\Models\UReception;

class OperationRecordController extends Controller
{
    /**
     * 全ての運転記録のデータを表示します。
     *
     */
    public function show($receptionNo)
    {
        $reception = UReception::findOrFail($receptionNo);
        // ログ出力
        $this->outputLog('運転記録設定アクセス',config('constants.logs.page_access'),'運転記録設定にアクセスしました。');
        $operationRecords = UReception::join('u_devices', 'u_devices.reception_no', '=', 'u_receptions.no')
                            ->leftjoin('u_operation_records', 'u_operation_records.device_id', '=', 'u_devices.id')
                            ->leftjoin('u_groups', 'u_groups.id', '=', 'u_devices.group_id')
                            ->where('u_groups.deleted_at', null)
                            ->where('u_devices.deleted_at', null)
                            ->where('u_operation_records.deleted_at', null)
                            ->where('u_receptions.no', $receptionNo)
                            ->orderBy('u_groups.name', 'ASC')
                            ->orderBy('device_type', 'ASC')
                            ->orderBy('device_no', 'ASC')
                            ->get(['u_operation_records.*',
                                   'u_devices.id as device_id',
                                   'u_devices.device_type',
                                   'u_devices.device_no',
                                   'u_groups.name as group_name']);
        return view('U0300.OperationRecord',compact(['operationRecords','receptionNo', 'reception']));
    }
    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName,$processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
