<?php

namespace App\Http\Controllers\U0300;

use Exception;
use App\Models\Auth;
use App\Models\User;
use App\Models\USlot;
use App\Commons\Logger;
use App\Models\CodeClass;
use App\Models\USchedule;
use App\Models\UReception;
use Illuminate\Http\Request;
use App\Models\UScheduleUser;
use Illuminate\Support\Carbon;
use App\Models\UScheduleDetail;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\U0300\StoreScheduleRequest;
use App\Http\Requests\U0300\UpdateScheduleRequest;

class SetScheduleController extends Controller
{
    /**
     * 新規日程の登録
     *
     * @return \Illuminate\View\View
     */
    public function create(Request $request, UReception $reception)
    {
        // 追加・編集できる権限持っているか
        $canCreateOrUpdate = $request->user()->can('createOrUpdateSchedule', $reception);

        // 更新または追加権限がない場合
        if (!$canCreateOrUpdate) {
            // ログ登録
            $this->createLog($reception->no, 'access', 'error', ['content_detail' => '権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'init_date' => 'nullable|date',
        ], );

        // バリデーション失敗の時初期日付を設定
        if ($validator->fails()) {
            $initDate = now();
        } else {
            $initDate = Carbon::parse($request->init_date);
        }

        // 初期ユーザID
        $initUserId = $request->has('init_user_id') ? $request->init_user_id : null;

        // アクセスログ登録
        $this->createLog($reception->no, 'access');

        // 訪問担当のリスト
        $persons = $this->getPersons('add');

        // 時間帯区分
        $slots = CodeClass::getSlots();

        // モード
        $mode = 'add';

        // 計上担当設定？
        $shouldSetPjMgr = $request->user()->can('setPjMgrViaSchedule', $reception);

        // 計上担当者ユーザ
        $pjMgrUsers = $shouldSetPjMgr ? $this->getPjmgrUsers() : collect([]);

        // 計上担当初期ユーザID
        if ($shouldSetPjMgr && $initUserId) {
            $initPjMgrId = $pjMgrUsers->firstWhere('id')?->id;
        } else {
            $initPjMgrId = null;
        }

        return view('U0300.SetSchedule', compact([
            'persons', // 訪問担当者
            'slots', // 時間帯
            'mode', // モード
            'reception', // 受付情報
            'initUserId', // 初期ユーザID
            'initDate', // 初期日付
            'shouldSetPjMgr', // 計上担当設定フラグ
            'pjMgrUsers', // 計上担当ユーザ
            'initPjMgrId', // 初期計上担当ユーザID
        ]));
    }

    /**
     * 新規日程の登録
     *
     * @return \Illuminate\View\View
     */
    public function store(StoreScheduleRequest $request, UReception $reception)
    {

        // 追加・編集できる権限持っているか
        $canCreateOrUpdate = $request->user()->can('createOrUpdateSchedule', $reception);

        // 更新または追加権限がない場合
        if (!$canCreateOrUpdate) {
            // ログ登録
            $this->createLog($reception->no, 'access', 'error', ['content_detail' => '権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        // バリデーション
        $validData = $request->validated();

        // 同じ日付で訪問登録できない
        $existingSchedules = $reception->schedules()->whereDate('date', Carbon::parse($validData['add_schedule_date']))->get();

        if ($existingSchedules->isNotEmpty()) {
            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '指定した日付にて訪問予定が既に登録されています。']), 422);
        }

        // トランザクション開始
        DB::beginTransaction();
        try {

            // 計上担当設定された場合
            if (!$reception->eff_eff_pjmgr_id && (isset($validData['pjmgr_id']) && $validData['pjmgr_id'])) {
                $reception->pjmgr_user_id = $validData['pjmgr_id'];
                $reception->save();
                $pjMgrUpdateMessage = '訪問予定と計上担当を正常に登録しました。';
            }

            // 新規訪問予定登録処理実行
            $this->addSchedule($validData, $reception);

            DB::commit(); // コミット

            // ログ登録
            $this->createLog($reception->no, 'insert');

            $message =  '訪問予定を正常に登録しました。';

            // 成功メッセージ
            session()->flash('success', $pjMgrUpdateMessage ?? $message );
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // 成功メッセージ返す
            return response()->json(['success' => $pjMgrUpdateMessage ?? $message], 200);
        } catch (Exception $e) {

            DB::rollBack(); // ロルバック

            // 登録失敗ログ
            $this->createLog($reception->no, 'insert', 'error', ['content_detail' => $e]);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '訪問予定登録に失敗しました。再度登録してください。']), 500);
        }
    }

    /**
     * 日程編集モーダル取得
     *
     * @return \Illuminate\View\View
     */
    public function show($schedule)
    {
        // 日程取得
        $schedule = $this->getSchedule($schedule);

        // 担当者取得
        $persons = $this->getPersons('read', $schedule);

        // 時間帯区分
        $slots = CodeClass::getSlots();

        return view('U0300.ViewSchedule', compact([
            'schedule', //日程
            'persons', // 訪問担当者
            'slots', // 時間帯
        ]));
    }

    /**
     * 日程編集モーダル取得
     *
     * @return \Illuminate\View\View
     */
    public function edit(Request $request, USchedule $schedule)
    {
        // 受付情報
        $reception = $schedule->reception;

        // 追加・編集できる権限持っているか
        $canCreateOrUpdate = $request->user()->can('createOrUpdateSchedule', $reception);

        // 更新または追加権限がない場合
        if (!$canCreateOrUpdate) {
            // ログ登録
            $this->createLog($reception->no, 'access', 'error', ['content_detail' => '権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        // アクセスログ登録
        $this->createLog($reception->no, 'access');

        // 担当者取得
        $persons = $this->getPersons('edit', $schedule);

        // 時間帯区分
        $slots = CodeClass::getSlots();

        // モード
        $mode = 'edit';

        return view('U0300.SetSchedule', compact([
            'reception', // 受付情報
            'schedule', // 日程
            'persons', // 訪問担当者
            'slots', // 時間帯
            'mode', // 編集モード
        ]));
    }

    /**
     * 日程編集処理
     *
     * @return JsonResponse
     */
    public function update(UpdateScheduleRequest $request, USchedule $schedule)
    {
        // 受付情報
        $reception = $schedule->reception;

        // 追加・編集できる権限持っているか
        $canCreateOrUpdate = $request->user()->can('createOrUpdateSchedule', $reception);

        // 更新または追加権限がない場合
        if (!$canCreateOrUpdate) {
            // ログ登録
            $this->createLog($reception->no, 'update', 'error', ['content_detail' => '権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        $validData = $request->validated();

        // 同じ日付で訪問変更できない
        $existingSchedules = $reception->schedules()
            ->whereDate('date', Carbon::parse($validData['edit_schedule_date']))
            ->where('id', '<>', $schedule->id)
            ->get();

        if ($existingSchedules->isNotEmpty()) {
            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '指定した日付にて訪問予定が既に登録されています。']), 422);
        }

        // 別のユーザが更新した場合の制御
        $updateAtFromInput = $validData['edit_updated_at'];
        if ($schedule->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))) {
            return response()->json(addMessages(['general_error_message' => '別のユーザにて既に更新されています。']), 422);
        }

        // 更新処理を行う
        // トランザクション開始
        DB::beginTransaction();
        try {

            // 訪問予定更新処理実行
            $this->updateSchedule($validData, $schedule);

            // コミット
            DB::commit();

            // 更新失敗ログ
            $this->createLog($reception->no, 'update');

            // 成功メッセージ
            $successMessage = '訪問予定を正常に更新しました。';
            session()->flash('success', $successMessage);
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように
            // 成功メッセージ返す
            return response()->json(['success' => $successMessage], 200);
        } catch (Exception $e) {

            // ロルバック
            DB::rollBack();

            // 更新失敗ログ
            $this->createLog($reception->no, 'update', 'error', ['content_detail' => $e]);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '訪問予定更新に失敗しました。再度編集してください。']), 500);
        }
    }

    /**
     * 日程削除処理
     *
     * @return JsonResponse
     */
    public function delete(Request $request, USchedule $schedule)
    {

        // 受付情報
        $reception = $schedule->reception;

        // 追加・編集できる権限持っているか
        $canDelete = $request->user()->can('deleteSchedule', $reception);

        // 更新または追加権限がない場合
        if (!$canDelete) {
            // ログ登録
            $this->createLog($reception->no, 'delete', 'error', ['content_detail' => '権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        // バリデータ作成
        $validator = Validator::make($request->all(), [
            'updated_at' => ['required', 'date'],
        ]);

        // バリデーション失敗場合
        if ($validator->fails()) {
            return response()->json(addMessages(['general_error_message' => '訪問予定削除に失敗しました。再度削除してください。']), 422);
        }

        // バリデーション結果データ
        $validData = $validator->validated();

        // 別のユーザが更新した場合の制御
        $updateAtFromInput = $validData['updated_at'];
        if ($schedule->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))) {
            return response()->json(addMessages(['general_error_message' => '別のユーザにて既に更新されています。']), 422);
        }

        // 削除処理
        DB::beginTransaction();
        try {

            // 訪問予定削除処理
            $this->deleteSchedule($schedule);

            DB::commit(); // 例外がない場合、コミット

            // 削除成功ログ
            $this->createLog($reception->no, 'delete');

            // 成功メッセージ
            $successMessage = '訪問予定を正常に削除しました。';
            session()->flash('success', $successMessage);
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // 成功メッセージ返す
            return response()->json(['success' => $successMessage], 200);
        } catch (Exception $e) {

            DB::rollBack(); // 例外が発生したら、ロルバック

            // 削除失敗ログ
            $this->createLog($reception->no, 'delete', 'error', ['content_detail' => $e]);
            return response()->json(addMessages(['general_error_message' => '訪問予定削除に失敗しました。再度削除してください。']), 422);
        }
    }

    /**
     * 日程取得
     *
     * @return \App\Models\USchedule
     */
    private function getSchedule($id)
    {
        return USchedule::with('scheduleDetails')->find($id);
    }

    /**
     * 担当者取得
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    private function getPersons(string $mode, USchedule $schedule = null)
    {
        // $modeは'edit'と'read'のみ
        if (!collect(['add', 'edit', 'read'])->contains($mode)) {
            throw new Exception("Only 'add', 'edit' or 'read' mode is allowed.");
        }

        // 訪問担当のリスト
        return User::where(function ($query) use ($schedule, $mode) {
            $query->when(collect(['read', 'edit'])->contains($mode), function ($query) use ($schedule) {
                $query->whereIn('id', function ($query) use ($schedule) { // 日程の担当
                    $query->select('user_id')
                        ->from('u_schedule_users')
                        ->where('schedule_id', $schedule->id)
                        ->whereNull('deleted_at');
                });
            })
                ->when(collect(['add', 'edit'])->contains($mode), function ($query) { // addとeditモードの場合全て訪問担当持っているユーザを含める
                    $query->orWhereHas('auths', function ($query) { // 訪問担当権限持っている
                        $query->whereIn('auth_class', [
                            config('constants.auth.pic'),
                            config('constants.auth.pic_external'),
                        ]);
                    });
                });
        })
            ->addSelect([
                'is_external' => Auth::selectRaw('true as is_external')
                    ->whereColumn('user_id', 'users.id')
                    ->where('auth_class', config('constants.auth.pic_external'))
                    ->limit(1),
            ])
            ->orderBy('is_external', 'desc')
            ->orderBy('short_name')
            ->get();
    }

    /**
     * ユーザinputより選択された担当者及び時間帯を取得
     *
     * @param array $personSlotInput バリデーション結果より
     *
     * @return Illuminate\Support\Collection
     */
    private function getSelectedPersonsSlots(array $personSlotInput)
    {
        return collect($personSlotInput)->filter(function ($person) {
            return collect($person)->has('slots');
        });
    }

    /**
     * ユーザinputより選択された時間帯を取得
     *
     * @param Illuminate\Support\Collection $selectedPersonSlots
     *
     * @return Illuminate\Support\Collection
     * [['slot_type' => 1], ['slot_type' => 2], ... ]のような形に変換する
     */
    private function getSelectedSlots($selectedPersonSlots)
    {
        return $selectedPersonSlots->map(function ($item) {
            return collect($item['slots'])->map(fn($slot, $key) => ['slot_type' => $key])->toArray();
        })->flatMap(fn($item) => $item)->unique('slot_type');
    }

    /**
     * ユーザinputより選択された担当者を取得
     *
     * @param Illuminate\Support\Collection $selectedPersonSlots
     *
     * @return Illuminate\Support\Collection
     * [['user_id' => 1], ['user_id' => 2], ...]のような形に変換する
     */
    private function getSelectedPersons($selectedPersonSlots)
    {
        return $selectedPersonSlots->map(fn($item) => ['user_id' => $item['id']]);
    }

    /**
     * ユーザinputより選択された担当者詳細を取得
     *
     * @param Illuminate\Support\Collection $selectedPersonSlots
     *
     * @return Illuminate\Support\Collection
     * [['user_id' => 1, 'slot_type' => 1], ['user_id' => 1, 'slot_type' => 2], ... ] のような形に変換する
     */
    private function getSelectedDetails($selectedPersonSlots)
    {
        return $selectedPersonSlots->map(function ($item) {
            $userId = $item['id'];
            return collect($item['slots'])->map(function ($slot, $key) use ($userId) {
                return ['user_id' => $userId, 'slot_type' => $key];
            });
        })->flatMap(fn($item) => $item);
    }

    /**
     * 新規訪問予定登録処理実行
     *
     * @param array $validData
     * @param \App\Models\UReception $reception
     *
     * @return void
     */
    private function addSchedule(array $validData, UReception $reception)
    {
        // 日程登録
        $schedule = USchedule::create([
            'date' => $validData['add_schedule_date'], // 日付
            'schedule_type' => config('constants.pe_schedule.visit'), // 予定区分
            'reception_no' => $reception->no, // 受付情報番号
            'content' => $validData['add_schedule_content'], // 日程詳細（内容）
        ]);

        // 選択された担当者
        $selectedPersonSlots = $this->getSelectedPersonsSlots($validData['add_schedule_persons']);

        // 時間帯登録 //  [['slot_type' => 1], ['slot_type' => 2], ... ]のような形に変換する
        $selectedSlots = $this->getSelectedSlots($selectedPersonSlots);

        // 日程テーブルに登録
        $schedule->slots()->createMany($selectedSlots);

        // 日程担当登録 // [['user_id' => 1], ['user_id' => 2], ...]のような形に変換する
        $selectedPersons = $this->getSelectedPersons($selectedPersonSlots);

        // 日程担当テーブル登録
        $schedule->scheduleUsers()->createMany($selectedPersons);

        // 日程担当詳細登録 // [['user_id' => 1, 'slot_type' => 1], ['user_id' => 1, 'slot_type' => 2], ... ] のような形に変換する
        $selectedDetails = $this->getSelectedDetails($selectedPersonSlots);

        // 日程担当詳細テーブル登録
        $schedule->scheduleDetails()->createMany($selectedDetails);

        // 受付状態更新
        $status = $reception->status;
        if (collect([
            config('constants.status.new'),
            config('constants.status.on_hold'),
            config('constants.status.visited'),
        ])->contains($status->status_type)) {
            $status->addToHistory(); // 履歴を登録
            $status = $status->setStatus(config('constants.status.will_visit')); //訪問予定に
            $status->save();
        }
    }

    /**
     * 訪問予定更新処理実行
     *
     * @param array $validData
     * @param \App\Models\USchedule $schedule
     *
     * @return void
     */
    private function updateSchedule(array $validData, USchedule $schedule)
    {
        // 日程登録
        $schedule->date = $validData['edit_schedule_date']; // 日付
        $schedule->content = $validData['edit_schedule_content']; // 日程詳細（内容）
        $schedule->save();

        // 選択された担当者
        $selectedPersonSlots = $this->getSelectedPersonsSlots($validData['edit_schedule_persons']);

        // ①時間帯更新 ----------------

        // リクエストよりの時間帯 //  [['slot_type' => 1], ['slot_type' => 2], ... ]のような形に変換する
        $inputSelectedSlots = $this->getSelectedSlots($selectedPersonSlots);

        // 時間帯テーブルのレコード(DB)
        $currentSlots = $schedule->slots;

        // 削除される予定の時間帯（リクエストにない時間帯）
        $tobeDeletedSlots = $currentSlots->whereNotIn('slot_type', $inputSelectedSlots->pluck('slot_type'));

        // 選択されないようになった時間帯削除
        USlot::whereIn('id', $tobeDeletedSlots->pluck('id'))->forceDelete();

        // 登録される予定の時間帯（DBにない時間帯）
        $tobeInsertedSlots = $inputSelectedSlots->whereNotIn('slot_type', $currentSlots->pluck('slot_type'));

        // 新時間帯の時間帯をテーブルに登録
        $schedule->slots()->createMany($tobeInsertedSlots);

        // ②日程担当更新 ----------------

        // リクエストよりの日程担当 // [['user_id' => 1], ['user_id' => 2], ...]のような形に変換する
        $inputSelectedPersons = $this->getSelectedPersons($selectedPersonSlots);

        // 日程担当テーブルのレコード(DB)
        $currentPersons = $schedule->scheduleUsers;

        // 削除される予定の日程担当（リクエストにない担当者）
        $tobeDeletedPersons = $currentPersons->whereNotIn('user_id', $inputSelectedPersons->pluck('user_id'));

        // 選択されないようになった日程担当削除
        UScheduleUser::whereIn('id', $tobeDeletedPersons->pluck('id'))->forceDelete();

        // 登録される予定の日程担当（DBにない日程担当）
        $tobeInsertedPersons = $inputSelectedPersons->whereNotIn('user_id', $currentPersons->pluck('user_id'));

        // 日程担当テーブルに登録
        $schedule->scheduleUsers()->createMany($tobeInsertedPersons); // 日程担当テーブル登録

        // ③日程担当詳細更新 ----------------

        // リクエストよりの日程担当詳細  // [['user_id' => 1, 'slot_type' => 1], ['user_id' => 1, 'slot_type' => 2], ... ] のような形に変換する
        $inputSelectedDetails = $this->getSelectedDetails($selectedPersonSlots);

        // 日程担当詳細テーブルのレコード(DB)
        $currentScheduleDetails = $schedule->scheduleDetails;

        // 削除される予定の日程担当詳細（リクエストにない担当者）
        $tobeDeletedPersonDetails = $currentScheduleDetails->filter(function ($person) use ($inputSelectedDetails) {
            return !$inputSelectedDetails->contains(function ($input) use ($person) {
                return $person->user_id == $input['user_id'] && $person->slot_type == $input['slot_type']; // $inputSelectedDetailsにないレコードを取得
            });
        });

        // 日程担当詳細削除
        UScheduleDetail::whereIn('id', $tobeDeletedPersonDetails->pluck('id'))->forceDelete();

        // 登録される予定の日程担当詳細（DBにない日程担当詳細）
        $tobeInsertedPersonDetails = $inputSelectedDetails->filter(function ($person) use ($currentScheduleDetails) {
            return !$currentScheduleDetails->contains(function ($current) use ($person) {
                return $person['user_id'] == $current->user_id && $person['slot_type'] == $current->slot_type;
            });
        });

        // 日程担当詳細テーブルに登録
        $schedule->scheduleDetails()->createMany($tobeInsertedPersonDetails); // 日程担当詳細テーブル登録
    }

    /**
     * 訪問予定削除処理
     *
     * @param USchedule $schedule
     * @return void
     */
    private function deleteSchedule(USchedule $schedule)
    {

        // 受付情報
        $reception = $schedule->reception;

        // 受付状態
        $status = $reception->status;

        // 受付情報に対する実績入力済の訪問予定
        $completeSchedules = $reception->completeSchedules;

        // 実績入力済の場合
        if ($schedule->hasCompleteResult()) {

            // 入力済の訪問が自分自身のみの場合かつ現在状態が訪問済
            if (
                $completeSchedules->count() == 1 &&
                $completeSchedules->first()->id == $schedule->id &&
                $status->status_type == config('constants.status.visited')
            ) {
                // 受付状態履歴を作成
                $status->addToHistory();

                // 状態区分を保留にする
                $status = $status->setStatus(config('constants.status.on_hold'), [
                    'status_detail_type' => config('constants.status_detail.self_scheduling'),
                    'remind_date' => null,
                    'remind_memo' => null,
                ]);

                // 状態保存
                $status->save();
            }
        } else { // 実績入力未完了の場合

            // 受付情報に対する実績入力未完了の訪問予定
            $incompleteSchedules = $reception->incompleteSchedules;

            // 実績入力未完了の訪問が自分自身のみの場合
            if (
                $incompleteSchedules->count() == 1 &&
                $incompleteSchedules->first()->id == $schedule->id
            ) {

                // 最新履歴状態
                $lastStatusType = $status->latestHistory->status_type;

                switch ($lastStatusType) {
                    case config('constants.status.on_hold'): // 前回の状態が[保留]（履歴から）
                        // 履歴より復活する
                        $status->restoreFromHistory();
                        break;
                    case config('constants.status.visited'): // 前回の状態が[訪問済]（履歴から）
                        if ($completeSchedules->count() >= 1) {
                            // 履歴より復活する
                            $status->restoreFromHistory();
                        } else {
                            // 状態区分を保留にする
                            $status = $status->setStatus(config('constants.status.on_hold'), [
                                'status_detail_type' => config('constants.status_detail.self_scheduling'),
                                'remind_date' => null,
                                'remind_memo' => null,
                            ]);
                            // 状態保存
                            $status->save();
                        }
                        break;
                    case config('constants.status.new'): // 前回の状態が[新規受付]（履歴から）
                        if ($completeSchedules->count() >= 1) {
                            // 状態区分を訪問済にする
                            $status = $status->setStatus(config('constants.status.visited'));
                            // 状態保存
                            $status->save();
                        } else {
                            // 履歴より復活する
                            $status->restoreFromHistory();
                        }
                        break;
                }
            }
        }

        $schedule->delete(); // 削除処理を行う
    }
    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $receptionNo,
        string $mode,
        string $status = 'success',
        array $options = ['content_detail' => null]
    ) {
        // $modeは'access', 'update', 'delete', 'insert'のみ
        if (!collect(['access', 'update', 'delete', 'insert'])->contains($mode)) {
            throw new Exception("Only 'access', 'update', 'delete', or 'insert' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        // ログタイプ
        $types = [
            'access' => config('constants.logs.page_access'),
            'update' => config('constants.logs.data_update'),
            'delete' => config('constants.logs.data_delete'),
            'insert' => config('constants.logs.data_insert'),
        ];

        // 処理名
        $names = [
            'access' => '受付訪問予定設定画面アクセス',
            'update' => '受付訪問予定更新',
            'delete' => '受付訪問予定削除',
            'insert' => '受付訪問予定追加',
        ];

        // 内容
        $contents = [
            'access' => [
                'success' => "受付{$receptionNo}の訪問予定設定画面をアクセスしました。",
                'error' => "受付{$receptionNo}の訪問予定設定画面のアクセスに失敗しました。",
            ],
            'update' => [
                'success' => "受付{$receptionNo}の訪問予定更新に成功しました。",
                'error' => "受付{$receptionNo}の訪問予定更新に失敗しました。",
            ],
            'delete' => [
                'success' => "受付{$receptionNo}の訪問予定削除に成功しました。",
                'error' => "受付{$receptionNo}の訪問予定削除に失敗しました。",
            ],
            'insert' => [
                'success' => "受付{$receptionNo}の訪問予定登録に成功しました。",
                'error' => "受付{$receptionNo}の訪問予定登録に失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'],
        ]);
    }

    /**
     * 計上担当ユーザ取得
     *
     * @return User
     */
    private function getPjmgrUsers()
    {
        return User::whereHas('auths', function ($query) { // 担当権限持っている
            $query->whereIn('auth_class', [
                config('constants.auth.pic'),
            ]);
        })
            ->orderBy('short_name')
            ->get();
    }
}
