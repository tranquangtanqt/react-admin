<?php

namespace App\Http\Controllers\U0300;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\USchedule;
use Illuminate\Support\Facades\DB;

/**
 * 作業実績情報
 */
class ResultInfoController extends Controller
{
    /**
     * 該当する作業実績情報情報を表示します。
     */
    public function index($scheduleId, $visited = null)
    {
        $schedule = USchedule::findOrFail($scheduleId);

        // 権限チェック
        $this->authorize('viewResult', $schedule);

        // 時間帯
        $slots = DB::table('u_schedules')
            ->join('u_slots', 'u_schedules.id', 'u_slots.schedule_id')
            ->join('code_classes', function ($join) {
                $join->on('u_slots.slot_type', '=', 'code_classes.key')
                    ->where('code_classes.identifier_code', '=', config('constants.codes.slot'));
            })
            ->where('u_schedules.id', $scheduleId)
            ->select('u_slots.slot_type', 'code_classes.value as slot_name')
            ->get();

        // 訪問担当ユーザ
        $users = DB::table('u_schedules')
            ->join('u_schedule_users', 'u_schedules.id', 'u_schedule_users.schedule_id')
            ->join('users', 'users.id', 'u_schedule_users.user_id')
            ->leftJoin('files', function ($join) {
                $join->on('files.id', '=', 'users.file_id')
                    ->where('files.deleted_at', null);
            })
            ->where('u_schedules.id', $scheduleId)
            ->select('users.short_name', 'users.file_id', 'files.file', 'users.name')
            ->get();

        // ＫＹポイント
        $workResult = DB::table('u_schedules')
            ->join('u_work_results', function ($join) {
                $join->on('u_schedules.id', '=', 'u_work_results.schedule_id')
                    ->whereNull('u_work_results.deleted_at');
            })
            ->join('code_classes', function ($join) {
                $join->on('u_work_results.ky_point_type', '=', 'code_classes.key')
                    ->where('code_classes.identifier_code', '=', config('constants.codes.ky'));
            })
            ->where('u_schedules.id', $scheduleId)
            ->where('u_work_results.deleted_at', null)
            ->select('u_work_results.ky_point_type', 'code_classes.value as ky_point_name', 'u_work_results.one_point')
            ->first();

        // 系統, 機種, 機番, 作業内容
        $workResultDetails = DB::table('u_schedules')
            ->join('u_work_result_details', function ($join) {
                $join->on('u_schedules.id', '=', 'u_work_result_details.schedule_id')
                    ->whereNull('u_work_result_details.deleted_at');
            })
            ->join('u_devices', function ($join) {
                $join->on('u_devices.id', '=', 'u_work_result_details.device_id')
                    ->whereNull('u_devices.deleted_at');
            })
            ->leftJoin('u_groups', function ($join) {
                $join->on('u_groups.id', '=', 'u_devices.group_id')
                    ->whereNull('u_groups.deleted_at');
            })
            ->where('u_schedules.id', $scheduleId)
            ->where('u_work_result_details.deleted_at', null)
            ->where('u_devices.deleted_at', null)
            ->select('u_groups.name', 'u_devices.device_type', 'u_devices.device_no', 'u_work_result_details.work_detail')
            ->get();

        $manhours = DB::table('u_schedules')
            ->join('u_man_hours', function ($join) {
                $join->on('u_schedules.id', 'u_man_hours.schedule_id')
                    ->whereNull('u_man_hours.deleted_at');
            })
            ->join('users', 'users.id', 'u_man_hours.user_id')
            ->leftJoin('files', function ($join) {
                $join->on('files.id', '=', 'users.file_id')
                    ->where('files.deleted_at', null);
            })
            ->leftJoin('code_classes as cls1', function ($join) {
                $join->on('u_man_hours.work_class', '=', 'cls1.key')
                    ->where('cls1.identifier_code', '=', config('constants.codes.l2_work'));
            })
            ->leftJoin('code_classes as cls2', function ($join) {
                $join->on('u_man_hours.work_type', '=', 'cls2.key')
                    ->where('cls2.identifier_code', '=', config('constants.codes.l2_work_class'));
            })
            ->leftJoin('code_classes as cls3', function ($join) {
                $join->on('u_man_hours.work_detail', '=', 'cls3.key')
                    ->where('cls3.identifier_code', '=', config('constants.codes.l2_work_detail'));
            })
            ->leftJoin('code_classes as cls4', function ($join) {
                $join->on('u_man_hours.coop_type', '=', 'cls4.key')
                    ->where('cls4.identifier_code', '=', config('constants.codes.coop'));
            })
            ->where('u_schedules.id', $scheduleId)
            ->where('u_man_hours.deleted_at', null)
            ->where('users.deleted_at', null)
            ->select('u_schedules.date', 'u_man_hours.id', 'u_man_hours.start_time', 'u_man_hours.end_time', 'u_man_hours.user_id',
                'users.short_name as short_name', 'users.name as name', 'files.file', 'u_man_hours.man_hour',
                'cls1.value as work_class', 'cls2.value as work_type', 'cls3.value as work_detail',
                'u_man_hours.work_content', 'cls4.value as coop_type', 'u_man_hours.schedule_id')
            ->orderBy('u_man_hours.id')
            ->get();

        $signature = DB::table('u_schedules')
            ->join('u_signatures', 'u_schedules.id', 'u_signatures.schedule_id')
            ->join('files', 'files.id', 'u_signatures.file_id')
            ->where('u_schedules.id', $scheduleId)
            ->where('u_signatures.deleted_at', null)
            ->where('files.deleted_at', null)
            ->select('u_signatures.id', 'u_signatures.file_id', 'u_signatures.digital_flag', 'u_signatures.signed_at', 'files.file', 'files.title')
            ->first();

        $status = DB::table('u_schedules')
            ->join('u_receptions', 'u_receptions.no', 'u_schedules.reception_no')
            ->join('u_statuses', 'u_receptions.no', 'u_statuses.reception_no')
            ->leftJoin('code_classes', function ($join) {
                $join->on('u_statuses.status_type', '=', 'code_classes.key')
                    ->where('code_classes.identifier_code', '=', config('constants.codes.status'));
            })
            ->where('u_schedules.id', $scheduleId)
            ->select('code_classes.key as status_type', 'code_classes.value')
            ->first();

        $displayControl = array(
            "reception_status" => false,
            "reception_status_delete" => true, //display button 削除
            "reception_status_visited" => '0', // show popup change status
        );

        if ($status) {
            if ($status->status_type != config('constants.status.work_done') &&
                $status->status_type != config('constants.status.checked') &&
                $status->status_type != config('constants.status.completed')) {
                $displayControl['reception_status'] = true;
            }

            // 受付状態 = 作業完了: システム管理者、業務責任者の権限を除き、戻る以外のボタンは非表示
            if ($status->status_type == config('constants.status.work_done') && (userIsSystemAdmin() || userIsManager())) {
                $displayControl['reception_status'] = true;
                $displayControl['reception_status_delete'] = false;
            }

            // 受付状態 = チェック済/受付完了: システム管理者の権限を除き、戻る以外のボタンは非表示。
            if (($status->status_type == config('constants.status.checked') || $status->status_type == config('constants.status.completed'))
                && userIsSystemAdmin()) {
                $displayControl['reception_status'] = true;
            }

            if ($visited != null && $visited == '1') {
                //  受付状態 = 訪問済み
                if ($status->status_type == config('constants.status.visited')) {
                    $displayControl['reception_status_visited'] = '1';
                }
            }
        }

        $flgAuth = array(
            'accountant' => false, // 3.計上担当
            'visiter' => false, // 4.訪問担当
            'visiter-cooperating-company' => false, //5.訪問担当（協力会社）
            'any' => false,
        );

        $auth = DB::table('auths')
            ->where('user_id', auth()->user()->id)
            ->first();

        if ($auth != null) {
            $flgAuth['any'] = true;
        }

        // 計上担当
        $l2_receptions = DB::table('l2_receptions')
            ->join('u_receptions', 'l2_receptions.no', 'u_receptions.no')
            ->where('l2_receptions.no', $schedule->reception_no)
            ->select('l2_receptions.no', 'l2_receptions.person_emp_code', 'u_receptions.pjmgr_user_id')
            ->first();

        if ($l2_receptions->person_emp_code) {
            if ($l2_receptions->person_emp_code == auth()->user()->external_user_id) {
                $flgAuth['accountant'] = true;
            }
        } else {
            if ($l2_receptions->pjmgr_user_id) {
                if ($l2_receptions->pjmgr_user_id == auth()->user()->id) {
                    $flgAuth['accountant'] = true;
                }
            }
        }

        // 訪問担当 / 訪問担当（協力会社）
        $scheduleUsers = DB::table('u_schedule_users')
            ->where('schedule_id', $scheduleId)
            ->where('user_id', auth()->user()->id)
            ->first();

        if ($scheduleUsers != null) {
            if (userIsPicExternal()) {
                $flgAuth['visiter-cooperating-company'] = true;
            } else {
                $flgAuth['visiter'] = true;
            }
        }

        return view('U0300.ResultInfo', compact(['schedule', 'slots', 'users', 'workResult', 'workResultDetails',
            'manhours', 'signature', 'displayControl', 'flgAuth']));
    }

    /**
     * 該当する作業実績情報情報を削除します。
     */
    public function deleteWorkResult($receptionNo, $scheduleId)
    {
        DB::beginTransaction(); // トランザクション開始
        try {

            $schedule = USchedule::find($scheduleId);

            // 作業実績削除
            $schedule->workResult()->delete();

            // 作業実績詳細削除
            $schedule->workResultDetails()->delete();

            // 工数削除
            $schedule->manHours()->delete();

            // 署名削除
            $schedule->signature()->forceDelete();

            // 状態変更
            $this->changeStatusByDelete($schedule);

            DB::commit(); // コミット

            // ログ出力
            $this->outputLog('作業実績情報',
                config('constants.logs.data_delete'),
                '作業実績情報を削除しました。');

            // 成功メッセージ
            session()->flash('success', '作業実績を正常に削除しました。');

            return redirect()->route('receptions.show', ['reception' => $receptionNo]);

        } catch (\Exception$e) {
            DB::rollBack(); // ロールバック

            // 失敗メッセージ
            session()->flash('failure', '予期せぬエラーが発生しましたため、作業実績削除に失敗しました。');

            // ログ出力
            $this->outputLog('作業実績情報',
                config('constants.logs.data_delete'),
                '作業実績情報の削除に失敗しました。',
                $e);

            return back();
        }
    }

    /**
     * 該当する工数情報を削除します。
     */
    public function deleteManhour($manhourId)
    {
        DB::beginTransaction(); // トランザクション開始
        try {

            DB::table('u_man_hours')
                ->where('id', $manhourId)
                ->update([
                    'updated_by' => auth()->user()->id,
                    'updated_at' => now(),
                    'deleted_at' => now(),
                ]);

            DB::commit(); // コミット

            // ログ出力
            $this->outputLog('工数削除',
                config('constants.logs.data_delete'),
                '工数を削除しました。');

            // 成功メッセージ
            session()->flash('success', '工数を正常に削除しました。');

            return redirect()->back();

        } catch (\Exception$e) {
            DB::rollBack(); // ロールバック
            // ログ出力
            $this->outputLog('工数削除',
                config('constants.logs.data_delete'),
                '工数の削除に失敗しました。',
                $e);

            // 失敗メッセージ
            session()->flash('failure', '予期せぬエラーが発生しましたため、工数削除に失敗しました。');

            return redirect()->back();
        }
    }

    /**
     *  該当する署名を削除します。
     */
    public function deleteSignature($signatureId, $fileId)
    {
        DB::beginTransaction(); // トランザクション開始
        try {

            DB::table('u_signatures')
                ->where('id', $signatureId)
                ->delete();

            DB::table('files')
                ->where('id', $fileId)
                ->delete();

            // ログ出力
            $this->outputLog('署名削除',
                config('constants.logs.data_delete'),
                '署名を削除しました。');

            DB::commit(); // コミット

            // 成功メッセージ
            session()->flash('success', '署名を正常に削除しました。');

            return redirect()->back();

        } catch (\Exception $e) {
            DB::rollBack(); // ロールバック
            // ログ出力
            $this->outputLog('署名削除',
                config('constants.logs.data_delete'),
                '署名の削除に失敗しました。',
                $e);

            // 失敗メッセージ
            session()->flash('failure', '予期せぬエラーが発生しましたため、署名削除に失敗しました。');

            return redirect()->back();
        }
    }

    /**
     * 実績削除により受付状態の変更
     *
     * @param USchedule
     *
     * @return void
     */
    private function changeStatusByDelete(USchedule $schedule)
    {

        // 状態
        $status = $schedule->reception->status;

        // 状態区分
        $statusType = $status->status_type;

        // 今の状態が保留または訪問済の場合
        if (collect([
            config('constants.status.on_hold'),
            config('constants.status.visited'),
        ])->contains($statusType)) {

            // 受付状態履歴を作成
            $status->addToHistory();

            // 状態区分を保留にする
            $status = $status->setStatus(config('constants.status.will_visit'));

            // 状態保存
            $status->save();
        }

    }
    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
