<?php

namespace App\Http\Controllers\U0300;

use Exception;
use App\Commons\Logger;
use App\Models\UStatus;
use App\Models\CodeClass;
use App\Models\USchedule;
use App\Models\UWorkResult;
use Illuminate\Http\Request;
use App\Rules\NotInvalidChars;
use App\Models\UWorkResultDetail;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class SetResultController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '作業実績情報を処理';

    /**
     *該当する作業実績情報を表示します。
     */
    public function show($scheduleId)
    {
        $schedule = USchedule::findOrFail($scheduleId);
        // 権限チェック
        $this->authorize('updateResult', $schedule);

        $allowEdit = true;

        // ログ出力
        $this->outputLog(config('constants.logs.page_access'), '作業実績設定画面にアクセスしました。');

        // 時間帯
        $slots = USchedule::join('u_slots', function ($join) {
            $join->on('u_slots.schedule_id', '=', 'u_schedules.id')
                ->whereNull('u_slots.deleted_at');
        })
            ->leftJoin('code_classes', function ($join) {
                $join->on('u_slots.slot_type', '=', 'code_classes.key')
                    ->where('code_classes.identifier_code', '=', config('constants.codes.slot'))
                    ->where('u_slots.deleted_at', null);
            })
            ->where('u_schedules.id', $scheduleId)
            ->select('u_slots.slot_type', 'code_classes.value as slot_name')
            ->get();

        // 訪問担当ユーザ
        $users = USchedule::join('u_schedule_users', function ($join) {
            $join->on('u_schedule_users.schedule_id', '=', 'u_schedules.id')
                ->whereNull('u_schedule_users.deleted_at');
        })
            ->join('users', 'users.id', 'u_schedule_users.user_id')
            ->leftJoin('files', function ($join) {
                $join->on('files.id', '=', 'users.file_id')
                    ->where('files.deleted_at', null);
            })
            ->where('u_schedules.id', $scheduleId)
            ->select('users.short_name', 'users.name', 'users.file_id', 'files.file')
            ->get();

        // ＫＹポイント
        $templateKYPonts = CodeClass::where('identifier_code', config('constants.codes.ky'))
            ->select('key', 'value')
            ->get();

        // 作業内容
        $templateWorkContents = CodeClass::where('identifier_code', config('constants.codes.work_content'))
            ->select('key', 'string1 as value')
            ->orderby('display_order')
            ->get();

        // ＫＹ, 作業実績入力完了 ,ワンポイント対策'
        $workResult = USchedule::leftJoin('u_work_results', function ($join) {
            $join->on('u_schedules.id', '=', 'u_work_results.schedule_id')
                ->whereNull('u_work_results.deleted_at');
        })
            ->where('u_schedules.id', $scheduleId)
            ->select('u_work_results.id', 'u_work_results.ky_point_type',
                'u_work_results.one_point', 'u_work_results.updated_at',
                'u_work_results.entry_complete_flag')
            ->first();

        // 系統, 機種, 機番, 作業内容
        $workResultDetails = USchedule::join('u_devices', 'u_devices.reception_no', 'u_schedules.reception_no')
            ->leftJoin('u_work_result_details', function ($join) {
                $join->on('u_schedules.id', '=', 'u_work_result_details.schedule_id')
                    ->on('u_devices.id', '=', 'u_work_result_details.device_id')
                    ->whereNull('u_work_result_details.deleted_at');
            })
            ->leftJoin('u_groups', function ($join) {
                $join->on('u_groups.id', 'u_devices.group_id')
                    ->where('u_groups.deleted_at', null);
            })
            ->where('u_schedules.id', $scheduleId)
            ->select('u_groups.name as group_name', 'u_devices.device_type', 'u_devices.device_no',
                'u_work_result_details.id', 'u_work_result_details.work_detail',
                'u_work_result_details.updated_at', 'u_devices.id as device_id')
            ->get();

        $status = USchedule::join('u_receptions', 'u_receptions.no', '=', 'u_schedules.reception_no')
            ->join('u_statuses', 'u_receptions.no', '=', 'u_statuses.reception_no')
            ->leftJoin('code_classes', function ($join) {
                $join->on('u_statuses.status_type', '=', 'code_classes.key')
                    ->where('code_classes.identifier_code', '=', config('constants.codes.status'));
            })
            ->where('u_schedules.id', $scheduleId)
            ->select('code_classes.key as key')
            ->first();
        if (($status != null) && ($status->key >= config('constants.status.work_done'))) {
            $allowEdit = false;
            // システム管理者の権限を
            if (userIsSystemAdmin()) {
                $allowEdit = true;
            } else {
                // システム管理者、業務責任者の権限を除き、戻る以外のボタンは非表示。
                if (($status->key == config('constants.status.work_done')) && userIsManager()) {
                    $allowEdit = true;
                }
            }
        }
        if ($workResult->id == null) {
            $actions = route('set-result.store');
            $method = 'POST';
        } else {
            $actions = route(('set-result.update'));
            $method = 'PATCH';
        }

        return view('U0300.SetResult', compact(['actions', 'method', 'schedule', 'slots', 'users', 'workResult',
            'templateKYPonts', 'schedule', 'templateWorkContents',
            'workResultDetails', 'scheduleId', 'allowEdit']));
    }

    /**
     *
     *該当する作業実績情報を表示します。
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'onePoint' => new NotInvalidChars(),
                'workContent.*' => new NotInvalidChars(),

            ], []
            ,
            [
                'onePoint' => 'ワンポイント対策',
                'workContent.*' => '作業内容',
            ]
        );
        if ($validator->fails()) {
            return back()->withInput()->withErrors($validator->errors());
        }

        // チェックでエラーがない場合は作業実績を登録し。
        $receptionNo = USchedule::join('u_receptions', 'u_receptions.no', '=', 'u_schedules.reception_no')
            ->where('u_schedules.id', $request->scheduleId)
            ->first()->reception_no;

        $status = UStatus::where('reception_no', $receptionNo)->first();

        // トランザクション開始
        DB::beginTransaction();
        try {
            // 受付状態を訪問済に変更する。
            $this->processName = '受付状態入替';

            // 作業完了チェックフラグ
            $completeFlag = $request->completeFlag == null ? false : true;

            // スケジュールID
            $scheduleId = $request->scheduleId;

            // 状態変更
            if ($completeFlag) {
                $this->changeStatus($scheduleId, $status, true);
            }

            // ログ出力
            $this->outputLog(config('constants.logs.data_insert'), '受付状態を登録しました。');

            UWorkResult::create([
                'schedule_id' => $scheduleId,
                'ky_point_type' => $request->kyPoint,
                'one_point' => $request->onePoint,
                'entry_complete_flag' => $completeFlag,
            ]);

            $this->processName = '作業実績情報登録';
            // 作業内容を変更します。
            foreach ($request->workContent ?? [] as $key => $value) {
                UWorkResultDetail::create([
                    'schedule_id' => $request->scheduleId,
                    'device_id' => $key,
                    'work_detail' => $value,
                ]);
            }

            $this->outputLog(config('constants.logs.data_insert'), '作業実績情報を登録しました。');
            // コミット
            DB::commit();
            return redirect()->route('result-info.index', ['scheduleId' => $request->scheduleId]);
        } catch (Exception $e) {
            // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_insert'), '作業実績情報の登録に失敗しました。', $e);
            return back();
        }
    }

    /**
     *
     *該当する作業実績情報を表示します。
     */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'onePoint' => new NotInvalidChars(),
                'workContent.*' => new NotInvalidChars(),

            ], []
            ,
            [
                'onePoint' => 'ワンポイント対策',
                'workContent.*' => '作業内容',
            ]
        );
        if ($validator->fails()) {
            return back()->withInput()->withErrors($validator->errors());
        }

        $scheduleId = $request->scheduleId;
        $workResult = UWorkResult::where('schedule_id', $scheduleId)->first();

        // チェックでエラーがない場合は作業実績を登録し。
        $receptionNo = USchedule::join('u_receptions', 'u_receptions.no', '=', 'u_schedules.reception_no')
            ->where('u_schedules.id', $scheduleId)
            ->first()->reception_no;

        $status = UStatus::where('reception_no', $receptionNo)->first();

        // 更新時間を確認してください
        if (!($workResult->updated_at == $request->updated_at)) {
            return back()->withInput()->with(['error' => '別のユーザーにて既に更新されています']);
        }

        foreach ($request->updatedAt ?? [] as $key => $value) {
            if ($value) {
                $detailId = $request->detailId[$key];
                $workDetail = UWorkResultDetail::where('id', $detailId)->first();
                if ($workDetail->updated_at != $value) {
                    return back()->withInput()->with(['error' => '別のユーザーにて既に更新されています']);
                }
            }
        }

        try {
            // トランザクション開始
            DB::beginTransaction();

            $this->processName = '作業実績情報入替';
            // 該当する作業実績情報を表示します。
            $changeFlg = false;
            if ($workResult->ky_point_type != $request->kyPoint) {
                $workResult->ky_point_type = $request->kyPoint;
                $changeFlg = true;
            }
            if ($workResult->one_point = $request->onePoint) {
                $workResult->one_point = $request->onePoint;
                $changeFlg = true;
            }

            // 作業完了チェックフラグ
            $completeFlag = $request->completeFlag == null ? false : true;

            if ($completeFlag != $workResult->entry_complete_flag) {
                $workResult->entry_complete_flag = $completeFlag;
                $changeFlg = true;

                // 状態変更
                $this->changeStatus($workResult->schedule_id, $status, $completeFlag);

                // ログ出力
                $this->outputLog(config('constants.logs.data_update'), '受付状態を入替しました。');

            }

            if ($changeFlg) {
                $workResult->save();
            }

            $changeFlg = false;
            // 作業内容を変更します。
            foreach ($request->workContent ?? [] as $key => $value) {
                $detailId = $request->detailId[$key];
                if ($detailId) {
                    $workDetail = UWorkResultDetail::where('id', $detailId)->first();
                    if ($workDetail->work_detail != $value) {
                        $changeFlg = true;
                        $workDetail->work_detail = $value;
                        $workDetail->save();
                    }
                } else {
                    UWorkResultDetail::create([
                        'schedule_id' => $request->scheduleId,
                        'device_id' => $key,
                        'work_detail' => $value,
                    ]);
                    $changeFlg = true;
                }
            }
            if ($changeFlg) {
                $this->outputLog(config('constants.logs.data_update'), '作業実績情報を入替しました。');
            }

            // コミット
            DB::commit();
            return redirect()->route('result-info.index', ['scheduleId' => $scheduleId]);
        } catch (\Exception$e) {
            // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_update'), '作業実績情報の入替に失敗しました。', $e);
            return back();
        }
    }

    /**
     * 状態変更
     *
     * @param int $scheduleId
     * @param UStatus
     * @param bool : 作業入力完了フラグ
     *
     * @return void
     */

    private function changeStatus($scheduleId, UStatus $status, $completeFlag = true)
    {

        $statusType = $status->status_type;

        switch ($statusType) {
            case config('constants.status.will_visit'):
                // 受付情報に対する実績入力未完了の訪問予定
                $incompleteSchedules = $status->reception->incompleteSchedules;

                // 実績入力未完了訪問予定が１つかつ今回の実績に対する訪問予定かる作業入力フラグがTRUE
                if (
                    $incompleteSchedules->count() == 1 &&
                    $incompleteSchedules->first()->id == $scheduleId &&
                    $completeFlag
                ) {

                    // 受付状態履歴を作成
                    $status->addToHistory();

                    // 訪問済に
                    $status = $status->setStatus(config('constants.status.visited'));

                    // 状態保存
                    $status->save();

                }
                break;
            case config('constants.status.visited'):
                if (!$completeFlag) {

                    // 最新履歴状態
                    $lastStatusType = $status->latestHistory->status_type;

                    if ($lastStatusType == config('constants.status.will_visit')) {
                        // 履歴より復活する
                        $status->restoreFromHistory();

                    } else if ($lastStatusType == config('constants.status.on_hold')) {
                        // 受付状態履歴を作成
                        $status->addToHistory();

                        // 訪問済に
                        $status = $status->setStatus(config('constants.status.will_visit'));

                        // 状態保存
                        $status->save();
                    }
                }
                break;
            case config('constants.status.on_hold'):
                if (!$completeFlag) {

                    // 受付状態履歴を作成
                    $status->addToHistory();

                    // 訪問済に
                    $status = $status->setStatus(config('constants.status.will_visit'));

                    // 状態保存
                    $status->save();
                }
                break;

        }

    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $this->processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
