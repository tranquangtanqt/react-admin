<?php

namespace App\Http\Controllers\U0300;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\CodeClass;
use App\Models\UWorkReport;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

/**
 * 有償無償設定
 *
 * @author  donlq
 * @create_date  2021-10-27
 */
class SetPaymentTypeController extends Controller
{

    /**
     * 作業報告テーブルに変更・新規追加する
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'value' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'    =>  'NG',
                'message'   =>  $validator->errors()->all(),
                'data'      =>  []
            ], 422);
        }
        $workReport = UWorkReport::where('reception_no', $request->receptionNo)->firstOrFail();
        if (
            $request->timeNow &&
            $workReport->updated_at?->notEqualTo(Carbon::create($request->timeNow))
        ) {
            return response()
                ->json([
                    'status' => 'NG',
                    'message' => '別のユーザーにて既に更新されています。',
                    'data' => []
                ], 500);
        }
        try {
            if ($workReport != null) {
                if ($workReport->payment_type != $request->value) {
                    $workReport->payment_type = $request->value;
                    $workReport->save();

                    // 成功メッセージ
                    session()->flash('success', '有償無償を正常に更新しました。');
                    session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

                    $this->outputLog('有償無償入替', config('constants.logs.data_update'), '有償無償を入替しました。');
                }
            }
        } catch (\Exception $e) {
            $this->outputLog('有償無償', config('constants.logs.data_update'), '有償無償画面登録エラー', $e);
            return response()->json([
                'status' => 'NG',
                'message' => '予期せぬエラーが発生しました。',
                'data' => []
            ], 500);
        }
    }

    /**
     * 該当する作業報告情報を表示します。
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Controller
     */
    public function show($receptionNo)
    {
        $this->outputLog("有償無償アクセス", config('constants.logs.page_access'), '有償無償にアクセスしました');

        try {
            $data = null;
            if ($receptionNo != null) {
                $data = UWorkReport::select('payment_type', 'updated_at')
                    ->where('reception_no', $receptionNo)
                    ->firstOrFail();
            }

            $codeClass = CodeClass::select('key', 'value')
                ->where('identifier_code', config('constants.codes.payment'))
                ->get();

            return response()->json(
                [
                    'paymentType' => $data->payment_type,
                    'codeClasses' => $codeClass,
                    'timeNow' => $data->updated_at->toDateTimeString()
                ]
            );
        } catch (\Exception $e) {
            $this->outputLog('有償無償', config('constants.logs.page_access'), '有償無償画面登録エラー', $e);
            return response()->json([
                'status' => 'NG',
                'message' => '予期せぬエラーが発生しました。',
                'data' => []
            ], 500);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
