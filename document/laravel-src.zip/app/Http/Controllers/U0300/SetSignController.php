<?php

namespace App\Http\Controllers\U0300;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\File;
use App\Models\USignature;
use Carbon\Carbon;
use App\Commons\Logger;
use App\Models\USchedule;
use Illuminate\Support\Facades\DB;

/**
 * 電子署名設定
 */
class SetSignController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '電子署名設定処理';

    /**
     * 該当する電子署名設定情報を表示します。
     *
     */
    public function show($scheduleId) {
        $schedule = USchedule::findOrFail($scheduleId);
        // 権限チェック
        $this->authorize('updateSignature', $schedule);

        $this->processName = '電子署名設定アクセス';
        // ログ出力
        $this->outputLog(config('constants.logs.page_access'), '電子署名設定画面にアクセスしました。');
        return view('U0300.SetSign',compact('scheduleId'));
    }

    /**
     * 新規で電子署名情報を登録します。
     * 該当する電子署名情報を変更します。
     *
     */
    public function store(Request $request) {
        $data_uri = $request->signature;
        $base64 = explode(",", $data_uri)[1];
        $scheduleId = $request->scheduleId;

        DB::beginTransaction();
        try{
            $userSignature = USignature::where('schedule_id', $scheduleId)->first();

            if($userSignature == null) {
                $this->processName = "ファイル登録";
                // 新しいファイルを作成する
                $newFile = File::create([
                    'file' => $base64,
                    'name' => '電子署名',
                    'public_flag' => true,
                ]);
                // ログ出力
                $this->outputLog(config('constants.logs.data_insert'), 'ファイルを登録しました。');

                $this->processName = "電子署名登録";
                // 電子署名を登録し
                USignature::create([
                    'schedule_id'  => $scheduleId ,
                    'digital_flag' => true,
                    'signed_at'    => Carbon::now(),
                    'file_id' => $newFile->id,
                ]);
                // ログ出力
                $this->outputLog(config('constants.logs.data_insert'), '署名を登録しました。');
            }else{
                $this->processName = "ファイル入替";
                $oldFile = File::where('id',$userSignature -> file_id)->first();
                $oldFile->file = $base64;
                $oldFile->name = '電子署名';
                $oldFile->title = null;
                $oldFile->public_flag = true;
                $oldFile->save();

                $signNature =  USignature::where('schedule_id', $scheduleId)->first();
                if($signNature->digital_flag == false) {
                    $signNature->digital_flag = true;
                    $signNature->save();
                }
                // ログ出力
                $this->outputLog(config('constants.logs.data_update'), 'ファイルを入替しました。');
            }
            DB::commit();
            return response()->json();
        } catch (\Exception $e) {
             // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_insert'), '登録処理で異常終了しました。', $e);
            // 作業実績情報画面に遷移する
            return back();
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $this->processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
