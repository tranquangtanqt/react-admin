<?php

namespace App\Http\Controllers\U0300;

use App\Http\Controllers\Controller;
use App\Http\Requests\U0300\SetManHourRequest;
use App\Models\CodeClass;
use App\Models\L2Reception;
use App\Models\UManHour;
use App\Models\USchedule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;
use App\Commons\Logger;
class SetManHourController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '工数設定処理';

    /**
     * 該当する工数情報を表示します
     */
    public function show($scheduleId)
    {
        $schedule = USchedule::findOrFail($scheduleId);

        // 権限チェック
        $this->authorize('updateManHour', $schedule);

        // ログ出力
        $this->outputLog(config('constants.logs.page_access'), '工数設定画面にアクセスしました。');
        $user  = Auth::user();
        $isRelatedL2  = 0;
        $minTime ='00:00';
        $maxTime ='23:59';

        $schudule = USchedule::where('id',$scheduleId)->first();
        $manHour =  UManHour::join('u_schedules','u_man_hours.schedule_id', '=', 'u_schedules.id')
                    ->where('u_man_hours.user_id','=',$user -> id)
                    ->where('u_man_hours.schedule_id','=',$scheduleId)
                    ->get(['u_man_hours.*','u_schedules.date'])
                    ->first();

        $pJL2 =   L2Reception::join('u_receptions','u_receptions.no','=','l2_receptions.no')
                                ->join('u_schedules','u_schedules.reception_no','=','u_receptions.no')
                                ->where('u_schedules.id','=',$scheduleId)
                                ->get(['l2_receptions.related_pj_no'])
                                ->first();

        // 受付に対するL2の関連ＰＪに値が設定されている場合は、作業区分は施工固定とする。
        if($pJL2 !=null && $pJL2->related_pj_no != null) {
            $isRelatedL2 = 1;
            $works= CodeClass::where('identifier_code',config('constants.codes.l2_work'))->first();
        } else {
            $works= CodeClass::where('identifier_code',config('constants.codes.l2_work'))->get();
        }
        $workClasses = CodeClass::where('identifier_code',config('constants.codes.l2_work_class'))->get();
        $workDetails = CodeClass::where('identifier_code',config('constants.codes.l2_work_detail'))->get();
        if ($manHour == null){
            // 新規追加
            $manHour = new UManHour();
            $action = URL::route('set-man-hour.store');

            // 新規の場合は、時間帯に紐づくコード区分マスタの値１（最小）値２（最大）を開始終了時間に設定する。
            $rangeTime =  USchedule::join('u_slots','u_slots.schedule_id','=','u_schedules.id')
                                    ->join('code_classes','u_slots.slot_type','=','code_classes.key')
                                    ->where('code_classes.identifier_code',config('constants.codes.slot'))
                                    ->where('u_schedules.id',$scheduleId)
                                    ->get(['code_classes.number1','code_classes.number2']);

            if(!$rangeTime->isEmpty()){
                $minTime = $this->convertStringTime(explode('.',$rangeTime->min('number1'))[0]);
                $maxTime = $this->convertStringTime(explode('.',$rangeTime->max('number2'))[0]);
                $manHour -> start_time = $minTime;
                $manHour -> end_time = $maxTime;
            }
        } else {
            $action = URL::route('set-man-hour.update');
        }
        return view('U0300.SetManHour',compact(['works','workClasses','workDetails','manHour','isRelatedL2','action','schudule','minTime','maxTime', 'schedule']));
    }

    /**
     *  新規で工数情報を登録します。
     */
    public function store(SetManHourRequest $request)
    {
       DB::beginTransaction();
       try {
            // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
            //--$request->startTime = date ('Hi',strtotime($request->startTime ));
            //--$request->endTime = date ('Hi',strtotime($request->endTime));
            $request->startTime = str_replace(":","",$request->startTime);
            $request->endTime = str_replace(":","",$request->endTime);
            // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応

            $this->processName = "工数登録";
            // 工数情報を登録し
            UManHour::Create([
                'schedule_id' =>$request->schedule_id,
                'user_id' => auth()->user()->id,
                'start_time' => $request->startTime,
                'end_time' => $request->endTime,
                'man_hour' => $request->manHour,
                'work_class' => $request->work,
                'work_type' => $request->workClass,
                'work_detail' => $request->wordDetail,
                'work_content' => $request->workContent,
                'coop_type' => config('constants.coop.yet')
            ]);
            // ログ出力
            $this->outputLog(config('constants.logs.data_insert'), '工数を登録しました。');

            DB::commit();
            // 作業実績情報画面に遷移する
            return redirect()->route('result-info.index', ['scheduleId' => $request->schedule_id]);
        } catch (\Exception $e) {
            // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_insert'), '工数の登録に失敗しました。',$e);
            // 作業実績情報画面に遷移する
            return back();
        }
    }

    /**
     * 該当する工数情報を変更します。
     */
    public function update(SetManHourRequest $request)
    {
        // 連携区分が連携済の場合エラーとする。
        $manHour = UManHour::where('schedule_id',$request->schedule_id)
                            ->where('user_id',auth()->user()->id)
                            ->first();
        if($manHour -> coop_type == config('constants.coop.active')
            || $manHour -> coop_type == config('constants.coop.target')){
            return back()->withInput()->withErrors(['linkedL2' => '既に連携されています。']);
        }
        DB::beginTransaction();
        try{
            // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
            //--$startTime = date('Hi',strtotime($request->startTime));
            //--$endTime = date('Hi',strtotime($request->endTime));
            $startTime = str_replace(":","",$request->startTime);
            $endTime = str_replace(":","",$request->endTime);
            // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応

            $this->processName = "工数入替";
            // 工数情報を登録し
            $manHour->start_time = $startTime;
            $manHour->end_time = $endTime;
            $manHour->man_hour = $request->manHour;
            $manHour->work_class = $request->work;
            $manHour->work_type = $request->workClass;
            $manHour->work_detail = $request->wordDetail;
            $manHour->work_content = $request->workContent;
            $manHour->save();
            // ログ出力
            $this->outputLog(config('constants.logs.data_update'),'工数を入替しました。');

            DB::commit();
            // 作業実績情報画面に遷移する
            return redirect()->route('result-info.index', ['scheduleId' => $request->schedule_id]);
        } catch (\Exception $e) {
            // ロールバック
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.data_update'),'工数の入替に失敗しました。', $e);
            // 作業実績情報画面に遷移する
            return back();
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processType, $content, $contentDetail = null){
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $this->processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }

     /**
     *
     *
     * @return string
     */
    private function convertStringTime($strTime)
    {
        if(strlen($strTime) == 3){
            return '0'.substr($strTime, 0, 1).':'.substr($strTime, -2);
        }else{
            return substr($strTime, 0, 2).':'.substr($strTime, -2);
        }
    }
}
