<?php

namespace App\Http\Controllers\U0300;

use App\Models\Auth;
use App\Models\User;
use App\Commons\Logger;
use App\Models\CodeClass;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Request as RequestFacade;

class SetScheduleCheckConditionController extends Controller
{

    /**
     * 訪問予定確認条件設定モーダル表示
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {

        // ログ登録
        $this->createLog();

        // バリデーション
        $validator = Validator::make($request->all(), [
            'mode' => 'required',
            'edit_schedule_date' => 'nullable|date_format:Y/m/d',
            'add_schedule_date' => 'nullable|date_format:Y/m/d',
            'edit_schedule_persons' => 'required_without:add_schedule_persons',
            'add_schedule_persons' => 'required_without:edit_schedule_persons',
        ], [
            'edit_schedule_date.date_format' => '予定日付の値が日付として扱えません。',
            'add_schedule_date.date_format' => '予定日付の値が日付として扱えません。',
        ]);

        // バリデーション失敗の時
        if ($validator->fails()) {
            return response()->json(
                $validator->errors(),
                422
            );
        }

        // バリデーション結果
        $validData = $validator->validated();

        // モード
        $mode = $validData['mode'];

        // 予定日付
        $scheduleDate = $validData[$mode . '_schedule_date'];

        // inputより担当者及び時間帯情報
        $inputPersonSlots = $validData[$mode . '_schedule_persons'];

        // 選択された担当者・時間帯
        $selectedPersonSlots = $this->getSelectedPersonsSlots($inputPersonSlots);

        // 選択された時間帯
        $selectedSlots = $this->getSelectedSlots($selectedPersonSlots);

        // 選択された担当者のID
        $selectedPersonIds = $selectedPersonSlots->pluck('id');

        // 予定確認条件画面上に表示される担当者
        $persons = $this->getPersons();

        // 予定確認条件画面上に表示される時間帯
        $slots = CodeClass::getSlots();


        return view('U0300.SetScheduleCheckCondition', compact([
            'mode', // モード
            'scheduleDate', // 予定日付
            'selectedSlots', // 選択された時間帯
            'selectedPersonIds', // 選択された担当者ID
            'slots', // 時間帯
            'persons', // 担当者
        ]));
    }

    /**
     * ユーザinputより選択された担当者及び時間帯を取得
     *
     * @param array $personSlotInput バリデーション結果より
     *
     * @return Illuminate\Support\Collection
     */
    private function getSelectedPersonsSlots(array $personSlotInput)
    {
        return collect($personSlotInput)->filter(function ($person) {
            return collect($person)->has('slots');
        });
    }

    /**
     * ユーザinputより選択された時間帯を取得
     *
     * @param Illuminate\Support\Collection $selectedPersonSlots
     *
     * @return Illuminate\Support\Collection
     */
    private function getSelectedSlots($selectedPersonSlots)
    {
        return $selectedPersonSlots->pluck('slots')
            ->map(fn ($item) => collect($item)->keys())
            ->flatten()
            ->unique();
    }

    /**
     * 担当者取得
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    private function getPersons()
    {

        // 訪問担当のリスト
        return User::where(function ($query) {
            $query->whereHas('auths', function ($query) { // 訪問担当権限持っている
                $query->whereIn('auth_class', [
                    config('constants.auth.pic'),
                    config('constants.auth.pic_external'),
                ]);
            });
        })
            ->addSelect([
                'is_external' => Auth::selectRaw('true as is_external')
                    ->whereColumn('user_id', 'users.id')
                    ->where('auth_class', config('constants.auth.pic_external'))
                    ->limit(1)
            ])
            ->orderBy('is_external', 'desc')
            ->get();
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => '訪問予定確認条件設定画面アクセス',
            'content' =>  '訪問予定確認条件設定画面をアクセスしました。',
            'request_url' => substr(RequestFacade::fullUrl(), 0, 255),
            'referer_url' => substr(RequestFacade::header('referer'), 0, 255),
        ]);
    }
}
