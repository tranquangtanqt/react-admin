<?php

namespace App\Http\Controllers\U0300;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\UOperationRecord;
use Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SetOperationRecordController extends Controller
{
    /**
     * 該当する運転記録情報を変更します。
     *
     */
    public function update(Request $request)
    {
        // 情報バリデーション
        $validator = Validator::make(
            $request->all(),
            [
                'record01' => 'nullable|regex:/^\d{1,3}(\.\d{1,2})?$/',
                'record02' => 'nullable|regex:/^\d{1,3}(\.\d{1,2})?$/',
                'record03' => 'nullable|regex:/^\d{1,3}(\.\d)?$/',
                'record04' => 'nullable|regex:/^\d{1,3}$/',
                'record05' => 'nullable|regex:/^\d{1,3}(\.\d)?$/',
                'record06' => 'nullable|regex:/^\d{1,3}(\.\d)?$/',
                'record07' => 'nullable|regex:/^\d{1,3}(\.\d)?$/',
                'record08' => 'nullable|regex:/^\d{1,3}(\.\d)?$/',
                'record09' => 'nullable|regex:/^\d{1,3}(\.\d)?$/',
                'record10' => 'nullable|regex:/^\d{1,3}(\.\d)?$/',
            ],
            [
                'record01.regex' => ':attribute|HPは整数3桁小数2桁で入力してください。',
                'record02.regex' => ':attribute|LPは整数3桁小数2桁で入力してください。',
                'record03.regex' => ':attribute|総合電流は整数3桁小数1桁で入力してください。',
                'record04.regex' => ':attribute|電圧は整数3桁で入力してください。',
                'record05.regex' => ':attribute|過熱度は整数3桁小数1桁で入力してください。',
                'record06.regex' => ':attribute|吸込は整数3桁小数1桁で入力してください。',
                'record07.regex' => ':attribute|吹出は整数3桁小数1桁で入力してください。',
                'record08.regex' => ':attribute|外気温は整数3桁小数1桁で入力してください。',
                'record09.regex' => ':attribute|吸入は整数3桁小数1桁で入力してください。',
                'record10.regex' => ':attribute|吐出は整数3桁小数1桁で入力してください。',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 'NG',
                'message' => $validator->errors()->all(), 'errors' => []
            ], 422);
        }

        DB::beginTransaction();
        try {
            if ($request->operationId != "") {

                $operationDevice = UOperationRecord::findOrFail($request->operationId);
                //更新時間を確認してください
                if (!($operationDevice->updated_at == $request->updated_at)) {
                    return response()
                        ->json([
                            'status' => 'NG',
                            'message' => 'Exclusive|別のユーザーにて既に更新されています'
                        ], 419);
                }
                //運転記録設定
                $operationDevice->record01 = $request->record01;
                $operationDevice->record02 = $request->record02;
                $operationDevice->record03 = $request->record03;
                $operationDevice->record04 = $request->record04;
                $operationDevice->record05 = $request->record05;
                $operationDevice->record06 = $request->record06;
                $operationDevice->record07 = $request->record07;
                $operationDevice->record08 = $request->record08;
                $operationDevice->record09 = $request->record09;
                $operationDevice->record10 = $request->record10;
                $operationDevice->save();

                // ログ出力
                $this->outputLog('運転記録入替', config('constants.logs.data_update'), '運転記録を入替しました。');
            } else {
                UOperationRecord::create([
                    'device_id' => $request->device_id,
                    'record01' => $request->record01,
                    'record02' => $request->record02,
                    'record03' => $request->record03,
                    'record04' => $request->record04,
                    'record05' => $request->record05,
                    'record06' => $request->record06,
                    'record07' => $request->record07,
                    'record08' => $request->record08,
                    'record09' => $request->record09,
                    'record10' => $request->record10
                ]);
                // ログ出力
                $this->outputLog('運転記録登録', config('constants.logs.data_update'), '運転記録を登録しました。');
            }

            // コミット
            DB::commit();
            $message = '運転記録を正常に設定しました。';
            session()->flash('success', $message);

            return response()->json([
                'status' => 'OK',
                'message' => $message,
            ]);
        } catch (\Exception $e) {
            // ロールバック
            DB::rollBack();

            // ログ出力
            $this->outputLog('運転記録入替', config('constants.logs.data_update'), '運転記録の入替に失敗しました。', $e);

            $message = '予期せぬエラーが発生しました。';

            return response()
                ->json([
                    'status' => 'NG',
                    'message' => "Exclusive|{$message}",
                ], 500);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
