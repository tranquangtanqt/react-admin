<?php

namespace App\Http\Controllers\U0900;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0900\CoopObjectRequest;
use App\Models\L2Object;
use App\Models\L2Reception;
use App\Models\UStatus;
use Illuminate\Support\Facades\DB;

class CoopObjectController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '物件情報連携処理';

    /**
     * 戻り値（正常）
     *
     * @var int
     */
    protected $nomalEnd = 0;

    /**
     * 戻り値（異常）
     *
     * @var int
     */
    protected $abNomalEnd = 9;

    /**
     * ログ基本情報
     *
     * @var array
     */
    private $logBase = [];

    /**
     * 処理対象受付番号
     * 
     * @var string
     */
    private $receptionNo = '';

    /**
     * 項目情報
     * @see  itemCol
     *  項目名,型,桁数,必須
     */
    private $itemInfomations = [
        ["reception_no", 'string'],
        ["customer_no", 'string'],
        ["customer_account_no", 'string'],
        ["customer_name", 'string'],
        ["customer_account_name", 'string'],
        ["pjmgr_dept_no", 'string'],
        ["pjmgr_emp_no", 'string'],
        ["contract_date", 'date'],
        ["work_start_date", 'date'],
        ["work_end_date", 'date'],
        ["project_status", 'string'],
        ["sales_application_flag", 'string'],
        ["order_cancellation_flag", 'string'],
        ["completion_year_month", 'string'],
        ["entry_emp_code", 'string'],
        ["entry_date_time", 'datetime'],
        ["login_emp_code", 'string'],
        ["registered_at", 'datetime'],
    ];

    /**
     * 項目情報（カラム）
     */
    private $itemCol = [
        "name" => 0,      // 項目名
        "type" => 1,      // 型(string,int,date,datetime)
    ];

    /**
     * 物件情報連携処理
     *
     * @param  App\Http\Requests\CoopObjectRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function index(CoopObjectRequest $request)
    {
        // ログ基本情報設定
        $this->logBase = [
            'user_id' => config('constants.sys_userid.batch_user'),
            'process_name' => $this->processName,
            'process_type' => config('constants.logs.api_access'),
            'user_agent' => '-',
            'request_url' => '-',
            'referer_url' => '-',
        ];

        // ログ出力
        $this->outputLog($this->processName . 'を開始しました。');

        // 検証
        $validated = $request->validated();

        $errorInfo = $this->setItem($validated);
        if ($errorInfo != "") {
            // エラーの場合
            // ログ出力
            $this->outputLog($this->processName . 'を終了しました。(9)');
            $result = [
                "result" => $this->abNomalEnd,
                'detail' => $errorInfo,
            ];
            return $this->resConversionJson($result, 500);
        } else {
            // 正常の場合
            // ログ出力
            $this->outputLog($this->processName . 'を終了しました。(0)');
            $result = [
                "result" => $this->nomalEnd,
                'detail' => "登録処理が正常終了しました。(受付番号:" . $this->receptionNo . ")",
            ];
            return $this->resConversionJson($result, 200);
        }
    }

    /**
     * 登録処理
     */
    private function setItem($validated)
    {
        $errorInfo = "";
        try {
            // バッチユーザ取得
            $batchUser = config('constants.sys_userid.batch_user');

            DB::beginTransaction(); // トランザクション開始

            $inputData = collect($validated["inputdata"]);

            // キー取得
            $no = $inputData->get("reception_no");
            $this->receptionNo = $no;

            // レコード抽出or作成
            $l2object = L2Object::firstOrNew(['reception_no' => $no]);
            // 各項目の値を設定する。
            $itemCol = $this->itemCol;
            foreach ($this->itemInfomations as $info) {
                $name = $info[$itemCol["name"]];
                $type = $info[$itemCol["type"]];
                $value = $inputData->get($name);
                // 型ごとの登録処理
                switch ($type) {
                    case "non":
                        break;
                    case "date":
                        if ($value == "") {
                            $l2object[$name] = null;
                        } else {
                            $l2object[$name] = sprintf('%s/%s/%s', substr($value, 0, 4), substr($value, 4, 2), substr($value, 6, 2));
                        }
                        break;
                    case "datetime":
                        if ($value == "") {
                            $l2object[$name] = null;
                        } else {
                            $l2object[$name] = sprintf('%s/%s/%s %s:%s:%s', substr($value, 0, 4), substr($value, 4, 2), substr($value, 6, 2), substr($value, 9, 2), substr($value, 11, 2), substr($value, 13, 2));
                        }
                        break;
                    default:
                        $l2object[$name] = $value;
                }
            }
            // 連携登録日時
            if ($l2object["coop_created_at"] == null) {
                $l2object["coop_created_at"] = now();
            }
            // 連携更新日時
            $l2object["coop_updated_at"] = now();
            $l2object->save();

            // 物件情報の売上申請済フラグが1の場合
            if ($inputData->get("sales_application_flag") == "1") {
                // L2受付取得
                $l2reception = L2Reception::find($no);
                // 受付状態取得
                $status = UStatus::find($no);
                if ($status != null){
                    if ($l2reception->related_pj_no == null and $status->status_type == config('constants.status.checked') ){
                        // 履歴を登録する
                        $status->addToHistory();

                        // L2受付の関連PJ番号が未設定で受付状態がチェック済の場合、状態を完了に更新する
                        $status->status_type = config('constants.status.completed');
                        $status->updated_by = $batchUser;
                        $status->save();
                    }
                }
            }

            DB::commit(); // コミット
        } catch (\Exception $e) {
            DB::rollBack(); // ロールバック
            // ログ出力
            $this->outputLog('登録処理で異常終了しました。', $e);
            $errorInfo = "登録処理で異常終了しました。";
        }
        return $errorInfo;
    }

    /**
     * レスポンスJson生成
     */
    private function resConversionJson($result, $statusCode = 200)
    {
        if (empty($statusCode) || $statusCode < 100 || $statusCode >= 600) {
            $statusCode = 500;
        }
        return response()->json($result, $statusCode, ['Content-Type' => 'application/json'], JSON_UNESCAPED_SLASHES);
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo = $this->logBase; // ログ情報初期化
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
