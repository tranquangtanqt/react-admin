<?php

namespace App\Http\Controllers\U0900;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0900\CoopReceptionRequest;
use App\Models\File;
use App\Models\L2Object;
use App\Models\L2Reception;
use App\Models\UAttachment;
use App\Models\UComment;
use App\Models\UCost;
use App\Models\UDevice;
use App\Models\UGasInInfo;
use App\Models\UGasOutInfo;
use App\Models\UGroup;
use App\Models\UManHour;
use App\Models\UOperationRecord;
use App\Models\UPhoto;
use App\Models\UQuotation;
use App\Models\UReception;
use App\Models\USchedule;
use App\Models\UScheduleDetail;
use App\Models\UScheduleUser;
use App\Models\USignature;
use App\Models\USlot;
use App\Models\UStatus;
use App\Models\UStatusHistory;
use App\Models\UWorkReport;
use App\Models\UWorkResult;
use App\Models\UWorkResultDetail;
use Illuminate\Support\Facades\DB;

class CoopReceptionController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '受付情報連携処理';

    /**
     * 戻り値（正常）
     *
     * @var int
     */
    protected $nomalEnd = 0;

    /**
     * 戻り値（異常）
     *
     * @var int
     */
    protected $abNomalEnd = 9;

    /**
     * ログ基本情報
     *
     * @var array
     */
    private $logBase = [];

    /**
     * 処理対象受付番号
     * 
     * @var string
     */
    private $receptionNo = '';

    /**
     * 項目情報
     * @see  itemCol
     *  項目名,型,桁数,必須
     */
    private $itemInfomations = [
        ["no", "string"],
        ["date", "date"],
        ["dept_no", "string"],
        ["emp_code", "string"],
        ["client_no", "string"],
        ["client_account_no", "string"],
        ["client_billing_deadline", "int"],
        ["client_name", "string"],
        ["client_person_name", "string"],
        ["client_address", "string"],
        ["client_tel", "string"],
        ["client_fax", "string"],
        ["client_mobile_tel", "string"],
        ["field_name", "string"],
        ["field_person_name", "string"],
        ["field_address", "string"],
        ["field_tel", "string"],
        ["field_fax", "string"],
        ["field_mobile_tel", "string"],
        ["dealer_no", "string"],
        ["dealer_account_no", "string"],
        ["dealer_name", "string"],
        ["dealer_person_name", "string"],
        ["dealer_tel", "string"],
        ["dealer_fax", "string"],
        ["dealer_mobile_tel", "string"],
        ["title", "string"],
        ["content", "string"],
        ["visit_date", "date"],
        ["visit_time_text", "string"],
        ["status", "string"],
        ["response_type", "string"],
        ["mainte_check_term", "string"],
        ["related_pj_no", "string"],
        ["work_type", "string"],
        ["target_order_no", "string"],
        ["person_dept_no", "string"],
        ["person_emp_code", "string"],
        ["completion_date", "date"],
        ["device_type1", "string"],
        ["device_type2", "string"],
        ["device_no1", "string"],
        ["device_no2", "string"],
        ["delivery_date", "date"],
        ["repair_work_type", "string"],
        ["repair_sector_type", "string"],
        ["repair_point_type", "string"],
        ["repair_status", "string"],
        ["cause", "string"],
        ["measure", "string"],
        ["note", "string"],
        ["deleted_flag", "string"],
        ["entry_emp_code", "string"],
        ["entry_date_time", "datetime"],
        ["login_emp_code", "string"],
        ["registered_at", "datetime"],
    ];

    /**
     * 項目情報（カラム）
     */
    private $itemCol = [
        "name" => 0,      // 項目名
        "type" => 1,      // 型(string,int,date,datetime)
    ];

    /**
     * 受付情報連携処理
     *
     * @param  App\Http\Requests\CoopReceptionRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function index(CoopReceptionRequest $request)
    {
        // ログ基本情報設定
        $this->logBase = [
            'user_id' => config('constants.sys_userid.batch_user'),
            'process_name' => $this->processName,
            'process_type' => config('constants.logs.api_access'),
            'user_agent' => '-',
            'request_url' => '-',
            'referer_url' => '-',
        ];

        // ログ出力
        $this->outputLog($this->processName . '処理を開始しました。');

        // 検証
        $validated = $request->validated();

        $errorInfo = $this->setItem($validated);
        if ($errorInfo != "") {
            // エラーの場合
            // ログ出力
            $this->outputLog($this->processName . '処理を終了しました。(9)');
            $result = [
                "result" => $this->abNomalEnd,
                'detail' => $errorInfo,
            ];
            return $this->resConversionJson($result, 500);
        } else {
            // 正常の場合
            // ログ出力
            $this->outputLog($this->processName . 'を終了しました。(0)', "(受付番号:" . $this->receptionNo . ")");
            $result = [
                "result" => $this->nomalEnd,
                'detail' => "登録処理が正常終了しました。",
            ];
            return $this->resConversionJson($result, 200);
        }
    }

    /**
     * 登録処理
     */
    private function setItem($validated)
    {
        $errorInfo = "";
        try {
            // バッチユーザ取得
            $batchUser = config('constants.sys_userid.batch_user');

            DB::beginTransaction(); // トランザクション開始

            $inputData = collect($validated["inputdata"]);

            // キー取得
            $no = $inputData->get("no");
            $this->receptionNo = $no;

            // レコード抽出or作成
            $l2reception = L2Reception::firstOrNew(['no' => $no]);
            // 各項目の値を設定する。
            $itemCol = $this->itemCol;
            foreach ($this->itemInfomations as $info) {
                $name = $info[$itemCol["name"]];
                $type = $info[$itemCol["type"]];
                $value = $inputData->get($name);
                // 型ごとの登録処理
                switch ($type) {
                    case "non":
                        break;
                    case "date":
                        if ($value == "") {
                            $l2reception[$name] = null;
                        } else {
                            $l2reception[$name] = sprintf('%s/%s/%s', substr($value, 0, 4), substr($value, 4, 2), substr($value, 6, 2));
                        }
                        break;
                    case "datetime":
                        if ($value == "") {
                            $l2reception[$name] = null;
                        } else {
                            $l2reception[$name] = sprintf('%s/%s/%s %s:%s:%s', substr($value, 0, 4), substr($value, 4, 2), substr($value, 6, 2), substr($value, 9, 2), substr($value, 11, 2), substr($value, 13, 2));
                        }
                        break;
                    default:
                        $l2reception[$name] = $value;
                }
            }
            // 連携登録日時
            if ($l2reception["coop_created_at"] == null) {
                $l2reception["coop_created_at"] = now();
            }
            // 連携更新日時
            $l2reception["coop_updated_at"] = now();
            $l2reception->save();

            //
            if ($l2reception->wasRecentlyCreated) {
                // 新規作成の場合、関連するテーブルの作成
                // 受付情報
                $reception = UReception::firstOrCreate(['no' => $no]);
                $reception["created_by"] = $batchUser;
                $reception["updated_by"] = $batchUser;
                $reception->save();

                // 受付状態
                $status = UStatus::firstOrCreate(['reception_no' => $no]);
                $status["status_type"] = config('constants.status.new'); // 状態区分
                $status["entry_complete_flag"] = config('constants.status.new'); // 入力完了フラグ
                $status["checked_flag"] = config('constants.status.new'); // 計上チェック済フラグ
                $status["created_by"] = $batchUser;
                $status["updated_by"] = $batchUser;
                $status->save();

                // 機器情報
                $deviceEntryCount = 0; // 機器情報登録件数
                for ($i = 1; $i <= 2; $i++) {
                    if ($l2reception["device_type" . $i] != "" or $l2reception["device_no" . $i] != "") {
                        $deviceEntryCount++; // 機器情報登録件数カウント
                        $device = new UDevice;
                        $device->reception_no = $no;
                        $device->represent_flag = ($deviceEntryCount == 1); // 代表機器フラグ
                        $device->device_type = $l2reception["device_type" . $i]; // 機器名
                        $device->device_no = $l2reception["device_no" . $i]; // 機番名
                        $device->created_by = $batchUser;
                        $device->updated_by = $batchUser;
                        $device->save();
                    }
                }

                // 作業報告
                $workreport = UWorkReport::firstOrCreate(['reception_no' => $no]);
                $workreport["payment_type"] = config('constants.payment.none'); // 有償無償区分
                $workreport["work_type"] = config('constants.work.none'); // 作業区分
                $workreport["created_by"] = $batchUser;
                $workreport["updated_by"] = $batchUser;
                $workreport->save();
            }

            // L2受付の削除フラグが1の場合、関連情報を物理削除
            if ($l2reception["deleted_flag"] == '1') {
                $this->outputLog($this->processName, '削除処理実行');

                // 物件情報
                L2Object::where('reception_no', $no)->forceDelete();

                // 受付状態
                UStatus::withTrashed()->where('reception_no', $no)->forceDelete();
                // 受付状態履歴
                UStatusHistory::withTrashed()->where('reception_no', $no)->forceDelete();

                // コメント
                UComment::withTrashed()->where('reception_no', $no)->forceDelete();

                // 日程
                $schedule = USchedule::withTrashed()->where('reception_no', $no);
                if ($schedule->exists()) {
                    $items = $schedule->get();
                    foreach ($items as $item) {
                        // 時間帯
                        USlot::withTrashed()->where('schedule_id', $item['id'])->forceDelete();
                        // 日程担当
                        UScheduleUser::withTrashed()->where('schedule_id', $item['id'])->forceDelete();
                        // 日程担当詳細
                        UScheduleDetail::withTrashed()->where('schedule_id', $item['id'])->forceDelete();
                        // 実績
                        UWorkResult::withTrashed()->where('schedule_id', $item['id'])->forceDelete();
                        // 実績詳細
                        UWorkResultDetail::withTrashed()->where('schedule_id', $item['id'])->forceDelete();
                        // 工数
                        UManHour::withTrashed()->where('schedule_id', $item['id'])->forceDelete();
                        // 署名
                        $signatures = USignature::withTrashed()->where('schedule_id', $item['id']);
                        if ($signatures->exists()) {
                            $signs = $signatures->get();
                            foreach ($signs as $sign) {
                                File::withTrashed()->where('id', $sign['file_id'])->forceDelete();
                            }
                        }
                        $signatures->forceDelete();
                    }
                }
                $schedule->forceDelete();

                // 充填情報
                UGasInInfo::withTrashed()->where('reception_no', $no)->forceDelete();
                // 回収情報
                UGasOutInfo::withTrashed()->where('reception_no', $no)->forceDelete();
                // 作業報告
                UWorkReport::withTrashed()->where('reception_no', $no)->forceDelete();

                // 添付
                $attachments = UAttachment::withTrashed()->where('reception_no', $no);
                if ($attachments->exists()) {
                    $items = $attachments->get();
                    foreach ($items as $item) {
                        File::withTrashed()->where('id', $item['file_id'])->forceDelete();
                    }
                }
                $attachments->forceDelete();

                // 写真
                $photos = UPhoto::withTrashed()->where('reception_no', $no);
                if ($photos->exists()) {
                    $items = $photos->get();
                    foreach ($items as $item) {
                        File::withTrashed()->where('id', $item['file_id'])->forceDelete();
                    }
                }
                $photos->forceDelete();

                // 原価明細
                UCost::withTrashed()->where('reception_no', $no)->forceDelete();
                // 見積明細
                UQuotation::withTrashed()->where('reception_no', $no)->forceDelete();

                // 機器情報
                $devices = UDevice::withTrashed()->where('reception_no', $no);
                if ($devices->exists()) {
                    $items = $devices->get();
                    foreach ($items as $item) {
                        // 運転記録
                        UOperationRecord::withTrashed()->where('device_id', $item['id'])->forceDelete();
                    }
                }
                $devices->forceDelete();
                // 系統
                UGroup::withTrashed()->where('reception_no', $no)->forceDelete();

                // 受付情報
                UReception::withTrashed()->where('no', $no)->forceDelete();
            }

            DB::commit(); // コミット
        } catch (\Exception $e) {
            DB::rollBack(); // ロールバック
            // ログ出力
            $this->outputLog('登録処理で異常終了しました。', "(受付番号:" . $this->receptionNo . ")" . $e);
            $errorInfo = "登録処理で異常終了しました。";
        }
        return $errorInfo;
    }

    /**
     * レスポンスJson生成
     */
    private function resConversionJson($result, $statusCode = 200)
    {
        if (empty($statusCode) || $statusCode < 100 || $statusCode >= 600) {
            $statusCode = 500;
        }
        return response()->json($result, $statusCode, ['Content-Type' => 'application/json'], JSON_UNESCAPED_SLASHES);
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo = $this->logBase; // ログ情報初期化
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
