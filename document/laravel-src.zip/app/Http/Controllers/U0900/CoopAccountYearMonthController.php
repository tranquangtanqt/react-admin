<?php

namespace App\Http\Controllers\U0900;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Http\Requests\U0900\CoopAccountYearMonthRequest;
use App\Models\L2AccountYearMonth;
use App\Models\SystemSetting;
use Illuminate\Support\Facades\DB;

class CoopAccountYearMonthController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '会計年月連携処理';

    /**
     * 戻り値（正常）
     *
     * @var int
     */
    protected $nomalEnd = 0;

    /**
     * 戻り値（異常）
     *
     * @var int
     */
    protected $abNomalEnd = 9;

    /**
     * ログ基本情報
     *
     * @var array
     */
    private $logBase = [];

    /**
     * 項目情報
     * @see  itemCol
     *  項目名,型,桁数,必須
     */
    private $itemInfomations = [
        ["account_year_month", "string"]
    ];

    /**
     * 項目情報（カラム）
     */
    private $itemCol = [
        "name" => 0,      // 項目名
        "type" => 1,      // 型(string,int,date,datetime)
    ];

    /**
     * 工数情報連携処理
     *
     * @param  App\Http\Requests\CoopAccountYearMonthRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function index(CoopAccountYearMonthRequest $request)
    {
        // ログ基本情報設定
        $this->logBase = [
            'user_id' => config('constants.sys_userid.batch_user'),
            'process_name' => $this->processName,
            'process_type' => config('constants.logs.api_access'),
            'user_agent' => '-',
            'request_url' => '-',
            'referer_url' => '-',
        ];

        // ログ出力
        $this->outputLog($this->processName . 'を開始しました。');

        // 検証
        $validated = $request->validated();

        $errorInfo = $this->setItem($validated);
        if ($errorInfo != "") {
            // エラーの場合
            // ログ出力
            $this->outputLog($this->processName . 'を終了しました。(9)');
            $result = [
                "result" => $this->abNomalEnd,
                'detail' => $errorInfo,
            ];
            return $this->resConversionJson($result, 500);
        } else {
            // 正常の場合
            // ログ出力
            $this->outputLog($this->processName . 'を終了しました。(0)');
            $result = [
                "result" => $this->nomalEnd,
                'detail' => "登録処理が正常終了しました。",
            ];
            return $this->resConversionJson($result, 200);
        }
    }

    /**
     * 登録処理
     */
    private function setItem($validated)
    {
        $errorInfo = "";
        try {
            // バッチユーザ取得
            $batchUser = config('constants.sys_userid.batch_user');

            DB::beginTransaction(); // トランザクション開始

            $inputData = collect($validated["inputdata"]);

            // レコード抽出or作成
            $l2accym = L2AccountYearMonth::firstOrNew();

            // 年月退避
            $accountYearMonth = $l2accym->account_year_month;

            // 各項目の値を設定する。
            $itemCol = $this->itemCol;
            foreach ($this->itemInfomations as $info) {
                $name = $info[$itemCol["name"]];
                $type = $info[$itemCol["type"]];
                $value = $inputData->get($name);
                // 型ごとの登録処理
                switch ($type) {
                    case "non":
                        break;
                    case "date":
                        if ($value == "") {
                            $l2accym[$name] = null;
                        } else {
                            $l2accym[$name] = sprintf('%s/%s/%s', substr($value, 0, 4), substr($value, 4, 2), substr($value, 6, 2));
                        }
                        break;
                    case "datetime":
                        if ($value == "") {
                            $l2accym[$name] = null;
                        } else {
                            $l2accym[$name] = sprintf('%s/%s/%s %s:%s:%s', substr($value, 0, 4), substr($value, 4, 2), substr($value, 6, 2), substr($value, 9, 2), substr($value, 11, 2), substr($value, 13, 2));
                        }
                        break;
                    default:
                        $l2accym[$name] = $value;
                }
            }
            // 連携登録日時
            if ($l2accym["coop_created_at"] == null) {
                $l2accym["coop_created_at"] = now();
            }
            // 連携更新日時
            $l2accym["coop_updated_at"] = now();
            $l2accym->save();

            // 年月の変更有無
            if ($accountYearMonth) {
                if ($accountYearMonth != $l2accym["account_year_month"]) {
                    // 年月に変更があった場合 工数連携停止フラグを更新
                    $coopManHourStop = SystemSetting::firstOrNew(['id' => 'CoopManHourStop']);
                    $coopManHourStop->value = '0';
                    $coopManHourStop->save();
                }
            }

            DB::commit(); // コミット
        } catch (\Exception $e) {
            DB::rollBack(); // ロールバック
            // ログ出力
            $this->outputLog('登録処理で異常終了しました。', $e);
            $errorInfo = "登録処理で異常終了しました。";
        }
        return $errorInfo;
    }

    /**
     * レスポンスJson生成
     */
    private function resConversionJson($result, $statusCode = 200)
    {
        if (empty($statusCode) || $statusCode < 100 || $statusCode >= 600) {
            $statusCode = 500;
        }
        return response()->json($result, $statusCode, ['Content-Type' => 'application/json'], JSON_UNESCAPED_SLASHES);
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo = $this->logBase; // ログ情報初期化
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
