<?php

namespace App\Http\Controllers\U0100;

use App\Models\Auth;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class ScheduleListSettingController extends Controller
{
    /**
     * スケジュール表示設定画面（リスト）
     *
     * @return \Illuminate\View\View
     */
    public function show(Request $request)
    {
        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date',
        ], );

        // バリデーション失敗の時
        if ($validator->fails()) {
            return response()->json(
                $validator->errors(),
                422
            );
        }

        $startDate = $request->start_date ? Carbon::parse($request->start_date) : now();
        $endDate = $request->end_date ? Carbon::parse($request->end_date) : $startDate;

        // 選択されたユーザ
        $selectedUserIds = $request->has('selected_users') ? array_keys($request->selected_users) : [auth()->user()->id];

        // スケジュール表示設定用のユーザー
        $users = User::select(['id', 'name', 'short_name', 'file_id'])
            ->addSelect([
                'is_external' => Auth::selectRaw('true as is_external')
                    ->whereColumn('user_id', 'users.id')
                    ->where('auth_class', config('constants.auth.pic_external'))
                    ->limit(1),
            ])
            ->whereHas('auths', function ($query) {
                $query->whereIn(
                    'auth_class',
                    collect(config('constants.auth'))->filter(function ($auth) {
                        return $auth != config('constants.auth.system_admin');
                    })
                );
            })
            ->orderBy('is_external', 'desc')
            ->get();

        return view('U0100.ScheduleListSetting', compact([
            'selectedUserIds', // 選択されたユーザID
            'users', // ユーザリスト
            'startDate',
            'endDate',
        ]));
    }

    public function validateForm(Request $request)
    {
        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'start_date' => 'required|date_format:Y/m/d',
            'end_date' => 'required|date_format:Y/m/d',
            'selected_users' => 'required',
        ], [
            'selected_users.required' => 'ユーザーを選択してください。',
        ], [
            'start_date' => '開始日',
            'end_date' => '終了日',
        ]);

        // バリデーション失敗の時
        if ($validator->fails()) {
            return response()->json(
                $validator->errors(),
                422
            );
        }

        $validData = $validator->validated();

        // 予定日付（開始）
        $startDate = Carbon::create($validData['start_date'])->startOfDay();

        // 予定日付（終了）
        $endDate = Carbon::create($validData['end_date'])->startOfDay();

        // 期間が30日以上の場合
        $term = config('constants.scheduleListTerm');
        if ($endDate->diffInDays($startDate) > $term) {
            $validator->errors()->add('date', "日付の期間は最大${term}日と設定してください。");
            return response()->json(
                $validator->errors(),
                422
            );
        }

        return response()->json(['message' => 'form is valid']);
    }
}
