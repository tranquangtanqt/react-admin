<?php

namespace App\Http\Controllers\U0100;

use Exception;
use App\Models\User;
use App\Commons\Logger;
use Carbon\CarbonPeriod;
use App\Models\CodeClass;
use App\Models\USchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Commons\CommonFunction;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\Collection;

class ScheduleListController extends Controller
{
    /**
     * スケジュール画面表示(リスト)
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        // ログ登録
        $this->createLog('access');

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date',
        ], );

        // バリデーション失敗の時
        if ($validator->fails()) {
            return back();
        }

        $startDate = $request->start_date ? Carbon::parse($request->start_date) : now()->startOfDay();
        $endDate = $request->end_date ? Carbon::parse($request->end_date)->endOfDay() : $startDate->copy()->endOfDay();

        if ($startDate->startOfDay()->equalTo($endDate->startOfDay())) {
            $dateRangeStrings = [$startDate->format('Y/m/d')];
        } else {
            $dateRangeStrings = [$startDate->format('Y/m/d'), $endDate->format('Y/m/d')];
        }

        // 一週間日付
        $dateRange = Carbon::parse($startDate)->toPeriod($endDate);

        // 選択されたユーザID
        if (userIsPicExternal()) { // 協力会社の場合
            $selectedUserIds = [auth()->user()->id];
        } else {
            $selectedUserIds = $request->has('selected_users') ? array_keys($request->selected_users) : [auth()->user()->id];
        }
        // 選択されたユーザ
        $selectedUsers = User::whereIn('id', $selectedUserIds)->orderBy('short_name')->get();

        // 日程取得
        $schedules = $this->getSchedules($dateRange, $selectedUserIds);

        // 時間帯区分
        $availableSlots = CodeClass::getSlots();
        $arrayOfSlots = $availableSlots->reduce(function ($tmp, $item) {
            return $tmp + [$item->key => $item->value];
        }, []);

        // 時間帯色取得
        $slotColors = CodeClass::getSlotColors();

        // 時間帯タイトル取得
        $slotTitles = CodeClass::getSlotTitles();


        // 予定区分
        $scheduleTypes = CodeClass::getScheduleTypes();
        $arrayOfScheduleTypes = $scheduleTypes->reduce(function ($tmp, $item) {
            return $tmp + [$item->key => $item->value];
        }, []);

        return view('U0100.ScheduleList', compact([
            'schedules', // 一致する日程
            'selectedUsers', // 選択されたユーザID
            'dateRange', // 日付
            'dateRangeStrings', // 日付文字
            'arrayOfSlots', // 時間帯コード区分
            'arrayOfScheduleTypes', // 予定区分
            'slotTitles', // 時間たいタイトル
            'slotColors', // 時間帯色
        ]));
    }

    /**
     * 日程を取得
     *
     * @param CarbonPeriod $dateRange
     * @param array $userIds
     * @return Collection
     */
    private function getSchedules(CarbonPeriod $dateRange, array $userIds)
    {
        // 日程のサブクエリ
        $scheduleSubquery = function ($query) use ($dateRange, $userIds) {
            $query->select('us.id')
                ->distinct()
                ->from('u_schedules as us')
                ->join('u_schedule_details as usd', function ($query) {
                    $query->on('usd.schedule_id', '=', 'us.id')
                        ->whereNull('usd.deleted_at');
                })
                ->whereNull('us.deleted_at')
                ->whereBetween('us.date', [$dateRange->startDate, $dateRange->endDate])
                ->whereIn('usd.user_id', $userIds);
        };

        return USchedule::select([
            'u_schedules.id', // 日程ID
            'date', // 日程日付
            'schedule_type', // 日程区分
            'reception_no', // 受付番号
            'title', // 日程件名
            'content', // 日程内容
            'slot_type', // 時間帯区分
        ])
            ->join('u_slots as slots', function ($join) { // 受付情報担当者ユーザのジョイン
                $join->on('slots.schedule_id', '=', 'u_schedules.id')
                    ->whereNull('slots.deleted_at');
            })
            ->whereIn('u_schedules.id', $scheduleSubquery)
            ->oldest('u_schedules.date')
            ->oldest('slot_type')
            ->with([
                'reception:no', // 受付情報
                'reception.oldestComment' => function ($query) {
                    $query->select(['u_comments.id', 'u_comments.reception_no', 'u_comments.comment']);
                },
                'l2Reception:no,field_name,content,client_name', // L2受付情報
                'namedUsers', // 日程担当者（ユーザ）
            ])
            ->withCasts([
                'date' => 'date', // 日付キャスト（Carbon)
            ])
            ->get();
    }

    /**
     * 時間帯色取得
     *
     * @param Collection
     * @return array style
     */

    private function getColorStyles($availableSlots)
    {
        return $availableSlots
            ->map(function ($item) {
                if (!$item->string1 || !CommonFunction::isColorCode("#{$item->string1}")) {
                    return ['key' => $item->key, 'color' => "000000"];
                }
                return ['key' => $item->key, 'color' => $item->string1];
            })
            ->reduce(function ($tmp, $item) {
                return $tmp + [$item['key'] => "border-left-color: #{$item['color']};"];
            }, []);
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $mode,
        string $status = 'success',
        array $options = ['item' => null, 'content_detail' => null]
    ) {

        // $modeは'access', 'pin'のみ
        if (!collect(['access'])->contains($mode)) {
            throw new Exception("Only 'access', or 'pin' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        $types = [
            'access' => config('constants.logs.page_access'),
        ];

        $names = [
            'access' => 'スケジュール画面（リスト）アクセス',
        ];

        $contents = [
            'access' => [
                'success' => "スケジュール画面（リスト）にアクセスしました。",
                'error' => "スケジュール画面（リスト）のアクセスに失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'] ?? null,
        ]);
    }
}
