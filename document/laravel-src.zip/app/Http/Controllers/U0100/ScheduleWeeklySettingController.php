<?php

namespace App\Http\Controllers\U0100;

use Exception;
use App\Models\Auth;
use App\Models\User;
use App\Commons\Logger;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class ScheduleWeeklySettingController extends Controller
{
    /**
     * 受付状態変更画面表示
     *
     * @return \Illuminate\View\View
     */
    public function show(Request $request)
    {
        // ログ登録
        $this->createLog('access');

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'date' => 'nullable|date',
        ], );

        // 選択されたユーザ
        $selectedUserIds = $request->has('selected_users') ? array_keys($request->selected_users) : [auth()->user()->id];

        // バリデーション失敗の時
        if ($validator->fails()) {
            $date = now();
        } else {
            $date = Carbon::parse($request->date);
        }

        // スケジュール表示設定用のユーザー
        $users = User::select(['id', 'name', 'short_name', 'file_id'])
            ->addSelect([
                'is_external' => Auth::selectRaw('true as is_external')
                    ->whereColumn('user_id', 'users.id')
                    ->where('auth_class', config('constants.auth.pic_external'))
                    ->limit(1),
            ])
            ->whereHas('auths', function ($query) {
                $query->whereIn(
                    'auth_class',
                    collect(config('constants.auth'))->filter(function ($auth) {
                        return $auth != config('constants.auth.system_admin');
                    })
                );
            })
            ->orderBy('is_external', 'desc')
            ->get();

        return view('U0100.ScheduleWeeklySetting', compact([
            'selectedUserIds', // 選択されたユーザID
            'users', // ユーザリスト
            'date', // 日付
        ]));
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $mode,
        string $status = 'success',
        array $options = ['item' => null, 'content_detail' => null]
    ) {

        // $modeは'access'のみ
        if (!collect(['access'])->contains($mode)) {
            throw new Exception("Only 'access' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        $types = [
            'access' => config('constants.logs.page_access'),
        ];

        $names = [
            'access' => 'スケジュール表示設定画面（週間）',
        ];

        $contents = [
            'access' => [
                'success' => "スケジュール表示設定画面（週間）にアクセスしました。",
                'error' => "スケジュール表示設定画面（週間）のアクセスに失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'] ?? null,
        ]);
    }
}
