<?php

namespace App\Http\Controllers\U0100;

use Exception;
use App\Models\Auth;
use App\Models\User;
use App\Commons\Logger;
use Carbon\CarbonPeriod;
use App\Models\CodeClass;
use App\Models\USchedule;
use App\Models\UReception;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Commons\CommonFunction;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\Collection;

class ScheduleWeeklyController extends Controller
{
    /**
     * スケジュール週画面表示
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        // ログ登録
        $this->createLog('access');

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'start_date' => 'nullable|date',
        ], );

        // 時間ロケールを日本に
        Carbon::setLocale('ja');

        // バリデーション失敗の時
        if ($validator->fails()) {
            $startDate = now();
        } else {
            $startDate = Carbon::parse($request->start_date);
        }
        $startDate = $startDate->startOfWeek();

        // 一週間日付
        $dateRange = Carbon::parse($startDate)->toPeriod($startDate->endOfWeek());

        // 選択されたユーザID
        if (userIsPicExternal()) { // 協力会社の場合
            $selectedUserIds = [auth()->user()->id];
        } else {
            // 初期表示ユーザ（管理者以外）
            $initialUserIds = $this->getInitialUserIds();

            $selectedUserIds = $request->has('selected_users') ? array_keys($request->selected_users) : $initialUserIds;
        }

        // 選択されたユーザ
        $selectedUsers = $this->getSelectedUsers($selectedUserIds);

        // ログインユーザが最初にする（順番変える）
        [$loggedInUser, $nonLoggedInUsers] = $selectedUsers->partition(fn($user) => $user->id == auth()->user()->id);
        $selectedUsers = $loggedInUser->merge($nonLoggedInUsers);

        // 日程取得
        $schedules = $this->getSchedules($dateRange, $selectedUserIds);

        // 時間帯色取得
        $slotColors = CodeClass::getSlotColors();

        // 時間帯タイトル取得
        $slotTitles = CodeClass::getSlotTitles();

        // Get Pinned Reception
        $pinnedReceptions = $this->getReceptions('pinned');

        // Get New Schedule
        $newReceptions = userIsFieldCoor() ? $this->getReceptions('new') : collect([]);

        // Get OnHold Schedule
        $onHoldReceptions = $this->getReceptions('on_hold');

        return view('U0100.ScheduleWeekly', compact([
            'dateRange', // 一週間日付
            'pinnedReceptions',
            'newReceptions',
            'onHoldReceptions',
            'schedules',
            'selectedUsers',
            'loggedInUser',
            'nonLoggedInUsers',
            'slotTitles', // 時間たいタイトル
            'slotColors', // 時間帯色
        ]));
    }

    /**
     * ピン留め処理
     *
     * @param UReception $uReception
     * @return JsonResponse
     */
    public function togglePin(UReception $reception)
    {

        try {
            // DB更新
            $pin = $reception->pinByLoggedInUser();

            if (!$pin) {
                $reception->pins()->create([
                    'user_id' => auth()->user()->id,
                    'flag' => true,
                ]);
            } else {
                $pin->flag = !$pin->flag;
                $pin->save();
            }

            // 成功メッセージ
            $message = 'ピン留めを正常に更新しました。';
            session()->flash('success', $message);
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // ログ登録
            $this->createLog('pin', 'success', ['item' => $reception->no]);

            // 成功メッセージ返す
            return response()->json(['success' => $message], 200);
        } catch (Exception $e) {

            // 成功メッセージ
            $message = 'ビン留の更新に失敗しました。';
            session()->flash('error', $message);
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // ログ登録
            $this->createLog('pin', 'error', ['item' => $reception->no]);

            // エラーメッセージ返す
            return response()->json(['general-message' => $message], 500);
        }
    }
    /**
     * 受付情報取得
     *
     * @return Collection
     */
    private function getReceptions(string $type)
    {
        if (!collect(['pinned', 'new', 'on_hold'])->contains($type)) {
            throw new Exception("Only 'pinned', 'new', or 'on_hold' is allowed for the type argumnent");
        }
        return UReception::select([
            'u_receptions.no', // 受付番号
            'l2.date', // 受付日付
            'l2.content', // 受付内容
            'field_name', // 受付現場名
            'client_name', // 依頼元名
            'pin.flag as pinned_flag', // ピン留めフラッグ
            'status_type',
        ]) // 必要な項目
            ->join('l2_receptions as l2', 'l2.no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->join('u_statuses as status', 'status.reception_no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->leftJoin('u_pins as pin', 'pin.reception_no', '=', 'u_receptions.no') // ピン留めとジョイン
            ->with('oldestComment') // 一番古いコメント取得
            ->withCasts(['date' => 'datetime']) // dateを日付にキャストする
            ->oldest('l2.date')
            ->when($type === 'new', function ($query) {
                $query->where('status.status_type', config('constants.status.new'))
                    ->where(function ($query) {
                        $query->where('pin.flag', 'false')
                            ->orWhereNull('pin.flag');
                    });
            })
            ->when($type === 'on_hold', function ($query) {
                $query->leftjoin('users as rec_pjmgr', 'rec_pjmgr.id', '=', 'u_receptions.pjmgr_user_id') // u_receptionより計上担当取得ため
                    ->leftjoin('users as l2_pjmgr', 'l2_pjmgr.external_user_id', '=', 'l2.person_emp_code') // l2_receptionsより計上担当取得ため
                    ->where('status.status_type', config('constants.status.on_hold'))
                    ->where(function ($query) { // 計上担当権限持っているか
                        $query->where('display_user_id', auth()->user()->id) // ダッシュボード表示担当ユーザーID = ログインユーザID
                            ->orWhere(function ($query) { // OR (
                                $query->whereNull('display_user_id') // ダッシュボード表示担当ユーザーID IS NULL
                                    ->where(function ($query) { // AND (
                                        $query->where('l2_pjmgr.id', auth()->user()->id) // 計上担当ユーザーID = ログインユーザID (L2受付情報)
                                            ->orWhere(function ($query) {
                                                $query->where('pjmgr_user_id', auth()->user()->id) // 計上担当ユーザーID = ログインユーザID (U受付情報)
                                                    ->whereNull('l2_pjmgr.id'); // 計上担当ユーザーID = NULL (L2受付情報)
                                            });
                                    }); // )
                            }); // )
                    })
                    ->where(function ($query) {
                        $query->where('pin.flag', 'false')
                            ->orWhereNull('pin.flag');
                    });
            })
            ->when($type === 'pinned', function ($query) {
                $query->where('pin.flag', 'true')
                    ->where('user_id', auth()->user()->id);
            })
            ->get();
    }

    /**
     * 日程を取得
     *
     * @param CarbonPeriod $dateRange
     * @param array $userIds
     *
     * @return Collection
     */
    private function getSchedules(CarbonPeriod $dateRange, array $userIds)
    {
        return USchedule::select([
            'u_schedules.id',
            'u_schedules.date',
            'schedule_type',
            'reception_no',
            'u_schedules.title',
            'slot_type',
            'usd.user_id',
            'l2.field_name',
            'u_schedules.created_by',
        ])
            ->leftJoin('l2_receptions as l2', 'l2.no', '=', 'u_schedules.reception_no')
            ->join('u_schedule_details as usd', function ($join) { // 受付情報担当者ユーザのジョイン
                $join->on('usd.schedule_id', '=', 'u_schedules.id')
                    ->whereNull('usd.deleted_at');
            })
            ->whereBetween('u_schedules.date', [$dateRange->startDate, $dateRange->endDate])
            ->whereIn('usd.user_id', $userIds)
            ->oldest('u_schedules.date')
            ->oldest('slot_type')
            ->withCasts([
                'date' => 'date',
            ])
            ->get();
    }

    /**
     * 選択したユーザ取得
     *
     * @param array $selectedUserIds
     * @return \Illuminate\Database\Eloquent\Collection
     */
    private function getSelectedUsers(array $selectedUserIds = [])
    {
        // ユーザリスト
        return User::withIsExternal()
            ->when($selectedUserIds, function ($query) use ($selectedUserIds) {
                $query->whereIn('id', $selectedUserIds);
            })
            ->orderBy('is_external', 'desc')
            ->orderBy('short_name')
            ->get();
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $mode,
        string $status = 'success',
        array $options = ['item' => null, 'content_detail' => null]
    ) {

        // $modeは'access', 'pin'のみ
        if (!collect(['access', 'pin'])->contains($mode)) {
            throw new Exception("Only 'access', or 'pin' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        $types = [
            'access' => config('constants.logs.page_access'),
            'pin' => config('constants.logs.data_update'),
        ];

        $names = [
            'access' => 'スケジュール画面（週間）アクセス',
            'pin' => 'ピン留め更新',
        ];

        $contents = [
            'access' => [
                'success' => "スケジュール画面（週間）にアクセスしました。",
                'error' => "スケジュール画面（週間）のアクセスに失敗しました。",
            ],
            'pin' => [
                'success' => "受付{$options['item']}のピン留め更新に成功しました。",
                'error' => "受付{$options['item']}のピン留め更新に失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'] ?? null,
        ]);
    }

    /**
     * 初期ユーザを取得する
     *
     * @return array id配列
     */
    private function getInitialUserIds()
    {
        return User::whereHas('auths', function ($query) {
            $query->whereIn(
                'auth_class',
                [
                    config('constants.auth.pic'), // 社内担当者
                    config('constants.auth.pic_external'), // 協力会社担当者
                ]
            );
        })
            ->orWhere('id', auth()->user()->id)
            ->orderBy('id')
            ->get()
            ->pluck('id')
            ->toArray();
    }
}
