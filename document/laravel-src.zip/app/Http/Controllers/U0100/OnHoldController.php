<?php

namespace App\Http\Controllers\U0100;

use App\Commons\Logger;
use App\Models\UReception;
use App\Http\Controllers\Controller;
use Exception;

class OnHoldController extends Controller
{
    /**
     * 保留受付画面表示
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // ログ登録
        $this->createLog();

        // --------------------------------------
        // <<日程調整（お客様要因）>>
        // --------------------------------------
        $customerSchedulingReceptions = $this->getOnHoldReceptions(config('constants.status_detail.customer_scheduling'));

        // --------------------------------------
        // <<日程調整（自社要因）>>
        // --------------------------------------
        $selfSchedulingReceptions = $this->getOnHoldReceptions(config('constants.status_detail.self_scheduling'));

        // --------------------------------------
        // <<点検後様子見>>
        // --------------------------------------
        $observingReceptions = $this->getOnHoldReceptions(config('constants.status_detail.observing'));

        // --------------------------------------
        // <<見積保留>>
        // --------------------------------------
        $quotationReceptions = $this->getOnHoldReceptions(config('constants.status_detail.quotation'));

        // --------------------------------------
        // <<部品納期未定>>
        // --------------------------------------
        $partsWaitingReceptions = $this->getOnHoldReceptions(config('constants.status_detail.parts_waiting'));

        // --------------------------------------
        // <<中間期>>
        // --------------------------------------
        $interphaseReceptions = $this->getOnHoldReceptions(config('constants.status_detail.interphase'));

        // --------------------------------------
        // <<メーカー対応>>
        // --------------------------------------
        $makerSupportReceptions = $this->getOnHoldReceptions(config('constants.status_detail.maker_support'));

        // --------------------------------------
        // <<定期点検>>
        // --------------------------------------
        $periodicReceptions = $this->getOnHoldReceptions(config('constants.status_detail.periodic'));

        return view('U0100.OnHold', compact([
            'customerSchedulingReceptions', // 日程調整(お客様要因)
            'selfSchedulingReceptions', // 日程調整(自社要因)
            'observingReceptions', // 点検後様子見
            'quotationReceptions', // 見積保留
            'partsWaitingReceptions', // 部品納期未定
            'interphaseReceptions', // 中間期
            'makerSupportReceptions', // メーカー対応
            'periodicReceptions', // 定期点検
        ]));
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => '保留受付画面アクセス',
            'content' => '保留受付画面をアクセスしました。',
        ]);
    }

    /**
     * リマインダー受付取得
     *
     * @param string $type 状態詳細区分
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getOnHoldReceptions(string $type)
    {
        $statusDetailTypes = config('constants.status_detail');

        if (!collect($statusDetailTypes)->contains($type)) {
            throw new Exception("The provide type is not recognized. Please check the available values of config('constants.status_detail').");
        }

        return $this->getReceptionBaseQuery()
            ->where('status.status_type', config('constants.status.on_hold'))
            ->where('status.status_detail_type', $type)
            ->where($this->getDisplayManagerFilter())
            ->orderBy('u_receptions.no')
            ->get();
    }

    /**
     * ベースクエリのColumn
     *
     * @return array
     */
    private function getBaseSelectColumns()
    {
        return [
            'u_receptions.no', // 受付番号
            'l2.date', // 受付日付
            'l2.content', // 受付内容
            'field_name', // 受付現場名
            'field_tel', // 受付現場電話番号
            'field_mobile_tel', // 受付現場携帯電話番号
            'client_name', // 依頼元名
            'pjmgr_user_id', // 計上担当ユーザID
            'display_user_id', // ダッシュボード表示担当ユーザID
            'remind_memo', // リマインドメモ
            'rec_pjmgr.name as rec_pjmgr_name', // 受付情報の計上担当名
            'l2_pjmgr.name as l2_pjmgr_name', //  L2受付情報の計上担当名
            'lo.order_cancellation_flag', // キャンセルフラグ
            'status.status_type', // 状態
            'cc.key as work_type', // 作業区分
            'cc.value as work_type_name', // 作業区分名称
        ];
    }

    /**
     * 受付ベースクエリ取得
     *
     * @return Illuminate\Database\Eloquent\Builder
     */
    private function getReceptionBaseQuery()
    {
        return UReception::select($this->getBaseSelectColumns()) // 必要な項目
            ->join('l2_receptions as l2', 'l2.no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->join('u_statuses as status', 'status.reception_no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->leftjoin('l2_objects as lo', 'lo.reception_no', '=', 'u_receptions.no')
            ->leftjoin('users as rec_pjmgr', 'rec_pjmgr.id', '=', 'u_receptions.pjmgr_user_id') // u_receptionより計上担当取得ため
            ->leftjoin('users as l2_pjmgr', 'l2_pjmgr.external_user_id', '=', 'l2.person_emp_code') // l2_receptionsより計上担当取得ため
            ->leftjoin('u_work_reports as uwr', function ($join) { // 作業区分抽出のため
                $join->on('uwr.reception_no', 'u_receptions.no')
                    ->whereNull('uwr.deleted_at');
            })
            ->leftjoin('code_classes as cc', function ($join) { // 作業区分抽出のため
                $join->on('cc.key', 'uwr.work_type')
                    ->where('cc.identifier_code', config('constants.codes.work'))
                    ->whereNull('cc.deleted_at');
            })
            ->with('oldestComment') // 一番古いコメント取得
            ->withCasts(['date' => 'datetime']); // dateを日付にキャストする
    }

    /**
     * 計上担当条件（ダッシュボード表示含め）
     *
     * @return Closure($query)
     */
    private function getDisplayManagerFilter()
    {
        return function ($query) {
            $query->where('display_user_id', auth()->user()->id) // ダッシュボード表示担当ユーザーID = ログインユーザID
                ->orWhere(function ($query) { // OR (
                    $query->whereNull('display_user_id') // ダッシュボード表示担当ユーザーID IS NULL
                        ->where(function ($query) { // AND (
                            $query->where('l2_pjmgr.id', auth()->user()->id) // 計上担当ユーザーID = ログインユーザID (L2受付情報)
                                ->orWhere(function ($query) {
                                    $query->where('pjmgr_user_id', auth()->user()->id) // 計上担当ユーザーID = ログインユーザID (U受付情報)
                                        ->whereNull('l2_pjmgr.id'); // 計上担当ユーザーID = NULL (L2受付情報)
                                });
                        }); // )
                }); // )
        };
    }
}
