<?php

namespace App\Http\Controllers\U0100;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\BatchStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * エラー通知画面
 */
class ErrorNotificationController extends Controller
{
    /**
     * 表示
     */
    public function index(Request $request, $processId)
    {
        // ログ登録
        $this->outputLog('エラー通知画面アクセス', config('constants.logs.page_access'), 'エラー通知画面をアクセスしました。');

        $batchStatus = BatchStatus::where('process_id', $processId) // 処理ID
            ->where('process_status', config('constants.batch.failure')) // 異常終了の時
            ->first();

        // エラーのバッチ状態が存在しない時に
        if (!$batchStatus) {
            abort(404);
        }

        return view('U0100.ErrorNotification', compact(
            [
                'batchStatus', // バッチ状態
            ]
        ));
    }

    /**
     * 更新
     */
    public function update(Request $request)
    {
        DB::beginTransaction();
        try {
            $batchStatus = BatchStatus::find($request->processId);
            $batchStatus->process_status = config('constants.batch.yet');
            $batchStatus->save();
            DB::commit();
            session()->flash('success', '連携エラーの状態を解消へ正常に更新しました。');
            $this->outputLog('エラー通知入替', config('constants.logs.data_update'), 'バッチ状態を入替しました。');
            // ダッシュボードに遷移する
            return redirect()->route('dashboard');
        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog('エラー通知入替', config('constants.logs.data_update'), '例外が発生しました。', $e);
            session()->flash('failure', '予期せぬエラーが発生しました。');
            // 元画面に遷移する
            return back();
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
