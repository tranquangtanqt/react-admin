<?php

namespace App\Http\Controllers\U0100;

use App\Models\Auth;
use App\Models\User;
use App\Commons\Logger;
use App\Models\CodeClass;
use App\Models\UReception;
use Illuminate\Http\Request;
use App\Commons\CommonFunction;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\Collection;

class SearchReceptionController extends Controller
{
    /**
     * 受付検索画面表示
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {

        // ログ登録
        $this->createLog('access');

        // 検索項目
        $searchParams = $request->all();

        // その他の条件が開くか
        $detail = $searchParams['detail'] ?? false;

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'start_date' => 'nullable|date_format:Y/m/d',
            'end_date' => 'nullable|date_format:Y/m/d',
            'complete_start_date' => 'nullable|date_format:Y/m/d',
            'complete_end_date' => 'nullable|date_format:Y/m/d',
            'elapsed_days_min' => 'nullable|integer|gte:0',
            'elapsed_days_max' => 'nullable|integer|gte:0',
        ], [
            '*.gte' => ':attributeは:value以上で入力してください。',
        ], [
            'start_date' => '受付日（開始）',
            'end_date' => '受付日（終了）',
            'complete_start_date' => '完了日（開始）',
            'complete_end_date' => '完了日（終了）',
            'elapsed_days_min' => '経過日数（開始）',
            'elapsed_days_max' => '経過日数（終了）',
        ]);

        // バリデーション失敗の時
        if ($validator->fails()) {
            return redirect()->route('search-reception.index')
                ->withErrors($validator)
                ->withInput();
        }

        // 状態・状態詳細区分
        $codeClasses = $this->getCodeClasses();

        // 状態
        $statusTypes = $codeClasses->where('identifier_code', config('constants.codes.status'));
        // 状態詳細
        $statusDetailTypes = $codeClasses->where('identifier_code', config('constants.codes.status_detail'));

        // 計上担当者ユーザ
        $pjmgrUsers = $this->getPjmgrUsers();

        // 訪問担当者ユーザ
        $picUsers = userIsPicExternal() ? $this->getPicUsers([auth()->user()->id]) : $this->getPicUsers();

        // 検索アクションか
        $searched = !empty($searchParams);

        // 受付情報検索（取得）
        $receptions = !empty($searchParams) ? $this->getReceptions($searchParams) : collect([]);

        // 色付けのスタイル
        $styles = $receptions->isNotEmpty() ? $this->getColorStyles() : collect([]);

        return view('U0100.SearchReception', compact([
            'searchParams', // 検索項目
            'statusTypes', // 状態区分
            'statusDetailTypes', // 状態詳細区分
            'pjmgrUsers', // 系統担当選択
            'picUsers', // 訪問担当選択
            'searched', // 検索か？
            'detail', // その他の条件が開くか
            'receptions', // 検索結果（受付情報）
            'styles', // 状態・経過日数による色スタイル
        ]));
    }

    /**
     * 計上担当ユーザ取得
     *
     * @return Collection
     */
    private function getPjmgrUsers()
    {
        return User::whereHas('auths', function ($query) { // 担当権限持っている
            $query->whereIn('auth_class', [
                config('constants.auth.pic'),
            ]);
        })
            ->orderBy('short_name')
            ->get();
    }

    /**
     * 訪問担当ユーザ取得
     *
     * @return Collection
     */
    private function getPicUsers(array $userIds = [])
    {
        return User::whereHas('auths', function ($query) { // 担当権限持っている
            $query->whereIn('auth_class', [
                config('constants.auth.pic'),
                config('constants.auth.pic_external'),
            ]);
        })
            ->when($userIds, function ($query) use ($userIds) {
                $query->whereIn('id', $userIds);
            })
            ->addSelect([
                'is_external' => Auth::selectRaw('true as is_external')
                    ->whereColumn('user_id', 'users.id')
                    ->where('auth_class', config('constants.auth.pic_external'))
                    ->limit(1),
            ])
            ->orderBy('is_external', 'desc')
            ->orderBy('short_name')
            ->get();
    }

    /**
     * ベースクエリのColumn
     *
     * @return array
     */
    private function getBaseSelectColumns()
    {
        return [
            'u_receptions.no', // 受付番号
            'l2.date', // 受付日付
            'l2.content', // 受付内容
            'field_name', // 受付現場名
            'field_tel', // 受付現場電話番号
            'field_mobile_tel', // 受付現場携帯電話番号
            'client_name', // 依頼元名
            'pjmgr_user_id', // 計上担当ユーザID
            'display_user_id', // ダッシュボード表示担当ユーザID
            'rec_pjmgr.name as rec_pjmgr_name', // 受付情報の計上担当名
            'l2_pjmgr.name as l2_pjmgr_name', //  L2受付情報の計上担当名
            'lo.order_cancellation_flag', // キャンセルフラグ
            'status.status_type', // 状態
            'status.canceled_at', // キャンセル状態
            'cc.key as work_type', // 作業区分
            'cc.value as work_type_name', // 作業区分名称
        ];
    }

    /**
     * 受付ベースクエリ取得
     *
     * @return Illuminate\Database\Eloquent\Builder
     */
    private function getReceptionBaseQuery()
    {
        return UReception::select($this->getBaseSelectColumns()) // 必要な項目
            ->join('l2_receptions as l2', 'l2.no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->join('u_statuses as status', 'status.reception_no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->leftjoin('l2_objects as lo', 'lo.reception_no', '=', 'u_receptions.no')
            ->leftjoin('users as rec_pjmgr', 'rec_pjmgr.id', '=', 'u_receptions.pjmgr_user_id') // u_receptionより計上担当取得ため
            ->leftjoin('users as l2_pjmgr', 'l2_pjmgr.external_user_id', '=', 'l2.person_emp_code') // l2_receptionsより計上担当取得ため
            ->leftjoin('u_work_reports as uwr', function ($join) { // 作業区分抽出のため
                $join->on('uwr.reception_no', 'u_receptions.no')
                    ->whereNull('uwr.deleted_at');
            })
            ->leftjoin('code_classes as cc', function ($join) { // 作業区分抽出のため
                $join->on('cc.key', 'uwr.work_type')
                    ->where('cc.identifier_code', config('constants.codes.work'))
                    ->whereNull('cc.deleted_at');
            })
            ->with('oldestComment') // 一番古いコメント取得
            ->withCasts(['date' => 'datetime']); // dateを日付にキャストする
    }

    /**
     * 受付取得(検索項目によって)
     *
     * @return Collection
     */
    private function getReceptions(array $params)
    {
        return $this->getReceptionBaseQuery()
        // 受付日付
            ->when($params['start_date'], function ($query) use ($params) {
                $query->whereDate('l2.date', '>=', $params['start_date']);
            })
            ->when($params['end_date'], function ($query) use ($params) {
                $query->whereDate('l2.date', '<=', $params['end_date']);
            })

        // 受付状態
            ->when($params['status'] ?? false, function ($query) use ($params) {
                $query->whereIn('status.status_type', array_keys($params['status']));
            })

        // お客様名
            ->when($params['field_name'], function ($query) use ($params) {
                $query->where('l2.field_name', 'like', '%' . $params['field_name'] . '%');
            })

        // お客様住所
            ->when($params['field_address'], function ($query) use ($params) {
                $query->where('l2.field_address', 'like', '%' . $params['field_address'] . '%');
            })

        // 表示順
            ->when($params['order'], function ($query) use ($params) {
                $query->orderBy('l2.no', $params['order']);
            })

        // 受付経過日数
            ->when($params['elapsed_days_min'] != null, function ($query) use ($params) {
                $query->whereDate('l2.date', '<=', now()->subDays($params['elapsed_days_min']));
            })
            ->when($params['elapsed_days_max'] != null, function ($query) use ($params) {
                $query->whereDate('l2.date', '>=', now()->subDays($params['elapsed_days_max']));
            })

        // 受付完了日
            ->when($params['complete_start_date'], function ($query) use ($params) {
                $query->whereDate('status.updated_at', '>=', $params['complete_start_date'])
                    ->where('status_type', config('constants.status.completed'));
            })
            ->when($params['complete_end_date'], function ($query) use ($params) {
                $query->whereDate('status.updated_at', '<=', $params['complete_end_date'])
                    ->where('status_type', config('constants.status.completed'));
            })

        // 受付状態詳細
            ->when($params['status_detail'] ?? false, function ($query) use ($params) {
                $query->whereIn('status.status_detail_type', array_keys($params['status_detail']));
            })

        // 計上担当
            ->when($params['selected_pjmgr_id'], function ($query) use ($params) {
                $query->where(function ($query) use ($params) {
                    $query->where('u_receptions.pjmgr_user_id', $params['selected_pjmgr_id'])
                        ->orWhere('l2_pjmgr.id', $params['selected_pjmgr_id']);
                });
            })

        // 訪問担当
            ->when($params['selected_pic_id'], function ($query) use ($params) {
                $query->whereHas('schedules', function ($query) use ($params) {
                    $query->join('u_schedule_details as usd', function ($query) {
                        $query->on('u_schedules.id', '=', 'usd.schedule_id')
                            ->whereNull('usd.deleted_at');
                    })->where('usd.user_id', $params['selected_pic_id']);
                });
            })

        // お客様TEL
            ->when($params['field_tel'] != null, function ($query) use ($params) {
                $query->where('l2.field_tel', 'like', $params['field_tel'] . '%');
            })

        // 依頼元名
            ->when($params['client_name'] != null, function ($query) use ($params) {
                $query->where('l2.client_name', 'like', '%' . $params['client_name'] . '%');
            })

        // 依頼元住所
            ->when($params['client_address'] != null, function ($query) use ($params) {
                $query->where('l2.client_address', 'like', '%' . $params['client_address'] . '%');
            })

        // 受付番号
            ->when($params['no'] != null, function ($query) use ($params) {
                $query->where('l2.no', 'like', $params['no'] . '%');
            })

        // 関連PJNO
            ->when($params['related_pj_no'] != null, function ($query) use ($params) {
                $query->where('l2.related_pj_no', 'like', $params['related_pj_no'] . '%');
            })

        // 機器情報関連
            ->when($params['device_type'] != null || $params['device_no'] != null, function ($query) use ($params) {
                $query->whereHas('devices', function ($query) use ($params) {
                    $query
                    // 機種
                        ->when($params['device_type'] != null, function ($query) use ($params) {
                            $query->where('device_type', 'like', '%' . $params['device_type'] . '%');
                        })
                        // 機番
                        ->when($params['device_no'] != null, function ($query) use ($params) {
                            $query->where('device_no', 'like', '%' . $params['device_no'] . '%');
                        });
                });
            })

            ->get();
    }

    /**
     * 時間帯色取得
     *
     * @return array style
     */
    private function getColorStyles()
    {
        // 時間帯区分
        $displayColors = CodeClass::select(['id', 'key', 'number1', 'string1'])
            ->where('identifier_code', config(('constants.codes.recept_display')))->get();
        return $displayColors
            ->map(function ($item) {
                $mapped = ['key' => $item->key, 'style' => "background: #{$item->string1};", 'value' => intval($item->number1)];
                if (!$item->string1 || !CommonFunction::isColorCode("#{$item->string1}")) {
                    $mapped['style'] = "background: #FFFFFF;";
                }
                return $mapped;
            });
    }

    /**
     * 状態・状態詳細区分取得
     *
     * @return Collection
     */
    private function getCodeClasses()
    {
        // 状態・状態詳細区分
        return CodeClass::select([
            'id',
            'identifier_code',
            'key',
            'value',
            'string1',
        ])
            ->whereIn('identifier_code', [
                config('constants.codes.status'),
                config('constants.codes.status_detail'),
            ])
            ->orderBy('identifier_code')
            ->orderBy('key')
            ->get();
    }
    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => '受付検索画面アクセス',
            'content' => '受付検索画面にアクセスしました。',
        ]);
    }
}
