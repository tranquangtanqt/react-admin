<?php

namespace App\Http\Controllers\U0100;

use Exception;
use App\Models\UCost;
use App\Commons\Logger;
use App\Models\USchedule;
use App\Models\UReception;
use App\Models\BatchStatus;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class DashboardController extends Controller
{

    /**
     * ダッシュボード画面表示
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // ログ登録
        $this->createLog();

        // --------------------------------------
        // <<連携エラー>>
        // --------------------------------------
        $errorBatches = $this->getBatchErrors();

        // --------------------------------------
        // <<リマインダー>>
        // --------------------------------------
        $reminderReceptions = $this->getReminderReceptions();

        // --------------------------------------
        // <<新規受付>>
        // --------------------------------------
        $newReceptions = $this->getNewReceptions();

        // --------------------------------------
        // <<計上担当未定>>
        // --------------------------------------
        $pjmgrUnsetReceptions = $this->getPjmgrUnsetReception();

        // --------------------------------------
        // <<計上担当決定>>
        // --------------------------------------
        $pjmgrSetReceptions = $this->getPjmgrSetReception();

        // --------------------------------------
        // <<原価明細未確認>>
        // --------------------------------------
        $costUncheckedReceptions = $this->getCostUncheckedReceptions();

        // --------------------------------------
        // <<訪問予定（本日）>>
        // --------------------------------------
        $todayVisitReceptions = $this->getScheduledReceptions('today');

        // --------------------------------------
        // <<訪問予定（実績未入力）>>
        // --------------------------------------
        $noInputVisitReceptions = $this->getScheduledReceptions('no-input');

        // --------------------------------------
        // <<訪問済>>
        // --------------------------------------
        $visitedReceptions = $this->getVisitedReceptions();

        // --------------------------------------
        // <<訪問予定（後日）>>
        // --------------------------------------
        $nextVisitReceptions = $this->getScheduledReceptions('next');

        // --------------------------------------
        // <<入力完了>>
        // --------------------------------------
        $inputCompleteReceptions = $this->getInputCompleteReceptions();

        // --------------------------------------
        // <<入力チェック済>>
        // --------------------------------------
        $inputCheckedReceptions = $this->getInputCheckedReceptions();

        return view('U0100.Dashboard', compact([
            'errorBatches', // バッチエラー
            'reminderReceptions', // リマインダー
            'newReceptions', // 新規受付
            'pjmgrUnsetReceptions', // 計上担当未定
            'pjmgrSetReceptions', // 計上担当決定
            'costUncheckedReceptions', // 原価明細未確認
            'todayVisitReceptions', // 訪問予定（本日）
            'noInputVisitReceptions', // 訪問予定（未入力）
            'visitedReceptions', // 訪問済
            'nextVisitReceptions', // 訪問予定（後日）
            'inputCompleteReceptions', // 入力完了
            'inputCheckedReceptions', // 入力チェック済
        ]));
    }

    /**
     * バッチエラー情報取得
     *
     * @return void
     */
    private function getBatchErrors()
    {
        if (!userIsManager()) { // 業務責任者以外場合
            return collect([]);
        }
        return BatchStatus::select('process_id', 'process_name', 'created_at')
            ->where('process_status', config('constants.batch.failure')) // 異常終了の時
            ->latest()
            ->get();
    }

    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog()
    {
        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => config('constants.logs.page_access'),
            'process_name' => 'ダッシュボード画面アクセス',
            'content' => 'ダッシュボード画面にアクセスしました。',
        ]);
    }

    /**
     * リマインダー受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getReminderReceptions()
    {
        return $this->getReceptionBaseQuery()
            ->whereDate('status.remind_date', '<=', now()->toDateString())
            ->where('status.status_type', config('constants.status.on_hold'))
            ->where($this->getDisplayManagerFilter())
            ->latest('status.remind_date')
            ->get();
    }

    /**
     * 新規受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getNewReceptions()
    {
        $newReceptionsQuery = $this->getReceptionBaseQuery()
            ->where('status.status_type', config('constants.status.new'))
            ->oldest('u_receptions.created_at');

        // 現場調整担当またはL2支援入力
        if (userIsFieldCoor() || userIsInputSupport()) {
            return $newReceptionsQuery->get();
        }

        // それ以外
        return $newReceptionsQuery->where($this->getDisplayManagerFilter())->get();
    }

    /**
     * 計上担当未定受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getPjmgrUnsetReception()
    {
        // 現場調整担当以外の場合
        if (!userIsFieldCoor()) {
            return collect([]);
        }

        return $this->getReceptionBaseQuery()->whereNull('pjmgr_user_id') // 受付情報の計上担当ユーザがNULL
            ->where(function ($query) {
                $query->whereRaw("l2.person_emp_code is null or l2.person_emp_code = ''"); // L2受付情報の担当社員コードがNULL OR ''
            })
            ->oldest('u_receptions.created_at')
            ->get();
    }

    /**
     * 計上担当決定受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getPjmgrSetReception()
    {
        // L2支援入力以外の場合
        if (!userIsInputSupport()) {
            return collect([]);
        }

        return $this->getReceptionBaseQuery()->whereNotNull('pjmgr_user_id') // 受付情報の計上担当ユーザがNOT NULL
            ->where(function ($query) {
                $query->whereRaw("l2.person_emp_code is null or l2.person_emp_code = ''"); // L2受付情報の担当社員コードがNULL OR ''
            })
            ->where('status.status_type', '<>', config('constants.status.completed'))
            ->oldest('u_receptions.created_at')
            ->get();
    }

    /**
     * 原価明細未確認受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getCostUncheckedReceptions()
    {
        // L2支援入力以外の場合
        if (!userIsInputSupport()) {
            return collect([]);
        }

        // 原価明細サブクエリ（古いものの未チェック原価)
        $oldestCostUnchecked = UCost::select('reception_no', DB::raw('MIN(updated_at) as cost_updated_at'))
            ->groupBy('reception_no')
            ->where('checked_flag', 'false');

        // 原価明細未確認クエリを実行
        return $this->getReceptionBaseQuery()
            ->joinSub($oldestCostUnchecked, 'cost', function ($join) { // 原価明細サブクエリとジョイン
                $join->on('u_receptions.no', '=', 'cost.reception_no');
            })
            ->where('status.status_type', '<>', config('constants.status.completed'))
            ->oldest('cost_updated_at') // 原価明細の更新日の古いもの順
            ->get();
    }

    /**
     * 訪問予定受付取得 (本日、後日、未入力)
     *
     * @param string $type (one of 'today', 'next', 'no-input')
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getScheduledReceptions(string $type)
    {
        // 予定タイプ
        $types = ['today', 'next', 'no-input']; // 本日、後日、未入力

        // typeのチェック
        if (!collect($types)->contains($type)) {
            throw new Exception("the type (parameter) should be on of 'today', 'next', or 'no-input'");
        }

        // 日程・日程担当・時間帯サブクエリ(ベース)
        $scheduleBaseSubquery = USchedule::select('reception_no', DB::raw('date::date as sche_date , MIN(slot_type) as min_slot'))
            ->join('u_slots as slot', function ($join) {
                $join->on('slot.schedule_id', '=', 'u_schedules.id')
                    ->whereNull('slot.deleted_at');
            })
            ->groupBy('reception_no', 'sche_date');

        // 訪問担当チェック用の生クエリ
        $picSubQuery = function ($query) {
            $query->select(DB::raw(1))->from('u_schedule_users as usu')
                ->whereColumn('usu.schedule_id', 'u_schedules.id')
                ->where('usu.user_id', auth()->user()->id)
                ->whereNull('usu.deleted_at');
        };

        $scheduleSubqueries = [
            'today' => (clone $scheduleBaseSubquery)->whereDate('date', '=', date('Y-m-d')), //本日の条件
            'next' => (clone $scheduleBaseSubquery)->whereDate('date', '>', date('Y-m-d')), // 後日の条件
            'no-input' => (clone $scheduleBaseSubquery)->whereDate('date', '<', date('Y-m-d')), // 未入力の条件
        ];

        // 受付情報取得
        return $this->getReceptionBaseQuery()
            ->joinSub($scheduleSubqueries[$type], 'sub_sche', function ($join) { // 本日の日程サブクエリとジョイン
                $join->on('sub_sche.reception_no', '=', 'u_receptions.no');
            })
            ->join('u_schedules', function ($join) { // 日程テーブルとジョインする
                $join->on('u_schedules.reception_no', '=', 'u_receptions.no')
                    ->whereRaw('u_schedules.date::date = sub_sche.sche_date::date')
                    ->whereNull('u_schedules.deleted_at');
            })
            ->leftjoin('u_work_results as uwr_sche', function ($join) { //  作業実績テーブルとジョインし、実績登録済みかつ作業完了チェック=TRUEのみ抽出する
                $join->on('uwr_sche.schedule_id', '=', 'u_schedules.id')
                    ->whereNull('uwr_sche.deleted_at');
            })
            ->where(function ($query) {
                $query->whereNull('uwr_sche.entry_complete_flag')
                    ->orWhere('uwr_sche.entry_complete_flag', false);
            })
            ->addSelect(['sche_date', 'min_slot', 'u_schedules.id as schedule_id', 'u_schedules.content as sche_content']) // 必要な項目をselect文に追加
            ->where('status.status_type', config('constants.status.will_visit')) // 受付状態が訪問予定
            ->when(!($type === 'no-input' && userIsManager()), function ($query) use ($picSubQuery) { // （未入力かつ責任者）以外時に訪問担当・計上担当条件をつける
                $query->where(function ($query) use ($picSubQuery) {
                    $query->where($this->getDisplayManagerFilter()) // 計上担当がダッシュボード表示ユーザか
                        ->orWhereExists($picSubQuery); // 訪問担当か
                });
            })
            ->oldest('sche_date') // 日程の日付が古いもの順（本日の時間系ない）
            ->oldest('min_slot') // 時間帯の早いものから順
            ->withCasts(['sche_date' => 'datetime']) // 日付をキャストする
            ->with('slots:schedule_id,slot_type,value', 'scheduleUsers:schedule_id,name,short_name') // 関連時間帯と日程担当レコードを取得（カードに表示）
            ->get();
    }

    /**
     * 訪問済受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getVisitedReceptions()
    {
        // 受付の最終訪問予定のサブクエリ
        $latestVisitScheduleSubquery = USchedule::select('reception_no', DB::raw('MAX(date) as sche_date'))
            ->groupBy('reception_no');

        // 訪問担当チェックのサブクエリ
        $picSubQuery = function ($query) {
            $query->select(DB::raw(1))->from('u_schedules as us')
                ->join('u_schedule_users as usu', function ($join) {
                    $join->on('us.id', '=', 'usu.schedule_id')
                        ->whereNull('usu.deleted_at');
                })
                ->whereNull('us.deleted_at')
                ->whereColumn('us.reception_no', 'u_receptions.no')
                ->where('usu.user_id', auth()->user()->id);
        };

        return $this->getReceptionBaseQuery()
            ->addSelect('sche_date') // 最終訪問予定日をselect文に追加
            ->joinSub($latestVisitScheduleSubquery, 'sub_sche', function ($join) { // 受付の最終訪問予定サブクエリとジョイン
                $join->on('u_receptions.no', '=', 'sub_sche.reception_no');
            })
            ->where('status.status_type', config('constants.status.visited')) // 訪問済状態
            ->where(function ($query) use ($picSubQuery) {
                $query->where(function ($query) use ($picSubQuery) {
                    $query->where($this->getDisplayManagerFilter()) // 計上担当がダッシュボード表示ユーザか
                        ->orWhereExists($picSubQuery); // 訪問担当か
                })
                    ->when(userIsManager(), function ($query) {
                        $query->orWhereDate('sche_date', '<', date('Y-m-d')); // 業務責任者の場合最終訪問日付がシステム日付より後
                    });
            })
            ->oldest('sche_date') // 最終訪問予定の過去のものから順
            ->get();
    }

    /**
     * 入力完了受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getInputCompleteReceptions()
    {
        // 業務責任者
        if (userIsManager()) {
            return $this->getReceptionBaseQuery()->where('status.status_type', config('constants.status.work_done')) // 作業完了状態
                ->oldest('status.entry_complete_at') //  入力完了日時順（古いものから)
                ->get();
        }

        // 業務責任者以外
        return $this->getReceptionBaseQuery()->where('status.status_type', config('constants.status.work_done')) // 作業完了状態
            ->where($this->getDisplayManagerFilter()) // 計上担当かの条件
            ->oldest('status.entry_complete_at') //  入力完了日時順（古いものから)
            ->get();
    }

    /**
     * 入力チェック済受付取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    private function getInputCheckedReceptions()
    {
        // (業務責任者 OR 入力支援)以外の場合
        if (!userIsManager() && !userIsInputSupport()) {
            return collect([]);
        }

        return $this->getReceptionBaseQuery()->where('status.status_type', config('constants.status.checked')) // 入力チェック状態
            ->oldest('status.checked_at') //  計上チェック済日時順（古いものから)
            ->get();
    }

    /**
     * ベースクエリのColumn
     *
     * @return array
     */
    private function getBaseSelectColumns()
    {
        return [
            'u_receptions.no', // 受付番号
            'l2.date', // 受付日付
            'l2.content', // 受付内容
            'field_name', // 受付現場名
            'field_tel', // 受付現場電話番号
            'field_mobile_tel', // 受付現場携帯電話番号
            'client_name', // 依頼元名
            'pjmgr_user_id', // 計上担当ユーザID
            'display_user_id', // ダッシュボード表示担当ユーザID
            'remind_memo', // リマインドメモ
            'rec_pjmgr.name as rec_pjmgr_name', // 受付情報の計上担当名
            'l2_pjmgr.name as l2_pjmgr_name', //  L2受付情報の計上担当名
            'lo.order_cancellation_flag', // キャンセルフラグ
            'status.status_type', // 状態
            'status.canceled_at', // キャンセル状態
            'cc.key as work_type', // 作業区分
            'cc.value as work_type_name', // 作業区分名称
        ];
    }

    /**
     * 受付ベースクエリ取得
     *
     * @return Illuminate\Database\Eloquent\Builder
     */
    private function getReceptionBaseQuery()
    {
        return UReception::select($this->getBaseSelectColumns()) // 必要な項目
            ->join('l2_receptions as l2', 'l2.no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->join('u_statuses as status', 'status.reception_no', '=', 'u_receptions.no') // 受付状態とジョイン
            ->leftjoin('l2_objects as lo', 'lo.reception_no', '=', 'u_receptions.no')
            ->leftjoin('users as rec_pjmgr', function ($join) {
                $join->on('rec_pjmgr.id', '=', 'u_receptions.pjmgr_user_id') // u_receptionより計上担当取得ため
                    ->whereNull('rec_pjmgr.deleted_at');
            })
            ->leftjoin('users as l2_pjmgr', function ($join) {
                $join->on('l2_pjmgr.external_user_id', '=', 'l2.person_emp_code') // l2_receptionsより計上担当取得ため
                    ->whereNull('l2_pjmgr.deleted_at');
            })
            ->leftjoin('u_work_reports as uwr', function ($join) { // 作業区分抽出のため
                $join->on('uwr.reception_no', 'u_receptions.no')
                    ->whereNull('uwr.deleted_at');
            })
            ->leftjoin('code_classes as cc', function ($join) { // 作業区分抽出のため
                $join->on('cc.key', 'uwr.work_type')
                    ->where('cc.identifier_code', config('constants.codes.work'))
                    ->whereNull('cc.deleted_at');
            })
            ->with('oldestComment') // 一番古いコメント取得
            ->withCasts(['date' => 'datetime']); // dateを日付にキャストする
    }

    /**
     * 計上担当条件（ダッシュボード表示含め）
     *
     * @return Closure($query)
     */
    private function getDisplayManagerFilter()
    {
        return function ($query) {
            $query->where('display_user_id', auth()->user()->id) // ダッシュボード表示担当ユーザーID = ログインユーザID
                ->orWhere(function ($query) { // OR (
                    $query->whereNull('display_user_id') // ダッシュボード表示担当ユーザーID IS NULL
                        ->where(function ($query) { // AND (
                            $query->where('l2_pjmgr.id', auth()->user()->id) // 計上担当ユーザーID = ログインユーザID (L2受付情報)
                                ->orWhere(function ($query) {
                                    $query->where('pjmgr_user_id', auth()->user()->id) // 計上担当ユーザーID = ログインユーザID (U受付情報)
                                        ->whereNull('l2_pjmgr.id'); // 計上担当ユーザーID = NULL (L2受付情報)
                                });
                        }); // )
                }); // )
        };
    }
}
