<?php

namespace App\Http\Controllers\U0100;

use Exception;
use App\Models\Auth;
use App\Models\User;
use App\Models\USlot;
use App\Commons\Logger;
use App\Models\CodeClass;
use App\Models\USchedule;
use Illuminate\Http\Request;
use App\Models\UScheduleUser;
use Illuminate\Support\Carbon;
use App\Models\UScheduleDetail;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\U0100\StoreScheduleSettingRequest;
use App\Http\Requests\U0100\UpdateScheduleSettingRequest;

class ScheduleSettingController extends Controller
{
    /**
     * 通常予定設定表示画面
     *
     * @return \Illuminate\View\View
     */
    public function show(Request $request, USchedule $schedule)
    {
        // アクセスログ登録
        $this->createLog('access');

        // 日程時間帯(登録された)
        $scheduleSlots = $schedule->slots;

        // 日程担当者(登録された)
        $schedulePersons = User::whereIn('id', $schedule->scheduleUsers->pluck('user_id'))->get();

        // 時間帯区分
        $slots = CodeClass::where('identifier_code', config('constants.codes.slot'))
            ->whereIn('key', $scheduleSlots->pluck('slot_type'))
            ->orderBy('key', 'asc')
            ->get();

        // 予定区分
        $scheduleTypes = CodeClass::codeKey(config('constants.codes.pe_schedule'), $schedule->schedule_type)->first();

        return view('U0100.ReadScheduleSetting', compact([
            'scheduleSlots', // DBの日程時間帯
            'schedulePersons', // DBの日程担当者
            'schedule', // 日程
            'slots', // 時間帯
            'scheduleTypes', // 予定区分
        ]));
    }

    /**
     * 通常予定設定追加画面
     *
     * @return \Illuminate\View\View
     */
    public function create(Request $request)
    {

        // バリエーションルールとメッセージ
        $validator = Validator::make($request->all(), [
            'init_date' => 'nullable|date',
        ], );

        // バリデーション失敗の時初期日付を設定
        if ($validator->fails()) {
            $initDate = now();
        } else {
            $initDate = Carbon::parse($request->init_date);
        }

        // 初期ユーザID
        $initUserId = $request->has('init_user_id') ? $request->init_user_id : null;

        // アクセスログ登録
        $this->createLog('access');

        // ユーザリスト
        $persons = $this->getUsers();

        // 時間帯区分
        $slots = CodeClass::getSlots();

        // 予定区分
        $scheduleTypes = CodeClass::getScheduleTypes();

        // モード
        $mode = 'add';

        // ルート先
        $action = route('schedule-setting.store');

        return view('U0100.ScheduleSetting', compact([
            'persons', // 訪問担当者
            'slots', // 時間帯
            'scheduleTypes', // 予定区分
            'mode', // モード
            'action', // ポストルート先
            'initUserId', // 初期ユーザID
            'initDate', // 初期日付
        ]));
    }

    /**
     * 通常予定設定追加処理
     *
     * @return \Illuminate\View\View
     */
    public function store(StoreScheduleSettingRequest $request)
    {

        // バリエーション
        $validData = $request->validated();

        // トランザクション開始
        DB::beginTransaction();
        try {

            // 日程登録
            $this->addSchedule($validData);

            DB::commit(); // コミット

            // 成功メッセージ
            session()->flash('success', '訪問予定を正常に登録しました。');
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // ログ登録
            $this->createLog('insert');

            // 成功メッセージ返す
            return response()->json(['success' => '訪問予定を正常に登録しました。'], 200);
        } catch (Exception $e) {

            DB::rollBack(); // ロルバック

            // 登録失敗ログ
            $this->createLog('insert', 'error', ['content_detail' => $e]);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '訪問予定登録に失敗しました。再度登録してください。']), 500);
        }
    }

    /**
     * 通常予定設定更新画面
     *
     * @return \Illuminate\View\View
     */
    public function edit(Request $request, USchedule $schedule)
    {
        // アクセスログ登録
        $this->createLog('access');

        // 日程時間帯(登録された)
        $scheduleSlots = $schedule->slots;

        // 日程担当者(登録された)
        $schedulePersons = $schedule->scheduleUsers;

        // ユーザリスト
        $persons = $this->getUsers();

        // 時間帯区分
        $slots = CodeClass::getSlots();

        // 予定区分
        $scheduleTypes = CodeClass::getScheduleTypes();

        // モード
        $mode = 'edit';

        // ルート先
        $action = route('schedule-setting.update', $schedule);

        return view('U0100.ScheduleSetting', compact([
            'scheduleSlots', // DBの日程時間帯
            'schedulePersons', // DBの日程担当者
            'schedule', // 日程
            'persons', // 訪問担当者
            'slots', // 時間帯
            'scheduleTypes', // 予定区分
            'mode', // モード
            'action', // ポストルート先
        ]));
    }
    /**
     * 通常予定設定更新処理
     *
     * @return \Illuminate\View\View
     */
    public function update(UpdateScheduleSettingRequest $request, USchedule $schedule)
    {
        // 編集できる権限持っているか
        $canUpdate = $request->user()->can('update', $schedule);

        // 更新権限がない場合
        if (!$canUpdate) {
            // ログ登録
            $this->createLog('update', 'error', ['item' => $schedule->id, 'content_detail' => '権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        // バリデーション結果
        $validData = $request->validated();

        // 別のユーザが更新した場合の制御
        $updateAtFromInput = $validData['updated_at'];
        if ($schedule->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))) {
            return response()->json(addMessages(['general_error_message' => '別のユーザにて既に更新されています。']), 422);
        }

        // トランザクション開始
        DB::beginTransaction();
        try {

            // 日程更新
            $this->updateSchedule($validData, $schedule);

            DB::commit(); // コミット

            // 成功メッセージ
            $message = '訪問予定を正常に更新しました。';
            session()->flash('success', $message);
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // ログ更新
            $this->createLog('insert', 'success', ['item' => $schedule->no, 'content_detail' => null]);

            // 成功メッセージ返す
            return response()->json(['success' => $message], 200);
        } catch (Exception $e) {

            DB::rollBack(); // ロルバック

            // 更新失敗ログ
            $this->createLog('update', 'error', ['item' => $schedule->id, 'content_detail' => $e]);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '訪問予定更新に失敗しました。再度更新してください。']), 500);
        }
    }

    /**
     * 通常予定設定削除
     *
     * @return \Illuminate\View\View
     */
    public function delete(Request $request, USchedule $schedule)
    {

        // 追加・編集できる権限持っているか
        $canDelete = $request->user()->can('delete', $schedule);

        // 更新または追加権限がない場合
        if (!$canDelete) {
            // ログ登録
            $this->createLog('delete', 'error', ['item' => $schedule->id, 'content_detail' => '権限がありません。']);

            // エラーメッセージ返す
            return response()->json(addMessages(['general_error_message' => '権限がありません。']), 403);
        }

        // バリデータ作成
        $validator = Validator::make($request->all(), [
            'updated_at' => ['required', 'date'],
        ]);

        // バリデーション失敗場合
        if ($validator->fails()) {
            return response()->json(addMessages(['general_error_message' => '予定削除に失敗しました。再度削除してください。']), 422);
        }

        // バリデーション結果データ
        $validData = $validator->validated();

        // 別のユーザが更新した場合の制御
        $updateAtFromInput = $validData['updated_at'];
        if ($schedule->updated_at?->notEqualTo(Carbon::create($updateAtFromInput))) {
            return response()->json(addMessages(['general_error_message' => '別のユーザにて既に更新されています。']), 422);
        }

        // 削除処理
        DB::beginTransaction();
        try {

            $schedule->delete(); // 削除処理を行う

            DB::commit(); // 例外がない場合、コミット

            // 削除成功ログ
            $this->createLog('delete', 'success', ['item' => $schedule->id]);

            // 成功メッセージ
            $successMessage = '予定を正常に削除しました。';
            session()->flash('success', $successMessage);
            session()->reflash(); // 次のリクエストにてフラッシュメッセージ残るように

            // 成功メッセージ返す
            return response()->json(['success' => $successMessage], 200);
        } catch (Exception $e) {

            DB::rollBack(); // 例外が発生したら、ロルバック

            // 削除失敗ログ
            $this->createLog('delete', 'error', ['item' => $schedule->id, 'content_detail' => $e]);
            return response()->json(addMessages(['general_error_message' => '予定削除に失敗しました。再度削除してください。']), 422);
        }
    }

    /**
     * 担当者取得
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    private function getUsers()
    {
        // ユーザリスト
        return User::addSelect([
            'is_external' => Auth::selectRaw('true as is_external')
                ->whereColumn('user_id', 'users.id')
                ->where('auth_class', config('constants.auth.pic_external'))
                ->limit(1),
        ])
            ->whereHas('auths', function ($query) {
                $query->whereIn(
                    'auth_class',
                    collect(config('constants.auth'))->filter(function ($auth) {
                        return $auth != config('constants.auth.system_admin');
                    })
                );
            })
            ->orderBy('is_external', 'desc')
            ->get();
    }

    /**
     * 新規予定登録処理実行
     *
     * @param array $validData
     * @param \App\Models\UReception $reception
     *
     * @return void
     */
    private function addSchedule(array $validData)
    {
        // 日程登録
        $schedule = USchedule::create([
            'date' => $validData['date'],
            'schedule_type' => $validData['type'],
            'title' => $validData['title'],
            'content' => $validData['content'],
        ]);

        // 選択された時間帯 //  [['slot_type' => 1], ['slot_type' => 2], ... ]のような形に変換する
        $selectedSlots = $this->getSelectedSlots($validData['slots']); //collect(array_keys($validData['slots']))->map(fn ($item) => ['slot_type' => $item]);

        // 日程テーブルに登録
        $schedule->slots()->createMany($selectedSlots);

        // 選択されたユーザ // [['user_id' => 1], ['user_id' => 2], ...]のような形に変換する
        $selectedPersons = $this->getSelectedPersons($validData['persons']);

        // 日程担当テーブル登録
        $schedule->scheduleUsers()->createMany($selectedPersons);

        // 日程担当詳細登録 // [['user_id' => 1, 'slot_type' => 1], ['user_id' => 1, 'slot_type' => 2], ... ] のような形に変換する
        $selectedDetails = $this->getSelectedDetails($selectedSlots, $selectedPersons);

        // 日程担当詳細テーブル登録
        $schedule->scheduleDetails()->createMany($selectedDetails);
    }

    /**
     * 予定更新処理実行
     *
     * @param array $validData
     * @param \App\Models\USchedule $schedule
     *
     * @return void
     */
    private function updateSchedule(array $validData, USchedule $schedule)
    {
        // 日程更新
        $schedule->update([
            'date' => $validData['date'],
            'schedule_type' => $validData['type'],
            'title' => $validData['title'],
            'content' => $validData['content'],
        ]);

        // ①時間帯更新 ----------------

        // リクエストよりの時間帯 //  [['slot_type' => 1], ['slot_type' => 2], ... ]のような形に変換する
        $inputSelectedSlots = $this->getSelectedSlots($validData['slots']);

        // 時間帯テーブルのレコード(DB)
        $currentSlots = $schedule->slots;

        // 削除される予定の時間帯（リクエストにない時間帯）
        $tobeDeletedSlots = $currentSlots->whereNotIn('slot_type', $inputSelectedSlots->pluck('slot_type'));

        // 選択されないようになった時間帯削除
        USlot::whereIn('id', $tobeDeletedSlots->pluck('id'))->forceDelete();

        // 登録される予定の時間帯（DBにない時間帯）
        $tobeInsertedSlots = $inputSelectedSlots->whereNotIn('slot_type', $currentSlots->pluck('slot_type'));

        // 新時間帯の時間帯をテーブルに登録
        $schedule->slots()->createMany($tobeInsertedSlots);

        // ②日程担当更新 ----------------

        // リクエストよりの日程担当 // [['user_id' => 1], ['user_id' => 2], ...]のような形に変換する
        $inputSelectedPersons = $this->getSelectedPersons($validData['persons']);

        // 日程担当テーブルのレコード(DB)
        $currentPersons = $schedule->scheduleUsers;

        // 削除される予定の日程担当（リクエストにない担当者）
        $tobeDeletedPersons = $currentPersons->whereNotIn('user_id', $inputSelectedPersons->pluck('user_id'));

        // 選択されないようになった日程担当削除
        UScheduleUser::whereIn('id', $tobeDeletedPersons->pluck('id'))->forceDelete();

        // 登録される予定の日程担当（DBにない日程担当）
        $tobeInsertedPersons = $inputSelectedPersons->whereNotIn('user_id', $currentPersons->pluck('user_id'));

        // 日程担当テーブルに登録
        $schedule->scheduleUsers()->createMany($tobeInsertedPersons); // 日程担当テーブル登録

        // ③日程担当詳細更新 ----------------

        // リクエストよりの日程担当詳細  // [['user_id' => 1, 'slot_type' => 1], ['user_id' => 1, 'slot_type' => 2], ... ] のような形に変換する
        $inputSelectedDetails = $this->getSelectedDetails($inputSelectedSlots, $inputSelectedPersons);

        // 日程担当詳細テーブルのレコード(DB)
        $currentScheduleDetails = $schedule->scheduleDetails;

        // 削除される予定の日程担当詳細（リクエストにない担当者）
        $tobeDeletedPersonDetails = $currentScheduleDetails->filter(function ($person) use ($inputSelectedDetails) {
            return !$inputSelectedDetails->contains(function ($input) use ($person) {
                return $person->user_id == $input['user_id'] && $person->slot_type == $input['slot_type']; // $inputSelectedDetailsにないレコードを取得
            });
        });

        // 日程担当詳細削除
        UScheduleDetail::whereIn('id', $tobeDeletedPersonDetails->pluck('id'))->forceDelete();

        // 登録される予定の日程担当詳細（DBにない日程担当詳細）
        $tobeInsertedPersonDetails = $inputSelectedDetails->filter(function ($person) use ($currentScheduleDetails) {
            return !$currentScheduleDetails->contains(function ($current) use ($person) {
                return $person['user_id'] == $current->user_id && $person['slot_type'] == $current->slot_type;
            });
        });

        // 日程担当詳細テーブルに登録
        $schedule->scheduleDetails()->createMany($tobeInsertedPersonDetails); // 日程担当詳細テーブル登録

    }

    /**
     * ユーザinputより選択された時間帯を取得
     *
     * @param array $slots
     *
     * @return Illuminate\Support\Collection
     * [['slot_type' => 1], ['slot_type' => 2], ... ]のような形に変換する
     */
    private function getSelectedSlots(array $slots)
    {
        return collect(array_keys($slots))->map(fn($item) => ['slot_type' => $item]);
    }

    /**
     * ユーザinputより選択されたユーザを取得
     *
     * @param array $persons
     *
     * @return Illuminate\Support\Collection
     * [['user_id' => 1], ['user_id' => 2], ...]のような形に変換する
     */
    private function getSelectedPersons(array $persons)
    {
        return collect(array_keys($persons))->map(fn($item) => ['user_id' => $item]);
    }

    /**
     * ユーザinputより選択された担当者詳細を取得
     *
     * @param Collection $slots (getSelectedSlotsの結果)
     * @param Collection $persons (getSelectedPersonsの結果)
     *
     * @return Illuminate\Support\Collection
     * [['user_id' => 1, 'slot_type' => 1], ['user_id' => 1, 'slot_type' => 2], ... ] のような形に変換する
     */
    private function getSelectedDetails($slots, $persons)
    {
        return $slots->crossJoin($persons)->map(fn($slotPerson) => collect($slotPerson)->reduce(fn($tmp, $item) => $tmp + $item, []));
    }
    /**
     * アクセスログ登録
     *
     * @return void
     */
    private function createLog(
        string $mode,
        string $status = 'success',
        array $options = ['item' => null, 'content_detail' => null],
    ) {
        // $modeは'access', 'update', 'delete', 'insert'のみ
        if (!collect(['access', 'update', 'delete', 'insert'])->contains($mode)) {
            throw new Exception("Only 'access', 'update', 'delete', or 'insert' mode is allowed.");
        }

        // $statusは'success', 'errror'のみ
        if (!collect(['success', 'error'])->contains($status)) {
            throw new Exception("Only 'success' or 'errror' status is allowed.");
        }

        // ログタイプ
        $types = [
            'access' => config('constants.logs.page_access'),
            'update' => config('constants.logs.data_update'),
            'delete' => config('constants.logs.data_delete'),
            'insert' => config('constants.logs.data_insert'),
        ];

        // 処理名
        $names = [
            'access' => '通常予定設定画面アクセス',
            'update' => '通常予定更新',
            'delete' => '通常予定削除',
            'insert' => '通常予定追加',
        ];

        // 内容
        $contents = [
            'access' => [
                'success' => "通常予定設定画面をアクセスしました。",
                'error' => "通常予定設定画面のアクセスに失敗しました。",
            ],
            'update' => [
                'success' => "通常予定{$options['item']}更新に成功しました。",
                'error' => "通常予定{$options['item']}更新に失敗しました。",
            ],
            'delete' => [
                'success' => "通常予定{$options['item']}削除に成功しました。",
                'error' => "通常予定{$options['item']}削除に失敗しました。",
            ],
            'insert' => [
                'success' => "通常予定{$options['item']}登録に成功しました。",
                'error' => "通常予定登録に失敗しました。",
            ],
        ];

        // ログ登録
        Logger::create([
            'user_id' => auth()->user()->id,
            'process_type' => $types[$mode],
            'process_name' => $names[$mode],
            'content' => $contents[$mode][$status],
            'content_detail' => $options['content_detail'] ?? null,
        ]);
    }
}
