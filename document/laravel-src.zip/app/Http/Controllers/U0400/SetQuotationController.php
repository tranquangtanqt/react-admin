<?php

namespace App\Http\Controllers\U0400;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\CodeClass;
use App\Models\UQuotation;
use App\Models\UReception;
use App\Models\UWorkReport;
use App\Rules\NotInvalidChars;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class SetQuotationController extends Controller
{
    /**
     * 処理名
     *
     * @var string
     */
    protected $processName = '';

    /**
     * 該当する見積設定画面情報を表示します。
     *
     * @return view
     */
    public function show($receptionNo)
    {
        $reception = UReception::findOrFail($receptionNo);

        // 権限チェック
        $this->authorize('updateQuotation', $reception);

        $workReport = UWorkReport::findOrFail($receptionNo);

        $this->processName = '見積設定アクセス';
        // ログ出力
        $this->outputLog(config('constants.logs.page_access'), '見積設定画面にアクセスしました。');

        // 見積明細
        $quotations = UQuotation::join('u_work_reports', 'u_work_reports.reception_no', '=', 'u_quotations.reception_no')
            ->where('u_quotations.reception_no', $receptionNo)
            ->select('u_quotations.*')
            ->orderBy('u_quotations.serial_no')
            ->get();

        // 単位選択
        $unitTemplates = CodeClass::where('identifier_code', config('constants.codes.quot_unit'))
            ->orderBy('display_order')->get();

        // 見積作業名・品名選択
        $nameTemplates = CodeClass::where('identifier_code', config('constants.codes.quot_work_name'))
            ->orderBy('display_order')->get();

        return view('U0400.SetQuotation', compact('receptionNo', 'quotations', 'unitTemplates', 'nameTemplates', 'workReport'));
    }

    /**
     * 該当する見積情報を変更します。
     *
     * @return void
     */
    public function update(Request $request)
    {
        $recepNo =  $request->reception_no;
        $workReport = UWorkReport::findOrFail($recepNo);

        $validator = Validator::make(
            $request->all(),
            [
                'name.*' => ['required', new NotInvalidChars()],
                'newName.*' => ['required', new NotInvalidChars()],
                'workNo.*' => 'nullable|regex:/^[\w-]*$/',
                'newWorkNo.*' => 'nullable|regex:/^[\w-]*$/',
                'quantity.*' => 'nullable|regex:/^\d{1,3}(\.\d{1,2})?$/',
                'newQuantity.*' => 'nullable|regex:/^\d{1,3}(\.\d{1,2})?$/',
                'unit.*' => ['nullable', new NotInvalidChars()],
                'newUnit.*' => ['nullable', new NotInvalidChars()],
                'amount.*' => 'nullable|regex:/^\d{1,3}(,\d{1,3}(,\d{1,3})?)?$/',
                'newAmount.*' => 'nullable|regex:/^\d{1,3}(,\d{1,3}(,\d{1,3})?)?$/'
            ],
            [
                'name.*.required' => ':attribute|作業名・品名を設定してください。',
                'newName.*.required' => ':attribute|作業名・品名を設定してください。',
                'workNo.*.regex' => ':attribute|作業Ｎｏ・品番に英数記号以外が含まれています。',
                'newWorkNo.*.regex' => ':attribute|作業Ｎｏ・品番に英数記号以外が含まれています。',
                'quantity.*.regex' => ':attribute|数量は整数3桁小数2桁で入力してください。',
                'newQuantity.*.regex' => ':attribute|数量は整数3桁小数2桁で入力してください。',
                'amount.*.regex' => ':attribute|金額は整数9桁で入力してください。',
                'newAmount.*.regex' => ':attribute|金額は整数9桁で入力してください。'
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 'NG',
                'message' => $validator->errors()->all(), 'errors' => []
            ], 422);
        }

        // 更新時間を確認してください
        if ($workReport->updated_at != $request->updated_at) {
            return response()->json([
                'status' => 'NG',
                'message' => 'Exclusive|別のユーザーにて既に更新されています。'
            ], 419);
        }

        // 更新時間を確認してください
        if ($request->updatedAt != null) {
            foreach ($request->updatedAt as $key => $value) {
                $quotation = UQuotation::where('id', $key)->first();
                if ($quotation->updated_at != $value) {
                    return response()->json([
                        'status' => 'NG',
                        'message' => 'Exclusive|別のユーザーにて既に更新されています。'
                    ], 419);
                }
            }
        }

        DB::beginTransaction();
        try {

            $tax = $workReport->tax_included_flag == true ? 1 : 0;
            if ($tax != $request->tax) {
                $this->processName = '見積消費税込フラグ入替';
                $workReport->tax_included_flag = $request->tax;
                $workReport->save();
                // ログ出力
                $this->outputLog(config('constants.logs.data_update'), '見積消費税込フラグ入を入替しました。');
            }

            // 見積削除
            if (!empty($request->deletedIds)) {
                $this->processName = '見積削除';
                DB::table('u_quotations')
                    ->where('reception_no', $recepNo)
                    ->whereIn('id', explode(",", $request->deletedIds))
                    ->delete();
                // ログ出力
                $this->outputLog(config('constants.logs.data_delete'), '見積を削除しました。');
            }

            // 見積入替
            if (!empty($request->id)) {
                $changeFlag = false;
                foreach ($request->id as $key => $value) {
                    $quotation = UQuotation::where('id', $value)->first();

                    if ($quotation->work_no != $request->workNo[$key]) {
                        $quotation->work_no = $request->workNo[$key];
                        $changeFlag = true;
                    }
                    if ($quotation->quantity != $request->quantity[$key]) {
                        $quotation->quantity = $request->quantity[$key];
                        $changeFlag = true;
                    }
                    if ($quotation->unit != $request->unit[$key]) {
                        $quotation->unit = $request->unit[$key];
                        $changeFlag = true;
                    }
                    if ($quotation->amount != $this->getAmount($request->amount[$key])) {
                        $quotation->amount = $this->getAmount($request->amount[$key]);
                        $changeFlag = true;
                    }
                    if ($quotation->name != $request->name[$key]) {
                        $quotation->name = $request->name[$key];
                        $changeFlag = true;
                    }

                    if ($changeFlag == true) {
                        $quotation->updated_by = auth()->user()->id;
                        $this->processName = '見積入替';
                        $quotation->save();
                    }
                }
                if ($changeFlag == true) {
                    // ログ出力
                    $this->outputLog(config('constants.logs.data_update'), '見積を入替しました。');
                }
            }

            // 見積登録
            if (!empty($request->newName)) {
                $this->processName = '見積登録';
                $quotations = UQuotation::where('reception_no', $recepNo)->get();
                $data = [];
                $serialNo = $quotations->max('serial_no');

                foreach ($request->newName as $key => $value) {
                    $serialNo++;
                    $newQuotation =
                        [
                            'reception_no' => $recepNo,
                            'serial_no' => $serialNo,
                            'work_no' =>  $request->newWorkNo[$key],
                            'quantity' => $request->newQuantity[$key],
                            'unit' =>  $request->newUnit[$key],
                            'amount' =>  $this->getAmount($request->newAmount[$key]),
                            'name' =>  $request->newName[$key],
                            'created_by' => auth()->user()->id,
                            'created_at' => Carbon::now(),
                            'updated_by' => auth()->user()->id,
                            'updated_at' => Carbon::now()
                        ];
                    array_push($data, $newQuotation);
                }
                UQuotation::insert($data);
                // ログ出力
                $this->outputLog(config('constants.logs.data_insert'), '見積を登録しました。');
            }

            DB::commit();
            $message =  '見積を正常に更新しました。';
            session()->flash('success', $message);
            return response()->json([
                'status' => 'OK',
                'message' => $message,
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            // ログ出力
            $this->outputLog(config('constants.logs.update'), '見積の入替に失敗しました', $e);
            $message = '予期せぬエラーが発生しました。';
            session()->flash('failure', $message);
            return response()->json([
                'status' => 'NG',
                'message' => $message,
            ], 500);
        }
    }

    /**
     * ログ出力
     *
     * @return int
     */
    public function getAmount($money)
    {
        return (int) str_replace(',', '', $money);
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $this->processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
