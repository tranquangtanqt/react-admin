<?php

namespace App\Http\Controllers\U0400;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\UReception;
use App\Rules\NotInvalidChars;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

/**
 * 原価設定
 */
class SetCostController extends Controller
{
    /**
     * 該当する原価設定情報を表示します。
     */
    public function index($receptionNo)
    {
        $reception = UReception::findOrFail($receptionNo);

        // 権限チェック
        $this->authorize('updateCost', $reception);

        $typeList = DB::table('code_classes')
            ->where('identifier_code', config('constants.codes.cost'))
            ->where('deleted_at', null)
            ->select('key', 'value')
            ->orderBy('display_order', 'ASC')
            ->get();

        $materialCostList = DB::table('code_classes')
            ->where('identifier_code', config('constants.codes.material_cost'))
            ->where('deleted_at', null)
            ->select('key', 'value')
            ->get();

        $constructCostList = DB::table('code_classes')
            ->where('identifier_code', config('constants.codes.construct_cost'))
            ->where('deleted_at', null)
            ->select('key', 'value')
            ->get();

        $first = DB::table('u_costs')
            ->where('reception_no', $receptionNo)
            ->where('registered_class', '0');

        $costs = DB::table('u_costs')
            ->where('reception_no', $receptionNo)
            ->where('registered_class', '<>', '0')
            ->orderBy('registered_class', 'ASC')
            ->unionAll($first)
            ->get();

        $maxCostId = $costs->max('id');

        // ログ出力
        $this->outputLog(
            '原価設定アクセス',
            config('constants.logs.page_access'),
            '原価設定にアクセスしました。'
        );

        return view('U0400.SetCost', compact([
            'costs', 'receptionNo', 'typeList', 'materialCostList', 'constructCostList', 'maxCostId'
        ]));
    }

    /**
     * 該当する原価設定情報を変更します。
     */
    public function change(Request $request)
    {
        // インプットデータを確実する
        $validator = Validator::make($request->all(), [
            'name.*' => ['required', new NotInvalidChars()],
            'name_new.*' => ['required', new NotInvalidChars()],
            'amount.*' => 'nullable|regex:/^\d{1,3}(,\d{1,3}(,\d{1,3})?)?$/',
            'amount_new.*' => 'nullable|regex:/^\d{1,3}(,\d{1,3}(,\d{1,3})?)?$/',
        ], [
            'name.*.required' => ':attribute|原価名称を設定してください。',
            'name_new.*.required' => ':attribute|原価名称を設定してください。',
            'amount.*.regex' => ':attribute|金額は整数9桁で入力してください。',
            'amount_new.*.regex' => ':attribute|金額は整数9桁で入力してください。',
        ], [
            'name' => '原価名称'
        ]);

        if ($validator->fails()) {
            return response()
                ->json([
                    'status' => 'NG',
                    'message' => $validator->errors()->all(),
                    'data' => []
                ], 422);
        }

        if ($request->updated_at) {
            $exclusive = DB::table('u_costs')
                ->where('reception_no', $request->reception_no)
                ->where('updated_at', '>', $request->updated_at)
                ->first();

            $countCostNow = DB::table('u_costs')
                ->where('reception_no', $request->reception_no)
                ->count();

            if ($exclusive || $countCostNow != $request->count_cost) {
                return response()->json([
                    'status' => 'NG',
                    'message' => '別のユーザーにて既に更新されています。',
                    'data' => []
                ], 500);
            }
        }

        try {
            DB::beginTransaction();

            if ($request->updated_at) {
                $checkUpdate = false;
                if ($request->update_arr != null) {
                    $update_arr = explode(",", $request->update_arr);
                    foreach ($update_arr as $update_id) {
                        $checkUpdate = true;
                        DB::table('u_costs')
                            ->where('id', $update_id)
                            ->update([
                                'type' => $request->type[$update_id],
                                'name' => $request->name[$update_id],
                                'amount' => $this->getAmount($request->amount[$update_id]),
                                'updated_at' => now(),
                                'updated_by' => auth()->user()->id
                            ]);
                    }

                    if ($checkUpdate) {
                        // ログ出力
                        $this->outputLog(
                            '原価設定入替',
                            config('constants.logs.data_update'),
                            '原価設定を入替しました。'
                        );
                    }
                }

                if ($request->delete_arr != null) {
                    $delete_arr = explode(",", $request->delete_arr);

                    $checkDelete = false;
                    DB::table('u_costs')
                        ->where('reception_no', $request->reception_no)
                        ->whereIn('id', $delete_arr)
                        ->delete();
                    $checkDelete = true;

                    if ($checkDelete) {
                        // ログ出力
                        $this->outputLog(
                            '原価設定削除',
                            config('constants.logs.data_delete'),
                            '原価設定を削除しました。'
                        );
                    }
                }
            }

            $maxSerialNo = DB::table('u_costs')
                ->where('reception_no', $request->reception_no)
                ->select('serial_no')
                ->max('serial_no');

            $checkAdd = false;

            if ($request->add_arr != null) {
                $add_arr = explode(",", $request->add_arr);
                foreach ($add_arr as $add_id) {
                    $maxSerialNo++;
                    DB::table('u_costs')
                        ->insert([
                            'reception_no' => $request->reception_no,
                            'serial_no' => $maxSerialNo,
                            'type' => $request->type_new[$add_id],
                            'name' => $request->name_new[$add_id],
                            'amount' => $this->getAmount($request->amount_new[$add_id]),
                            'registered_class' => '0',
                            'checked_flag' => false,
                            'created_at' => now(),
                            'created_by' => auth()->user()->id,
                            'updated_at' => now(),
                            'updated_by' => auth()->user()->id
                        ]);
                    $checkAdd = true;
                }

                if ($checkAdd) {
                    // ログ出力
                    $this->outputLog(
                        '原価設定登録',
                        config('constants.logs.data_insert'),
                        '原価設定を登録しました。'
                    );
                }
            }

            DB::commit();

            session()->flash('success', '原価を正常に設定しました。');

            return response()->json(['status' => 200]);
        } catch (\Exception $e) {
            DB::rollBack();

            $this->outputLog(
                '原価設定',
                config('constants.logs.data_insert'),
                '原価設定画面登録エラー',
                $e
            );
            return response()->json([
                'message' => '予期せぬエラーが発生しました。',
                'data' => []
            ], 500);
        }
    }

    /**
     * 金額での","を削除する。
     */
    private function getAmount($money)
    {
        return (int) str_replace(',', '', $money);
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
