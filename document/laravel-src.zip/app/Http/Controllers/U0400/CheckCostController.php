<?php

namespace App\Http\Controllers\U0400;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use App\Models\UReception;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * 原価チェック
 */
class CheckCostController extends Controller
{
    /**
     * 全ての原価チェックのデータを表示します。
     */
    public function index($receptionNo)
    {

        $reception = UReception::findOrFail($receptionNo);

        // 入力支援権限持っているか
        $authFlg = userIsInputSupport();

        $typeList = DB::table('code_classes')
            ->where('identifier_code', config('constants.codes.cost'))
            ->where('deleted_at', null)
            ->select('key', 'value')
            ->orderBy('display_order', 'ASC')
            ->get();

        $first = DB::table('u_costs')
            ->where('reception_no', $receptionNo)
            ->where('registered_class', '0');

        $costs = DB::table('u_costs')
            ->where('reception_no', $receptionNo)
            ->where('registered_class', '<>', '0')
            ->orderBy('registered_class', 'ASC')
            ->unionAll($first)
            ->get();

        // ログ出力
        $this->outputLog(
            '原価チェックアクセス',
            config('constants.logs.page_access'),
            '原価チェックにアクセスしました。'
        );

        return view('U0400.CheckCost', compact([
            'costs', 'receptionNo', 'typeList', 'authFlg'
        ]));
    }

    /**
     * 該当する原価チェック情報を変更します。
     */
    public function update(Request $request)
    {
        $arrId = array();
        if ($request->checked_flag) {
            foreach ($request->checked_flag as $id) {
                array_push($arrId, $id);
            }
        }

        $exclusive = DB::table('u_costs')
            ->where('reception_no', $request->receptionNo)
            ->where('updated_at', '>', $request->updated_at)
            ->first();

        if ($exclusive) {
            return back()->with(['messageErr' => '別のユーザーにて既に更新されています。']);
        }

        DB::beginTransaction();
        try {
            DB::table('u_costs')
                ->where('reception_no', $request->receptionNo)
                ->update([
                    'checked_flag' => false,
                    'updated_at' => now(),
                    'updated_by' => auth()->user()->id
                ]);

            if ($arrId) {
                DB::table('u_costs')
                    ->where('reception_no', $request->receptionNo)
                    ->whereIn('id', $arrId)
                    ->update([
                        'checked_flag' => true,
                        'updated_at' => now(),
                        'updated_by' => auth()->user()->id
                    ]);
            }

            DB::commit();
            session()->flash('success', '原価チェックを正常に設定しました。');
            // ログ出力
            $this->outputLog(
                '原価チェック入替',
                config('constants.logs.data_update'),
                '原価チェックを入替しました。'
            );

            return redirect()->route('receptions.finance.show', ['reception' => $request->receptionNo]);
        } catch (\Exception $e) {
            DB::rollBack();
            $this->outputLog(
                '原価チェック',
                config('constants.logs.data_update'),
                '原価チェック画面登録エラー',
                $e
            );

            session()->flash('failure', '予期せぬエラーが発生しました。');
            return redirect()->route('receptions.finance.show', ['reception' => $request->receptionNo]);
        }
    }

    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
