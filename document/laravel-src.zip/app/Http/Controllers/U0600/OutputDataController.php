<?php

namespace App\Http\Controllers\U0600;

use App\Commons\Logger;
use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

/**
 * データ出力
 *
 * @author  donlq
 * @create_date  2021-10-28
 */
class OutputDataController extends Controller
{
    /**
     *
     *
     * @return \Illuminate\Http\Controller
     */
    public function show()
    {

        // ログ出力
        $this->outputLog(
            'データ出力アクセス',
            config('constants.logs.page_access'),
            'データ出力にアクセスしました。'
        );
        return view('U0600.OutputData')->with(['dateStart' => null, 'dateEnd' => null]);
    }

    /**
     *
     *
     * @param  request $request
     * @return \Illuminate\Http\Controller
     */
    public function export(request $request)
    {
        try {
            $validator = Validator::make(
                $request->all(),
                [
                    'dateStart' => 'required|date_format:Y/m/d|before_or_equal:dateEnd',
                    'dateEnd' => 'required|date_format:Y/m/d',
                ],
                [
                    'dateStart.required' => 'dateStart|開始交付年月日を設定してください。',
                    'dateEnd.required' => 'dateEnd|終了交付年月日を設定してください。',
                    'dateStart.date_format' => 'dateStart|開始交付年月日はYYYY/MM/DDで設定してください。',
                    'dateEnd.date_format' => 'dateEnd|終了交付年月日はYYYY/MM/DDで設定してください。',
                    'dateStart.before_or_equal' => 'dateStart|終了交付年月日は開始交付年月日以降の日付を設定してください。'
                ]
            );
            if ($validator->fails()) {
                return response()->json([
                    'status'    =>  'NG',
                    'message'   =>  $validator->errors()->all(),
                    'data'      =>  []
                ], 422);
            }


            $gasin = DB::table('u_gas_in_info')
                ->leftJoin('code_classes as cls1', function ($join) {
                    $join->on('u_gas_in_info.type', '=', 'cls1.key')
                        ->where('cls1.identifier_code', '=', config('constants.codes.fill'))
                        ->whereNull('cls1.deleted_at');
                })
                ->leftJoin('code_classes as cls2', function ($join) {
                    $join->on('u_gas_in_info.gas_type', '=', 'cls2.key')
                        ->where('cls2.identifier_code', '=', config('constants.codes.fill_type'))
                        ->whereNull('cls2.deleted_at');
                })
                ->whereNull('u_gas_in_info.deleted_at')
                ->where('date', '<=', $request->dateEnd)
                ->where('date', '>=', $request->dateStart)
                ->select('cls1.value as value_type', 'cls2.value as value_gas_type', 'type', 'gas_type', 'gas_type_name', 'date', 'reception_no', 'quantity')
                ->get()
                ->toArray();

            $gasOut = DB::table('u_gas_out_info')
                ->leftJoin('code_classes as cls1', function ($join) {
                    $join->on('u_gas_out_info.type', '=', 'cls1.key')
                        ->where('cls1.identifier_code', '=', config('constants.codes.collect'))
                        ->whereNull('cls1.deleted_at');
                })
                ->leftJoin('code_classes as cls2', function ($join) {
                    $join->on('u_gas_out_info.gas_type', '=', 'cls2.key')
                        ->where('cls2.identifier_code', '=', config('constants.codes.collect_type'))
                        ->whereNull('cls2.deleted_at');
                })
                ->whereNull('u_gas_out_info.deleted_at')
                ->where('date', '<=', $request->dateEnd)
                ->where('date', '>=', $request->dateStart)
                ->select('cls1.value as value_type', 'cls2.value as value_gas_type', 'type', 'gas_type', 'gas_type_name', 'date', 'reception_no', 'quantity')
                ->get()
                ->toArray();

            $list = array_merge($gasin, $gasOut);

            // ログ出力
            $this->outputLog(
                'データ出力ダウンロード',
                config('constants.logs.download'),
                'データ出力をダウンロードしました。'
            );
            if ($list == []) {
                return response()->json(['status' => 'NG', 'message' => '該当するデータが見つかりませんでした。', 'data' => []], 500);
            }
            $listSort = collect($list);
            $list = $listSort->sortBy('reception_no');
            $headers = array(
                "Content-Disposition" => "attachment; filename=GasInfo_" . now()->year . now()->month . now()->day . "_" . now()->hour . now()->minute . now()->second . ".csv",
                "Content-type"        => "application/csv",
                "Content-Description" => "File Transfer",
                "Pragma"              => "no-cache",
                "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0"
            );
            $callback = function () use ($list) {
                $handle = fopen('php://output', 'w');
                ob_clean();
                $header = [];
                $this->push($header, '受付番号');
                $this->push($header, '充塡回収区分');
                $this->push($header, '充塡回収種類');
                $this->push($header, '充塡回収種類名');
                $this->push($header, '充塡回収量');
                $this->push($header, '充填回収交付年月日');
                fwrite($handle, implode(',', $header) . PHP_EOL);
                foreach ($list as $item) {
                    $data = [];
                    $item->value_type = $this->trimSpace($item->value_type);
                    $item->value_gas_type = $this->trimSpace($item->value_gas_type);
                    $item->gas_type_name = $this->trimSpace($item->gas_type_name);
                    $item->reception_no = $this->trimSpace($item->reception_no);
                    $this->push($data, $item->reception_no);
                    $this->push($data, $item->value_type);
                    $this->push($data, $item->value_gas_type);
                    $this->push($data, $item->gas_type_name);
                    array_push($data, $item->quantity);
                    array_push($data, date('Y/m/d', strtotime($item->date)));
                    fwrite($handle, implode(',', $data) . PHP_EOL);
                }
                ob_flush();
                fclose($handle);
            };
            return response()->stream($callback, 200, $headers);
        } catch (\Exception $e) {
            $this->outputLog('データ出力', config('constants.logs.download'), 'データ出力に失敗しました。', $e);
            return response()->json(['status' => 'NG', 'message' => '予期せぬエラーが発生しました。', 'data' => []], 500);
        }
    }
    function push(&$data, $item)
    {
        if (count(explode('"', $item)) % 2 == 0) {
            $item = Str::replaceArray('"', ['""'], $item);
        }
        $quote = chr(34);
        if ($item == null) {
            $data[] = $item;
        } else {
            $data[] = $quote . strval($item) . $quote;
        }
    }
    public function trimSpace($value)
    {
        mb_internal_encoding('UTF-8');
        mb_regex_encoding('UTF-8');
        $value = mb_ereg_replace("^[\n\r\s\t　]+", '', $value);
        $value = mb_ereg_replace("[\n\r\s\t　]+$", '', $value);
        $value = trim($value);
        return $value;
    }
    /**
     * ログ出力
     *
     * @return void
     */
    private function outputLog($processName, $processType, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        $logInfo['user_id'] = auth()->user()->id;
        $logInfo['process_name'] = $processName;
        $logInfo['process_type'] = $processType;
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }
}
