<?php

namespace App\Http\Requests\U0300;

use App\Rules\NotInvalidChars;
use Illuminate\Foundation\Http\FormRequest;

class SetManHourRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
            //--'startTime' => 'required|date_format:H:i|before:endTime',
            //--'endTime'   => 'required|date_format:H:i',
            'startTime' => 'required|regex:/^[0-3][0-9]:[0-5][0-9]$/',
            'endTime'   => 'required|regex:/^[0-3][0-9]:[0-5][0-9]$/',
            // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応
            'manHour'   => 'required|regex:/^\d{1,2}(\.\d{1,2})?$/',
            'workContent' =>['nullable', new NotInvalidChars()],
            'work' => 'required',
        ];
    }


    // ADD START 20220404 Ishino OT-034 35:59まで入力可能とする対応
    /**
     * モーダル情報追加
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return void
     */
    public function withValidator($validator)
    {
        $start_time = $this->input('startTime');
        $end_time = $this->input('endTime');
        $validator->after(function ($validator) use($start_time, $end_time) {
            if (strcmp( $start_time , $end_time ) > 0) {
                $validator->errors()->add('endTime', '終了時間は開始時間以降の値を設定してください。');
            }
        });

    }
    // ADD E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応

    /**
     * Get custom attributes for validator errors.
    *
    * @return array
     */
     public function attributes()
     {
        return [
            'workContent' => '作業内容',
            'work' => '作業区分',
        ];
    }

       /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'startTime.required' => '開始時間を設定してください。',
            // DEL START 20220404 Ishino OT-034 35:59まで入力可能とする対応
            //'startTime.before' => '終了時間は開始時間以降の値を設定してください。',
            // DEL E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応
            'endTime.required' => '終了時間を設定してください。',
            // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
            //--'startTime.date_format' => '開始時間はHH:MM形式で設定してください',
            //--'endTime.date_format' => '終了時間はHH:MM形式で設定してください。',
            'startTime.regex' => '開始時間はHH:MM形式で設定してください',
            'endTime.regex' => '終了時間はHH:MM形式で設定してください。',
            // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応
            'manHour.required' => '工数を設定してください。',
            'work.required' => ':attributeを設定してください。',
            'manHour.regex' => '工数は整数2桁小数2桁で入力してください。',
            'workContent.required' => ':attributeを設定してください。',
        ];
    }
}
