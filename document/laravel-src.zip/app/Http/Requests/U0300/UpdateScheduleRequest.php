<?php

namespace App\Http\Requests\U0300;

use App\Rules\NotInvalidChars;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateScheduleRequest extends FormRequest
{
    protected $errorBag = 'edit-schedule';

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'edit_schedule_date' => ['required', 'date_format:Y/m/d'],
            // CHG START 20220406 Ishino OT-018 詳細の必須入力を任意入力に変更（required属性を削除）
            //'edit_schedule_content' => ['required', new NotInvalidChars],
            'edit_schedule_content' => [new NotInvalidChars],
            // CHG E N D 20220406 Ishino OT-018 詳細の必須入力を任意入力に変更（required属性を削除）
            'edit_schedule_persons.*.slots' => [''],
            'edit_schedule_persons.*.id' => ['required'],
            'edit_schedule_id' => ['required', 'integer'],
            'edit_updated_at' => ['required', 'date'],
        ];
    }

    /**
     * モーダル情報追加
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return void
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            // 選択された時間帯
            $existSlots = request()->collect('edit_schedule_persons')
                ->filter(function ($item) {
                    return collect($item)->has('slots');
                });

            if ($existSlots->isEmpty()) { // 時間帯が選択されない場合
                $validator->errors()->add('edit_schedule_slots', '時間帯を選択肢てください。');
            }
        });

    }

    /**
     * エラーメッセージ設定
     *
     * @return array
     */
    public function messages()
    {
        return [
            'edit_schedule_date.required' => '予定日付を設定してください。',
            'edit_schedule_date.date_format' => '予定日付の値が日付として扱えません。',
            'edit_schedule_content.required' => '詳細を設定してください。',
        ];
    }

    /**
     * 項目名設定設定
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'edit_schedule_date' => '予定日付',
            'edit_schedule_content' => '詳細',
        ];
    }

    /**
     * バリデーション失敗の時
     *
     * @return void
     */
    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json($validator->errors(), 422));
    }
}
