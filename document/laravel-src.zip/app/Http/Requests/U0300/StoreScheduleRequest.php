<?php

namespace App\Http\Requests\U0300;

use App\Rules\NotInvalidChars;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreScheduleRequest extends FormRequest
{

    protected $errorBag = 'add-schedule';

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'add_schedule_date' => ['required', 'date_format:Y/m/d',],
            // CHG START 20220406 Ishino OT-018 詳細の必須入力を任意入力に変更（required属性を削除）
            //'add_schedule_content' => ['required', new NotInvalidChars],
            'add_schedule_content' => [new NotInvalidChars],
            // CHG E N D 20220406 Ishino OT-018 詳細の必須入力を任意入力に変更（required属性を削除）
            'add_schedule_persons.*.slots' => [''],
            'add_schedule_persons.*.id' => ['required'],
            'pjmgr_id' => ['nullable'],
        ];
    }

    /**
     * モーダル情報追加
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return void
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            // 選択された時間帯
            $existSlots = request()->collect('add_schedule_persons')
                ->filter(function ($item) {
                    return collect($item)->has('slots');
                });

            if ($existSlots->isEmpty()) { // 時間帯が選択されない場合
                $validator->errors()->add('add_schedule_slots', '時間帯を選択肢てください。');
            }
        });

    }

    /**
     * エラーメッセージ設定
     *
     * @return array
     */
    public function messages()
    {
        return [
            'add_schedule_date.required' => '予定日付を設定してください。',
            'add_schedule_date.date_format' => '予定日付の値が日付として扱えません。',
            'add_schedule_content.required' => '詳細を設定してください。',
        ];
    }

    /**
     * 項目名設定設定
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'add_schedule_date' => '予定日付',
            'add_schedule_content' => '詳細',
        ];
    }

    /**
     * バリデーション失敗の時
     *
     * @return void
     */
    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json($validator->errors(), 422));
    }

}
