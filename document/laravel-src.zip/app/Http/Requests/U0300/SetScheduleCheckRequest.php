<?php

namespace App\Http\Requests\U0300;

use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class SetScheduleCheckRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'mode' => 'required',
            'start_date' => ['bail', 'required', 'date_format:Y/m/d', 'before_or_equal:end_date',], // 予定日付（開始）
            'end_date' => ['bail', 'required', 'date_format:Y/m/d'], // 予定日付（終了）
            'schedule_slots' => ['required'],
            'internal_persons' => ['bail', 'required', 'digits_between:1,2'],
            'external_persons' => ['bail', 'required', 'digits_between:1,2'],
            'schedule_persons' => ['required'],
        ];
    }

    /**
     * エラーメッセージ設定
     *
     * @return array
     */
    public function messages()
    {
        return [
            'required' => ':attributeを設定してください。',
            'start_date.before_or_equal' => '予定日付（開始）が予定日付（終了）超えています。',
            'schedule_slots.required' => '時間帯を選択してください。',
            'schedule_persons.required' => '担当者を選択してください。',
            'digits_between' => ':attributeは整数:max桁を設定してください。',
            'date_format' => ':attributeの値が日付として扱えません。',
        ];
    }

    /**
     * 項目名設定設定
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'start_date' => '予定日付（開始）',
            'end_date' => '予定日付（終了）',
            'internal_persons' => '社内人数',
            'external_persons' => '協力会社人数',
        ];
    }

    /**
     * バリデーション失敗の時
     *
     * @return void
     */
    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json($validator->errors(), 422));
    }

    /**
     * モーダル情報追加
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return void
     */
    public function withValidator($validator)
    {
        if (!$validator->fails()) {
            $validator->after(function ($validator) {
                $reqStartDate = request()->get('start_date');
                $reqEndDate = request()->get('end_date');

                if (!$reqStartDate || !$reqEndDate) { // 開始日・終了日がないとき
                    return;
                }

                try {
                    // 予定日付（開始）
                    $startDate = Carbon::create($reqStartDate)->startOfDay();

                    // 予定日付（終了）
                    $endDate = Carbon::create($reqEndDate)->startOfDay();
                } catch (Exception $e) {
                    return;
                }

                // 期間が30日以上の場合
                $term = config('constants.scheduleCheckTerm');
                if ($endDate->diffInDays($startDate) > $term) {
                    $validator->errors()->add('date', "予定日付の期間は最大${term}日と設定してください。");
                }
            });
        }
    }
}
