<?php

namespace App\Http\Requests\X0600;

use App\Rules\Password;
use App\Models\CodeClass;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Http\FormRequest;

class UpdatePasswordRequest extends FormRequest
{


    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'password' => ['required', 'current_password'],
            'new_password' => $this->getNewPasswordRules(),
        ];
    }

    /**
     * バリデーションメッセージ
     *
     * @return array
     */
    public function messages()
    {
        return [
            '*.required' => ':attributeを入力してください。',
            'password.current_password' => '現在のパスワードに誤りがあります。',
            '*.alpha_num' => ':attributeの形式が正しくありません。',
            '*.different' => ':attributeは現在のパスワードと異なるパスワードとしてください。',
            '*.min' =>  ':attributeには:min以上入力してください。',
        ];
    }

    /**
     * 項目名設定設定
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'password' => '現在のパスワード',
            'new_password' => '新しいパスワード',
        ];
    }


    /**
     * 新しいパスワードのルール取得
     */
    private function getNewPasswordRules()
    {

        $policy = CodeClass::whereIdentifierCode(config('constants.codes.password'))->get();

        $newPasswordRules = ['required', 'confirmed', 'different:password'];

        // 長さチェック
        $lengthPolicy = $policy->where('key', config('constants.password.min'))->first();
        $length = intval($lengthPolicy->number1);

        $passwordRules = Password::min($length)->validChars();

        // 大文字小文字
        $mixedCasePolicy = $policy->where('key', config('constants.password.mixed_case'))->first();
        if ($mixedCasePolicy->number1 > 0) {
            $passwordRules = $passwordRules->mixedCase();
        }

        // 英字
        $lettersPolicy = $policy->where('key', config('constants.password.letters'))->first();
        if ($lettersPolicy->number1 > 0) {
            $passwordRules = $passwordRules->letters();
        }

        // 数字
        $numbersPolicy = $policy->where('key', config('constants.password.numbers'))->first();
        if ($numbersPolicy->number1 > 0) {
            $passwordRules = $passwordRules->numbers();
        }

        // 記号
        $symbolsPolicy = $policy->where('key', config('constants.password.symbols'))->first();
        if ($symbolsPolicy->number1 > 0) {
            $passwordRules = $passwordRules->symbols();
        }

        return array_merge($newPasswordRules, [$passwordRules]);
    }
}
