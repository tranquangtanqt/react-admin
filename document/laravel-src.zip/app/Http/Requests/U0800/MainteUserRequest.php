<?php

namespace App\Http\Requests\U0800;

use Illuminate\Foundation\Http\FormRequest;
use App\Rules\NotInvalidChars;

class MainteUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'login_id' => 'required|regex:/^[a-zA-Z0-9]*$/',
            'name' => ['required', new NotInvalidChars()],
            'short_name' => ['required', new NotInvalidChars()],
            'email' => 'required|email',
            'external_company_id' => ['regex:/^[a-zA-Z0-9]*$/', 'nullable', new NotInvalidChars()],
            'external_user_id' => ['regex:/^[a-zA-Z0-9]*$/', 'nullable', new NotInvalidChars()]
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'login_id.required' => 'ユーザーIDを入力してください。',
            'login_id.regex' => 'ログインIDに英数記号以外が含まれています。',
            'name.required' => '氏名を入力してください。',
            'short_name.required' => '略称を入力してください。',
            'email.required' => 'メールアドレスを入力してください。',
            'email.email' => 'メールアドレスの形式が正しくありません。',
            'external_company_id.regex' => '会社コードに入力禁止文字が含まれています。',
            'external_user_id.regex' => 'ユーザーコードに入力禁止文字が含まれています。'
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'name' => '氏名',
            'short_name' => '略称',
            'external_company_id' => '会社コード',
            'external_user_id' => 'ユーザーコード'
        ];
    }
    /**
     * Prepare the data for validation.
     *
     * @return void
     */
    protected function prepareForValidation()
    {
        $this->merge([
        ]);
    }
}
