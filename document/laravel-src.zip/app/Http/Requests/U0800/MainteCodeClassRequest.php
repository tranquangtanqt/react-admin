<?php

namespace App\Http\Requests\U0800;

use Illuminate\Foundation\Http\FormRequest;
use App\Rules\NotInvalidChars;

class MainteCodeClassRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'key' => 'required|regex:/^[a-zA-Z0-9]*$/',
            'value' => ['required', new NotInvalidChars()],
            'display_order' => 'required|regex:/^[a-zA-Z0-9]*$/',
            'number1' => 'numeric|between:0,999999999.999|nullable',
            'number2' => 'numeric|between:0,999999999.999|nullable',
            'number3' => 'numeric|between:0,999999999.999|nullable',
            'string1' => new NotInvalidChars(),
            'string2' => new NotInvalidChars(),
            'string3' => new NotInvalidChars()
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'key.required' => 'キーを入力してください。',
            'key.regex' => 'キーに英数記号以外が含まれています。',
            'value.required' => '値を入力してください。',
            'display_order.required' => '表示順を入力してください。',
            'display_order.regex' => '表示順に英数記号以外が含まれています。',
            'number1.numeric' => '数値１は整数9桁小数3桁で入力してください。',
            'number1.between' => '数値１は整数9桁小数3桁で入力してください。',
            'number2.numeric' => '数値２は整数9桁小数3桁で入力してください。',
            'number2.between' => '数値２は整数9桁小数3桁で入力してください。',
            'number3.numeric' => '数値３は整数9桁小数3桁で入力してください。',
            'number3.between' => '数値３は整数9桁小数3桁で入力してください。'
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'value' => '値',
            'string1' => '文字１',
            'string2' => '文字２',
            'string3' => '文字３',

        ];
    }
    /**
     * Prepare the data for validation.
     *
     * @return void
     */
    protected function prepareForValidation()
    {
        $this->merge([
        ]);
    }
}
