<?php

namespace App\Http\Requests\U0100;

use App\Rules\NotInvalidChars;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateScheduleSettingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'date' => ['required', 'date_format:Y/m/d',],
            'type' => ['required'],
            'slots' => ['required'],
            'persons' => ['required'],
            'title' => ['required', 'max:20', new NotInvalidChars],
            'content' => ['max:100', new NotInvalidChars],
            'updated_at' => ['required', 'date'],
        ];
    }
    /**
     * エラーメッセージ設定
     *
     * @return array
     */
    public function messages()
    {

        return [
            'updated_at' => '予定更新に失敗しました。',
        ];
    }

    /**
     * 項目名設定設定
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'date' => '日付',
            'type' => '予定区分',
            'slots' => '時間帯',
            'persons' => 'ユーザー',
            'title' => '件名',
            'content' => '内容',
        ];
    }

    /**
     * バリデーション失敗の時
     *
     * @return void
     */
    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json($validator->errors(), 422));
    }
}
