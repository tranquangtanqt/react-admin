<?php

namespace App\Http\Requests\U0900;

use App\Models\CodeClass;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class CoopAccountYearMonthRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // APIキーチェック
        $auth = false;
        $apikey = $this->header('X-API-Key');
        if (!empty($apikey)) {
            $codeclass = CodeClass::codeKey(config('constants.codes.api_key'), config('constants.api_key.coopaccountyearmonth'))->first();
            if ($codeclass != null) {
                $auth = ($apikey == $codeclass->string1);
            }
        }
        return $auth;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'inputdata' => ['present'],
            'inputdata.account_year_month' => ['present', 'required', 'date_format:Ym'],
        ];
    }

    /**
     * 認証エラー
     *
     * @return void
     *
     * @throws \Illuminate\Auth\Access\HttpResponseException
     */
    protected function failedAuthorization()
    {
        $res = response()->json([
            'result' => 9,
            'detail' => '認証に失敗しました。',
        ], 401);
        throw new HttpResponseException($res);
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'inputdata.account_year_month.date_format' => ':attributeは正しい年月ではありません。',
            'inputdata.*.date_format' => ':attributeは正しい日付ではありません。',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        $errors = json_decode($validator->errors());
        // バリデーションエラーをdetail用に入れ直し
        $detail = [];
        foreach ($errors as $key=> $value) {
            if (is_array($value)){
                foreach ($value as $subKey=> $subValue) {
                    array_push($detail, $subValue);
                }
            }
        }
        $res = response()->json([
            'result' => 9,
            'detail' => $detail,
        ], 400);
        throw new HttpResponseException($res);
    }
}
