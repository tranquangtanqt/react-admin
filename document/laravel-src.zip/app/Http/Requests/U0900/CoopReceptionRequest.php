<?php

namespace App\Http\Requests\U0900;

use App\Models\CodeClass;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

/**
 * 受付情報連携リクエスト
 */
class CoopReceptionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // APIキーチェック
        $auth = false;
        $apikey = $this->header('X-API-Key');
        if (!empty($apikey)) {
            $codeclass = CodeClass::codeKey(config('constants.codes.api_key'), config('constants.api_key.coopreception'))->first();
            if ($codeclass != null) {
                $auth = ($apikey == $codeclass->string1);
            }
        }
        return $auth;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'inputdata' => ['present'],
            'inputdata.no' => ['present', 'required', 'string', 'max:11'],
            'inputdata.date' => ['present', 'required', 'date_format:Ymd'],
            'inputdata.dept_no' => ['present', 'required', 'string', 'max:7'],
            'inputdata.emp_code' => ['present', 'required', 'string', 'max:5'],
            'inputdata.client_no' => ['present', 'nullable', 'string', 'max:7'],
            'inputdata.client_account_no' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.client_billing_deadline' => ['present', 'nullable', 'integer', 'max:99'],
            'inputdata.client_name' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.client_person_name' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.client_address' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.client_tel' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.client_fax' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.client_mobile_tel' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.field_name' => ['present', 'required', 'string', 'max:120'],
            'inputdata.field_person_name' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.field_address' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.field_tel' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.field_fax' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.field_mobile_tel' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.dealer_no' => ['present', 'nullable', 'string', 'max:7'],
            'inputdata.dealer_account_no' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.dealer_name' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.dealer_person_name' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.dealer_tel' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.dealer_fax' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.dealer_mobile_tel' => ['present', 'nullable', 'string', 'max:15'],
            'inputdata.title' => ['present', 'required', 'string', 'max:120'],
            'inputdata.content' => ['present', 'required', 'string', 'max:4000'],
            'inputdata.visit_date' => ['present', 'nullable', 'date_format:Ymd'],
            'inputdata.visit_time_text' => ['present', 'nullable', 'string', 'max:200'],
            'inputdata.status' => ['present', 'required', 'string', 'max:4'],
            'inputdata.response_type' => ['present', 'required', 'string', 'max:4'],
            'inputdata.mainte_check_term' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.related_pj_no' => ['present', 'nullable', 'string', 'max:11'],
            'inputdata.work_type' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.target_order_no' => ['present', 'nullable', 'string', 'max:11'],
            'inputdata.person_dept_no' => ['present', 'nullable', 'string', 'max:7'],
            'inputdata.person_emp_code' => ['present', 'nullable', 'string', 'max:5'],
            'inputdata.completion_date' => ['present', 'nullable', 'date_format:Ymd'],
            'inputdata.device_type1' => ['present', 'nullable', 'string', 'max:20'],
            'inputdata.device_type2' => ['present', 'nullable', 'string', 'max:20'],
            'inputdata.device_no1' => ['present', 'nullable', 'string', 'max:20'],
            'inputdata.device_no2' => ['present', 'nullable', 'string', 'max:20'],
            'inputdata.delivery_date' => ['present', 'nullable', 'date_format:Ymd'],
            'inputdata.repair_work_type' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.repair_sector_type' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.repair_point_type' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.repair_status' => ['present', 'nullable', 'string', 'max:4'],
            'inputdata.cause' => ['present', 'nullable', 'string', 'max:4000'],
            'inputdata.measure' => ['present', 'nullable', 'string', 'max:4000'],
            'inputdata.note' => ['present', 'nullable', 'string', 'max:4000'],
            'inputdata.deleted_flag' => ['present', 'required', 'string', 'max:1'],
            'inputdata.entry_emp_code' => ['present', 'nullable', 'string', 'max:10'],
            'inputdata.entry_date_time' => ['present', 'nullable', 'date_format:Ymd His'],
            'inputdata.login_emp_code' => ['present', 'nullable', 'string', 'max:10'],
            'inputdata.registered_at' => ['present', 'nullable', 'date_format:Ymd His'],
        ];
    }

    /**
     * 認証エラー
     *
     * @return void
     *
     * @throws \Illuminate\Auth\Access\HttpResponseException
     */
    protected function failedAuthorization()
    {
        $res = response()->json([
            'result' => 9,
            'detail' => '認証に失敗しました。',
        ], 401);
        throw new HttpResponseException($res);
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'inputdata.entry_date_time.date_format' => ':attributeは正しい日時ではありません。',
            'inputdata.registered_at.date_format' => ':attributeは正しい日時ではありません。',
            'inputdata.*.date_format' => ':attributeは正しい日付ではありません。',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        $errors = json_decode($validator->errors());
        // バリデーションエラーをdetail用に入れ直し
        $detail = [];
        foreach ($errors as $key=> $value) {
            if (is_array($value)){
                foreach ($value as $subKey=> $subValue) {
                    array_push($detail, $subValue);
                }
            }
        }
        $res = response()->json([
            'result' => 9,
            'detail' => $detail,
        ], 400);
        throw new HttpResponseException($res);
    }
}
