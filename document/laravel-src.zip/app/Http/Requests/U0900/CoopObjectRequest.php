<?php

namespace App\Http\Requests\U0900;

use App\Models\CodeClass;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class CoopObjectRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // APIキーチェック
        $auth = false;
        $apikey = $this->header('X-API-Key');
        if (!empty($apikey)) {
            $codeclass = CodeClass::codeKey(config('constants.codes.api_key'), config('constants.api_key.coopobject'))->first();
            if ($codeclass != null) {
                $auth = ($apikey == $codeclass->string1);
            }
        }
        return $auth;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'inputdata' => ['present'],
            'inputdata.reception_no' => ['present', 'required', 'string', 'max:11', 'exists:l2_receptions,no'],
            'inputdata.customer_no' => ['present', 'required', 'string', 'max:7'],
            'inputdata.customer_account_no' => ['present', 'required', 'string', 'max:4'],
            'inputdata.customer_name' => ['present', 'required', 'string', 'max:120'],
            'inputdata.customer_account_name' => ['present', 'nullable', 'string', 'max:120'],
            'inputdata.pjmgr_dept_no' => ['present', 'required', 'string', 'max:7'],
            'inputdata.pjmgr_emp_no' => ['present', 'required', 'string', 'max:5'],
            'inputdata.contract_date' => ['present', 'required', 'date_format:Ymd'],
            'inputdata.work_start_date' => ['present', 'required', 'date_format:Ymd'],
            'inputdata.work_end_date' => ['present', 'required', 'date_format:Ymd'],
            'inputdata.project_status' => ['present', 'required', 'string', 'max:4'],
            'inputdata.sales_application_flag' => ['present', 'required', 'string', 'max:1'],
            'inputdata.order_cancellation_flag' => ['present', 'required', 'string', 'max:1'],
            'inputdata.completion_year_month' => ['present', 'nullable', 'string', 'max:6'],
            'inputdata.entry_emp_code' => ['present', 'nullable', 'string', 'max:5'],
            'inputdata.entry_date_time' => ['present', 'nullable', 'date_format:Ymd His'],
            'inputdata.login_emp_code' => ['present', 'nullable', 'string', 'max:5'],
            'inputdata.registered_at' => ['present', 'nullable', 'date_format:Ymd His'],
        ];
    }

    /**
     * 認証エラー
     *
     * @return void
     *
     * @throws \Illuminate\Auth\Access\HttpResponseException
     */
    protected function failedAuthorization()
    {
        $res = response()->json([
            'result' => 9,
            'detail' => '認証に失敗しました。',
        ], 401);
        throw new HttpResponseException($res);
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'inputdata.reception_no.exists' => ':attributeに対する受付が登録されていません。',
            'inputdata.entry_date_time.date_format' => ':attributeは正しい日時ではありません。',
            'inputdata.registered_at.date_format' => ':attributeは正しい日時ではありません。',
            'inputdata.*.date_format' => ':attributeは正しい日付ではありません。',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        $errors = json_decode($validator->errors());
        // バリデーションエラーをdetail用に入れ直し
        $detail = [];
        foreach ($errors as $key=> $value) {
            if (is_array($value)){
                foreach ($value as $subKey=> $subValue) {
                    array_push($detail, $subValue);
                }
            }
        }
        $res = response()->json([
            'result' => 9,
            'detail' => $detail,
        ], 400);
        throw new HttpResponseException($res);
    }
}
