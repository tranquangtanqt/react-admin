<?php

namespace App\Http\Requests\U0200;

use App\Rules\NotInvalidChars;
use Illuminate\Support\Facades\Session;
use Illuminate\Foundation\Http\FormRequest;

class UpdateRemarkRequest extends FormRequest
{

    protected $errorBag = 'remark';

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'updated_at' => ['date', 'nullable'],
            'remark'  => ['required', new NotInvalidChars],
        ];
    }

    /**
     * モーダル情報追加
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return void
     */
    public function withValidator($validator)
    {
        if ($validator->fails()) {
            session()->flash('active_modal_id', 'remark-modal');
        }
    }
    /**
     * エラーメッセージ設定
     *
     * @return array
     */
    public function messages()
    {
        return [
            'remark.required' => 'お客様向け備考を入力してください。',
        ];
    }

    /**
     * 項目名設定設定
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'remark' => 'お客様向け備考',
        ];
    }
}
