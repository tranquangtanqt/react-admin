<?php

namespace App\Http\Requests\U0200;

use App\Rules\NotInvalidChars;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateStatusRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $onHold = config('constants.status.on_hold');

        return [
            'updated_at' => ['required', 'date'],
            'status_type' => ['max:5'],
            'status_detail_type' => ['max:12', "required_if:status_type,${onHold}"],
            'remind_date' => ['nullable', 'max:12', 'date_format:Y/m/d'],
            'remind_memo' => ['max:100', new NotInvalidChars],
            'cancel' => ['nullable'],
        ];
    }

    /**
     * エラーメッセージ設定
     *
     * @return array
     */
    public function messages()
    {
        return [
            'status_detail_type.required_if' => '状態詳細区分を指定してください。',
        ];
    }

    /**
     * バリデーション失敗の時
     *
     */
    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            response()->json(
                $validator->errors(),
                422
            )
        );
    }
}
