<?php

namespace App\Http\Requests\U0200;

use App\Rules\NotInvalidChars;
use Illuminate\Foundation\Http\FormRequest;

class UpdateBillingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'updated_at' => ['date', 'nullable'],
            'billing_name'  => ["nullable",new NotInvalidChars,'max:20'],
            'billing_tel' => ["nullable","regex:/^[a-zA-Z0-9!#$%'()*+,.:;=?@\[\]^_`{|}\\\~-]*$/","max:15"],
            'billing_fax' => ["nullable","regex:/^[a-zA-Z0-9!#$%'()*+,.:;=?@\[\]^_`{|}\\\~-]*$/","max:15"],
        ];
    }

    /**
     * モーダル情報追加
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return void
     */
    public function withValidator($validator)
    {
        if ($validator->fails()) {
            session()->flash('active_modal_id', 'billing-modal');
        }
    }

    /**
     * エラーメッセージ設定
     *
     * @return array
     */
    public function messages()
    {
        return [
            'billing_tel.regex' => ':attributeに英数記号以外が含まれています。',
            'billing_fax.regex' => ':attributeに英数記号以外が含まれています。',
        ];
    }

    /**
     * 項目名設定設定
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'billing_name' => '請求先名',
            'billing_tel' => '請求先TEL',
            'billing_fax' => '請求先FAX',
        ];
    }
}
