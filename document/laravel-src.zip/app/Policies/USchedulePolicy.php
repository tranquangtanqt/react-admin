<?php

namespace App\Policies;

use App\Models\USchedule;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class USchedulePolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, USchedule $uSchedule)
    {
        //
    }

    /**
     * 実績情報照会権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewResult(User $user, USchedule $uSchedule)
    {
        // 協力会社以外照会可能
        if (!userIsPicExternal()) {
            return true;
        }

        // 訪問担当の場合
        if ($uSchedule->reception->isPic($user)) {
            return true;
        }

        return false;
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user, USchedule $uSchedule)
    {
        // 日程作成者か日程詳細に入っている
        return $user->id === $uSchedule->created_by ||
        $uSchedule->scheduleDetails()->where('user_id', $user->id)->get()->isNotEmpty();
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, USchedule $uSchedule)
    {
        // 日程作成者か日程詳細に入っている
        return $user->id === $uSchedule->created_by ||
        $uSchedule->scheduleDetails()->where('user_id', $user->id)->get()->isNotEmpty();
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function restore(User $user, USchedule $uSchedule)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function forceDelete(User $user, USchedule $uSchedule)
    {
        //
    }

    /**
     * 該当する実績を削除できるかのポリシー
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function deleteResult(User $user, USchedule $uSchedule)
    {
        // 実績かあるか
        $hasResult = $uSchedule->has_results;
        if (!$hasResult) { // 実績がない場合削除できない
            return false;
        }

        // 受付情報
        $reception = $uSchedule->reception;

        // 状態
        $statusType = $reception->status->status_type;

        // 現場調整担当者かつ状態が訪問予定の場合
        if (userIsFieldCoor() && $statusType == config('constants.status.will_visit')) {
            return true;
        }

        // 該当する受付の計上担当か
        $isPjmgr = $reception?->eff_pjmgr_id === $user->id;

        // 訪問担当か
        $isPic = $uSchedule->isPic($user);

        // 業務責任者・計上担当・訪問担当・入力支援かつ状態が訪問済・保留・訪問予定
        if (
            (userIsManager() || userIsInputSupport() || $isPjmgr || $isPic) &&
            collect([
                config('constants.status.will_visit'),
                config('constants.status.visited'),
                config('constants.status.on_hold'),
            ])->contains($statusType)
        ) {
            return true;
        }

        // それ以外
        return false;
    }

    /**
     * 該当する実績を更新できるかのポリシー
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateResult(User $user, USchedule $uSchedule)
    {
        // 受付情報
        $reception = $uSchedule->reception;

        // 状態
        $statusType = $reception?->status?->status_type;

        if (!collect([
            config('constants.status.will_visit'), // 訪問予定
            config('constants.status.visited'), // 訪問済
            config('constants.status.on_hold'), // 保留
        ])->contains($statusType)) {
            return false;
        }

        if (
            config('constants.status.will_visit') == $statusType &&
            userIsFieldCoor()
        ) {
            return true;
        }

        // 該当する受付の計上担当か
        $isPjmgr = $reception?->eff_pjmgr_id === $user->id;

        // 訪問担当か
        $isPic = $uSchedule->isPic($user);

        if (
            (userIsSystemAdmin() || userIsInputSupport() || $isPjmgr || $isPic) &&
            collect([
                config('constants.status.will_visit'),
                config('constants.status.visited'),
                config('constants.status.on_hold'),
            ])->contains($statusType)
        ) {
            return true;
        }

        // (業務責任者）・状態が訪問予定・訪問済
        if (
            userIsManager() &&
            collect([
                config('constants.status.will_visit'),
                config('constants.status.visited'),
            ])->contains($statusType)
        ) {
            return true;
        }

        // 実績かあるか
        $hasResult = $uSchedule->has_results;

        // (業務責任者かつ実績あり）・状態が保留
        if (
            config('constants.status.on_hold') == $statusType &&
            (userIsManager() && $hasResult)
        ) {
            return true;
        }

        // それ以外
        return false;
    }

    /**
     * 工数設定権限権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateManHour(User $user, USchedule $uSchedule)
    {
        $status = $uSchedule->reception?->status;
        if (
            $uSchedule->reception->isPic($user) && // 訪問担当
            !userIsPicExternal() && // 協力会社以外
            collect([
                config('constants.status.will_visit'), // 訪問予定
                config('constants.status.visited'), // 訪問済
                config('constants.status.on_hold'), // 保留
            ])->contains($status->status_type)
        ) {
            return true;
        }

        return false;
    }

    /**
     * 署名更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\USchedule  $uSchedule
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateSignature(User $user, USchedule $uSchedule)
    {

        // 受付情報
        $reception = $uSchedule->reception;

        // 状態
        $statusType = $reception?->status?->status_type;

        if (collect([
            config('constants.status.new'), // 新規
            config('constants.status.work_done'), // 作業完了
            config('constants.status.checked'), // チェック済
            config('constants.status.completed'), // 受付完了
        ])->contains($statusType)) {
            return false;
        }

        // 該当する受付の計上担当か
        $isPjmgr = $reception?->eff_pjmgr_id === $user->id;

        // 訪問担当か
        $isPic = $uSchedule->isPic($user);

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsInputSupport() || // 入力支援担当
            $isPjmgr || // 計上担当
            $isPic // 訪問担当
        ) {
            return true;
        }

        if (
            userIsFieldCoor() && // 現場調整担当
            collect([
                config('constants.status.will_visit'), // 訪問予定
                config('constants.status.on_hold'), // 保留
            ])->contains($statusType)
        ) {
            return true;
        }
        return false;
    }
}
