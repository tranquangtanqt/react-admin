<?php

namespace App\Policies;

use App\Models\User;
use App\Models\UStatus;
use App\Traits\StatusChange;
use Illuminate\Auth\Access\HandlesAuthorization;

class UStatusPolicy
{
    use HandlesAuthorization, StatusChange;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UStatus  $uStatus
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, UStatus $uStatus)
    {
        //
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UStatus  $uStatus
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user, UStatus $uStatus)
    {

        $mutationStates = $this->getMutationStates($uStatus);

        if ($mutationStates->count() > 1) {
            return true;
        }

        // 上記以外
        return false;
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UStatus  $uStatus
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, UStatus $uStatus)
    {
        //
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UStatus  $uStatus
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function restore(User $user, UStatus $uStatus)
    {
        $lastStatusType = $uStatus->latestHistory?->status_type;

        // 基本的にシステム管理者が引き戻し可能

        // 業務責任者かつ状態がチェック済→作業完了
        if (
            (userIsManager() || userIsSystemAdmin()) &&
            $uStatus->status_type === config('constants.status.checked') &&
            $lastStatusType === config('constants.status.work_done')
        ) {
            return true;
        }

        // (現場調整担当OR入力支援）かつ状態が保留→新規受付
        if (
            (userIsFieldCoor() || userIsInputSupport() || userIsSystemAdmin()) &&
            $uStatus->status_type === config('constants.status.on_hold') &&
            $lastStatusType === config('constants.status.new')
        ) {
            return true;
        }

        // 入力支援かつ状態が受付完了→チェック済
        if (
            (userIsInputSupport() || userIsSystemAdmin()) &&
            $uStatus->status_type === config('constants.status.completed') &&
            $lastStatusType === config('constants.status.checked')
        ) {
            return true;
        }

        // 受付
        $reception = $uStatus->reception;

        // 計上担当ユーザ
        $isPjmgr = $reception->eff_pjmgr_id === $user->id;

        // ダッシュボード表示ユーザ
        $isDisplayUser = $reception->display_user_id === $user->id;

        // (計上担当ORダッシュボード表示ユーザ）かつ状態が作業完了→（訪問済、保留、新規受付）
        if (
            ($isPjmgr || $isDisplayUser || userIsSystemAdmin()) &&
            ($uStatus->status_type === config('constants.status.work_done') &&
                collect([
                    config('constants.status.visited'), // 訪問済受付
                    config('constants.status.on_hold'), // 保留受付
                    config('constants.status.will_visit'), // 訪問予定
                    config('constants.status.new'), // 新規受付
                ])->contains($lastStatusType))
        ) {
            return true;
        }

        // (現場調整 OR L2入力支援）かつ状態が作業完了→（新規受付）引き戻し可能
        if (
            (userIsFieldCoor() || userIsInputSupport()) &&
            $uStatus->status_type === config('constants.status.work_done') &&
            $lastStatusType === config('constants.status.new')
        ) {
            return true;
        }
        // 上記以外
        return false;
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UStatus  $uStatus
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function forceDelete(User $user, UStatus $uStatus)
    {
        //
    }
}
