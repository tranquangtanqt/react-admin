<?php

namespace App\Policies;

use App\Models\UReception;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UReceptionPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, UReception $uReception)
    {
        // 協力会社以外照会可能
        if (!userIsPicExternal()) {
            return true;
        }

        // 訪問担当の場合
        if ($uReception->isPic($user)) {
            return true;
        }

        return false;
    }

    /**
     * 受付情報金額タブの照会権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewFinance(User $user, UReception $uReception)
    {
        // 協力会社以外照会可能
        return !userIsPicExternal();
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function create(User $user)
    {
        //
    }

    /**
     * コメント追加権限
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function createComment(User $user, UReception $uReception)
    {
        return (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsFieldCoor() || // 現場調整担当
            userIsInputSupport() || // 入力支援担当
            $uReception->isPic($user) || // 訪問担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        );
    }

    /**
     * 追加・編集できるか
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function createOrUpdateSchedule(User $user, UReception $uReception)
    {
        $status = $uReception->status;

        // 入力完了以降の場合編集・追加不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($status->status_type)) {
            return false;
        }

        // 業務責任者・現場調整担当者・入力支援が追加・編集可能
        if (userIsSystemAdmin() || userIsManager() || userIsFieldCoor() || userIsInputSupport()) {
            return true;
        }

        // 計上担当の場合追加・変更可能
        $isPjmgr = $uReception->eff_pjmgr_id === $user->id;
        if ($isPjmgr) {
            return true;
        }

        return false;
    }
    /**
     * 訪問予定削除権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function deleteSchedule(User $user, UReception $uReception)
    {
        $status = $uReception->status;

        // TODO: 削除できる権限（ユーザ）？

        // 状態が新規受付、作業完了、チェック済、受付完了の場合
        if (collect([
            config('constants.status.new'),
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($status->status_type)) {
            return false;
        }

        return true;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user, UReception $uReception)
    {
        //
    }

    /**
     * ユーザが受付の計上担当更新できるか
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateProjectManager(User $user, UReception $uReception)
    {

        // 業務責任者、現場調整担当、システム管理者の場合更新できる
        if (userIsManager() || userIsFieldCoor() || userIsSystemAdmin()) {
            return true;
        }

        // 入力支援担当者かつ受付に対して、ダッシュボード表示ユーザになっているばあい
        if (userIsInputSupport() && $uReception->display_user_id == $user->id) {
            return true;
        }

        return false;
    }


    /**
     * 請求先更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateBilling(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsFieldCoor() || // 現場調整担当
            userIsInputSupport() || // 入力支援担当
            $uReception->isPic($user) || // 訪問担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 系統更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateGroup(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        // 業務責任者、現場調整担当、入力支援、計上担当、訪問担当システム管理者の場合更新できる
        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsFieldCoor() || // 現場調整担当
            userIsInputSupport() || // 入力支援担当
            $uReception->isPic($user) || // 訪問担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 機器情報更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateDevice(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        // 業務責任者、現場調整担当、入力支援、計上担当、訪問担当システム管理者の場合更新できる
        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsFieldCoor() || // 現場調整担当
            userIsInputSupport() || // 入力支援担当
            $uReception->isPic($user) || // 訪問担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * お客様向け備考更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateRemark(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsFieldCoor() || // 現場調整担当
            userIsInputSupport() || // 入力支援担当
            $uReception->isPic($user) || // 訪問担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 添付更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateAttachment(User $user, UReception $uReception)
    {

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsFieldCoor() || // 現場調整担当
            userIsInputSupport() || // 入力支援担当
            $uReception->isPic($user) || // 訪問担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 作業区分更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateWorkType(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsInputSupport() || // 入力支援担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 有償無償更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updatePaymentType(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsInputSupport() || // 入力支援担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 充填回収更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateGas(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        if (
            $uReception->isPic($user) && // 訪問担当
            collect([
                config('constants.status.will_visit'), // 訪問予定
                config('constants.status.on_hold'), // 保留
            ])->contains($statusType)
        ) {
            return true;
        }

        if (
            userIsInputSupport() && // 入力支援
            !collect([
                config('constants.status.on_hold'), // 保留
            ])->contains($statusType)
        ) {
            return true;
        }

        return false;
    }
    /**
     * 原価更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateCost(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsInputSupport() || // 入力支援担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 見積更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateQuotation(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 作業完了、チェック済、受付完了の場合更新不可
        if (collect([
            config('constants.status.work_done'),
            config('constants.status.checked'),
            config('constants.status.completed'),
        ])->contains($statusType)) {
            return false;
        }

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            userIsInputSupport() || // 入力支援担当
            $uReception->eff_pjmgr_id === $user->id// 計上担当
        ) {
            return true;
        }

        return false;
    }

    /**
     * 運転記録情報更新権限
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function updateOperation(User $user, UReception $uReception)
    {

        $statusType = $uReception->status?->status_type;

        // 訪問予定、訪問済、保留以外の場合更新不可
        if (!collect([
            config('constants.status.will_visit'),
            config('constants.status.visited'),
            config('constants.status.on_hold'),
        ])->contains($statusType)) {
            return false;
        }

        // 入力支援の場合
        if (userIsInputSupport() && $statusType == config('constants.status.visited')) {
            return true;
        }

        if ($uReception->isPic($user) && // 訪問担当
            $statusType != config('constants.status.visited')) { // 訪問済以外
            return true;
        }

        // 計上担当ユーザ
        $isPjmgr = $uReception->eff_pjmgr_id === $user->id;

        // ダッシュボード表示ユーザ
        $isDisplayUser = $uReception->display_user_id === $user->id;

        if (
            userIsSystemAdmin() || // システム管理者
            userIsManager() || // 業務責任者
            $isPjmgr || // 計上担当者
            $isDisplayUser // ダッシュボード表示ユーザ
        ) {
            return true;
        }

        return false;
    }
    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, UReception $uReception)
    {
        //
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function restore(User $user, UReception $uReception)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function forceDelete(User $user, UReception $uReception)
    {
        //
    }

    /**
     * ユーザが訪問担当設定際に受付の計上担当更新できるか
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\UReception  $uReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function setPjMgrViaSchedule(User $user, UReception $uReception)
    {
        if ($uReception->eff_pjmgr_id || $uReception->display_user_id) {
            return false;
        }

        // 業務責任者・現場調整担当者・編集可能
        if (userIsSystemAdmin() || userIsManager() || userIsFieldCoor()) {
            return true;
        }

        return false;
    }
}
