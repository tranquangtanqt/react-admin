<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BatchStatus extends Model
{
    use HasFactory;

    protected $primaryKey = 'process_id';

    public $incrementing = false;

    public $timestamps = false;

    protected $guarded = [];

    public $keyType = 'string';

    protected $casts = [
        'process_id' => 'string',
        'created_at' => 'datetime'
    ];

}
