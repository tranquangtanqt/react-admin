<?php

namespace App\Models;

use App\Commons\CommonFunction;
use App\Traits\CreatedUpdatedBy;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CodeClass extends Model
{
    use HasFactory, CreatedUpdatedBy;

    protected $guarded = [];

    /**
     * 識別コードとキーによってモデル取得スコップ
     *
     * @param string $code (from config('constants.code'))
     * @param string $key (from config('constants.<code>.<key>'))
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeCodeKey($query, $code, $key)
    {
        return $query->where([
            'identifier_code' => $code,
            'key' => $key,
        ]);
    }

    /**
     * パスワードポリシーのキーによってモデル取得スコップ
     *
     * @param string $key (from config('constants.password.<key>'))
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopePasswordKey($query, $key)
    {
        return $query->codeKey(config('constants.codes.password'), $key);
    }

    /**
     * 時間帯区分を取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    public static function getSlots()
    {
        return self::select([
            'id',
            'key',
            'value',
            'display_order',
            'number1',
            'number2',
            'number3',
            'string1',
            'string2',
            'string3',
        ])
            ->where('identifier_code', config('constants.codes.slot'))
            ->orderBy('display_order')
            ->get();
    }

    /**
     * 予定区分を取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    public static function getScheduleTypes()
    {
        return self::select([
            'id',
            'key',
            'value',
            'display_order',
            'number1',
            'number2',
            'number3',
            'string1',
            'string2',
            'string3',
        ])
            ->where('identifier_code', config('constants.codes.pe_schedule'))
            ->orderByRaw('CAST(display_order AS DECIMAL) asc')
            ->get();
    }

    /**
     * 状態区分を取得
     *
     * @param array $statuses
     * @return Illuminate\Database\Eloquent\Collection
     */
    public static function getStatuses(array $statuses = [])
    {
        return self::select('id', 'key', 'value')
            ->where('identifier_code', config('constants.codes.status'))
            ->when(!empty($statuses), function ($query) use ($statuses) {
                $query->whereIn('key', $statuses);
            })
            ->orderBy('display_order')
            ->get();
    }

    /**
     * 状態詳細区分を取得
     *
     * @return Illuminate\Database\Eloquent\Collection
     */
    public static function getStatusDetails()
    {
        return self::select('id', 'key', 'value')
            ->where('identifier_code', config('constants.codes.status_detail'))
            ->orderBy('display_order')
            ->get();
    }

    /**
     * 時間帯タイトル取得
     *
     * @return array slotTitle
     */
    public static function getSlotTitles()
    {
        // 時間帯区分
        $availableSlots = self::getSlots();

        return $availableSlots
            ->reduce(function ($tmp, $item) {
                if (
                    collect([
                        config('constants.slot.morning'),
                        config('constants.slot.night'),
                    ])->contains($item->key)
                ) {
                    return $tmp + [$item->key => $item->value];
                }
                return $tmp + [$item->key => formatSlotTime($item->number1) . '-' . formatSlotTime($item->number2)];
            }, []);
    }

    /**
     * 時間帯色取得
     *
     * @return array style
     */
    public static function getSlotColors()
    {
        // 時間帯区分
        $availableSlots = self::getSlots();
        return $availableSlots
            ->map(function ($item) {
                if (!$item->string1 || !CommonFunction::isColorCode("#{$item->string1}")) {
                    return ['key' => $item->key, 'color' => "000000"];
                }
                return ['key' => $item->key, 'color' => $item->string1];
            })
            ->reduce(function ($tmp, $item) {
                return $tmp + [$item['key'] => "#{$item['color']};"];
            }, []);
    }

    /**
     * デフォルトのキャンセル計上担当者ログインID取得
     *
     * @return string | null
     */
    public static function getDefaultCancelPjMgrLoginId()
    {
        return self::codeKey(
            config('constants.codes.default_setting'),
            config('constants.default_setting.cancelpjmgr'),
        )
            ->first()?->string1;
    }
}
