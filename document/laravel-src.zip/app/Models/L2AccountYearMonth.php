<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class L2AccountYearMonth extends Model
{
    use HasFactory;

    protected $primaryKey = 'account_year_month';

    public $incrementing = false;

    public $timestamps = false;

    protected $guarded = [];

    public $keyType = 'string';

    protected $casts = [
        'account_year_month' => 'string',
    ];
}
