<?php

namespace App\Models;

use App\Traits\CreatedUpdatedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UStatus extends Model
{
    use HasFactory, SoftDeletes, CreatedUpdatedBy;

    protected $primaryKey = 'reception_no';

    protected $guarded = [];

    public $keyType = 'string';

    protected $casts = [
        'reception_no' => 'string',
        'remind_date' => 'datetime',
        'entry_complete_at' => 'datetime',
        'checked_at' => 'datetime',
        'completion_date' => 'datetime',
    ];

    /**
     * 受付情報取得
     */
    public function reception()
    {
        return $this->belongsTo(UReception::class, 'reception_no',  'no');
    }

    /**
     * 最新の履歴を取得
     */
    public function latestHistory()
    {
        return $this->hasOne(UStatusHistory::class, 'reception_no', 'reception_no')->ofMany('serial_no', 'max');
    }

    /**
     * 履歴を登録
     *
     * @return void
     */
    public function addToHistory()
    {
        // 連番番号取得
        $latestHistory = UStatusHistory::select('reception_no', 'serial_no')->withTrashed()
            ->where('reception_no', $this->reception_no)->orderBy('serial_no', 'desc')->first();
        $serialNo = $latestHistory ? $latestHistory->serial_no + 1 : 1;

        // 履歴登録
        UStatusHistory::create([
            'reception_no' => $this->reception_no,
            'serial_no' => $serialNo,
            'status_type' => $this->status_type,
            'status_detail_type' => $this->status_detail_type,
            'remind_date' => $this->remind_date,
            'remind_memo' => $this->remind_memo,
            'entry_complete_flag' => $this->entry_complete_flag,
            'entry_complete_at' => $this->entry_complete_at,
            'entry_complete_user_id' => $this->entry_complete_user_id,
            'checked_flag' => $this->checked_flag,
            'checked_at' => $this->checked_at,
            'checked_user_id' => $this->checked_user_id,
            'completion_date' => $this->completion_date,
            'canceled_at' => $this->canceled_at,
        ]);
    }

    /**
     * 履歴復活
     *
     * @return $this
     */
    public function restoreFromHistory()
    {
        $lastStatus = $this->latestHistory;

        // 前回の状態より復活する
        $this->reception_no = $lastStatus->reception_no;
        $this->status_type = $lastStatus->status_type;
        $this->status_detail_type = $lastStatus->status_detail_type;
        $this->remind_date = $lastStatus->remind_date;
        $this->remind_memo = $lastStatus->remind_memo;
        $this->entry_complete_flag = $lastStatus->entry_complete_flag;
        $this->entry_complete_at = $lastStatus->entry_complete_at;
        $this->entry_complete_user_id = $lastStatus->entry_complete_user_id;
        $this->checked_flag = $lastStatus->checked_flag;
        $this->checked_at = $lastStatus->checked_at;
        $this->checked_user_id = $lastStatus->checked_user_id;
        $this->completion_date = $lastStatus->completion_date;
        $this->canceled_at = $lastStatus->canceled_at;
        $this->save();

        // 前回の履歴を削除する
        $lastStatus->delete();

        return $this;
    }

    /**
     * 状態変更
     * @param string $statusType
     * @param array $details = ['status_detail_type' => $statusDetailType, ...]
     *
     * @return $this
     */
    public function setStatus(string $statusType, array $details = []) {

        $this->status_type = $statusType;

        if($statusType != config('constants.status.on_hold')) {
            $this->status_detail_type = null;
            $this->remind_date = null;
            $this->remind_memo = null;
        } else {
            foreach ($details as $key => $value) {
                $this->{$key} = $value;
            }
        }

       return $this;
    }

}
