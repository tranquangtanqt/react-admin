<?php

namespace App\Models;

use App\Traits\CreatedUpdatedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class USignature extends Model
{
    use HasFactory, SoftDeletes, CreatedUpdatedBy;

    protected $guarded = [];


    /**
     * ファイル取得
     */
    public function file()
    {
        return $this->belongsTo(File::class);
    }

    /**
     * モデルブート
     *
     * @return void
     */
    public static function booted()
    {

        static::deleting(function ($signature) {
            // ファイル削除
            $signature->file()->forceDelete(); // 物理削除（要確認）

        });
    }

}
