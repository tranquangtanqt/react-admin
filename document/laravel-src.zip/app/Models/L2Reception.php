<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class L2Reception extends Model
{
    use HasFactory;

    protected $primaryKey = 'no';

    public $incrementing = false;

    public $timestamps = false;

    protected $guarded = [];

    public $keyType = 'string';

    protected $casts = [
        'no' => 'string',
        'date' => 'datetime',
        'visit_date' => 'datetime',
        'completion_date' => 'datetime',
        'delivery_date' => 'datetime',
        'entry_date_time' => 'datetime',
        'registered_at' => 'datetime',
        'coop_created_at' => 'datetime',
        'coop_updated_at' => 'datetime',
    ];

    /**
     * 受付情報取得
     */
    public function reception()
    {
        return $this->hasOne(UReception::class, 'no', 'no');
    }

    /**
     * 受付情報取得
     */
    public function l2Object()
    {
        return $this->hasOne(L2Object::class, 'reception_no', 'no');
    }
}
