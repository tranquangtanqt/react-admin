<?php

namespace App\Models;

use App\Traits\CreatedUpdatedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UGasInInfo extends Model
{
    use HasFactory, SoftDeletes, CreatedUpdatedBy;

    protected $table = 'u_gas_in_info';

    protected $primaryKey = 'reception_no';

    public $incrementing = false;

    protected $guarded = [];

    public $keyType = 'string';

    protected $casts = [
        'reception_no' => 'string',
        'date' => 'datetime',
    ];

    /**
     * 受付情報取得
     */
    public function reception()
    {
        return $this->belongsTo(UReception::class, 'reception_no',  'no');
    }
}
