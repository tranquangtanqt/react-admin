<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UQuotation extends Model
{
    use HasFactory, SoftDeletes;

    protected $guarded = [];

    /**
     * 受付情報取得
     */
    public function reception()
    {
        return $this->belongsTo(UReception::class, 'reception_no',  'no');
    }

}
