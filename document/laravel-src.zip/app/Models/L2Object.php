<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class L2Object extends Model
{
    use HasFactory;

    protected $primaryKey = 'reception_no';

    public $incrementing = false;

    public $timestamps = false;

    protected $guarded = [];


    public $keyType = 'string';

    protected $casts = [
        'reception_no' => 'string',
    ];

    /**
     * 受付情報取得
     */
    public function l2Reception()
    {
        return $this->belongsTo(L2Reception::class, 'reception_no',  'no');
    }
}
