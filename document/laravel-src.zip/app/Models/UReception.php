<?php

namespace App\Models;

use App\Models\UWorkReport;
use App\Traits\CreatedUpdatedBy;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class UReception extends Model
{
    use HasFactory, SoftDeletes, CreatedUpdatedBy;

    protected $primaryKey = 'no';

    public $incrementing = false;

    protected $guarded = [];

    public $keyType = 'string';

    protected $casts = [
        'no' => 'string',
    ];

    /**
     * L2受付取得
     */
    public function l2Reception()
    {
        return $this->belongsTo(L2Reception::class, 'no', 'no');
    }

    /**
     * L2物件取得
     */
    public function l2Object()
    {
        return $this->hasOne(L2Object::class, 'reception_no', 'no');
    }

    /**
     * 受付状態取得
     */
    public function status()
    {
        return $this->hasOne(UStatus::class, 'reception_no', 'no');
    }

    /**
     * ピン留め取得
     */
    public function pins()
    {
        return $this->hasMany(UPin::class, 'reception_no', 'no');
    }

    /**
     * ログインユーザのピン留め取得
     *
     * @return UPin
     */
    public function pinByLoggedInUser()
    {
        return $this->pins()->where('user_id', auth()->user()->id)->first();
    }

    /**
     * コメント取得
     */
    public function comments()
    {
        return $this->hasMany(UComment::class, 'reception_no', 'no');
    }

    /**
     * 一番古いコメント取得
     */
    public function oldestComment()
    {
        return $this->hasOne(UComment::class, 'reception_no', 'no')->oldestOfMany(); //ofMany('created_at', 'min');
    }

    /**
     * コメント取得
     */
    public function groups()
    {
        return $this->hasMany(UGroup::class, 'reception_no', 'no');
    }

    /**
     * 機器情報取得
     */
    public function devices()
    {
        return $this->hasMany(UDevice::class, 'reception_no', 'no');
    }

    /**
     * 日程取得
     */
    public function schedules()
    {
        return $this->hasMany(USchedule::class, 'reception_no', 'no');
    }

    /**
     * 未完了日程（実績がないOR(入力済フラッグFALSE OR NULL))取得
     *
     */
    public function incompleteSchedules()
    {
        return $this->hasMany(USchedule::class, 'reception_no', 'no')
            ->select('u_schedules.*')
            ->leftJoin('u_work_results as result', function ($join) {
                $join->on('u_schedules.id', '=', 'result.schedule_id')
                    ->whereNull('result.deleted_at');
            })
            ->where(function ($query) {
                $query->whereNull('entry_complete_flag')
                    ->orWhere('entry_complete_flag', false);
            });
    }

    /**
     * 完了日程（実績の入力済フラッグTRUE)取得
     *
     */
    public function completeSchedules()
    {
        return $this->hasMany(USchedule::class, 'reception_no', 'no')
            ->select('u_schedules.*')
            ->join('u_work_results as result', function ($join) {
                $join->on('u_schedules.id', '=', 'result.schedule_id')
                    ->where('entry_complete_flag', true) // 入力完了フラグがTRUE
                    ->whereNull('result.deleted_at');
            });
    }

    /**
     * 充填取得
     */
    public function gasIn()
    {
        return $this->hasOne(UGasInInfo::class, 'reception_no', 'no');
    }

    /**
     * 充填取得
     */
    public function gasOut()
    {
        return $this->hasOne(UGasOutInfo::class, 'reception_no', 'no');
    }

    /**
     * 作業報告取得
     */
    public function workReport()
    {
        return $this->hasOne(UWorkReport::class, 'reception_no', 'no');
    }

    /**
     * 添付取得
     */
    public function attachments()
    {
        return $this->hasMany(UAttachment::class, 'reception_no', 'no');
    }

    /**
     *  写真取得
     */
    public function photos()
    {
        return $this->hasMany(UPhoto::class, 'reception_no', 'no');
    }

    /**
     *  原価明細取得
     */
    public function costs()
    {
        return $this->hasMany(UCost::class, 'reception_no', 'no');
    }

    /**
     *  見積明細取得
     */
    public function quotations()
    {
        return $this->hasMany(UQuotation::class, 'reception_no', 'no');
    }

    /**
     *  計上担当者取得
     */
    public function pjManager()
    {
        return $this->belongsTo(User::class, 'pjmgr_user_id', 'id');
    }

    /**
     *  ダッシュボード表示ユーザ取得
     */
    public function displayUser()
    {
        return $this->belongsTo(User::class, 'display_user_id', 'id');
    }

    /**
     *  時間帯取得
     * ※本メソッドはUReceptionが'schedule_id'を持っていると前提する
     */
    public function slots()
    {
        return $this->hasMany(USlot::class, 'schedule_id', 'schedule_id')
            ->join('code_classes', function ($join) {
                $join->on('u_slots.slot_type', '=', 'code_classes.key')
                    ->where('code_classes.identifier_code', config('constants.codes.slot'));
            });
    }

    /**
     *  日程担当取得
     * ※本メソッドはUReceptionが'schedule_id'を持っていると前提する
     */
    public function scheduleUsers()
    {
        return $this->hasMany(UScheduleUser::class, 'schedule_id', 'schedule_id')
            ->join('users', 'users.id', '=', 'u_schedule_users.user_id');
    }

    /**
     * 計上担当者ユーザID取得
     * L2Receptionにて設定した場合、L2により取得
     *
     * @return int | null
     */
    public function getEffPjmgrIdAttribute()
    {
        $l2Reception = $this->l2Reception()
            ->leftjoin('users', 'users.external_user_id', '=', 'person_emp_code')
            ->select(['no', 'person_emp_code', 'users.id as pjmgr_user_id'])->first();

        if ($l2Reception->person_emp_code) { // L2で設定した場合
            return $l2Reception->pjmgr_user_id;
        }

        return $this->pjManager?->id;
    }

    /**
     * ユーザが当受付の訪問担当かのチェック
     *
     * @param User $user
     *
     * @return bool
     */
    public function isPic(User $user)
    {
        return $this->schedules()
            ->whereHas('scheduleUsers', function ($query) use ($user) {
                $query->where('user_id', $user->id)
                    ->whereNull('deleted_at');
            })
            ->get()
            ->isNotEmpty();
    }


    /**
     * 合計の工数を取得する
     *
     * @return int|float|string
     */
    public function getTotalManHour()
    {

        // 訪問予定を取得する
        $schedules = $this->schedules;

        // 訪問予定がない場合
        if ($schedules->isEmpty()) {
            return 0;
        }

        // 合計の工数を返す
        return UManHour::whereIn('schedule_id', $schedules->pluck('id'))->sum('man_hour');

    }
}
