<?php

namespace App\Models;

use App\Traits\CreatedUpdatedBy;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Facades\Hash;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, CreatedUpdatedBy;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'short_name',
        'login_id',
        'password',
        'email',
        'file_id',
        'external_company_id',
        'external_user_id',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password_updated_at' => 'datetime',
    ];

    /**
     * 権限取得
     */
    public function auths()
    {
        return $this->hasMany(Auth::class);
    }

    /**
     * パスワードの暗号化
     *
     * パスワードの登録・変更のお時に暗号化する
     *
     * @param str @password
     * @return void
     */
    public function setPasswordAttribute($password)
    {
        $this->attributes['password'] = Hash::make($password);
        $this->attributes['password_updated_at'] = now();
    }

    /**
     * パスワード期限切れチェック
     *
     * @return bool
     */
    public function passwordIsExpired()
    {
        // パスワードのコードクラス取得
        $passwordCodeClass = CodeClass::select('id', 'number1')
            ->passwordKey(config('constants.password.exp_days'))
            ->first();

        // パスワードの更新期限
        $passwordExpDays = (int) $passwordCodeClass->number1;

        // パスワード更新期限 = 0 の場合期限切れがない
        if (!$passwordExpDays) {
            return false;
        }

        return $this->daysFromPasswordUpdated() >= $passwordExpDays;
    }

    /**
     * パスワード更新日より日数
     *
     * @return int
     */
    private function daysFromPasswordUpdated()
    {
        return $this->password_updated_at?->startOfDay()->diffInDays(now()->startOfDay()) ?? 0;
    }

    /**
     * $auths権限をいずれか持っているか
     *
     * @param array $auths: [config('constants.auth')]
     * @return bool
     */
    public function hasAnyAuths(array $auths)
    {
        return $this->auths->whereIn('auth_class', $auths)->isNotEmpty();
    }

    /**
     * $auth権限もっているか
     *
     * @param string $auth: config('constants.auth')
     * @return bool
     */
    public function hasAuth(string $auth)
    {
        return $this->auths->where('auth_class', $auth)->isNotEmpty();
    }

    /**
     * システム管理者
     *
     * @return bool
     */
    public function isSystemAdmin()
    {
        return $this->hasAuth(config('constants.auth.system_admin'));
    }

    /**
     * プロフィ画像パース
     *
     * @return string
     */
    public function getAvatarAttribute()
    {
        if (!$this->file_id) {
            return asset('/storage/default/user_profile.jpg');
        }

        return route('image.show', $this->file_id);
    }

    /**
     * 協力会社担当者かの追加クエリ
     *
     */
    public function scopeWithIsExternal($query)
    {
        $query->addSelect(['is_external' => Auth::selectRaw('true as is_external')
                ->whereColumn('user_id', 'users.id')
                ->where('auth_class', config('constants.auth.pic_external'))
                ->limit(1),
        ]);
    }
}
