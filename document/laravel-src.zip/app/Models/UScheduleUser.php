<?php

namespace App\Models;

use App\Traits\CreatedUpdatedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UScheduleUser extends Model
{
    use HasFactory, SoftDeletes, CreatedUpdatedBy;

    protected $guarded = [];

    /**
     * 日程取得
     */
    public function schedule()
    {
        return $this->belongsTo(USchedule::class, 'schedule_id',  'id');
    }
}
