<?php

namespace App\Models;

use App\Traits\CreatedUpdatedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class USchedule extends Model
{
    use HasFactory, SoftDeletes, CreatedUpdatedBy;

    protected $guarded = [];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'reception_no' => 'string',
        'date' => 'datetime',
    ];

    /**
     * 受付情報取得
     */
    public function reception()
    {
        return $this->belongsTo(UReception::class, 'reception_no', 'no');
    }

    /**
     * L2受付情報取得
     */
    public function l2Reception()
    {
        return $this->belongsTo(L2Reception::class, 'reception_no', 'no');
    }

    /**
     * 時間帯取得
     */
    public function slots()
    {
        return $this->hasMany(USlot::class, 'schedule_id', 'id');
    }

    /**
     * 関連時間帯情報（名称含む）取得
     */
    public function labeledSlots()
    {
        return $this->hasMany(USlot::class, 'schedule_id', 'id')
            ->join('code_classes as cc', function ($join) {
                $join->on('u_slots.slot_type', 'cc.key')
                    ->where('identifier_code', config('constants.codes.slot'));
            })
            ->select('u_slots.id', 'u_slots.schedule_id', 'cc.id', 'cc.key', 'cc.value')
            ->orderBy('cc.key');
    }

    /**
     * 日程担当取得
     */
    public function scheduleUsers()
    {
        return $this->hasMany(UScheduleUser::class, 'schedule_id', 'id');
    }

    /**
     * 日程担当詳細取得
     */
    public function scheduleDetails()
    {
        return $this->hasMany(UScheduleDetail::class, 'schedule_id', 'id');
    }

    /**
     * 関連ユーザ（担当者ユーザ）情報（名前含む）取得
     */
    public function namedUsers()
    {
        return $this->hasMany(UScheduleUser::class, 'schedule_id', 'id')
            ->join('users', 'users.id', '=', 'u_schedule_users.user_id')
            ->select('u_schedule_users.id', 'u_schedule_users.user_id', 'schedule_id', 'users.name', 'users.short_name', 'users.file_id');
    }

    /**
     * 工数取得
     */
    public function manHours()
    {
        return $this->hasMany(UManHour::class, 'schedule_id', 'id');
    }

    /**
     * 署名取得
     */
    public function signature()
    {
        return $this->hasOne(USignature::class, 'schedule_id', 'id');
    }

    /**
     * 署名取得
     */
    public function signatures()
    {
        return $this->hasMany(USignature::class, 'schedule_id', 'id');
    }

    /**
     * 作業実績取得
     */
    public function workResult()
    {
        return $this->hasOne(UWorkResult::class, 'schedule_id', 'id');
    }

    /**
     * 作業実績詳細取得
     */
    public function workResultDetails()
    {
        return $this->hasMany(UWorkResultDetail::class, 'schedule_id', 'id');
    }

    /**
     * モデルブート
     *
     * @return void
     */
    public static function booted()
    {

        static::deleting(function ($schedule) {
            // 時間帯削除
            $schedule->slots()->delete();

            // 日程担当削除
            $schedule->scheduleUsers()->delete();

            // 日程担当詳細削除
            $schedule->scheduleDetails()->delete();

            // 作業実績削除
            $schedule->workResult()->delete();

            // 作業実績詳細削除
            $schedule->workResultDetails()->delete();

            // 工数削除
            $schedule->manHours()->delete();

            // 署名削除
            $schedule->signature()->forceDelete();

        });
    }

    /**
     * 実績を持っているか
     */
    public function getHasResultsAttribute()
    {
        // 日程、作業実績、作業実績詳細、署名、工数をジョインし、実績があるかをチェックする
        $results = self::leftJoin('u_work_results as wr', function ($join) {
            $join->on('u_schedules.id', '=', 'wr.schedule_id')
                ->whereNull('wr.deleted_at');
        })
            ->leftJoin('u_work_result_details as wrd', function ($join) {
                $join->on('u_schedules.id', '=', 'wrd.schedule_id')
                    ->whereNull('wrd.deleted_at');
            })
            ->leftJoin('u_signatures as s', function ($join) {
                $join->on('u_schedules.id', '=', 's.schedule_id')
                    ->whereNull('s.deleted_at');
            })
            ->leftJoin('u_man_hours as mh', function ($join) {
                $join->on('u_schedules.id', '=', 'mh.schedule_id')
                    ->whereNull('mh.deleted_at');
            })
            ->select('u_schedules.id')
            ->where('u_schedules.id', $this->id)
            ->whereNull('mh.deleted_at')
            ->where(function ($query) {
                $query->whereNotNull('wr.id')
                    ->orWhereNotNull('wrd.id')
                    ->orWhereNotNull('s.id')
                    ->orWhereNotNull('mh.id');
            })
            ->get();

        return $results->isNotEmpty();
    }

    /**
     * チェック済実績持っているか？
     *
     * @return bool
     */
    public function hasCompleteResult()
    {
        return $this->workResult?->entry_complete_flag == true;
    }

    /**
     * 対象ユーザが担当者か？
     *
     * @param User
     *
     * @return bool
     */
    public function isPic(User $user)
    {
        return $this->scheduleUsers->where('user_id', $user->id)->isNotEmpty();
    }

}
