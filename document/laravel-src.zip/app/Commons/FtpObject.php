<?php

namespace App\Commons;

use League\Flysystem\Filesystem;
use League\Flysystem\Adapter\Local;
use League\Flysystem\Adapter\Ftp as Adapter;
use League\Flysystem\Config;

class FtpObject
{
    /**
    * 実行情報
    * @see  __construct()
    */
    public $executeLog;

    /**
    * FTP接続情報
    * @see  __construct()
    */
    private $ftpConnection = [];

    /**
    * ローカルディレクトリパス
    */
    private $storageDirectory;

    /**
    * ダウンロード対象ファイル名
    * @see  __construct()
    */
    private $downloadFiles = [];

    /**
    * 最大試行回数
    * @see  __construct()
    */
    private $maxTries;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->executeLog="";
        // 接続情報設定
        $ftpconf = config('filesystems.disks.ftp');
        $this->ftpConnection = [
            'host'     => $ftpconf['host'],
            'username' => $ftpconf['username'],
            'password' => $ftpconf['password'],
            'port'     => $ftpconf['port'],
            'ssl'      => $ftpconf['ssl'],
            'passive'  => $ftpconf['passive'],
            'timeout'  => $ftpconf['timeout'],
            'ignorePassiveAddress' => false,
        ];

        //$this->storageDirectory = env('STORAGE_DIRECTORY');

        $this->maxTries = 3;
    }

    /**
     * 実行情報設定
     *
     * @return void
     */
    private function appendLog($value)
    {
        $this->executeLog .= $value;
    }

    /**
     * 実行情報設定
     *
     * @return void
     */
    private function appendLineLog($value)
    {
        $this->appendLog($value ."\n");
    }

    /**
     * ダウンロードファイル設定
     *
     * @return void
     */
    public function setDownloadFiles(array $downloadFiles)
    {
        $this->downloadFiles = $downloadFiles;
    }
    
    /**
     * ローカルディレクトリパス設定
     *
     * @return void
     */
    public function setStorageDirectory($storageDirectory)
    {
        $this->storageDirectory = $storageDirectory;
    }

    /**
     * ファイル有無チェック
     * 
     * @return bool
     */
    public function hasFile($targetFile)
    {
        // CHG START 20220404 Ishino OT-034 FTPのファイル有無に対する対応
        //--$ftpConnection = $this->ftpConnection;
        //--// ファイルがない場合時間がかかるのでtimeoutに5を設定
        //--$ftpConnection['timeout']=5;
        //--$remoteFilesystem = new Filesystem(new Adapter($ftpConnection), new Config(['disable_asserts'=> true]));
        //--return $remoteFilesystem->has($targetFile);
        $targetDir = dirname($targetFile);
        $targetFileName = basename($targetFile);
        $ftpConnection = $this->ftpConnection;
        $remoteFilesystem = new Filesystem(new Adapter($ftpConnection), new Config(['disable_asserts'=> true]));
        
        // リストを取得
        try {
            $entries = $remoteFilesystem->listContents($targetDir);
        } catch (\Exception $e) {
            return false;
        }
        // リストに該当ファイルがあるかチェック
        foreach ($entries as $entry) {
            if ($entry['type'] === 'file') {
                if ($entry['path'] === $targetFileName) {return true;}
                //print($entry['path'] . ' is a file.' . PHP_EOL);
            }
        }
        return false;
        // CHG E N D 20220404 Ishino OT-034 FTPのファイル有無に対する対応
    }

    /**
     * ファイル削除
     * 
     * @return bool
     */
    public function deleteFile($targetFile)
    {
        $this->appendLineLog("deleteFile start");
        if ($this->hasFile($targetFile) === true) {
            $remoteFilesystem = new Filesystem(new Adapter($this->ftpConnection), new Config(['disable_asserts'=> true]));
            return $remoteFilesystem->delete($targetFile);
        }
        $this->appendLineLog("deleteFile e n d");
    }

    /**
     * ファイルアップロード(新規)
     * 
     * @return bool
     */
    public function writeFile($uploadFile,$localFile ,)
    {
        $this->appendLineLog("writeFile start");
        try {
            // 接続先
            $remoteFilesystem = new Filesystem(new Adapter($this->ftpConnection), new Config(['disable_asserts'=> true]));
        } catch (\Exception $e) {
            $this->appendLineLog("FTPサーバー接続エラー");
            $this->appendLineLog($e);
            $this->appendLineLog("writeFile e n d");
            return false;
        }
        
        try {
            // ローカル
            $localFilesystem = new Filesystem(new Local($this->storageDirectory));
        } catch (\Exception $e) {
            $this->appendLineLog("ローカルフォルダ接続エラー (" . $this->storageDirectory . ")");
            $this->appendLineLog($e);
            $this->appendLineLog("writeFile e n d");
            return false;
        }

        try {
            // ファイル内容の読み込み
            $content = $localFilesystem->read($localFile);
        } catch (\Exception $e) {
            $this->appendLineLog("ファイル内容読み込みエラー (" . $this->storageDirectory . "\\" . $localFile . ")");
            $this->appendLineLog($e);
            $this->appendLineLog("writeFile e n d");
            return false;
        }

        try {
            // アップロード
            $result = $remoteFilesystem->write($uploadFile, $content);
        } catch (\Exception $e) {
            $this->appendLineLog("アップロードエラー (" . $this->storageDirectory . "\\" . $localFile . ")");
            $this->appendLineLog($e);
            $this->appendLineLog("writeFile e n d");
            return false;
        }
        $this->appendLineLog("writeFile e n d");
        return $result;
    }

    /**
     * ファイル操作処理を実行する
     * 
     * @return bool
     */
    public function execute()
    {
        if ($this->download($this->ftpConnection) === false) {
            return false;
        }

        return true;
    }

    /**
     * ファイルのダウンロードを行う
     *
     * @param array $ftpConnection FTP接続情報
     * @return bool
     */
    public function download(array $ftpConnection)
    {
        //Log::info('App\FileOperation:download() start');
        echo "download start \n";

        // エラー時、設定したトライ回数分処理を行う
        for ($i = 1; $i <= $this->maxTries; $i++) {
            try {
                // 接続先
                $remoteFilesystem = new Filesystem(new Adapter($ftpConnection));
                // ローカル
                $localFilesystem = new Filesystem(new Local($this->storageDirectory));

                // 設定したファイル数分取得処理を行う
                foreach ($this->downloadFiles as $downloadFile) {

                    // ファイル内容の読み込み
                    $content = $remoteFilesystem->read($downloadFile);

                    // 前回ファイルをアーカイブ
                    if ($localFilesystem->has($downloadFile) === true) {
                        $localFilesystem->rename($downloadFile, 'archive/' . $downloadFile);
                    }

                    // ローカルファイルに書き込み（ファイルがない場合は新規で作られる）
                    $result = $localFilesystem->write($downloadFile, $content);

                    //Log::info('App\FileOperation:download() ' . $downloadFile . ' download processed. Result : ' . ($result === true ? 'SUCCESS' : 'FAILURE'));

                    echo "download \n";
                }

                //Log::info('App\FileOperation:download() end');

                return $result;

            } catch (\Exception $e) {

                //Log::error("App\FileOperation:download() ExceptionError(Try count " . $i . ")： \n" . $e);
                sleep(10);

            }
        }

        //Log::error("App\FileOperation:download() Error (Max trial end.)");
        return false;
    }

}