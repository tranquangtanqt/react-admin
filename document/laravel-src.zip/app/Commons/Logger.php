<?php

namespace App\Commons;

use Exception;
use Illuminate\Support\Str;
use App\Models\Log as LogModel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Request;
use phpDocumentor\Reflection\Types\Boolean;

class Logger
{
    private $userId;
    private $processType;
    private $processName;
    private $content;
    private $contentDetail;
    private $userAgent;
    private $requestUrl;
    private $refererUrl;
    private $message;
    private $errorMessage = "logsテーブルの登録に失敗しました。";

    public function __construct($logData = [])
    {
        // ログデータを設定する
        $this->userId = $logData['user_id'] ?? null;
        $this->processType = $logData['process_type'] ?? null;
        $this->processName = $logData['process_name'] ?? null;
        $this->content = $logData['content'] ?? null;
        $this->contentDetail = $logData['content_detail'] ?? null;
        $this->userAgent = $logData['user_agent'] ?? null;
        $this->requestUrl = $logData['request_url'] ?? null;
        $this->refererUrl = $logData['referer_url'] ?? null;

        // 必須項目有無チェック
        if (!$this->requiredFieldFilled()) {
            throw new Exception("user_id, process_type, process_name, and content are required in the input array");
        }

        // constants.phpのログ処理区分が正しいかのチェック
        if (!$this->processTypeIsValid()) {
            throw new Exception("process_type is not valid. See 'logs' values in config/constants.php");
        }

        $this->processTypes =  config('constants.logs', []);

        // リクエストよりの情報を取得し、設定する
        $this->userAgent = $this->userAgent ?? Request::header('user_agent');
        $this->requestUrl = $this->requestUrl ?? Request::fullUrl();
        $this->refererUrl = $this->refererUrl ?? Request::header('referer');

        // 表示順：ユーザID、処理区分、処理名、内容、User-Agent、Request URL, Referer URL
        $this->message = "\tユーザアクセスログ："
            . "\t{$this->userId}"
            . "\t{$this->processType}"
            . "\t{$this->processName}"
            . "\t{$this->content}"
            . "\t{$this->userAgent}"
            . "\t{$this->requestUrl}"
            . "\t{$this->refererUrl}";
    }

    /**
     * loggerインスタンスを生成
     * @param  Array $logData
     * $logData = [
     *      'user_id' => $userId,
     *      'process_type' => $processType,
     *      'process_name' => $processName,
     *      'content' => $content,
     *      'content_detail' => $contentDetail,
     *      'user_agent' => $userAgent,
     *      'request_url' => $requestUrl,
     *      'referer_url' => $refererUrl,
     * ]
     * @return $this
     */
    public static function make($logData)
    {
        return new Logger($logData);
    }

    /**
     * loggerインスタンスを生成し、DBに登録
     * @param  Array $logData
     * $logData = [
     *      'user_id' => $userId,
     *      'process_type' => $processType,
     *      'process_name' => $processName,
     *      'content' => $content,
     *      'content_detail' => $contentDetail,
     * ]
     * @return $this
     */
    public static function create($logData)
    {
        $log = new Logger($logData);
        return $log->logToDB();
    }

    /**
     * logsテーブルに登録
     *
     * Loggerのデータをlogsテーブルに登録
     *
     * @return $this
     **/
    public function logToDB()
    {
        try {
            LogModel::create([
                'user_id' => $this->userId,
                'process_type' => $this->processType,
                'process_name' => $this->processName,
                'content' => $this->content,
                'content_detail' => $this->contentDetail,
                'user_agent' => $this->userAgent,
                'request_url' => $this->requestUrl,
                'referer_url' => $this->refererUrl,
            ]);
        } catch (\Exception $e) {
            Log::error($e);
            Log::error($this->errorMessage . "\n {$this->message} \n");
        }
        return $this;
    }

    /**
     * logsテーブルに登録
     *
     * Loggerのデータをログファイルに吐き出す
     *
     * @return $this
     **/
    public function logToFile()
    {

        Log::info($this->message);

        return $this;
    }

    /**
     *  必須項目有無のチェック
     *
     * user_id, process_type, process_name, content が必須
     * 存在するかをチェックする。
     *
     * @return Boolean
     **/
    private function requiredFieldFilled()
    {
        return Str::of($this->userId)->trim()->isNotEmpty()
            && Str::of($this->processType)->trim()->isNotEmpty()
            && Str::of($this->processName)->trim()->isNotEmpty()
            && Str::of($this->content)->trim()->isNotEmpty();
    }

    /**
     * constants.phpのログ処理区分に入っているかのチェック
     *
     * process_typeがconstants.phpのlogs定数にあるかのチェック
     *
     * @return Boolean
     **/
    private function processTypeIsValid()
    {
        return collect(config('constants.logs', []))
            ->containsStrict($this->processType);
    }
}
