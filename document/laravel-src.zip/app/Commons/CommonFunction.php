<?php

namespace App\Commons;

/**
 * 共通関数クラス
 */
class CommonFunction
{
    /**
     * ファイルパス結合
     *
     * @param array $path_arry 結合パス
     * @return string
     */
    public static function pathCombine($pass_arry)
    {

        $ret_pass   =   ""; //結果の格納用変数
        $trim_str   =   DIRECTORY_SEPARATOR; //ディレクトリの区切り文字

        foreach ($pass_arry as $value) {
            if ($ret_pass == "") {
                $ret_pass   =   $value;
            } else {
                //末尾と先頭(結合部分の区切り文字)をトリム
                $ret_pass   =   rtrim($ret_pass, $trim_str);
                $value      =   ltrim($value, $trim_str);
                //改めて結合部分に区切り文字を入れる
                $ret_pass   =   $ret_pass . $trim_str . $value;
            }
        }
        return $ret_pass;
    }

    /**
     * カラーコードチェック
     *
     * @param   string $color チェック対象カラーコード
     * @return  boolean
     */
    public static function isColorCode($color)
    {
        if (preg_match("/^#([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/", $color)) {
            return true;
        } else {
            return false;
        }
    }
}
