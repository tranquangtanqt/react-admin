<?php

// ヘルパー関数雛形
// if (!function_exists('customFunction')) {
//     function customFunction() {
//         return 'something';
//     }
// }

// ユーザが特定権限を持ってるか

use Illuminate\Support\Str;
use Illuminate\Support\MessageBag;

if (!function_exists('userHasAuth')) {
    function userHasAuth(string $auth)
    {
        $auths = session()->get('auths');
        return $auths->where('auth_class', $auth)->isNotEmpty();
    }
}

// ユーザが特定複数権限いずれかを持ってるか
if (!function_exists('userHasAnyAuths')) {
    function userHasAnyAuths(array $auth)
    {
        $auths = session()->get('auths');
        return $auths->whereIn('auth_class', $auth)->isNotEmpty();
    }
}

// ユーザがシステム管理者か
if (!function_exists('userIsSystemAdmin')) {
    function userIsSystemAdmin()
    {
        return userHasAuth(config('constants.auth.system_admin'));
    }
}

// ユーザが業務責任者か
if (!function_exists('userIsManager')) {
    function userIsManager()
    {
        return userHasAuth(config('constants.auth.manager'));
    }
}

// ユーザが入力支援か
if (!function_exists('userIsInputSupport')) {
    function userIsInputSupport()
    {
        return userHasAuth(config('constants.auth.input_support'));
    }
}

// ユーザが現場調整担当か
if (!function_exists('userIsFieldCoor')) {
    function userIsFieldCoor()
    {
        return userHasAuth(config('constants.auth.field_coordinator'));
    }
}

// ユーザが訪問担当か
if (!function_exists('userIsPic')) {
    function userIsPic()
    {
        return userHasAuth(config('constants.auth.pic'));
    }
}

// ユーザが訪問担当(協力会社)か
if (!function_exists('userIsPicExternal')) {
    function userIsPicExternal()
    {
        return userHasAuth(config('constants.auth.pic_external'));
    }
}

// エラーメッセージバッグを作成追加
if (!function_exists('addMessages')) {
    function addMessages(array $messages = [])
    {
        $messageBag = new MessageBag();
        foreach ($messages as $key => $value) {
            $messageBag->add($key, $value);
        }
        return $messageBag;
    }
}

// ファイルIDにより、ユーザアーバーター取得
if (!function_exists('avatarByFileId')) {
    function avatarByFileId(int $fileId = null)
    {
        return $fileId ? route('image.show', $fileId) : asset('/storage/default/user_profile.jpg');
    }
}

if (!function_exists('formatSlotTime')) {
    /**
     * 時間帯と時間をフォーマットする
     *
     * @param string $slotValue (時間帯コード区分の数値１、数値２)
     * @return string HH:MM
     */
    function formatSlotTime(string $slotValue)
    {
        $paddedSlotValue = Str::padLeft((int) $slotValue, 4, '0');

        return substr($paddedSlotValue, 0, 2) . ":" . substr($paddedSlotValue, 2, 2);
    }
}
