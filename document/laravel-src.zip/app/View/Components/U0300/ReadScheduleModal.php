<?php

namespace App\View\Components\U0300;

use App\Models\USchedule;
use Illuminate\View\Component;

class ReadScheduleModal extends Component
{

    public $persons; // 担当者
    public $slots; // 時間帯
    public $action; // ルート（アクション）
    public $schedule; // 日程

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($persons, $slots, USchedule $schedule)
    {
        $this->persons = $persons; // 担当者
        $this->slots = $slots; // 時間帯

        $this->action =  route('set-schedule.show', ['schedule' => $schedule->id]); // 表示ルート
        $this->schedule = $schedule; // 日程
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0300.read-schedule-modal');
    }
}
