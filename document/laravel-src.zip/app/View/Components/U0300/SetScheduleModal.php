<?php

namespace App\View\Components\U0300;

use App\Models\UReception;
use App\Models\USchedule;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\View\Component;

class SetScheduleModal extends Component
{
    public $persons; // 担当者
    public $slots; // 時間帯
    public $mode; // モード：追加、編集
    public $action; // ルート（アクション）
    public $reception; // 受付情報
    public $schedule; // 日程
    public $initDate; // 初期日付
    public $initUserId; // 初期ユーザID
    public $shouldSetPjMgr; // 計上担当設定フラグ
    public $initPjMgrId; // 初期計上担当ユーザID


    public function __construct(
        $persons,
        $slots,
        string $mode = 'add',
        UReception $reception = null,
        USchedule $schedule = null,
        Carbon $initDate = null,
        int $initUserId = null,
        bool $shouldSetPjMgr = false,
        int $initPjMgrId = null,
    ) {
        // 追加、編集以外モードがない
        if (!collect(['add', 'edit'])->contains($mode)) {
            throw new Exception("Only 'add' or 'edit' is allowed for 'mode' arguments. ");
        }

        // 追加モードの時、受付情報が必須
        if ($mode === 'add' && !$reception) {
            throw new Exception('Reception is required for the add mode.');
        }

        // 編集モードの時、日程が必須
        if ($mode === 'edit' && !$schedule) {
            throw new Exception('Schedule is required for the edit mode.');
        }

        $this->persons = $persons; // 担当者
        $this->slots = $slots; // 時間帯
        $this->mode = $mode; // モード：追加、編集
        $this->initDate = $initDate; // 初期日付
        $this->initUserId = $initUserId; // 初期ユーザID
        $this->shouldSetPjMgr = $shouldSetPjMgr; // 計上担当設定フラグ
        $this->initPjMgrId = $initPjMgrId; // 初期計上担当ユーザID

        $actions = [
            'add' =>  $mode === 'add' ? route('set-schedule.store', ['reception' => $reception]) : null, // 追加ルート
            'edit' =>  $mode === 'edit' ? route('set-schedule.update', ['schedule' => $schedule->id]) : null, // 編集ルート
        ];

        $this->action =  $actions[$mode]; // ルート（アクション）
        $this->schedule = $schedule; // 日程
        $this->reception = $reception; // 受付情報
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0300.set-schedule-modal');
    }
}
