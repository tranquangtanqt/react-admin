<?php

namespace App\View\Components\U0100;

use App\Models\UReception;
use Illuminate\View\Component;

class ReminderReceptionCard extends Component
{

    public $buttons = ['schedule', 'status', 'comment'];
    public $reception;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(UReception $reception)
    {
        $this->reception = $reception;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0100.reminder-reception-card');
    }
}
