<?php

namespace App\View\Components\U0100;

use App\Models\USchedule;
use Illuminate\View\Component;

class ScheduleListGeneralCard extends Component
{
    public $schedule; // 日程
    public $slots; // 時間帯コード区分配列
    public $scheduleTypes; // 時間帯コード区分配列
    public $slotTitles; // 時間帯タイトル
    public $slotColors; // 時間帯色

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(
        USchedule $schedule,
        array $slots,
        array $scheduleTypes,
        array $slotTitles,
        array $slotColors
    ) {
        $this->schedule = $schedule;
        $this->slots = $slots;
        $this->scheduleTypes = $scheduleTypes;
        $this->slotTitles = $slotTitles;
        $this->slotColors = $slotColors;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0100.schedule-list-general-card');
    }
}
