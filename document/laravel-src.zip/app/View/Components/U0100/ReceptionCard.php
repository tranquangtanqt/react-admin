<?php

namespace App\View\Components\U0100;

use App\Models\UReception;
use Illuminate\View\Component;

class ReceptionCard extends Component
{

    public $reception;
    public $reminder;
    public $schedule;
    public $buttons;
    public $warning;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(UReception $reception, string $reminder = 'off', string $schedule = 'off', array $buttons = [])
    {
        $this->reception = $reception;
        $this->reminder = $reminder;
        $this->schedule = $schedule;
        $this->buttons = collect($buttons);
        $this->warning = $reception->status_type != config('constants.status.completed') && $reception->order_cancellation_flag == '1';
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0100.reception-card');
    }
}
