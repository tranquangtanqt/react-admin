<?php

namespace App\View\Components\U0100;

use Carbon\Carbon;
use Illuminate\View\Component;
use Illuminate\Database\Eloquent\Collection;

class UserSelectionModal extends Component
{
    public $users;
    public $date;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(Collection $users, Carbon $date)
    {
        $this->users = $users;
        $this->date = $date;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0100.user-selection-modal');
    }
}
