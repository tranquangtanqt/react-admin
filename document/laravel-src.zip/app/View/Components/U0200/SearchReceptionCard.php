<?php

namespace App\View\Components\U0200;

use App\Models\UReception;
use Illuminate\View\Component;
use Illuminate\Support\Collection;

class SearchReceptionCard extends Component
{

    public $reception; // 受付情報
    public $warning; // 赤マーク（警告）
    public $style; // 色付けスタイル

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(UReception $reception, Collection $styles)
    {
        $this->reception = $reception;
        $this->warning = $reception->status_type != config('constants.status.completed') && $reception->order_cancellation_flag == '1';


        // 色付けスタイル制御
        $this->style = "background: #FFFFFF";
        if ($reception->status_type == config('constants.status.completed')) { // 完了場合
            $this->style = $styles->where('key', config('constants.recept_display.complete'))->first()['style'];
        } else { // 経過超過の場合
            $limit1Data = $styles->where('key', config('constants.recept_display.limit_1'))->first();
            $limit2Data = $styles->whEre('key', config('constants.recept_display.limit_2'))->first();

            // 経過日数
            $elapsedDays = $reception->date?->startOfDay()?->diffInDays(now()->startOfDay(), false);

            // limit_1 < limit_2の前提で
            if ($elapsedDays >= $limit2Data['value']) {
                $this->style = $limit2Data['style'];
            } else if ($elapsedDays >= $limit1Data['value']) {
                $this->style = $limit1Data['style'];
            }

        }
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0200.search-reception-card');
    }
}
