<?php

namespace App\View\Components\U0200;

use App\Models\UReception;
use GuzzleHttp\Psr7\Uri;
use Illuminate\View\Component;

class PrintButton extends Component
{
    public $reception; // 受付情報
    public $schedules; // 受付情報

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(string $receptionNo)
    {
        $this->reception = UReception::find($receptionNo);
        $this->schedules = $this->reception->schedules()->orderby('date')->get();
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0200.print-button');
    }
}
