<?php

namespace App\View\Components\U0200;

use App\Models\USchedule;
use Illuminate\View\Component;

class ScheduleCard extends Component
{

    public $schedule; // 訪問予定（日程）
    public $receptionNo; // 受付情報番号
    public $editable; // 編集可能か
    public $slotTitles; // 時間帯タイトル
    public $slotColors; // 時間帯色

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(
        USchedule $schedule,
        string $receptionNo,
        array $slotTitles,
        array $slotColors,
        bool $editable = true
    ) {
        $this->schedule = $schedule;
        $this->receptionNo = $receptionNo;
        $this->editable = $editable;
        $this->slotTitles = $slotTitles;
        $this->slotColors = $slotColors;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.U0200.schedule-card');
    }
}
