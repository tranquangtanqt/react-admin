<?php

namespace App\Console\Commands\U0900;

use App\Commons\CommonFunction;
use App\Commons\FtpObject;
use App\Commons\Logger;
use App\Mail\SystemErrorMail;
use App\Models\BatchStatus;
use App\Models\L2AccountYearMonth;
use App\Models\SystemSetting;
use App\Models\UManHour;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Mail;
use SebastianBergmann\CodeCoverage\BranchAndPathCoverageNotSupportedException;

class CoopManHour extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:CoopManHour';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '工数情報連携処理';

    /**
     * 戻り値（正常）
     *
     * @var int
     */
    protected $nomalEnd = 0;

    /**
     * 戻り値（連携実施中）
     *
     * @var int
     */
    protected $unFinished = 1;

    /**
     * 戻り値（L2連携未完了）
     *
     * @var int
     */
    protected $l2UnFinished = 7;

    /**
     * 戻り値（前回異常）
     *
     * @var int
     */
    protected $alreadyAbNomalEnd = 8;

    /**
     * 戻り値（異常）
     *
     * @var int
     */
    protected $abNomalEnd = 9;

    /**
     * ログ基本情報
     *
     * @var array
     */
    private $logBase = [];

    /**
     * 処理開始日時
     *
     * @var string
     */
    private $execTimestamp = "";

    /**
     * 出力明細件数
     *
     * @var int
     */
    private $outputCount = 0;

    /**
     * 対象日付開始日
     *
     * @var string
     */
    private $ymStart = "";

    /**
     * 対象日付終了日翌日
     *
     * @var string
     */
    private $ymNext = "";

    /**
     * 処理対象更新フラグ
     *
     * @var boolean
     */
    private $targetUpdatedFlag = false;

    /**
     * 連携対象ステータス
     *
     * @var string[]
     */
    private $targetCoopType = [];

    /**
     * 処理中エラー詳細
     *
     * @var string
     */
    private $notification = "";

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        // 処理開始日時
        $this->execTimestamp = date("YmdHis");

        // ログ基本情報設定
        $this->logBase = [
            'user_id' => config('constants.sys_userid.batch_user'),
            'process_name' => $this->description,
            'process_type' => config('constants.logs.coop_process'),
            'user_agent' => '-',
            'request_url' => '-',
            'referer_url' => '-',
        ];
        // 連携対象ステータス設定
        $coopType = config('constants.coop');
        $this->targetCoopType = [
            $coopType["yet"],
            $coopType["skip"],
            $coopType["stop"],
            $coopType["target"],
        ];
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        $tran = false; // トランザクション開始

        // コンソール＆ログ出力
        $this->outputConsoleLog($this->description . ' 開始', '処理を開始しました。');
        try {

            // バッチステータス更新処理（開始）
            switch ($this->updateStatus("start", $res)) {
                case $this->unFinished:
                    $res = $this->unFinished; // 戻り値-連携実施中
                    // コンソール＆ログ出力
                    $this->outputConsoleLog("前回連携処理が実行中です。", "前回連携処理が実行中です。");
                    goto endtry;
                    break;
                case $this->alreadyAbNomalEnd:
                    $res = $this->alreadyAbNomalEnd; // 戻り値-前回異常
                    // コンソール＆ログ出力
                    $this->outputConsoleLog("前回連携処理が異常終了しています。", "前回連携処理が異常終了しています。");
                    goto endtry;
                    break;
                case $this->abNomalEnd:
                    goto endtry;
                    break;
            }

            // FTPクラス
            $ftpobj = new FtpObject();
            // ローカル一時ディレクトリ
            $tmpDir = CommonFunction::pathCombine([storage_path(), env('U0904_TMPDIR')]);
            // フォルダがなければ作成
            File::ensureDirectoryExists($tmpDir);

            // ローカル退避ディレクトリ
            $bkupDir = CommonFunction::pathCombine([storage_path(), env('U0904_BKUPDIR')]);
            // フォルダがなければ作成
            File::ensureDirectoryExists($bkupDir);

            // ローカルファイル名
            $localFileName = env('U0904_LOCALFILENAME');
            $localFileName = str_replace('.csv', '_' . $this->execTimestamp . '.csv', $localFileName);
            // FTP送信ファイル（FTPフルパス）
            $sendFile = env('U0904_SENDFILE');

            // 会計年月取得処理
            $this->getAccountYearMonth();

            // ファイルの存在チェック
            if ($ftpobj->hasFile($sendFile)) {
                // ファイルが存在する場合は、連携先(L2)が未処理、または連携中のため処理スキップ
                // コンソール＆ログ出力
                $this->outputConsoleLog("L2連携未完了のため、連携処理をスキップします。", "L2連携未完了のため、連携処理をスキップします。", "FTPサーバーにファイルあり　" . $sendFile);

                $this->notification = "L2連携未完了です。（連携ファイルあり）";
                $res = $this->l2UnFinished; // 戻り値-L2連携未完了

                DB::beginTransaction(); // トランザクション開始
                $tran = true;
                // 連携対象ステータス更新
                $this->updateTargetStatus($this->targetCoopType, config('constants.coop.stop'));
            } else {
                // ファイルが存在しない場合は、CSVを出力
                DB::beginTransaction(); // トランザクション開始
                $tran = true;
                // 連携ファイル作成処理
                if ($this->createFile($localFileName, $tmpDir) === $this->nomalEnd) {

                    // ファイル送信処理
                    if ($this->sendFile($ftpobj, $tmpDir, $localFileName, $sendFile, $bkupDir) === $this->nomalEnd) {
                        $res = $this->nomalEnd; // 戻り値-正常
                    }
                }

                if ($this->targetUpdatedFlag) {
                    // 連携対象ステータス更新
                    switch ($res) {
                        case $this->nomalEnd: // 正常
                        case $this->alreadyAbNomalEnd: // 前回異常
                            $updateStatus = config('constants.coop.active');
                            break;
                        default:
                            $updateStatus = config('constants.coop.stop');
                            break;
                    }
                    $this->updateTargetStatus([config('constants.coop.target')], $updateStatus);
                }
            }
        } catch (\Exception $e) {
            $res = $this->abNomalEnd; // 戻り値-異常
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "予期せぬエラーが発生しました。", '予期せぬエラーが発生しました。', $e);
            $this->notification = "予期せぬエラーが発生しました。";
        } finally {
            // エラーメール送信
            switch ($res) {
                case $this->nomalEnd: // 正常
                case $this->unFinished: // 連携実施中
                    break;
                default:
                    // 上記以外の場合のみ
                    $this->sendErrorMail();
                    break;
            }

            switch ($res) {
                case $this->unFinished: // 連携実施中
                case $this->alreadyAbNomalEnd: // 前回異常
                    break;
                default:
                    // 連携実施中、前回異常以外の場合

                    // トランザクション処理
                    if ($tran == true) {
                        /*
                        if($res==$this->nomalEnd or $res==$this->nomalEnd) {
                            // 正常、０件正常の場合
                            DB::commit(); // コミット
                        } else {
                            DB::rollBack(); // ロールバック
                        }
                        */
                        DB::commit(); // コミット
                    }

                    // バッチステータス更新処理（終了）
                    $this->updateStatus("end", $res, $this->notification);
                    break;
            }
            // コンソール＆ログ出力
            $this->outputConsoleLog($this->description . " 終了(" . $res . ")", "処理を終了しました。(" . $res . ")");
        }
        endtry:
        return $res;
    }

    /**
     * 会計年月取得処理
     *
     * @return void
     */
    private function getAccountYearMonth()
    {
        echo "会計年月取得処理\n";
        // 会計年月取得
        $l2AccountYearMonth = L2AccountYearMonth::first();

        if ($l2AccountYearMonth) {
            $ym = substr($l2AccountYearMonth->account_year_month, 0, 6);
            if (strptime($ym, '%Y%m')) {
                // 抽出対象月初日付
                $this->ymStart = date('Y/m/d', strtotime($ym . "01"));
                // 抽出対象翌月月初日付
                $this->ymNext = date('Y/m/01', strtotime($this->ymStart . " +1 month"));
                // ADD START 20220518 Ishino -003 工数連携対象を当日までの分とする
                // 当日、翌日を取得
                $today = now()->format('Y/m/d');
                $tommorow = date('Y/m/d', strtotime($today . " +1 day"));
                
                if ($this->ymStart <= $today && $this->ymNext >= $tommorow) {
                    // 当日が会計月度内の場合は終了日を設定して未来日は抽出対象としない
                    $this->ymNext = $tommorow;
                } elseif ($this->ymStart > $today) {
                    // 当日が会計月度の前の場合は終了日を設定して未来日は抽出対象としない
                    $this->ymNext = $tommorow;
                }
                // ADD E N D 20220518 Ishino -003 工数連携対象を当日までの分とする
            } else {
                // 会計年月の取得に失敗した場合
                // コンソール＆ログ出力
                $this->outputConsoleLog("会計年月の取得に失敗しました。", '会計年月取得処理で異常終了しました。', '会計年月から日付に変換出来ません。（' . $l2AccountYearMonth->account_year_month . '）');
                throw new Exception("会計年月の取得に失敗しました。");
            }
        } else {
            // 会計年月が存在しない場合
            // コンソール＆ログ出力
            $this->outputConsoleLog("会計年月が取得できません。", '会計年月取得処理で異常終了しました。', '会計年月が取得出来ません。');
            throw new Exception("会計年月の取得に失敗しました。");
        }
    }

    /**
     * 連携ファイル作成処理
     *
     * @param string $fileName ファイル名
     * @param string $tmpDir 一時フォルダ
     * @return int
     */
    private function createFile($fileName, $tmpDir)
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        echo "連携ファイル作成処理\n";
        try {
            // 一時ファイル
            $tmpFile = CommonFunction::pathCombine([$tmpDir, $fileName]);

            // 連携区分
            $coopType = config('constants.coop');

            // 日付フォーマット
            $dateFormat = 'YYYYMMDD';
            // 日付フォーマット2
            $dateFormat2 = 'YYYYMMDD HH24MISS';

            // 工数連携停止を取得
            $systemSetting = SystemSetting::find('CoopManHourStop');
            $coopManHourStop = false;
            if ($systemSetting?->value == '1') {
                $coopManHourStop = true;
            };

            // 連携対象ステータス更新
            $targetCoopType = $this->targetCoopType;
            array_push($targetCoopType, $coopType["except"]); // 連携対象の条件に更新対象外を追加
            if ($coopManHourStop) {
                // 工数連携停止の場合
                $this->updateTargetStatus($targetCoopType, $coopType["stop"]); // 連携中止へ更新

            } else {
                // 工数連携停止の以外場合
                $this->updateTargetStatus($targetCoopType, $coopType["target"]); // 更新対象へ更新
                $this->updateTargetStatus($targetCoopType, $coopType["except"]); // 更新対象外へ更新

            }

            // 工数データ抽出
            $targetDatas = DB::table('u_man_hours as mh')
                ->select('mh.*')
                ->addSelect(DB::raw('to_char(mh.updated_at,\'' . $dateFormat2 . '\') as updated_at_fmt')) // 更新日のフォーマット
                ->leftJoin('u_schedules as sc', 'mh.schedule_id', '=', 'sc.id') // 日程テーブルとのJOIN
                ->addSelect(DB::raw('to_char(sc.date,\'' . $dateFormat . '\') as sc_date')) // 日程のフォーマット
                ->addSelect('sc.reception_no as reception_no') // 受付番号
                ->leftJoin('l2_receptions as l2re', 'sc.reception_no', '=', 'l2re.no') // L2受付テーブルとのJOIN
                ->addSelect('l2re.related_pj_no as related_pj_no') // 関連PJ番号
                ->leftJoin('users', 'mh.user_id', '=', 'users.id') // ユーザーテーブルとのJOIN
                ->addSelect('users.external_user_id as ex_user_id') // 外部ユーザーコード
                ->where('sc.date', '>=', $this->ymStart)
                ->where('sc.date', '<', $this->ymNext)
                ->where("mh.coop_type", '=', $coopType["target"])
                ->get();

            // ファイルオープン
            $workStream = tmpfile();
            $stream = fopen($tmpFile, "w+");

            // 文字項目指定
            $stringField = array(0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1);

            // ヘッダーレコード出力
            fputcsv($workStream, array("00"));

            // 明細レコード編集・出力
            foreach ($targetDatas as $targetData) {
                $line = []; // 行初期化
                array_push($line, "10");                            // レコード種別（明細）
                array_push($line, $targetData->id);                 // 工数ID
                array_push($line, $targetData->ex_user_id);         // 社員コード
                array_push($line, $targetData->sc_date);            // 作業日付
                // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
                //--array_push($line, $targetData->start_time);         // 開始時刻
                //--array_push($line, $targetData->end_time);           // 終了時刻
                if($targetData->start_time>'2359' || $targetData->end_time>'2359'){
                    array_push($line, "");                          // 開始時刻
                    array_push($line, "");                          // 終了時刻
                } else {
                    array_push($line, $targetData->start_time);     // 開始時刻
                    array_push($line, $targetData->end_time);       // 終了時刻
                }
                // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応
                array_push($line, $targetData->man_hour);           // 実績工数
                if ($targetData->related_pj_no == null) {
                    array_push($line, $targetData->work_class);     // 建材作業区分
                } else {
                    array_push($line, config('constants.l2_work.construction'));  // 建材作業区分(施工)
                }
                array_push($line, $targetData->work_type);          // 建材作業分類区分
                array_push($line, $targetData->work_detail);        // 建材作業詳細区分
                array_push($line, $targetData->work_content);       // 作業内容
                if ($targetData->related_pj_no == null) {
                    if ($targetData->work_class == config('constants.l2_work.construction')) {
                        array_push($line, $targetData->reception_no);   // 受注番号
                    } else {
                        array_push($line, "");                      // 受注番号(未設定)
                    }
                } else {
                    array_push($line, $targetData->related_pj_no);  // 受注番号
                }
                array_push($line, $targetData->ex_user_id);         // 更新社員レコード
                array_push($line, $targetData->updated_at_fmt);     // 更新日時
                $this->_fputcsv($workStream, $line, $stringField);  // 出力
                //fputcsv($workStream, $line); // 出力
                ++$this->outputCount;
            }

            // トレーラーレコード出力
            fputcsv($workStream, array("99"));

            // 一時ファイルを改行コードCRLF、Shift-JISに変換して出力
            rewind($workStream);
            $workStream = str_replace(PHP_EOL, "\r\n", stream_get_contents($workStream));
            $workStream = mb_convert_encoding($workStream, 'SJIS-win', 'UTF-8');
            fwrite($stream, $workStream);

            // コンソール＆ログ出力
            $wklog = "対象日付：" . $this->ymStart . "から" . $this->ymNext . "の前日　明細出力件数：" . $this->outputCount . "件";
            $this->outputConsoleLog("連携ファイル作成　" . $wklog, '連携ファイル作成', $wklog);

            $res = $this->nomalEnd; // 戻り値-正常
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "連携ファイル作成処理で異常終了しました。", '連携ファイル作成処理で異常終了しました。', $e);
            $this->notification = "連携ファイル作成処理で異常終了しました。";
        } finally {
            // ファイルクローズ
            if (isset($stream)) {
                fclose($stream);
            }
        }
        endtry:

        return $res;
    }

    /**
     * CSVフォーマット
     * 
     * @param stream $stream ストリーム
     * @param array $data 出力データ
     * @param array $stringField 文字列指定（0:文字列以外　1:文字列）
     */
    private function _fputcsv($stream, $data, $stringField)
    {
        $count = 0;
        $out = '';
        foreach ($data as $row) {
            // 改行コード置換
            $rowedit = str_replace("\r", '\\r', $row);
            $rowedit = str_replace("\n", '\\n', $rowedit);
            if ($count != 0) {
                $out .= ",";
            }
            if ($stringField[$count] == 1) {
                $out .= '"' . $rowedit . '"';
            } else {
                $out .= $rowedit;
            }
            ++$count;
        }
        fwrite($stream, $out);
        fwrite($stream, PHP_EOL);
    }

    /**
     * 連携対象ステータス更新
     *
     * @param string $target 更新対象
     * @param string $status 更新ステータス
     * @return void
     */
    private function updateTargetStatus($target, $status)
    {
        if ($status == config('constants.coop.except')) {
            // 工数データ更新（連携対象外）
            $targetDatas = DB::table('u_man_hours as mh')
                ->leftJoin('u_schedules as sc', 'mh.schedule_id', '=', 'sc.id') // 日程テーブルとのJOIN
                ->Join('l2_receptions as l2re', function ($join) {
                    $join->on('sc.reception_no', '=', 'l2re.no')
                        ->whereNull('l2re.related_pj_no');
                }) // L2受付テーブルとのJOIN
                ->leftJoin('l2_objects as l2ob', function ($join) {
                    $join->on('sc.reception_no', '=', 'l2ob.reception_no');
                }) // L2物件テーブルとのJOIN
                ->where('sc.date', '>=', $this->ymStart)
                ->where('sc.date', '<', $this->ymNext)
                ->whereIn("mh.coop_type", $target)
                ->where("mh.work_class", "=", config('constants.l2_work.construction'))
                ->where(function ($query) {
                    $query->where('l2ob.order_cancellation_flag', '=', '1') // 1:キャンセル
                        ->orWhereNull('l2ob.reception_no');
                })
                ->update(['mh.coop_type' => $status, 'updated_by' => config('constants.sys_userid.batch_user'), 'updated_at' => NOW()]);

            // 工数データ更新（連携対象外-外部連携社員コードなし）
            $targetDatas = DB::table('u_man_hours as mh')
                ->leftJoin('u_schedules as sc', 'mh.schedule_id', '=', 'sc.id') // 日程テーブルとのJOIN
                ->leftJoin('users', 'mh.user_id', '=', 'users.id') // ユーザーテーブルとのJOIN
                ->leftJoin('users as upuser', 'mh.updated_by', '=', 'upuser.id') // ユーザーテーブルとのJOIN（更新ユーザ）
                ->where('sc.date', '>=', $this->ymStart)
                ->where('sc.date', '<', $this->ymNext)
                ->whereIn("mh.coop_type", $target)
                ->whereRaw(('users.external_user_id is null'))
                ->update(['mh.coop_type' => $status, 'updated_by' => config('constants.sys_userid.batch_user'), 'updated_at' => NOW()]);
        } else {
            // 工数データ更新

            $targetDatas = DB::table('u_man_hours as mh')
                ->leftJoin('u_schedules as sc', 'mh.schedule_id', '=', 'sc.id') // 日程テーブルとのJOIN
                ->where('sc.date', '>=', $this->ymStart)
                ->where('sc.date', '<', $this->ymNext)
                ->whereIn("mh.coop_type", $target)
                ->whereNull('mh.deleted_at')
                ->update(['mh.coop_type' => $status, 'updated_by' => config('constants.sys_userid.batch_user'), 'updated_at' => NOW()]);

            $this->targetUpdatedFlag = true;
        }
    }

    /**
     * ファイル送信処理
     *
     * @param class $ftpobj FtpObjectクラス
     * @param string $tmpDir 一時フォルダ
     * @param string $fileName ファイル名
     * @param string $sendFile 送信ファイル名（フルパス）
     * @param string $bkupDir バックアップフォルダ
     * @return int
     */
    private function sendFile($ftpobj, $tmpDir, $fileName, $sendFile, $bkupDir)
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        echo "ファイル送信処理\n";
        try {
            // 一時ファイル
            $tmpFile = CommonFunction::pathCombine([$tmpDir, $fileName]);
            // 退避ファイル
            $bkupFile = CommonFunction::pathCombine([$bkupDir, $fileName]);

            // ローカルフォルダ設定
            $ftpobj->setStorageDirectory($tmpDir);
            // ファイル送信
            if ($ftpobj->writeFile($sendFile, $fileName)) {
                // コンソール＆ログ出力
                $this->outputConsoleLog("FTPサーバーファイルアップロード成功", 'FTPサーバーファイルアップロード成功');
            } else {
                // コンソール＆ログ出力
                $this->outputConsoleLog($ftpobj->executeLog . "\n" . "ファイル送信処理で異常終了しました。", 'ファイル送信処理で異常終了しました。', $ftpobj->executeLog);
                $this->notification = "ファイル送信処理で異常終了しました。";
                goto endtry;
            }

            // 連携ファイル退避処理
            try {
                // ファイルコピー(退避)
                File::copy($tmpFile, $bkupFile);
                File::delete($tmpFile);
            } catch (\Exception $e) {
                // コンソール＆ログ出力
                $this->outputConsoleLog($e . "\n" . "連携ファイル退避処理で異常終了しました。", '連携ファイル作退避処理で異常終了しました。', $e);
                $this->notification = "連携ファイル退避処理で異常終了しました。";
                $res = $this->abNomalEnd; // 戻り値-異常
                goto endtry;
            }

            $res = $this->nomalEnd; // 戻り値-正常
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "ファイル送信処理で異常終了しました。", 'ファイル送信処理で異常終了しました。', $e);
            $this->notification = "ファイル送信処理で異常終了しました。";
            $res = $this->abNomalEnd; // 戻り値-異常
        }
        endtry:
        return $res;
    }

    /**
     * バッチステータス更新処理
     *
     * @param string $action start:開始、end:終了
     * @return int
     */
    private function updateStatus($action, $action_res, $notification = null)
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        echo "バッチステータス更新処理 action=" . $action . "\n";
        if ($action == "start") {
            $process_status = config('constants.batch.processing');
        } else {
            if ($action_res == $this->nomalEnd) {
                if ($this->outputCount == 0) {
                    $process_status = config('constants.batch.success_no_data'); // 正常終了(データなし)
                } else {
                    $process_status = config('constants.batch.success'); // 正常終了
                }
            } else {
                $process_status = config('constants.batch.failure'); // 異常終了
            }
        }

        // パラメタ
        $prm = [
            "action" => $action,
            "process_status" => $process_status,
            "notification" => $notification,
        ];
        try {
            $res = DB::transaction(function () use ($prm) {
                if ($prm['action'] == "start") {
                    // 開始時
                    $batchStatus = BatchStatus::where("process_id", "=", "CoopManHour")->first();
                    if ($batchStatus == null) {
                        // レコードがない場合、初期値を設定
                        $batchStatus = BatchStatus::insert([
                            "process_id" => "CoopManHour",
                            "process_name" => "工数情報連携",
                            "process_status" => $prm['process_status'],
                            "created_at" => NOW(),
                        ]);
                        $res = $this->nomalEnd; // 戻り値-正常
                    } elseif ($batchStatus->process_status == config('constants.batch.processing')) {
                        // 処理中の場合
                        $res = $this->unFinished; // 戻り値-処理中
                    } elseif ($batchStatus->process_status == config('constants.batch.failure')) {
                        // 異常の場合
                        $res = $this->alreadyAbNomalEnd; // 戻り値-処理中
                    } else {
                        $batchStatus->update([
                            "process_status" => $prm['process_status'],
                            "notification" => $prm['notification'],
                            "created_at" => NOW(),
                        ]);
                        $res = $this->nomalEnd; // 戻り値-正常
                    }
                } else {
                    // 終了時
                    BatchStatus::where("process_id", "=", "CoopManHour")
                        ->update([
                            "process_status" => $prm['process_status'],
                            "notification" => $prm['notification'],
                            "created_at" => NOW(),
                        ]);
                    $res = $this->nomalEnd; // 戻り値-正常
                }
                return $res;
            });
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "バッチステータス更新処理で異常終了しました。", 'バッチステータス更新処理で異常終了しました。', $e);
            $this->notification = "バッチステータス更新処理で異常終了しました。";
            $res = $this->abNomalEnd; // 戻り値-異常
        }
        endtry:
        return $res;
    }

    /**
     * コンソール＆ログ出力
     *
     * @return void
     */
    private function outputConsoleLog($console, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        echo $console . " \n";
        $logInfo = $this->logBase; // ログ情報初期化
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }

    /**
     * エラーメール送信
     * 
     */
    private function sendErrorMail()
    {
        try {
            echo  "エラーメール送信 \n";
            // 送信先を環境設定から取得して設定
            $mailTo = explode(',', env('MAIL_TO_ADDRESS_SYSTEM_ERROR'));

            $errorInfo = array(); // エラー情報
            $errorInfo['errorprocess'] = $this->description; // エラー対象処理名設定
            $errorInfo['loginurl'] = route('login'); // ログインURL設定

            // メール送信
            Mail::to($mailTo)->send(new SystemErrorMail($errorInfo));
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "エラーメール送信で異常終了しました。", 'エラーメール送信で異常終了しました。', $e);
        }
    }
}
