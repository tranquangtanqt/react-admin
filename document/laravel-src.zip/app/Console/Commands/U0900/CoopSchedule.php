<?php

namespace App\Console\Commands\U0900;

use App\Commons\CommonFunction;
use App\Commons\Logger;
use App\Mail\SystemErrorMail;
use App\Models\BatchStatus;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Mail;

class CoopSchedule extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:CoopSchedule';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'スケジュール連携処理';

    protected $processId = 'CoopSchedule';
    protected $processName = 'スケジュール連携';

    /**
     * 戻り値（正常）
     *
     * @var int
     */
    protected $nomalEnd = 0;

    /**
     * 戻り値（連携実施中）
     *
     * @var int
     */
    protected $unFinished = 1;

    /**
     * 戻り値（前回異常）
     *
     * @var int
     */
    protected $alreadyAbNomalEnd = 8;

    /**
     * 戻り値（異常）
     *
     * @var int
     */
    protected $abNomalEnd = 9;

    /**
     * ログ基本情報
     *
     * @var array
     */
    private $logBase = [];

    /**
     * 処理開始日時
     *
     * @var string
     */
    private $execTimestamp = "";

    /**
     * 出力明細件数
     *
     * @var int
     */
    private $outputCount = 0;

    /**
     * 対象日付開始日
     *
     * @var string
     */
    private $ymdStart = "";

    /**
     * 対象日付終了日翌日
     *
     * @var string
     */
    private $ymdNext = "";

    /**
     * 処理中エラー詳細
     *
     * @var string
     */
    private $notification = "";

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        // 処理開始日時
        $this->execTimestamp = date("YmdHis");

        // ログ基本情報設定
        $this->logBase = [
            'user_id' => config('constants.sys_userid.batch_user'),
            'process_name' => $this->description,
            'process_type' => config('constants.logs.coop_process'),
            'user_agent' => '-',
            'request_url' => '-',
            'referer_url' => '-',
        ];
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        $tran = false; // トランザクション開始

        // コンソール＆ログ出力
        $this->outputConsoleLog($this->description . ' 開始', '処理を開始しました。');
        try {

            // バッチステータス更新処理（開始）
            switch ($this->updateStatus("start", $res)) {
                case $this->unFinished:
                    $res = $this->unFinished; // 戻り値-連携実施中
                    // コンソール＆ログ出力
                    $this->outputConsoleLog("前回連携処理が実行中です。", "前回連携処理が実行中です。");
                    goto endtry;
                    break;
                case $this->alreadyAbNomalEnd:
                    $res = $this->alreadyAbNomalEnd; // 戻り値-前回異常
                    // コンソール＆ログ出力
                    $this->outputConsoleLog("前回連携処理が異常終了しています。", "前回連携処理が異常終了しています。");
                    goto endtry;
                    break;
                case $this->abNomalEnd:
                    goto endtry;
                    break;
            }

            // ローカル一時ディレクトリ
            $tmpDir = CommonFunction::pathCombine([storage_path(), env('U0905_TMPDIR')]);
            // フォルダがなければ作成
            File::ensureDirectoryExists($tmpDir);

            // ローカル退避ディレクトリ
            $bkupDir = CommonFunction::pathCombine([storage_path(), env('U0905_BKUPDIR')]);
            // フォルダがなければ作成
            File::ensureDirectoryExists($bkupDir);

            // 連携データディレクトリ
            $dataDir = env('U0905_DATADIR');
            // フォルダがなければ作成
            File::ensureDirectoryExists($dataDir);

            // ローカルファイル名
            $localFileName = env('U0905_LOCALFILENAME');
            $backupFileName = str_replace('.csv', '_' . $this->execTimestamp . '.csv', $localFileName);
            // 一時ファイル
            $tmpFile = CommonFunction::pathCombine([$tmpDir, $localFileName]);
            // 退避ファイル
            $backupFile = CommonFunction::pathCombine([$bkupDir, $backupFileName]);
            // データファイル
            $dataFile = CommonFunction::pathCombine([$dataDir, $backupFileName]);
            // 期間
            $daysEnd = env('U0905_DAYS');
            // モジュール
            $module = env('U0905_MODULE');
            // 設定ファイル
            $config = env('U0905_CONFIG');
            // 設定ファイル雛形
            $configTemplate = env('U0905_CONFIGTEMPLATE');
            // 抽出対象開始日
            $this->ymdStart = date("Y/m/d");
            // 抽出対象終了日翌日
            $this->ymdNext = date('Y/m/d', strtotime($this->ymdStart . " +" . $daysEnd . " day"));

            DB::beginTransaction(); // トランザクション開始
            $tran = true;
            // 連携ファイル作成処理
            if ($this->createFile($localFileName, $tmpDir) === $this->nomalEnd) {

                // データフォルダにあるファイルを削除
                $dataFiles = File::files($dataDir);
                foreach ($dataFiles as $delFile) {
                    File::delete($delFile->getpathName());
                }

                // ファイルコピー(データフォルダ)
                File::copy($tmpFile, $dataFile);

                // ファイル送信処理
                if ($this->execCoopSchedule($localFileName, $tmpDir, $module, $config, $configTemplate, $daysEnd) === $this->nomalEnd) {

                    // ファイルコピー(退避)
                    File::copy($tmpFile, $backupFile);
                    $res = $this->nomalEnd; // 戻り値-正常
                }
            }
        } catch (\Exception $e) {
            $res = $this->abNomalEnd; // 戻り値-異常
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "予期せぬエラーが発生しました。", '予期せぬエラーが発生しました。', $e);
            $this->notification = "予期せぬエラーが発生しました。";
        } finally {
            // エラーメール送信
            switch ($res) {
                case $this->nomalEnd: // 正常
                case $this->unFinished: // 連携実施中
                    break;
                default:
                    // 上記以外の場合のみ
                    $this->sendErrorMail();
                    break;
            }

            switch ($res) {
                case $this->unFinished: // 連携実施中
                case $this->alreadyAbNomalEnd: // 前回異常
                    break;
                default:
                    // 連携実施中、前回異常以外の場合

                    // トランザクション処理
                    if ($tran == true) {
                        /*
                        if($res==$this->nomalEnd or $res==$this->nomalEnd) {
                            // 正常、０件正常の場合
                            DB::commit(); // コミット
                        } else {
                            DB::rollBack(); // ロールバック
                        }
                        */
                        DB::commit(); // コミット
                    }

                    // バッチステータス更新処理（終了）
                    $this->updateStatus("end", $res, $this->notification);
                    break;
            }
            // コンソール＆ログ出力
            $this->outputConsoleLog($this->description . " 終了(" . $res . ")", "処理を終了しました。(" . $res . ")");
        }
        endtry:
        return $res;
    }

    /**
     * 連携ファイル作成処理
     *
     * @param string $fileName ファイル名
     * @param string $tmpDir 一時フォルダ
     * @return int
     */
    private function createFile($fileName, $tmpDir)
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        echo "連携ファイル作成処理\n";
        try {
            // 一時ファイル
            $tmpFile = CommonFunction::pathCombine([$tmpDir, $fileName]);

            // 一時ファイルが存在する場合は削除
            if (File::exists($tmpFile)) {
                $content = File::delete($tmpFile);
            }

            // 連携区分
            $coopType = config('constants.coop');

            // 日付フォーマット
            $dateFormat = 'YYYY-MM-DD';
            // 時間フォーマット
            $timeFormat = 'FM0000';

            // スケジュールデータ抽出
            $targetDatas = DB::table('u_schedules as sch')
                ->select('sch.*')
                ->addSelect(DB::raw('to_char(sch.date,\'' . $dateFormat . '\') as date_fmt')) // 日付のフォーマット

                // コード区分テーブルとのJOIN
                ->leftjoin('code_classes as sch_type', function ($join) {
                    $join->where('sch_type.identifier_code', config('constants.codes.pe_schedule'))
                        ->on('sch_type.key', 'sch.schedule_type');
                })
                ->addSelect('sch_type.value as type_name') // 予定区分名

                // 日程担当詳細テーブルとのJOIN
                ->leftjoin('u_schedule_details as sch_d', function ($join) {
                    $join->on('sch_d.schedule_id', 'sch.id')
                        ->whereNull('sch_d.deleted_at');
                })
                ->addSelect('sch_d.id as detail_id') // 日程担当詳細ID

                // コード区分テーブルとのJOIN
                ->leftjoin('code_classes as slot', function ($join) {
                    $join->where('slot.identifier_code', config('constants.codes.slot'))
                        ->on('slot.key', 'sch_d.slot_type')
                        ->whereNull('slot.deleted_at');
                })
                ->addSelect(DB::raw('to_char(slot.number1,\'' . $timeFormat . '\') as start_time')) // 開始時間
                ->addSelect(DB::raw('to_char(slot.number2,\'' . $timeFormat . '\') as end_time')) // 終了時間

                // L2受付テーブルとのJOIN
                ->leftjoin('l2_receptions as l2re', function ($join) {
                    $join->on('sch.reception_no', 'l2re.no')
                        ->whereNull('sch_d.deleted_at');
                })
                ->addSelect('l2re.field_name') // 現場名

                // ユーザーテーブルとのJOIN
                ->join('users', function ($join) {
                    $join->on('users.id', 'sch_d.user_id')
                        ->whereNotNull('users.external_company_id')
                        ->whereNotNull('users.external_user_id')
                        ->whereNull('users.deleted_at');
                })
                ->addSelect('users.external_company_id') // 外部連携会社コード
                ->addSelect('users.external_user_id') // 外部連携ユーザーコード

                ->where('sch.date', '>=', $this->ymdStart)
                ->where('sch.date', '<', $this->ymdNext)
                ->whereNull('sch.deleted_at')

                ->orderBy('users.external_company_id', 'asc')
                ->orderBy('users.external_user_id', 'asc')
                ->orderBy('date_fmt', 'asc')
                ->orderBy('start_time', 'asc')
                ->get();
            //->toSql();
            //dd($targetDatas);

            // 文字項目指定
            $stringField = array(0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0);
            // ファイルオープン
            $workStream = tmpfile();
            $stream = fopen($tmpFile, "w+");
            // ヘッダーレコード出力
            fputcsv($workStream, array("連携元スケジュールキー", "登録社員会社コード", "登録社員社員コード", "開始日付", "開始時刻", "終了日付", "終了時刻", "予定区分名", "件名", "内容", "公開非公開", "変更可否", "通常バナー"));

            // 明細レコード編集・出力
            foreach ($targetDatas as $targetData) {
                $line = []; // 行初期化
                array_push($line, $targetData->detail_id);          // 日程担当詳細ID
                array_push($line, $targetData->external_company_id); // 外部連携会社コード
                array_push($line, $targetData->external_user_id);   // 外部連携ユーザーコード
                array_push($line, $targetData->date_fmt);           // 日付
                array_push($line, $targetData->start_time);         // 開始時刻
                array_push($line, $targetData->date_fmt);           // 日付
                array_push($line, $targetData->end_time);           // 終了時刻
                if ($targetData->reception_no == null) {
                    array_push($line, $targetData->type_name);      // 予定区分
                    array_push($line, $targetData->title);          // 件名
                    array_push($line, $targetData->content);        // 内容
                } else {
                    array_push($line, $targetData->type_name);      // 予定区分
                    array_push($line, $targetData->field_name);     // 件名
                    array_push($line, $targetData->content);        // 内容
                }
                array_push($line, 1);         // 公開非公開 1:公開
                array_push($line, 0);         // 変更可否 0:変更不可
                array_push($line, 0);         // 通常バナー 0:通常スケジュール

                $this->_fputcsv($workStream, $line, $stringField); // 出力

                ++$this->outputCount;
            }

            // 一時ファイルを改行コードCRLF、Shift-JISに変換して出力
            rewind($workStream);
            $workStream = str_replace(PHP_EOL, "\r\n", stream_get_contents($workStream));
            $workStream = mb_convert_encoding($workStream, 'SJIS-win', 'UTF-8');
            fwrite($stream, $workStream);

            // コンソール＆ログ出力
            $wklog = "対象日付：" . $this->ymdStart . "から" . $this->ymdNext . "の前日　スケジュール出力件数：" . $this->outputCount . "件";
            $this->outputConsoleLog("連携ファイル作成　" . $wklog, '連携ファイル作成', $wklog);

            $res = $this->nomalEnd; // 戻り値-正常
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "連携ファイル作成処理で異常終了しました。", '連携ファイル作成処理で異常終了しました。', $e);
            $this->notification = "連携ファイル作成処理で異常終了しました。";
        } finally {
            // ファイルクローズ
            if (isset($stream)) {
                fclose($stream);
            }
        }
        endtry:

        return $res;
    }

    /**
     * CSVフォーマット
     * 
     * @param stream $stream ストリーム
     * @param array $data 出力データ
     * @param array $stringField 文字列指定（0:文字列以外　1:文字列）
     */
    private function _fputcsv($stream, $data, $stringField)
    {
        $count = 0;
        $out = '';
        foreach ($data as $row) {
            // 改行コード置換
            $rowedit = str_replace("\r", '\\r', $row);
            $rowedit = str_replace("\n", '\\n', $rowedit);
            if ($count != 0) {
                $out .= ",";
            }
            if ($stringField[$count] == 1) {
                $out .= '"' . $rowedit . '"';
            } else {
                $out .= $rowedit;
            }
            ++$count;
        }
        fwrite($stream, $out);
        fwrite($stream, PHP_EOL);
    }

    /**
     * スケジュール連携モジュール実行
     *
     * @param string $fileName ファイル名
     * @param string $tmpDir 一時フォルダ
     * @param string $module モジュールパス
     * @param string $config 設定ファイルパス
     * @param string $configTemplate 設定雛形ファイルパス
     * @param string $daysEnd 期間
     * @return int
     */
    private function execCoopSchedule($fileName, $tmpDir, $module, $config, $configTemplate, $daysEnd)
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        echo "スケジュール連携モジュール実行\n";
        try {
            // 設定雛形ファイルから設定ファイル作成
            if (File::exists($configTemplate)) {
                $content = File::get($configTemplate);
                $content = str_replace('{prm_end}', $daysEnd, $content);
                File::put($config, $content);
            }

            $cmd = 'bash ' . $module . ' 2>&1'; // モジュール実行
            exec($cmd, $output, $code);
            $msg = implode(PHP_EOL, $output); // UTF-8へ変換
            echo $msg . "\n";

            if ($code != 0) {
                throw new \Exception($msg);
            } else {
                $res = $this->nomalEnd; // 戻り値-正常
            }
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "スケジュール連携モジュール実行処理で異常終了しました。", 'スケジュール連携モジュール実行処理で異常終了しました。', $e);
            $this->notification = "スケジュール連携モジュール実行処理で異常終了しました。";
        }
        return $res;
    }

    /**
     * バッチステータス更新処理
     *
     * @param string $action start:開始、end:終了
     * @return int
     */
    private function updateStatus($action, $action_res, $notification = null)
    {
        $res = $this->abNomalEnd; // 戻り値-異常
        echo "バッチステータス更新処理 action=" . $action . "\n";
        if ($action == "start") {
            $process_status = config('constants.batch.processing');
        } else {
            if ($action_res == $this->nomalEnd) {
                if ($this->outputCount == 0) {
                    $process_status = config('constants.batch.success_no_data'); // 正常終了(データなし)
                } else {
                    $process_status = config('constants.batch.success'); // 正常終了
                }
            } else {
                $process_status = config('constants.batch.failure'); // 異常終了
            }
        }

        // パラメタ
        $prm = [
            "action" => $action,
            "process_status" => $process_status,
            "notification" => $notification,
        ];
        try {
            $res = DB::transaction(function () use ($prm) {
                if ($prm['action'] == "start") {
                    // 開始時
                    $batchStatus = BatchStatus::where("process_id", $this->processId)->first();
                    if ($batchStatus == null) {
                        // レコードがない場合、初期値を設定
                        $batchStatus = BatchStatus::insert([
                            "process_id" => $this->processId,
                            "process_name" => $this->processName,
                            "process_status" => $prm['process_status'],
                            "created_at" => NOW(),
                        ]);
                        $res = $this->nomalEnd; // 戻り値-正常
                    } elseif ($batchStatus->process_status == config('constants.batch.processing')) {
                        // 処理中の場合
                        $res = $this->unFinished; // 戻り値-処理中
                    } elseif ($batchStatus->process_status == config('constants.batch.failure')) {
                        // 異常の場合
                        $res = $this->alreadyAbNomalEnd; // 戻り値-処理中
                    } else {
                        $batchStatus->update([
                            "process_status" => $prm['process_status'],
                            "notification" => $prm['notification'],
                            "created_at" => NOW(),
                        ]);
                        $res = $this->nomalEnd; // 戻り値-正常
                    }
                } else {
                    // 終了時
                    BatchStatus::where("process_id", $this->processId)
                        ->update([
                            "process_status" => $prm['process_status'],
                            "notification" => $prm['notification'],
                            "created_at" => NOW(),
                        ]);
                    $res = $this->nomalEnd; // 戻り値-正常
                }
                return $res;
            });
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "バッチステータス更新処理で異常終了しました。", 'バッチステータス更新処理で異常終了しました。', $e);
            $this->notification = "バッチステータス更新処理で異常終了しました。";
            $res = $this->abNomalEnd; // 戻り値-異常
        }
        endtry:
        return $res;
    }

    /**
     * コンソール＆ログ出力
     *
     * @return void
     */
    private function outputConsoleLog($console, $content, $contentDetail = null)
    {
        // コンソール＆ログ出力
        echo $console . " \n";
        $logInfo = $this->logBase; // ログ情報初期化
        $logInfo['content'] = $content;
        $logInfo['content_detail'] = $contentDetail;
        Logger::create($logInfo);
    }

    /**
     * エラーメール送信
     * 
     */
    private function sendErrorMail()
    {
        try {
            echo  "エラーメール送信 \n";
            // 送信先を環境設定から取得して設定
            $mailTo = explode(',', env('MAIL_TO_ADDRESS_SYSTEM_ERROR'));

            $errorInfo = array(); // エラー情報
            $errorInfo['errorprocess'] = $this->description; // エラー対象処理名設定
            $errorInfo['loginurl'] = route('login'); // ログインURL設定

            // メール送信
            Mail::to($mailTo)->send(new SystemErrorMail($errorInfo));
        } catch (\Exception $e) {
            // コンソール＆ログ出力
            $this->outputConsoleLog($e . "\n" . "エラーメール送信で異常終了しました。", 'エラーメール送信で異常終了しました。', $e);
        }
    }
}
