<?php

namespace App\Traits;

trait CreatedUpdatedBy
{
    /**
     * Boot the trait
     *
     * @return void
     */
    public static function bootCreatedUpdatedBy()
    {
        // 登録前の処理
        static::creating(function ($model) {
            if (!$model->isDirty('created_by') && auth()->check()) {
                $model->created_by = auth()->user()->id;
            }
            if (!$model->isDirty('updated_by') && auth()->check()) {
                $model->updated_by = auth()->user()->id;
            }
        });

        // 更新前の処理
        static::updating(function ($model) {

            if (!$model->isDirty('updated_by') && auth()->check()) {
                $model->updated_by = auth()->user()->id;
            }
        });
    }
}
