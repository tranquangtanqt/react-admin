<?php

namespace App\Traits;

use App\Models\UStatus;

trait StatusChange
{
    /**
     * 変更可能な受付状態パターンを取得
     *
     * @param UStatus
     * @return Collection
     */
    private function getMutationStates(UStatus $uStatus)
    {
        $statuses = collect([$uStatus->status_type]);

        // 基本的にシステム管理者が更新可能

        // (現場調整担当OR入力支援）かつ新規受付
        if ((userIsFieldCoor() || userIsInputSupport() || userIsSystemAdmin()) &&
            $uStatus->status_type === config('constants.status.new')
        ) {
            $statuses = $statuses->merge([config('constants.status.on_hold')]);
        }

        // 業務責任者かつ作業完了
        if (
            (userIsManager() || userIsSystemAdmin()) &&
            $uStatus->status_type === config('constants.status.work_done')
        ) {
            $statuses = $statuses->merge([config('constants.status.checked')]);
        }

        // 入力支援かつチェック済
        if (
            (userIsInputSupport() || userIsSystemAdmin()) &&
            $uStatus->status_type === config('constants.status.checked')
        ) {
            $statuses = $statuses->merge([config('constants.status.completed')]);
        }

        // 受付
        $reception = $uStatus->reception;
        // ユーザ
        $user = auth()->user();

        // 計上担当ユーザ
        $isPjmgr = $reception->eff_pjmgr_id === $user->id;

        // ダッシュボード表示ユーザ
        $isDisplayUser = $reception->display_user_id === $user->id;

        // 計上担当権限持つか？ => 計上担当ORダッシュボード表示ユーザORシステム管理者
        $hasPjmgrAuth = $isPjmgr || $isDisplayUser || userIsSystemAdmin();

        // 計上担当かつ訪問済
        if (
            $hasPjmgrAuth &&
            $uStatus->status_type === config('constants.status.visited')
        ) {
            $statuses = $statuses->merge([
                config('constants.status.on_hold'),
                config('constants.status.work_done'),
            ]);
        }

        // 計上担当かつ保留
        if (
            $hasPjmgrAuth &&
            $uStatus->status_type === config('constants.status.on_hold')
        ) {
            $statuses = $statuses->merge([
                config('constants.status.visited'),
                config('constants.status.work_done'),
            ]);
        }

        // 計上担当かつ訪問予定
        if (
            $hasPjmgrAuth &&
            $uStatus->status_type === config('constants.status.will_visit')
        ) {
            $statuses = $statuses->merge([config('constants.status.work_done')]);
        }

        // (計上担当 OR 現場調整担当者 OR L2入力支援)かつ新規受付の場合新規->作業完了を変更可
        if (
            ($hasPjmgrAuth || userIsFieldCoor() || userIsInputSupport()) && // 計上担当未決定の場合現場調整担当者もキャンセルできるように
            $uStatus->status_type === config('constants.status.new')
        ) {
            $statuses = $statuses->merge([config('constants.status.work_done')]);
        }

        return $statuses;
    }
}
