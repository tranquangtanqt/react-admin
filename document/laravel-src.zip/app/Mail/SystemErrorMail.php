<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SystemErrorMail extends Mailable
{
    use Queueable, SerializesModels;

    // エラー情報
    public $errorInfo;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($errorInfo)
    {
        $this->errorInfo = $errorInfo;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        // メール件名
        $mailSubject = '';
        // メール本文
        $mailBody = array();
        $bodyFlag = false;
        foreach (file(storage_path('app/mail/SystemError.txt')) as $line) {
            $editLine = mb_convert_encoding($line, "UTF-8", "SJIS"); // Shift-JISをUTF8に変換

            // 情報置換
            $replaceinfos = ['errorprocess','loginurl'];
            foreach ($replaceinfos as $replaceinfo){
                // 置換
                if (array_key_exists($replaceinfo, $this->errorInfo)){
                    $editLine = str_replace("{\$".$replaceinfo."}", $this->errorInfo[$replaceinfo], $editLine);
                }
            }

            if ($bodyFlag) {
                $editLine = str_replace("\r\n", "<br>", $editLine);
                $editLine = str_replace("\r", "<br>", $editLine);
                $editLine = str_replace("\n", "<br>", $editLine);
            } else {
                $mailSubject = $editLine; // メール件名設定
            }

            array_push($mailBody, $editLine);
            $bodyFlag = true;
        }

        return $this->subject($mailSubject)
            ->view('X0000.MailContent', ['details' => $mailBody])
            ->from(config('mail.from.address'));
    }
}
