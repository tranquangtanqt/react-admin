<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUWorkResultDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_work_result_details', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('schedule_id');
            $table->unsignedBigInteger('device_id');
            $table->string('work_detail', 255)->nullable();
            $table->boolean('enabled')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // foreign keys
            $table->foreign('schedule_id')
                ->references('id')
                ->on('u_schedules')
                ->onDelete('cascade')
                ->onUpdate('cascade');
            $table->foreign('device_id')
                ->references('id')
                ->on('u_devices');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_work_result_details');
    }
}
