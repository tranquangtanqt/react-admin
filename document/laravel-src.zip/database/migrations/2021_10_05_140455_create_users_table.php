<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255);
            $table->string('short_name', 255);
            $table->string('login_id', 255);
            $table->string('password', 255);
            $table->timestamp('password_updated_at')->nullable();
            $table->string('email', 255);
            $table->unsignedBigInteger('file_id')->nullable();
            $table->string('external_company_id', 255)->nullable();
            $table->string('external_user_id', 255)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // indexes
            $table->unique('login_id', 'users_idx01');
            $table->unique('email', 'users_idx02');
            $table->unique(["external_company_id", "external_user_id"], 'users_idx03');

            // foreign keys
            $table->foreign('file_id')
                ->references('id')
                ->on('files');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
