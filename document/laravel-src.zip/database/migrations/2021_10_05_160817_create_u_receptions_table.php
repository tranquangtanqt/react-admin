<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUReceptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_receptions', function (Blueprint $table) {
            $table->string('no', 255)->primary();
            $table->unsignedBigInteger('pjmgr_user_id')->nullable();
            $table->unsignedBigInteger('display_user_id')->nullable();
            $table->string('related_pjno', 255)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // foreign keys
            $table->foreign('pjmgr_user_id')
                ->nullable()
                ->references('id')
                ->on('users');

            $table->foreign('display_user_id')
                ->nullable()
                ->references('id')
                ->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_receptions');
    }
}
