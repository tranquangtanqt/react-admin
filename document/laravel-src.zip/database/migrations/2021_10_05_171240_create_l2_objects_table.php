<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateL2ObjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('l2_objects', function (Blueprint $table) {
            $table->string('reception_no', 255)->primary();
            $table->string('customer_no', 7)->nullable();
            $table->string('customer_account_no', 4)->nullable();
            $table->string('customer_name', 120)->nullable();
            $table->string('customer_account_name', 120)->nullable();
            $table->string('pjmgr_dept_no', 7)->nullable();
            $table->string('pjmgr_emp_no', 5)->nullable();
            $table->timestamp('contract_date')->nullable();
            $table->timestamp('work_start_date')->nullable();
            $table->timestamp('work_end_date')->nullable();
            $table->string('project_status', 4)->nullable();
            $table->string('sales_application_flag', 1)->nullable();
            $table->string('order_cancellation_flag', 1)->nullable();
            $table->string('completion_year_month', 6)->nullable();
            $table->string('entry_emp_code', 10)->nullable();
            $table->timestamp('entry_date_time')->nullable();
            $table->string('login_emp_code', 10)->nullable();
            $table->timestamp('registered_at')->nullable();
            $table->timestamp('coop_created_at')->nullable();
            $table->timestamp('coop_updated_at')->nullable();

            // foreign keys
            $table->foreign('reception_no')
                ->references('no')
                ->on('l2_receptions')
                ->onDelete('cascade')
                ->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('l2_objects');
    }
}
