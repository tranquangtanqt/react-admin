<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCodeClassesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('code_classes', function (Blueprint $table) {
            $table->id();
            $table->string('identifier_code', 255);
            $table->string('key', 255);
            $table->string('value', 255)->nullable();
            $table->string('display_order', 255)->nullable();
            $table->decimal('number1', 12, 3)->nullable();
            $table->decimal('number2', 12, 3)->nullable();
            $table->decimal('number3', 12, 3)->nullable();
            $table->string('string1', 255)->nullable();
            $table->string('string2', 255)->nullable();
            $table->string('string3', 255)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // indexes
            $table->unique(['identifier_code', 'key'], 'code_classes_idx01');

            // foreign keys
            $table->foreign('identifier_code')
                ->references('code')
                ->on('identifier_codes');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('code_classes');
    }
}
