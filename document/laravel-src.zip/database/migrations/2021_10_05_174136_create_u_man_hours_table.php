<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUManHoursTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_man_hours', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('schedule_id');
            $table->unsignedBigInteger('user_id');
            $table->string('start_time', 4)->nullable();
            $table->string('end_time', 4)->nullable();
            $table->decimal('man_hour', 4, 2)->nullable();
            $table->string('work_class', 4)->nullable();
            $table->string('work_type', 4)->nullable();
            $table->string('work_detail', 4)->nullable();
            $table->string('work_content', 511)->nullable();
            $table->string('order_no', 11)->nullable();
            $table->string('coop_type', 255)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // foreign keys
            $table->foreign('schedule_id')
                ->references('id')
                ->on('u_schedules')
                ->onDelete('cascade')
                ->onUpdate('cascade');
            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_man_hours');
    }
}
