<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUGasOutInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_gas_out_info', function (Blueprint $table) {
            $table->string('reception_no', 255)->primary();
            $table->string('type', 255);
            $table->string('gas_type', 255);
            $table->string('gas_type_name', 255)->nullable();
            $table->decimal('quantity', 5, 2)->nullable();
            $table->timestamp('date')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // foreign keys
            $table->foreign('reception_no')
                ->references('no')
                ->on('u_receptions')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_gas_out_info');
    }
}
