<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('logs', function (Blueprint $table) {
            $table->unsignedBigInteger('user_id');
            $table->string('process_type', 255);
            $table->string('process_name', 255);
            $table->string('content', 255);
            $table->text('content_detail')->nullable();
            $table->text('user_agent')->nullable();
            $table->string('request_url', 255)->nullable();
            $table->string('referer_url', 255)->nullable();
            $table->timestamp('created_at');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('logs');
    }
}
