<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddBillingNameTelFaxColumnsToUReceptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('u_receptions', function (Blueprint $table) {
            $table->string('billing_name', 120)->nullable();
            $table->string('billing_tel', 15)->nullable();
            $table->string('billing_fax', 15)->nullable();
            //
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('u_receptions', function (Blueprint $table) {
            $table->dropColumn('billing_name');
            $table->dropColumn('billing_tel');
            $table->dropColumn('billing_fax');
            //
        });
    }
}
