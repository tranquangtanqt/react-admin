<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUQuotationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_quotations', function (Blueprint $table) {
            $table->id();
            $table->string('reception_no', 255);
            $table->integer('serial_no');
            $table->string('work_no', 255)->nullable();
            $table->decimal('quantity', 5, 2)->nullable();
            $table->string('unit', 255)->nullable();
            $table->integer('amount')->nullable();
            $table->string('name', 255)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // indexes
            $table->unique(['reception_no', 'serial_no'], 'quotations_idx01');

            // foreign keys
            $table->foreign('reception_no')
                ->references('no')
                ->on('u_receptions')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_quotations');
    }
}
