<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateL2ReceptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('l2_receptions', function (Blueprint $table) {
            $table->string('no', 255)->primary();
            $table->timestamp('date')->nullable();
            $table->string('dept_no', 7)->nullable();
            $table->string('emp_code', 5)->nullable();
            $table->string('client_no', 7)->nullable();
            $table->string('client_account_no', 4)->nullable();
            $table->integer('client_billing_deadline')->nullable();
            $table->string('client_name', 120)->nullable();
            $table->string('client_person_name', 120)->nullable();
            $table->string('client_address', 120)->nullable();
            $table->string('client_tel', 15)->nullable();
            $table->string('client_fax', 15)->nullable();
            $table->string('client_mobile_tel', 15)->nullable();
            $table->string('field_name', 120)->nullable();
            $table->string('field_person_name', 120)->nullable();
            $table->string('field_address', 120)->nullable();
            $table->string('field_tel', 15)->nullable();
            $table->string('field_fax', 15)->nullable();
            $table->string('field_mobile_tel', 15)->nullable();
            $table->string('dealer_no', 7)->nullable();
            $table->string('dealer_account_no', 4)->nullable();
            $table->string('dealer_name', 120)->nullable();
            $table->string('dealer_person_name', 120)->nullable();
            $table->string('dealer_tel', 15)->nullable();
            $table->string('dealer_fax', 15)->nullable();
            $table->string('dealer_mobile_tel', 15)->nullable();
            $table->string('title', 120)->nullable();
            $table->string('content', 4000)->nullable();
            $table->timestamp('visit_date')->nullable();
            $table->string('visit_time_text', 200)->nullable();
            $table->string('status', 4)->nullable();
            $table->string('response_type', 4)->nullable();
            $table->string('mainte_check_term', 4)->nullable();
            $table->string('related_pj_no', 11)->nullable();
            $table->string('work_type', 4)->nullable();
            $table->string('target_order_no', 11)->nullable();
            $table->string('person_dept_no', 7)->nullable();
            $table->string('person_emp_code', 5)->nullable();
            $table->timestamp('completion_date')->nullable();
            $table->string('device_type1', 20)->nullable();
            $table->string('device_type2', 20)->nullable();
            $table->string('device_no1', 20)->nullable();
            $table->string('device_no2', 20)->nullable();
            $table->timestamp('delivery_date')->nullable();
            $table->string('repair_work_type', 4)->nullable();
            $table->string('repair_sector_type', 4)->nullable();
            $table->string('repair_point_type', 4)->nullable();
            $table->string('repair_status', 4)->nullable();
            $table->string('cause', 4000)->nullable();
            $table->string('measure', 4000)->nullable();
            $table->string('note', 4000)->nullable();
            $table->string('deleted_flag', 1)->nullable();
            $table->string('entry_emp_code', 10)->nullable();
            $table->timestamp('entry_date_time')->nullable();
            $table->string('login_emp_code', 10)->nullable();
            $table->timestamp('registered_at')->nullable();
            $table->timestamp('coop_created_at')->nullable();
            $table->timestamp('coop_updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('l2_receptions');
    }
}
