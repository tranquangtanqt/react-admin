<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUStatusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_statuses', function (Blueprint $table) {
            $table->string('reception_no', 255)->primary();
            $table->string('status_type', 255)->nullable();
            $table->string('status_detail_type', 255)->nullable();
            $table->timestamp('remind_date')->nullable();
            $table->string('remind_memo', 255)->nullable();
            $table->boolean('entry_complete_flag')->nullable();
            $table->timestamp('entry_complete_at')->nullable();
            $table->string('entry_complete_user_id', 255)->nullable();
            $table->boolean('checked_flag')->nullable();
            $table->timestamp('checked_at')->nullable();
            $table->string('checked_user_id', 255)->nullable();
            $table->timestamp('completion_date')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // foreign keys
            $table->foreign('reception_no')
                ->references('no')
                ->on('u_receptions')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_statuses');
    }
}
