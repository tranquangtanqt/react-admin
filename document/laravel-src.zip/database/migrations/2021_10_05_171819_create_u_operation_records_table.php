<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUOperationRecordsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_operation_records', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('device_id');
            $table->decimal('record01', 5, 2)->nullable();
            $table->decimal('record02', 5, 2)->nullable();
            $table->decimal('record03', 5, 2)->nullable();
            $table->decimal('record04', 5, 2)->nullable();
            $table->decimal('record05', 5, 2)->nullable();
            $table->decimal('record06', 5, 2)->nullable();
            $table->decimal('record07', 5, 2)->nullable();
            $table->decimal('record08', 5, 2)->nullable();
            $table->decimal('record09', 5, 2)->nullable();
            $table->decimal('record10', 5, 2)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // foreign keys
            $table->foreign('device_id')
                ->references('id')
                ->on('u_devices')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_operation_records');
    }
}
