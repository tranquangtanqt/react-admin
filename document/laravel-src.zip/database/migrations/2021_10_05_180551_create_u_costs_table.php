<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUCostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_costs', function (Blueprint $table) {
            $table->id();
            $table->string('reception_no', 255);
            $table->integer('serial_no');
            $table->string('type', 255)->nullable();
            $table->string('registered_class', 255)->nullable();
            $table->boolean('checked_flag')->nullable();
            $table->string('name', 255)->nullable();
            $table->decimal('amount', 9)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // indexes
            $table->unique(['reception_no', 'serial_no'], 'costs_idx01');

            // foreign keys
            $table->foreign('reception_no')
                ->references('no')
                ->on('u_receptions')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_costs');
    }
}
