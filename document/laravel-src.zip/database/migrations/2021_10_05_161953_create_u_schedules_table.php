<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUSchedulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('u_schedules', function (Blueprint $table) {
            $table->id();
            $table->timestamp('date');
            $table->string('schedule_type', 255);
            $table->string('reception_no', 255)->nullable();
            $table->string('title', 255)->nullable();
            $table->text('content')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // indexes
            $table->index(['reception_no', 'date'], 'u_schedules_idx01');
            $table->index('date', 'u_schedules_idx02');

            // foreign keys
            $table->foreign('reception_no')
                ->references('no')
                ->on('u_receptions')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('u_schedules');
    }
}
