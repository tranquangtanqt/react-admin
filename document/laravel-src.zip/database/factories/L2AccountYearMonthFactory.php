<?php

namespace Database\Factories;

use App\Models\L2AccountYearMonth;
use Illuminate\Database\Eloquent\Factories\Factory;

class L2AccountYearMonthFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = L2AccountYearMonth::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
