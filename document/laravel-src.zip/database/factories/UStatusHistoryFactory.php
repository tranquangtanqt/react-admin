<?php

namespace Database\Factories;

use App\Models\UStatusHistory;
use Illuminate\Database\Eloquent\Factories\Factory;

class UStatusHistoryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UStatusHistory::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
