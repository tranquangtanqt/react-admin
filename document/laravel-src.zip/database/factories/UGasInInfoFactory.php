<?php

namespace Database\Factories;

use App\Models\UGasInInfo;
use App\Models\UReception;
use Illuminate\Database\Eloquent\Factories\Factory;

class UGasInInfoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UGasInInfo::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'reception_no' => UReception::factory(),
            'type' => '1',
            'gas_type' => '1',
            'quantity' => $this->faker->numberBetween(1,30),
            'date' => $this->faker->dateTimeThisMonth(),
            'created_at' => $this->faker->dateTimeThisMonth(),
            'updated_at' => $this->faker->dateTimeThisMonth(),

        ];
    }
}
