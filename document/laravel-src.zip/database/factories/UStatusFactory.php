<?php

namespace Database\Factories;

use App\Models\UReception;
use App\Models\UStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class UStatusFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UStatus::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $statuses = config('constants.status');
        $statusDetails = config('constants.status_detail');

        return [
            'reception_no' => UReception::factory(),
            'status_type' => collect($statuses)->random(),
            'status_detail_type' => collect($statusDetails)->random(),
            'remind_date' => $this->faker->dateTimeThisMonth(),
            'remind_memo' => $this->faker->realText(rand(10,30)),
            'entry_complete_flag' => $this->faker->boolean(),
            'entry_complete_at' => null,
            'entry_complete_user_id' => null,
            'checked_flag' => null,
            'checked_at' => null,
            'checked_user_id' => null,
            'completion_date' => null,
        ];
    }
}
