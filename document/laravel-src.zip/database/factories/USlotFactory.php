<?php

namespace Database\Factories;

use App\Models\USlot;
use App\Models\USchedule;
use Illuminate\Database\Eloquent\Factories\Factory;

class USlotFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = USlot::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'schedule_id' => USchedule::factory(),
            'slot_type' => collect(config('constants.slot'))->random(),
        ];
    }
}
