<?php

namespace Database\Factories;

use App\Models\UManHour;
use Illuminate\Database\Eloquent\Factories\Factory;

class UManHourFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UManHour::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
