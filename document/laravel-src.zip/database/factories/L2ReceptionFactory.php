<?php

namespace Database\Factories;

use App\Models\L2Reception;
use Illuminate\Database\Eloquent\Factories\Factory;

class L2ReceptionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = L2Reception::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'no' => $this->faker->unique(false, 5000)->numberBetween(1,10000),
            'date' => now(),
            'dept_no' => $this->faker->randomDigit(),
            'emp_code' => $this->faker->randomDigit(),
            'client_no' => $this->faker->randomDigit(),
            'client_account_no' => $this->faker->randomDigit(),
            'client_billing_deadline' => $this->faker->numberBetween(1,30),
            'client_name' => $this->faker->company(),
            'client_person_name' => $this->faker->name(),
            'client_address' => $this->faker->address(),
            'client_tel' => $this->faker->phoneNumber(),
            'client_fax' => $this->faker->phoneNumber(),
            'client_mobile_tel' => $this->faker->phoneNumber(),
            'field_name' => $this->faker->city(),
            'field_person_name' => $this->faker->name(),
            'field_address' => $this->faker->address(),
            'field_tel' => $this->faker->phoneNumber(),
            'field_fax' => $this->faker->phoneNumber(),
            'field_mobile_tel' => $this->faker->phoneNumber(),
            'dealer_no' => $this->faker->randomDigit(),
            'dealer_account_no' => $this->faker->randomDigit(),
            'dealer_name' => $this->faker->company(),
            'dealer_person_name' => $this->faker->name(),
            'dealer_tel' => $this->faker->phoneNumber(),
            'dealer_fax' => $this->faker->phoneNumber(),
            'dealer_mobile_tel' => $this->faker->phoneNumber(),
            'title' => $this->faker->realText(rand(10, 20)),
            'content' => $this->faker->realText(rand(10, 50)),
            'visit_date' => $visitDate = now()->addDays($this->faker->numberBetween(1, 30)),
            'visit_time_text' => $visitDate->toDateTimeString(),
            // 'status' => $this->faker,
            // 'response_type' => $this->faker,
            // 'business_type' => $this->faker,
            // 'mainte_check_term' => $this->faker,
            // 'related_pj_no' => $this->faker,
            // 'work_type' => $this->faker,
            'target_order_no' => $this->faker->randomDigit(),
            'person_dept_no' => $this->faker->randomDigit(),
            'person_emp_code' => $this->faker->randomDigit(),
            // 'completion_date' => $this->faker,
            // 'device_type1' => $this->faker,
            // 'device_type2' => $this->faker,
            // 'device_no1' => $this->faker,
            // 'device_no2' => $this->faker,
            // 'delivery_date' => $this->faker,
            // 'repair_work_type' => $this->faker,
            // 'repair_sector_type' => $this->faker,
            // 'repair_point_type' => $this->faker,
            // 'repair_status' => $this->faker,
            'cause' => $this->faker->realText(10),
            'measure' => $this->faker->realText(10),
            'note' => $this->faker->realText(10),
            // 'deleted_flag' => $this->faker,
            'entry_emp_code' => $this->faker->randomDigit(),
            'entry_date_time' => $this->faker->dateTimeThisMonth(),
            'login_emp_code' => $this->faker->randomDigit(),
            'registered_at' => $this->faker->dateTimeThisMonth(),
            'coop_created_at' => $coopCreatedAt = $this->faker->dateTimeThisMonth(),
            'coop_updated_at' => $coopCreatedAt,
        ];
    }
}
