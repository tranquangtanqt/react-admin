<?php

namespace Database\Factories;

use App\Models\USchedule;
use App\Models\UScheduleUser;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class UScheduleUserFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UScheduleUser::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'schedule_id' => USchedule::factory(),
            'user_id' => User::factory(),
        ];
    }
}
