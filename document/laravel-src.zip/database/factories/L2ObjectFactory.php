<?php

namespace Database\Factories;

use App\Models\L2Object;
use Illuminate\Database\Eloquent\Factories\Factory;

class L2ObjectFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = L2Object::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
