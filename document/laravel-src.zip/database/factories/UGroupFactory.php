<?php

namespace Database\Factories;

use App\Models\UGroup;
use App\Models\UReception;
use Illuminate\Database\Eloquent\Factories\Factory;

class UGroupFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UGroup::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'reception_no' => UReception::factory(),
            'name' => $this->faker->word(),
            'delivery_date' => $this->faker->dateTimeThisMonth(),
            'created_at' => $this->faker->dateTimeThisMonth(),
            'updated_at' => $this->faker->dateTimeThisMonth(),
        ];
    }
}
