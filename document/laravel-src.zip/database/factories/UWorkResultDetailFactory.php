<?php

namespace Database\Factories;

use App\Models\UDevice;
use App\Models\USchedule;
use App\Models\UWorkResultDetail;
use Illuminate\Database\Eloquent\Factories\Factory;

class UWorkResultDetailFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UWorkResultDetail::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'schedule_id' => USchedule::factory(),
            'device_id' => UDevice::factory(),
            'work_detail' => $this->faker->word(),
            'created_at' => $this->faker->dateTimeThisMonth(),
            'updated_at' => $this->faker->dateTimeThisMonth(),
        ];
    }
}
