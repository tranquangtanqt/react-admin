<?php

namespace Database\Factories;

use App\Models\L2Reception;
use App\Models\UReception;
use Illuminate\Database\Eloquent\Factories\Factory;

class UReceptionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UReception::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $createdDate = $this->faker->dateTimeThisMonth();
        return [
            'no' => L2Reception::factory(),
            'pjmgr_user_id' => null,
            'display_user_id' => null,
            'related_pjno' => null,
            'created_at' => $createdDate,
            'updated_at' => $createdDate,
        ];
    }
}
