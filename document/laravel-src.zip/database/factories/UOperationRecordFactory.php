<?php

namespace Database\Factories;

use App\Models\UOperationRecord;
use Illuminate\Database\Eloquent\Factories\Factory;

class UOperationRecordFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UOperationRecord::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
