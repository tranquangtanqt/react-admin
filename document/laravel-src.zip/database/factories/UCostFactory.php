<?php

namespace Database\Factories;

use App\Models\UCost;
use App\Models\UReception;
use Illuminate\Database\Eloquent\Factories\Factory;

class UCostFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UCost::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'reception_no' => UReception::factory(),
            'serial_no' => $this->faker->unique()->numberBetween(1, 1000),
            'type' => $this->faker->word(),
            'registered_class' => $this->faker->word(),
            'checked_flag' => $this->faker->boolean(),
            'name' => $this->faker->realText(10),
            'amount' => $this->faker->numberBetween(1000, 10000),
            'created_at' => $this->faker->dateTimeThisMonth(),
            'updated_at' => $this->faker->dateTimeThisMonth(),
        ];
    }
}
