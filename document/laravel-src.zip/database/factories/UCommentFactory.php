<?php

namespace Database\Factories;

use App\Models\UComment;
use App\Models\UReception;
use Illuminate\Database\Eloquent\Factories\Factory;

class UCommentFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UComment::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'reception_no' => UReception::factory(),
            'comment' => $this->faker->realText(rand(10,40)),
        ];
    }
}
