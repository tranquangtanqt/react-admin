<?php

namespace Database\Factories;

use App\Models\UDevice;
use App\Models\UGroup;
use App\Models\UReception;
use Illuminate\Database\Eloquent\Factories\Factory;

class UDeviceFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UDevice::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'reception_no' => UReception::factory(),
            'represent_flag' => 'true',
            'group_id' => UGroup::factory(),
            'device_type' => $this->faker->userName(),
            'device_no' => $this->faker->userName(),
            'created_at' => $this->faker->dateTimeThisMonth(),
            'updated_at' => $this->faker->dateTimeThisMonth(),
        ];
    }
}
