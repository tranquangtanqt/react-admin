<?php

namespace Database\Factories;

use App\Models\UReception;
use App\Models\USchedule;
use Illuminate\Database\Eloquent\Factories\Factory;

class UScheduleFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = USchedule::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'date' => $this->faker->dateTimeBetween('-3 days', '+3 days'),
            'schedule_type' => '1',
            'reception_no' => UReception::factory(),
            'title' => $this->faker->realText(20),
            'content' => $this->faker->realText(20),
        ];
    }
}
