<?php

namespace Database\Factories;

use App\Models\BatchStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class BatchStatusFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = BatchStatus::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $statuses = config('constants.batch');
        return [
            'process_id' => $this->faker->unique()->randomNumber(5),
            'process_name' => $this->faker->realText(rand(10, 50)),
            'process_status' => collect($statuses)->random(),
            'notification' => $this->faker->realText(rand(10, 50)),
            'created_at' => $this->faker->dateTimeThisMonth(),
        ];
    }
}
