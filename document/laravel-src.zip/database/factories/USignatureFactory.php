<?php

namespace Database\Factories;

use App\Models\USchedule;
use App\Models\USignature;
use Illuminate\Database\Eloquent\Factories\Factory;

class USignatureFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = USignature::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'schedule_id' => USchedule::factory(),
            'digital_flag' => 'true',
            'signed_at' => $this->faker->dateTimeThisMonth(),
            'file_id' => '1',
            'created_at' => $this->faker->dateTimeThisMonth(),
            'updated_at' => $this->faker->dateTimeThisMonth(),
        ];
    }
}
