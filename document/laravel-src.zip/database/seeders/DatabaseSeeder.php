<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\UStatus;
use App\Models\UComment;
use App\Models\CodeClass;
use App\Models\USchedule;
use App\Models\UReception;
use App\Models\BatchStatus;
use App\Models\IdentifierCode;
use Illuminate\Database\Seeder;
use App\Models\Auth as UserAUthModel;
use App\Models\SystemSetting;
use App\Models\UDevice;
use App\Models\UGasInInfo;
use App\Models\UGasOutInfo;
use App\Models\USignature;
use App\Models\UWorkResultDetail;
use League\CommonMark\Extension\CommonMark\Node\Inline\Code;
use PDO;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {

        if (config('app.debug') && config('app.env') === 'local') { // デバッグモードかつロカル環境の時
            // 開発用初期化
            $this->devSeed();
        } else {
            // 導入の時の初期化
            $this->prodSeed();
        }
    }

    private function devSeed()
    {
        // ファイル
        $this->createFile('app/public/test.png', '1');

        SystemSetting::factory()->create([
            'id' => 'CoopManHourStop',
            'value' => '0',
        ]);

        USignature::factory()->create();
        UWorkResultDetail::factory()->create();
        UGasInInfo::factory()->create();
        UGasOutInfo::factory()->create();

        // ユーザ作成
        $user0 = User::factory()->create([
            'login_id' => 'const',
            'email' => 'const@const.jp',
        ]);

        $user1 = User::factory()->create([
            'login_id' => 'manager',
            'email' => 'manager@const.jp',
        ]);
        $user2 = User::factory()->create([
            'login_id' => 'field',
            'email' => 'field@const.jp',
        ]);

        $user3 = User::factory()->create([
            'login_id' => 'pic',
            'email' => 'pic@const.jp',
        ]);

        $user4 = User::factory()->create([
            'login_id' => 'pic_ext',
            'email' => 'pic_ext@const.jp',
        ]);

        $user5 = User::factory()->create([
            'login_id' => 'input',
            'email' => 'input@const.jp',
        ]);

        // 権限追加
        $user0->auths()->create([
            'auth_class' => config('constants.auth.system_admin'),
        ]);
        $user1->auths()->create([
            'auth_class' => config('constants.auth.manager'),
        ]);
        $user2->auths()->create([
            'auth_class' => config('constants.auth.field_coordinator'),
        ]);
        $user3->auths()->create([
            'auth_class' => config('constants.auth.pic'),
        ]);
        $user4->auths()->create([
            'auth_class' => config('constants.auth.pic_external'),
        ]);
        $user5->auths()->create([
            'auth_class' => config('constants.auth.input_support'),
        ]);

        // コード区分追加
        $this->generateIdentifierCodes();

        // 受付情報追加
        UReception::factory()->count(5)
            ->has(
                USchedule::factory()
                    ->count(2)
                    ->hasSlots(1)
                    ->hasScheduleUsers(1, [
                        'user_id' => rand(3, 4),
                    ]),
                'schedules'
            )
            ->hasStatus()
            ->hasComments(5)
            ->hasCosts(5)
            ->create();

        // バッチ状態追加
        BatchStatus::factory(4)->create();
    }

    private function createFile($filename, $count)
    {
        for ($i = 0; $i < $count; $i++) {

            $tmp_path = storage_path($filename);
            $fp = fopen($tmp_path, 'rb');
            $bool = true;
            // PDOを使ってデータの挿入
            //$db = DB::connection()->stream_get_wrappers;    // PDOオブジェクト取得
            $db = new PDO('pgsql:host=127.0.0.1;dbname=constmainte;', 'constmainte', 'constcIn26');
            $db->setAttribute($db::ATTR_ERRMODE, $db::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("INSERT INTO files(file,name,thumbnail,title,public_flag) VALUES (?,?,?,?,?)");
            //$stmt->bindParam(1, $id);
            $stmt->bindParam(1, $fp, $db::PARAM_LOB);
            $stmt->bindParam(2, $tmp_path);
            $stmt->bindParam(3, $tmp_path);
            $stmt->bindParam(4, $tmp_path);
            $stmt->bindParam(5, $bool);
            $stmt->execute();
        }
    }

    private function prodSeed()
    {
        // ユーザ作成
        $user0 = User::factory()->create([
            'login_id' => $loginId = 'system01',
            'email' => 'system@mitani-cs.co.jp',
            'password' => $loginId . '@X',
        ]);

        // 権限追加
        $user0->auths()->create([
            'auth_class' => config('constants.auth.system_admin'),
        ]);

        // コード区分作成
        $this->generateIdentifierCodes();

        // システム設定
        SystemSetting::factory()->create([
            'id' => 'CoopManHourStop',
            'value' => '0',
        ]);
    }

    private function generateIdentifierCodes()
    {

        // データ取得
        $identifierCodes = $this->getIndetifierCodeClasses();

        foreach ($identifierCodes as $code) {

            // 識別コードマスタ作成
            $identifierCode = IdentifierCode::create([
                'code' => $code['code'],
                'name' => $code['name'],
                'description' => $code['description'],
            ]);

            // コード区分マスタ作成
            foreach ($code['classes'] as $class) {
                CodeClass::create([
                    'identifier_code' => $identifierCode->code,
                    'key' => $class['key'],
                    'value' => $class['value'],
                    'display_order' => $class['display_order'],
                    'number1' => $class['number1'],
                    'number2' => $class['number2'],
                    'number3' => $class['number3'],
                    'string1' => $class['string1'],
                    'string2' => $class['string2'],
                    'string3' => $class['string3'],
                ]);
            }
        }
    }


    // 識別コード及びコード区分データ取得
    private function getIndetifierCodeClasses()
    {
        return [
            'logs' => [
                'code' => 'X0001',
                'name' => 'ログ処理区分',
                'description' => 'ログに出力する実施処理を表す',
                'classes' => [
                    ['key' => '0', 'value' => 'ログイン', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => 'ログアウト', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '画面起動', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => 'データ登録', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => 'データ更新', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => 'データ削除', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => 'データ入替', 'display_order' => '6', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '7', 'value' => 'ダウンロード', 'display_order' => '7', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '8', 'value' => '内部処理', 'display_order' => '8', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9', 'value' => 'APIアクセス', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '10', 'value' => '連携処理', 'display_order' => '10', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],

                ],
            ],
            'coop' => [
                'code' => 'X0002',
                'name' =>    '連携区分',
                'description' => '連携の状態を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => '未連携', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '連携済', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '連携スキップ', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '連携対象', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '8', 'value' => '連携中止', 'display_order' => '8', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9', 'value' => '対象外', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'batch' => [
                'code' => 'X0003',
                'name' =>    'バッチ処理状態',
                'description' => 'バッチ処理の状態を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => '未処理', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '処理中', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '正常終了(データなし)', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '正常終了', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9', 'value' => '異常終了', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'password' => [
                'code' => 'X0004',
                'name' =>    'パスワードポリシー',
                'description' => 'パスワードポリシーを表す。値は設定名称。数値１は設定値。文字１は設定の説明。数値１以外は変更不可。追加削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => 'パスワード更新期限', 'display_order' => '0', 'number1' => '0', 'number2' => null, 'number3' => null, 'string1' => 'パスワード更新期限日数を数値１に設定　無制限の場合は0を設定', 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '最低文字数', 'display_order' => '1', 'number1' => '8', 'number2' => null, 'number3' => null, 'string1' => '最低文字数を数値１に設定', 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '大文字小文字混在強制', 'display_order' => '2', 'number1' => '0', 'number2' => null, 'number3' => null, 'string1' => '有効：数値１に1を設定、無効：数値１に0を設定', 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '英字強制', 'display_order' => '3', 'number1' => '0', 'number2' => null, 'number3' => null, 'string1' => '有効：数値１に1を設定、無効：数値１に0を設定', 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '数字強制', 'display_order' => '4', 'number1' => '1', 'number2' => null, 'number3' => null, 'string1' => '有効：数値１に1を設定、無効：数値１に0を設定', 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => '記号強制', 'display_order' => '5', 'number1' => '0', 'number2' => null, 'number3' => null, 'string1' => '有効：数値１に1を設定、無効：数値１に0を設定', 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => '前回不一致', 'display_order' => '6', 'number1' => '1', 'number2' => null, 'number3' => null, 'string1' => '有効：数値１に1を設定、無効：数値１に0を設定', 'string2' => null, 'string3' => null,],
                    ['key' => '9', 'value' => 'パスワード再設定URL有効期限', 'display_order' => '9', 'number1' => '1', 'number2' => null, 'number3' => null, 'string1' => 'パスワード再設定URLの有効期限を時間で指定します。', 'string2' => null, 'string3' => null,],
                ],
            ],
            'api_key' => [
                'code' => 'X0005',
                'name' =>    'APIキー',
                'description' => '各APIごとのAPIキーを設定する。値はAPI名称。文字１はAPIキー。',
                'classes' => [
                    ['key' => 'coopreception', 'value' => '受付情報連携', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => substr(str_shuffle(str_repeat('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz0123456789', 3)), 0, 32), 'string2' => null, 'string3' => null,],
                    ['key' => 'coopobject', 'value' => '物件情報連携', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => substr(str_shuffle(str_repeat('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz0123456789', 3)), 0, 32), 'string2' => null, 'string3' => null,],
                    ['key' => 'coopaccountyearmonth', 'value' => '会計年月情報連携', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => substr(str_shuffle(str_repeat('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz0123456789', 3)), 0, 32), 'string2' => null, 'string3' => null,],
                ],
            ],
            'slot' => [
                'code' => 'U0001',
                'name' =>    '時間帯区分',
                'description' => '時間帯を表す。値は時間帯の表示名、数値１は開始時間、数値２は終了時間、文字１は受付の表示色。文字１以外は変更不可。追加削除不可。',
                'classes' => [
                    ['key' => '1', 'value' => '早朝', 'display_order' => '1', 'number1' => '500', 'number2' => '830', 'number3' => null, 'string1' => '004EFF', 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => 'ＡＭ１', 'display_order' => '2', 'number1' => '830', 'number2' => '1030', 'number3' => null, 'string1' => '32C5FF', 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => 'ＡＭ２', 'display_order' => '3', 'number1' => '1030', 'number2' => '1200', 'number3' => null, 'string1' => 'FFFF00', 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => 'ＰＭ１', 'display_order' => '4', 'number1' => '1300', 'number2' => '1500', 'number3' => null, 'string1' => 'F7B500', 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => 'ＰＭ２', 'display_order' => '5', 'number1' => '1500', 'number2' => '1700', 'number3' => null, 'string1' => 'FA6400', 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => '夜間', 'display_order' => '6', 'number1' => '1700', 'number2' => '2400', 'number3' => null, 'string1' => 'B620E0', 'string2' => null, 'string3' => null,],
                ],
            ],
            'reception_display' => [
                'code' => 'U0002',
                'name' =>    '受付検索表示区分',
                'description' => '受付検索の表示設定。数値１は受付経過日数、文字１は受付の表示色。数値１、文字１以外は変更不可。追加削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => '完了', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'C0C0C0', 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '日数経過１', 'display_order' => '1', 'number1' => '90', 'number2' => null, 'number3' => null, 'string1' => 'FFFF7F', 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '日数経過２', 'display_order' => '2', 'number1' => '180', 'number2' => null, 'number3' => null, 'string1' => 'FF7F7F', 'string2' => null, 'string3' => null,],
                ],
            ],
            'status' => [
                'code' => 'U0003',
                'name' =>    '状態区分',
                'description' => '受付の状態を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => '新規受付', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '訪問予定', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '訪問済', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '保留', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '作業完了', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => 'チェック済', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => '受付完了', 'display_order' => '6', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'status_detail' => [
                'code' => 'U0004',
                'name' =>    '状態詳細区分',
                'description' => '受付の状態の詳細を表す。（保留時の詳細）追加修正削除不可。',
                'classes' => [
                    ['key' => '1', 'value' => '見積保留', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '見積保留', 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '日程調整（お客様要因）', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '日程調整客', 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '日程調整（自社要因）', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '日程調整社', 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '様子見', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '様子見', 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => '部品待ち', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '部品待ち', 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => '中間期', 'display_order' => '6', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '中間期', 'string2' => null, 'string3' => null,],
                    ['key' => '7', 'value' => 'メーカー対応', 'display_order' => '7', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'メーカー', 'string2' => null, 'string3' => null,],
                    ['key' => '8', 'value' => '定期点検', 'display_order' => '8', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '定期点検', 'string2' => null, 'string3' => null,],
                ],
            ],
            'payment' => [
                'code' => 'U0005',
                'name' =>    '有償無償区分',
                'description' => '有償・無償の選択を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => '未設定', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '有償', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '無償', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'ky' => [
                'code' => 'U0006',
                'name' =>    'ＫＹポイント区分',
                'description' => 'ＫＹポイントを表す。値は画面表示。削除不可。値を変更した場合、これまでに登録した値も表示が変わる。',
                'classes' => [
                    ['key' => '0', 'value' => '未設定', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '火気', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '梯子', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '脚立', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '楊重', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => '感電', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'work' => [
                'code' => 'U0007',
                'name' =>    '作業区分',
                'description' => '作業区分を表す。値は画面表示。削除不可。値を変更した場合、これまでに登録した値も表示が変わる。',
                'classes' => [
                    ['key' => '0', 'value' => '未設定', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '一般', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => 'オーバーホール', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '保守', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '更新', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => '物品', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'auth' => [
                'code' => 'U0008',
                'name' =>    '権限区分',
                'description' => '権限を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => 'システム管理者', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '業務責任者', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '現場調整担当', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '担当', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '担当（協力会社）', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => '入力支援', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'cost' => [
                'code' => 'U0009',
                'name' =>    '原価種類区分',
                'description' => '原価種類を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '1', 'value' => '材料', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '工事', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'fill' => [
                'code' => 'U0010',
                'name' =>    '充塡区分',
                'description' => '充塡の区分を表す。値は画面表示。値を変更した場合、これまでに登録した値も表示が変わる。削除した場合、選択肢に表示されない。',
                'classes' => [
                    ['key' => '1', 'value' => '設置', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '設置以外', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'collect' => [
                'code' => 'U0011',
                'name' =>    '回収区分',
                'description' => '回収の区分を表す。値は画面表示。値を変更した場合、これまでに登録した値も表示が変わる。削除した場合、選択肢に表示されない。',
                'classes' => [
                    ['key' => '1', 'value' => '整備', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '破棄等', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'fill_type' => [
                'code' => 'U0012',
                'name' =>    '充塡種類区分',
                'description' => '充塡の種類を表す。値は画面表示、数値１は単価。値を変更した場合、これまでに登録した値も表示が変わる。数値１は変更後の原価計算結果が変わる。キー0はその他で変更不可。削除した場合、選択肢に表示されない。',
                'classes' => [
                    ['key' => '0', 'value' => 'その他', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => 'R410A', 'display_order' => '1', 'number1' => '1350', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => 'R407C', 'display_order' => '2', 'number1' => '1550', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => 'R22', 'display_order' => '3', 'number1' => '1550', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => 'R32', 'display_order' => '4', 'number1' => '2100', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'collect_type' => [
                'code' => 'U0013',
                'name' =>    '回収種類区分',
                'description' => '回収の種類を表す。値は画面表示、数値１は単価。値を変更した場合、これまでに登録した値も表示が変わる。数値１は変更後の原価計算結果が変わる。キー0はその他で変更不可。削除した場合、選択肢に表示されない。',
                'classes' => [
                    ['key' => '0', 'value' => 'その他', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => 'R410A', 'display_order' => '1', 'number1' => '700', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => 'R407C', 'display_order' => '2', 'number1' => '700', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => 'R22', 'display_order' => '3', 'number1' => '700', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => 'R32', 'display_order' => '4', 'number1' => '700', 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'cost_register' => [
                'code' => 'U0014',
                'name' =>    '原価登録区分',
                'description' => '原価の登録起因を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '0', 'value' => '手入力', 'display_order' => '0', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1', 'value' => '充塡情報', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '回収情報', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'material' => [
                'code' => 'U0015',
                'name' =>    '材料原価名称雛形',
                'description' => '材料原価の入力雛形を表す。追加修正削除可能。値は雛形。',
                'classes' => [
                    ['key' => '1', 'value' => 'CNB', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => 'ダイキン', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'construction_cost' => [
                'code' => 'U0016',
                'name' =>    '工事原価名称雛形',
                'description' => '工事原価の入力雛形を表す。追加修正削除可能。値は雛形。',
                'classes' => [
                    ['key' => '1', 'value' => 'イサオ空調', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '大沢空調', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => 'セトサービス', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => 'ヤマモトシステムサービス', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => 'エアーネクト', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'quotation' => [
                'code' => 'U0017',
                'name' =>    '見積単位雛形',
                'description' => '見積の単位の入力雛形を表す。追加修正削除可能。値は雛形。キーが1の値を初期値とする。',
                'classes' => [
                    ['key' => '1', 'value' => '式', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '個', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => 'Kg', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => 'L', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],

                ],
            ],
            'quotation_work' => [
                'code' => 'U0018',
                'name' =>    '見積作業名・品名雛形',
                'description' => '見積の作業名・品名の入力雛形を表す。追加修正削除可能。値は雛形。キーが1の値を初期値とする。',
                'classes' => [
                    ['key' => '1', 'value' => '見積作業一式', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '点検作業', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '点検修理作業', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '重量運搬費', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => '技術サービス費', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => '作業足場一式', 'display_order' => '6', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '7', 'value' => '冷媒フロン回収処理費', 'display_order' => '7', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '8', 'value' => '出向諸経費', 'display_order' => '8', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9', 'value' => '冷媒ガス充塡', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '10', 'value' => '材料費', 'display_order' => '10', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'work_content' => [
                'code' => 'U0019',
                'name' =>    '作業内容雛形',
                'description' => '作業内容の入力雛形を表す。追加修正削除可能。文字１は雛形。',
                'classes' => [
                    ['key' => '1', 'value' => null, 'display_order' => '01', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '室内機熱交換器よりガス漏れ有り。', 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => null, 'display_order' => '02', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'INV圧縮機絶縁不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => null, 'display_order' => '03', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'STD圧縮機絶縁不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => null, 'display_order' => '04', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'INV圧縮機起動不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => null, 'display_order' => '05', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'STD圧縮機起動不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => null, 'display_order' => '06', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '室内ファンモータ異音・振動有り。', 'string2' => null, 'string3' => null,],
                    ['key' => '7', 'value' => null, 'display_order' => '07', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '室外ファンモータ異音・振動有り。', 'string2' => null, 'string3' => null,],
                    ['key' => '8', 'value' => null, 'display_order' => '08', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '冷媒ガスの不足。ガス漏れ有り。', 'string2' => null, 'string3' => null,],
                    ['key' => '9', 'value' => null, 'display_order' => '09', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '室外基板不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '10', 'value' => null, 'display_order' => '10', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '室内基板不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '11', 'value' => null, 'display_order' => '11', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '室外ファンモータ不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '12', 'value' => null, 'display_order' => '12', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '室外ファンモータ・基板不良。', 'string2' => null, 'string3' => null,],
                    ['key' => '13', 'value' => null, 'display_order' => '13', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'ドレンパン・ドレン配管汚れ及び目詰まり有り。', 'string2' => null, 'string3' => null,],
                    ['key' => '14', 'value' => null, 'display_order' => '14', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '更新工事・試運転完了。', 'string2' => null, 'string3' => null,],
                    ['key' => '15', 'value' => null, 'display_order' => '15', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '部品交換が必要。', 'string2' => null, 'string3' => null,],
                    ['key' => '16', 'value' => null, 'display_order' => '16', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '修理・試運転完了。', 'string2' => null, 'string3' => null,],
                    ['key' => '17', 'value' => null, 'display_order' => '17', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '冷媒ガス回収完了。', 'string2' => null, 'string3' => null,],
                    ['key' => '18', 'value' => null, 'display_order' => '18', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'ガス漏れ検査が必要。', 'string2' => null, 'string3' => null,],
                    ['key' => '19', 'value' => null, 'display_order' => '19', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '経過観察要。', 'string2' => null, 'string3' => null,],
                    ['key' => '20', 'value' => null, 'display_order' => '20', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'ドレンパン・ドレン配管の清掃が必要。', 'string2' => null, 'string3' => null,],
                    ['key' => '21', 'value' => null, 'display_order' => '21', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => '清掃完了。', 'string2' => null, 'string3' => null,],
                ],
            ],

            'url' => [
                'code' => 'U0020',
                'name' =>    'URL',
                'description' => 'URLを表す。値は設定名称。文字１にURLを設定。追加削除不可。',
                'classes' => [
                    ['key' => 'qrcode', 'value' => 'QRコードのURL', 'display_order' => 'qrcode', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => 'https://www.mitani-cs.co.jp/rakuda/', 'string2' => null, 'string3' => null,],
                ],
            ],

            'pe_schedule' => [
                'code' => 'G0001',
                'name' =>    'PE予定区分',
                'description' => 'POWEREGGに連携する予定区分を表す。POWEREGGに合わせた設定が必要。',
                'classes' => [
                    ['key' => '1', 'value' => '執務', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2', 'value' => '打合せ', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '3', 'value' => '会議', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '4', 'value' => '来客', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '5', 'value' => '休憩', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '6', 'value' => '将来投資', 'display_order' => '6', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '7', 'value' => '訪問', 'display_order' => '7', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '8', 'value' => '研修', 'display_order' => '8', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9', 'value' => '現場業務', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '25', 'value' => 'Teams会議', 'display_order' => '10', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '24', 'value' => 'テレワーク', 'display_order' => '11', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '10', 'value' => '出張', 'display_order' => '12', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '11', 'value' => '顧客と同行', 'display_order' => '13', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '12', 'value' => '接待', 'display_order' => '14', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '13', 'value' => '休暇', 'display_order' => '15', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '14', 'value' => 'その他', 'display_order' => '16', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'l2_material' => [
                'code' => 'G0002',
                'name' =>    'L2建材作業区分',
                'description' => 'L2に連携する工数の建材作業区分を表す。追加修正削除不可。',
                'classes' => [
                    ['key' => '1001', 'value' => '施工', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9001', 'value' => 'その他', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2001', 'value' => '営業活動', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'l2_material_type' => [
                'code' => 'G0003',
                'name' =>    'L2建材作業分類区分',
                'description' => 'L2に連携する工数の建材作業分類区分を表す。L2に合わせた設定が必要。',
                'classes' => [
                    ['key' => '1101', 'value' => '現場指示', 'display_order' => '1', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1102', 'value' => '施工図作成', 'display_order' => '2', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1103', 'value' => '書類作成', 'display_order' => '3', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1104', 'value' => '検査等立会', 'display_order' => '4', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1105', 'value' => '定例打合せ出席', 'display_order' => '5', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1106', 'value' => '修理作業', 'display_order' => '6', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1107', 'value' => '保守立会・指示', 'display_order' => '7', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1108', 'value' => '修理作業指示', 'display_order' => '8', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1109', 'value' => '取扱説明', 'display_order' => '9', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1110', 'value' => '冷媒回収', 'display_order' => '10', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1111', 'value' => '試運転調整・データ測定', 'display_order' => '11', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2101', 'value' => '現場調査', 'display_order' => '12', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2102', 'value' => '無償及び是正工事立会', 'display_order' => '13', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2103', 'value' => '商談打合せ同行', 'display_order' => '14', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2201', 'value' => '無償修理', 'display_order' => '15', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2202', 'value' => '現場調査', 'display_order' => '16', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2203', 'value' => '丸ごと診断', 'display_order' => '17', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2204', 'value' => '見積り作成', 'display_order' => '18', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2205', 'value' => '点検表作成', 'display_order' => '19', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2206', 'value' => '作業完了書作成', 'display_order' => '20', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2301', 'value' => '修理作業', 'display_order' => '21', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2302', 'value' => '現場調査', 'display_order' => '22', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2303', 'value' => '現況説明', 'display_order' => '23', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9101', 'value' => '受注前検討会', 'display_order' => '24', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9102', 'value' => '受注引継会', 'display_order' => '25', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9103', 'value' => '原価検討会', 'display_order' => '26', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9104', 'value' => '施工前検討会', 'display_order' => '27', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9105', 'value' => '安全・品質PT', 'display_order' => '28', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '9106', 'value' => '部・課定例会議', 'display_order' => '29', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '1112', 'value' => '施工業者手配', 'display_order' => '30', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                    ['key' => '2104', 'value' => '無償定期検査立会い', 'display_order' => '31', 'number1' => null, 'number2' => null, 'number3' => null, 'string1' => null, 'string2' => null, 'string3' => null,],
                ],
            ],
            'l2_material_detail' => [
                'code' => 'G0004',
                'name' =>    'L2建材作業詳細区分',
                'description' => 'L2に連携する工数のL2建材作業詳細区分を表す。L2に合わせた設定が必要。', 'classes' => [],
            ],
        ];
    }
}
