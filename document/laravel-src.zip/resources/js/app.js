require("./bootstrap");
require("./customs/commons");
require("./customs/U0300/set-schedule");
require("./customs/U0200/set-project-manager");
require("./customs/U0200/set-status");
require("./customs/U0100/schedule-weekly");

// jquery-ui日付デフォルト設定
$.datepicker.setDefaults({
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    beforeShow: function (input, inst) {
        setDatepickerPos(input, inst);
    },
    onClose: function () {
        $(this).trigger("focus");

        // 日付フォーマット(YYYY/MM/DD)
        const dateString = this.value;

        // 有効な日付の場合のみ自動フォーマットを実行する
        if (isValidDate(dateString)) {
            const year = dateString.substring(0, 4);
            const month = dateString.substring(4, 6);
            const day = dateString.substring(6, 8);
            const delimiter = "/";
            this.value = year + delimiter + month + delimiter + day;
        }
    },
    showOtherMonths: true,
    selectOtherMonths: true,
});

// 日付選択画面表示位置設定
function setDatepickerPos(input, inst) {
    var rect = input.getBoundingClientRect();
    setTimeout(function () {
        var scrollTop = $("body").scrollTop();
        inst.dpDiv.css({ top: rect.top + input.offsetHeight + scrollTop });
    }, 0);
}

/**
 * 有効な日付のチェック
 *
 * @param {string} dateString 8桁の数値
 *
 * @returns {boolean}
 */
function isValidDate(dateString) {
    // 8桁の数値のみ
    if (dateString.length !== 8 || isNaN(dateString)) {
        return false;
    }

    // 日付をParseする
    const year = dateString.substring(0, 4);
    const month = dateString.substring(4, 6);
    const day = dateString.substring(6, 8);

    // 年と月のチェック
    if (year < 1000 || year > 3000 || month <= 0 || month > 12) {
        return false;
    }

    // 月の日数
    var monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    // Adjust for leap years
    if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) {
        monthLength[1] = 29;
    }

    // 日付チェック
    return day > 0 && day <= monthLength[month - 1];
}
