// HTMLDOMのチェック
window.isDOM = (el) => el instanceof Element;

// エラー出力
window.outputErrors = function (errorIdPrefix, errorResponse) {
    // エラーメッセージをモーダり表示
    for (const key in errorResponse) {
        let $errors = "";
        errorResponse[key]?.forEach((msg) => {
            $errors += `<div>${msg}</div>`;
        });
        $(`#${errorIdPrefix}_${key}_error`)
            .html($errors)
            .parent("div")
            .removeClass("d-none");
    }
};

// エラークリア
window.hideErrors = function (errorIdPrefix) {
    $(`div[id^=${errorIdPrefix}][id$=_error`)
        .html("")
        .parent("div")
        .addClass("d-none");
};

// モーダルからフォームをサブミットするための通知を起動
window.confirmSubmitFromModal = function (
    event,
    message,
    originModalId,
    formId,
    confirmModalId = "confirmation-modal"
) {
    event.preventDefault();
    event.stopPropagation();
    $modal = $(`#${confirmModalId}`);
    $modal.find("[data-role=message]").html(message);
    $modal
        .find("[data-role=confirm]")
        .removeAttr("onclick")
        .click(() => {
            $(`#${formId}`).trigger("submit");
        });
    $(`#${originModalId}`).modal("hide");
    $modal.modal("show");
};


// AJAXタイムアウト 「0」の場合タイムアウトなし
window.ajaxTimeout = 0;
