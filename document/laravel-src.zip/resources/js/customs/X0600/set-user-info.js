var fileInput = document.getElementById("file");
var deleteImg = document.getElementById("deleteImg");

window.onload = function () {
    $("#save").prop("disabled", true);
};

// Change file event
fileInput.addEventListener("change", function () {
    jQuery("#alert").html("");
    jQuery("strong").html("");
    const [fileData] = file.files;
    const validImageTypes = ["gif", "png", "jpg", "jpeg"];

    if (fileData == undefined) {
        userImg.src = "/storage/default/user_profile.jpg";
    }

    if (fileData) {
        let extension = fileData.name.split(".").pop();
        // Check existed file choisen is a image
        if (!validImageTypes.includes(extension)) {
            jQuery("#alert").html("拡張子はjpg、jpeg、png、gifのみ登録可能です。");
            $("#save").prop("disabled", true);
        } else {
            userImg.src = URL.createObjectURL(fileData);
            $("#save").prop("disabled", false);
        }
    }
});

// Delete photo profile
deleteImg.addEventListener("click", function () {
    jQuery("#confirm-delete").modal("show");
});

window.confirmDelete = function () {
    jQuery("#confirm-delete").modal("hide");
    $.ajax({
        url: "/set-user-info/delete",
        type: "DELETE",
        data: {
            _token: $('input[name="_token"]').val(),
        },
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        success: function (res) {
            window.location.reload();
        },
        error: function () {
            $("#loading").addClass("d-none");
        },
    });
};
