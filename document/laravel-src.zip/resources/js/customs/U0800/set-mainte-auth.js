$(function () {
    $('#u0802-submit').on('click', '.submit-btn', function () {
        $("#loading").removeClass("d-none");
        $("#frm-auth").submit();
    });
});


$(function () {
    $('input[type="checkbox"]').on('change', function () {
        if ($(this).attr('id') == 'checkbox-4') {
            // 担当（協力会社）
            // チェックされた場合は他のチェックを外す
            if ($(this).prop('checked')) {
                $('input[type="checkbox"]').prop('checked', false);
                $(this).prop('checked', true);
            }
        } else {
            // 担当（協力会社）以外
            // チェックされた場合は担当（協力会社）のチェックを外す
            if ($(this).prop('checked')) {
                $('#checkbox-4').prop('checked', false);
            }
        }
    });
});