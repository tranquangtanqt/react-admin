var u0801_openModal = document.getElementsByClassName('u0801-open-modal');
for (var i = 0; i < u0801_openModal.length; i++) {
    u0801_openModal[i].addEventListener("click", function(event) {
        var a = this.getAttribute("u0801-data-id");
        document.getElementById("u0801-id").value = a;
    });
}

var u0801_buttonOk = document.getElementById("u0801-ok");
u0801_buttonOk.addEventListener("click", function(event) {
    document.getElementById("loading").classList.remove("d-none");
    var id = document.getElementById("u0801-id").value;
    document.getElementById("u0801-frm-" + id).submit();
});
