$(function() {
    $('#choose-identifier-code').on('click', '.submit-btn', function(){
        $("#loading").removeClass("d-none");
        let code = $('#code').val();
        if(code){
            window.location.href = "/mainte-code-class/show-identifier/" + code;
        }
    });

    $('#u0803-ok').on('click', function(){
        $("#loading").removeClass("d-none");
        let id = $("#u0803-id").val();
        $("#u0803-frm-" + id).submit();
    });

    $('.u0803-open-modal').on('click', function(){
        let id = $(this).attr('u0803-data-id');
        $('#u0803-id').val(id);
    });

    $("#u0803-submit").on("click", ".submit-btn", function(){
        $("#loading").removeClass("d-none");
        $("#u0803-frm").submit();
    });
});
