$(function() {
    $('#u0801-submit').on('click', '.submit-btn', function(){
        $("#loading").removeClass("d-none");
        $("#frm-mainte-user").submit();
    });
});
