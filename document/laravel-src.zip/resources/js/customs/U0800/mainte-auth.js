var u0802_openModal = document.getElementsByClassName('u0802-open-modal');
for (let i = 0; i < u0802_openModal.length; i++) {
    u0802_openModal[i].addEventListener("click", function(event) {
        let id = this.getAttribute("u0802-data-id");
        document.getElementById("u0802-id").value = id;
    });
}

var u0802_buttonOk = document.getElementById("u0802-ok");
u0802_buttonOk.addEventListener("click", function(event) {
    document.getElementById("loading").classList.remove("d-none");
    let id = document.getElementById("u0802-id").value;
    document.getElementById("u0802-frm-" + id).submit();
});
