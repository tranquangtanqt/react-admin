// 受付のモーダルのAJAX
window.fetchSetProjectManagerModal = function (element) {
    if (!element || !isDOM(element)) {
        throw "The argument should be specified and should be an html element with 'data-target-route' attribute.";
    }

    $.ajax({
        url: element.dataset.targetRoute,
        dataType: "html",
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            modalId = "set-project-manager-modal";
            $(`#js-${modalId}`).html(result);
            $(`#${modalId}`).modal("show");
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            alert("受付担当者設定画面起動に失敗しました。再度試してください。");
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

window.submitSetProjectManager = function (event, element) {
    event.preventDefault();
    event.stopPropagation();

    if (!element || !isDOM(element)) {
        throw "The argument should be specified and should be an html element with 'data-target-route' attribute.";
    }
    const data = $(element).serializeArray(); // フォームのデータ
    const url = $(element).prop("action"); // url取得

    $.ajax({
        url: url,
        method: "POST",
        dataType: "json",
        data: data,
        beforeSend: function () {
            $("div[id$=-user-id-error").html("").addClass("d-none");
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            location.reload(true);
        },
        error: function (jqXHR, testStatus, error) {
            const errorResponse = JSON.parse(jqXHR.responseText);

            // エラーメッセージをモーダり表示
            for (const key in errorResponse) {
                $(`#set-pjmgr-${key}-error`)
                    .html(errorResponse[key])
                    .removeClass("d-none");
            }
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};
