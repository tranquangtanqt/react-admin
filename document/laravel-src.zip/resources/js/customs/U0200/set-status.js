const { update } = require("lodash");

// 受付のモーダルのAJAX
window.fetchSetStatusModal = function (element) {
    if (!element || !isDOM(element)) {
        throw "The argument should be specified and should be an html element with 'data-target-route' attribute.";
    }

    $.ajax({
        url: element.dataset.targetRoute,
        dataType: "html",
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            modalId = "set-status-modal";
            $(`#js-${modalId}`).html(result);
            $(`#${modalId}`).modal("show");

            $("input[role=datepicker]").datepicker({
                minDate: 0,
            });
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            alert("受付状態設定画面起動に失敗しました。再度試してください。");
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// 状態変更を確定する時
window.submitSetStatus = function (
    event,
    element,
    currentWillVisit, // 現在の受付状態が訪問予定か
    workDoneStatus = "4" // 作業完了固定値
) {
    if (!element || !isDOM(element)) {
        throw "The argument should be specified and should be an html element with 'action' attribute.";
    }

    event.preventDefault();
    event.stopPropagation();

    const newStatus = $("#set-status-status-type").val();
    const shouldConfirm = currentWillVisit && newStatus == workDoneStatus; // 現在の受付状態が訪問予定かつ訪問予定から作業完了に変更する

    const confirmMessage =
        "受付をキャンセルします。\n作業完了していない訪問予定があり、予定を削除します。\n作業実績（工数、署名）が登録されている場合、その情報も削除されます。\n受付状態を変更してよろしいですか。";

    //　確認メッセージ
    if (shouldConfirm){
        if ($(element).find('[name=cancel]').prop('checked')) {
            // 受付キャンセルにチェックあり
            if (!confirm(confirmMessage)) {
                return;
            }
        } else {
            // 受付キャンセルにチェックなし
            alert('作業完了していない訪問予定があるため、変更出来ません。');
            return;
        }
    }

    const data = $(element).serializeArray(); // フォームのデータ
    const url = $(element).prop("action"); // url取得
    const errorIdPrefix = "set_status";

    $.ajax({
        url: url,
        method: "POST",
        dataType: "json",
        data: data,
        beforeSend: function () {
            hideErrors(errorIdPrefix);
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            location.reload(true);
        },
        error: function (jqXHR, testStatus, error) {
            const errorResponse = JSON.parse(jqXHR.responseText);

            outputErrors(errorIdPrefix, errorResponse); // エラー表示

            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

window.restoreStatus = function (element) {
    if (!element || !isDOM(element)) {
        throw "The argument should be specified and should be an html element with 'data-target-route' attribute.";
    }

    if (!confirm("状態を引き戻します。よろしいですか。")) {
        return;
    }

    const errorIdPrefix = "set_status";
    const url = element.dataset.targetRoute;
    const updatedAt = element.dataset.updatedAt;

    $.ajax({
        url: url,
        type: "POST",
        dataType: "json",
        data: {
            _method: "PATCH",
            _token: $("input[name=_token").val(),
            updated_at: updatedAt,
        },
        beforeSend: function () {
            hideErrors(errorIdPrefix);
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            location.reload(true);
        },
        error: function (jqXHR, testStatus, error) {
            const errorResponse = JSON.parse(jqXHR.responseText);

            outputErrors(errorIdPrefix, errorResponse);

            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};
