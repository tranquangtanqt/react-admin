require("lightbox2/dist/js/lightbox-plus-jquery.min.js");

// 画面タイプ 1=ImageList  2=Info
var u0208_type;
if ($('#u0208-show-error').length) { u0208_type = 1 } else { u0208_type = 2 }
var fileInput = document.getElementById("u0208-file");

window.fncU0208SelectFile = function () {
    fncU0208ClearError();
    if (u0208_type == 1) {
        $('#u0208-show-error').addClass('d-none');
        if ($('#u0208-show-success')) {
            $('#u0208-show-success').addClass('d-none');
        }

        if ($('#u0208-show-error-server')) {
            $('#u0208-show-error-server').addClass('d-none');
        }
    }

    fileInput.click();
}
// エラーメッセージクリア
window.fncU0208ClearError = function () {
    if (u0208_type == 1) {
        $('#u0208-show-error').addClass('d-none');
    } else {
        $('#photoValidError').text('');
    }
}
// エラーメッセージセット
window.fncU0208SetError = function (strMsg) {
    if (u0208_type == 1) {
        $('#u0208-show-error').removeClass('d-none');
        $('#u0208-show-error').text(strMsg);
    } else {
        $('#photoValidError').text(strMsg);
    }
    fileInput.value = ""; // ファイル選択クリア
}

// ファイル選択後処理

fileInput.addEventListener("change", function (event) {
    $("#loading").removeClass("d-none");

    var fullPath = this.value;
    if (fullPath) {
        var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
        var filename = fullPath.substring(startIndex);
        if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            filename = filename.substring(1);
        }
        if (filename != '') {
            let fileExtension = filename.split('.').pop();
            let extension = ['jpg', 'jpeg', 'png', 'gif'];
            let size = document.getElementById("u0208-max-file-size-value").value;
            let sizeMB = size * 1048567;
            if (!extension.includes(fileExtension.toLowerCase())) {
                fncU0208SetError("拡張子はjpg、jpeg、png、gifのみ登録可能です。");
                $("#loading").addClass("d-none");
            } else {
                if (fileInput.files[0].size == 0) {
                    fncU0208SetError("ファイルサイズが0バイトのファイルはアップロードできません。");
                    $("#loading").addClass("d-none");
                } else if (fileInput.files[0].size >= sizeMB) {
                    let strErr = "アップロードファイルの上限を超えるため、登録できません。（最大" + size + "MB）";
                    fncU0208SetError(strErr);
                    $("#loading").addClass("d-none");
                } else {
                    document.getElementById('u0208-frm-photo').submit();
                }
            }
        }
    }
});

if (u0208_type == 1) {
    // ImageList用
    var openModal = document.getElementsByClassName('open-modal');
    for (var i = 0; i < openModal.length; i++) {
        openModal[i].addEventListener("click", function (event) {
            var a = this.getAttribute("data-id");
            document.getElementById("photo-id").value = a;
        });
    }

    var buttonOk = document.getElementById("ok");
    buttonOk.addEventListener("click", function (event) {
        var id = document.getElementById("photo-id").value;
        document.getElementById("frm" + id).submit();
    });
}
