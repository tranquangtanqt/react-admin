window.onload=function(){
    $('#u0206-submit .submit-btn').click(function(){
        postForm();
    })
    removeGroupData();
    //系統設定を追加する
    $("#addGroup").click(function(){
        $('#formGroups').append(` <div class="d-flex mb-2 align-items-baseline group-data" count="${parseInt($('.group-data').last().attr('count'))+1}">
                                    <div class="d-flex flex-column w-100 me-2">
                                            <input type="text" class="form-control nameGroup" maxlength="20" style="min-width:200px" nameType="${parseInt($('.group-data').last().attr('count'))+1}"
                                                name="nameNew[${parseInt($('.group-data').last().attr('count'))+1}]" autofocus>
                                                <div class='invalid-feedback d-block'></div>
                                    </div>
                                    <div class="d-flex align-items-baseline dateGroup">
                                        <div class="d-flex flex-column">
                                            <input type="text" role="datepicker" autocomplete="off" placeholder="YYYY/MM/DD" deliveryDateNew="${parseInt($('.group-data').last().attr('count'))+1}" name="deliveryDateNew[${parseInt($('.group-data').last().attr('count'))+1}]"
                                                value="${$('#deliveryDate').val()}" class="picker form-control datepicker me-2">
                                                <div class='invalid-feedback d-block'></div>
                                            </div>
                                        <i class="bi bi-trash-fill removeGroup btn" isNew="true" title="系統を削除する"></i>
                                    </div>
                                </div>
                                `);
        removeGroupData();
        $("input[role=datepicker]").datepicker();
    });
}
var idDelete=[];
window.removeGroupData=function (){
    //系統設定を削除する
    $('.removeGroup').click(function(){
        let removeTag=this;
        if($(this).attr("isNew")=="false"){
            $('#btnShowModal').click();
            $('#okClick').click(function(){
                $('#closeModal').click();
                if($(removeTag).parent().parent().children().children().attr('idgroup')!=null)
                    idDelete.push($(removeTag).parent().parent().children().children().attr('idgroup'));
                $(removeTag).parent().parent().remove();
            })
        }else{
            $(removeTag).parent().parent().remove();
        }
    });
}

window.unique=function (arr) {
return Array.from(new Set(arr))
}
window.postForm=function (){
    $("#loading").removeClass("d-none");
    $('#deleteData').val(unique(idDelete));
    if(parseInt($('.group-data').last().attr('count'))+1!=0){
        $.ajax({
            url: '/set-group/store',
            data: $("#formPostGroup").serialize(),
            method: 'POST',
            beforeSend: function () {
                $("#loading").removeClass("d-none");
            },
            success: function(data){
                window.location.href = `/receptions/${$('#receptionNoData').val()}`
            },
            error:function(data){
                $("#loading").addClass("d-none")
                $('.errorAll').css('display','none');
                $('.invalid-feedback').text('');
                if(data.status==422)
                {
                    for(let pr of data.responseJSON.message){
                        if(pr.split('|')[0].split('.')[0]=="deliveryDate"||pr.split('|')[0].split('.')[0]=="deliveryDateNew"){
                            $(`[${pr.split('|')[0].split('.')[0]}=${pr.split('|')[0].split('.')[1]}]`).next().text(pr.split('|')[1]);
                        }else{
                            $(`[nameType=${pr.split('|')[0].split('.')[1]}]`).next().text(pr.split('|')[1]);
                        }
                    }
                }
                if(data.status==500){
                    $('.errorAll').css('display','block');
                    $('.errorAll').text(data.responseJSON.message);
                }
            },
            complete: function () {
                $("#loading").addClass("d-none");
            },
            timeout: ajaxTimeout
        });
    }
}
