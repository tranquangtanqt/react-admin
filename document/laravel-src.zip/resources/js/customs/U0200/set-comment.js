$(function() {
    $('#u0204-submit .submit-btn').click(function(){
        postFormComment();
    })
})
//モーダルを表示
window.openModalComment=function(receptionNo="",idCommnent=""){
    $('.U0204 #commentValidError').text('');
    $('.U0204 #txtCommnent').val('');
    $('.U0204 #txtId').val('');
    $('.U0204 #txtReceptionNo').val('');
    if(idCommnent!=""){
        $.ajax({
            url: `/set-comment/${idCommnent}`,
            method: 'GET',
            beforeSend: function () {
                $("#loading").removeClass("d-none");
            },
            success: function(data){
                $('.U0204 #txtCommnent').val(data);
                $('#btnShowModal-U0204').click();
                $('.U0204 #txtId').val(idCommnent);
            },
            complete: function () {
                $("#loading").addClass("d-none");
            },
            error:function(data){
                $("#loading").addClass("d-none")
            },
            timeout: ajaxTimeout
        });
    } else {
        $('#btnShowModal-U0204').click();
        $('.U0204 #txtReceptionNo').val(receptionNo);
    }
}

//コメントを送る
window.postFormComment=function(){
    $.ajax({
        url: '/set-comment/store',
        data: $(".U0204 #frm").serialize(),
        method: 'POST',
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function(data){
            $('.U0204 #closeModalComment').click();
            location.reload(true);
        },
        error:function(data){
            $("#loading").addClass("d-none");
            $('.U0204 #commentValidError').text(data.responseJSON.message);
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout
    });
}
