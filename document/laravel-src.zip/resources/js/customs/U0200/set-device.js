window.onload=function(){
    $('#u0207-submit .submit-btn').click(function(){
        postForm();
    });
    removeDeviceData();
    //機器情報を追加する
    $("#addDevice").click(function(){
        $('#formDevices').append(`<div class="d-flex mb-2 align-items-baseline device-data" count="${parseInt($('.device-data').last().attr('count'))+1}">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center deviceCustomer">
                                            <input type="radio" id="html" class="me-1 radioCheckBoxRepresent" name="representFlag"
                                                value="${parseInt($('.device-data').last().attr('count'))+1}">
                                            <select class="form-select drop-select form-control form-select me-2 min-w-h"
                                                name="groupIdNew[${parseInt($('.device-data').last().attr('count'))+1}]"
                                                    aria-label=".form-select-sm example" autofocus>
                                                <option value=""></option>
                                                ${$('#dropdownData').val()}
                                            </select>
                                        </div><div class='invalid-feedback d-block'></div>
                                    </div>
                                    <div class="d-flex me-2 dateDevice deviceCustomer flex-column width-200">
                                        <input type="text" class="form-control nameDevice min-w-200" maxlength="20" deviceTypeNew="${parseInt($('.device-data').last().attr('count'))+1}" name="deviceTypeNew[${parseInt($('.device-data').last().attr('count'))+1}]" value="">
                                        <div class='invalid-feedback d-block'></div>
                                    </div>
                                    <div class="d-flex dateDevice deviceCustomer align-items-baseline">
                                        <div class="width-200">
                                            <input type="text" idDevice='' class="form-control nameDevice min-w-200"
                                                maxlength="20"
                                                deviceNoNew="${parseInt($('.device-data').last().attr('count'))+1}"
                                                name="deviceNoNew[${parseInt($('.device-data').last().attr('count'))+1}]">
                                                <div class='invalid-feedback d-block'></div>
                                        </div>
                                        <i class="bi bi-trash-fill removeDevice btn" isNew="true" title="機器情報を削除する"></i>
                                    </div>
                                </div>`);
        removeDeviceData();
        if($('input[name=representFlag]:checked').val()==null){
            $('.radioCheckBoxRepresent').prop('checked', false);
            $('.radioCheckBoxRepresent').first().prop('checked', true);
        }
    });
}
let idDelete=[];
window.removeDeviceData=function(){
    //機器情報を削除する
    $('.removeDevice').click(function(){
    let removeTag=this;
    if($(this).attr("isNew")=="false"){
        $('#btnShowModal').click();
        $('#okClick').click(function(){
            $('#closeModal').click();
            if($(removeTag).attr('idDevice')!=null)
            idDelete.push($(removeTag).attr('idDevice'));
            $(removeTag).parent().parent().remove();
            if($('input[name=representFlag]:checked').val()==null){
                $('.radioCheckBoxRepresent').prop('checked', false);
                $('.radioCheckBoxRepresent').first().prop('checked', true);
            }
        })
    }else{
        $(removeTag).parent().parent().remove();
        if($('input[name=representFlag]:checked').val()==null){
            $('.radioCheckBoxRepresent').prop('checked', false);
            $('.radioCheckBoxRepresent').first().prop('checked', true);
        }
    }
})
}

//重複を削除する
window.unique=function(arr) {
return Array.from(new Set(arr)) //
}

//フォームを送信する
window.postForm=function(){
    $('#deleteData').val(unique(idDelete));
    if(parseInt($('.device-data').last().attr('count'))+1!=0){
        $.ajax({
            url: '/set-device/store',
            data: $("#formPostDevice").serialize(),
            method: 'POST',
            beforeSend: function () {
                $("#loading").removeClass("d-none");
            },
            success: function(data){
                window.location.href = `/receptions/${$('#receptionNoData').val()}`
            },
            error:function(data){
                $('.errorAll').css('display','none');

                if(data.status==422){
                    for(let pr of data.responseJSON.message){
                        $(`[${pr.split('|')[0].split('.')[0]}=${pr.split('|')[0].split('.')[1]}]`).next().text(pr.split('|')[1]);
                    }
                }

                if(data.status==500){
                    $('.errorAll').css('display','block');
                    $('.errorAll').text(data.responseJSON.message);
                }
            }
            ,
            complete: function () {
                $("#loading").addClass("d-none");
            },
            timeout: ajaxTimeout
        });
    }
}
