var u0208_outFile;
var u0208_maxFileSize;
var u0208_fullPath;

$(function() {
    u0208_outFile = document.getElementById("filename");
    u0208_maxFileSize = document.getElementById("max-file-size-value");
    u0208_fullPath = "";

    $('#u0208-submit').on('click', '.submit-btn', function(){
        $("#loading").removeClass("d-none");
        $('.invalid-feedback').addClass('d-none');

        let title = document.getElementById('title');
        var u0208Check = false;

        if(!u0208Check){
            if(checkTitle(title.value) == 1){
                title.classList.add('is-invalid');
                document.getElementById('title-err').classList.remove('d-none');
                document.getElementById('title-err').innerHTML = "タイトルを入力してください。";
                u0208Check = true;
            } else if(checkTitle(title.value) == 2){
                title.classList.add('is-invalid');
                document.getElementById('title-err').classList.remove('d-none');
                document.getElementById('title-err').innerHTML = "タイトルに入力禁止文字が含まれています。";
                u0208Check = true;
            } else {
                title.classList.remove('is-invalid');
            }
        }

        if(document.getElementById("file").value.length == 0){
            u0208Check = true;
            document.getElementById("file-err").classList.remove('d-none');
            document.getElementById('file-err').innerHTML = "ファイルを選択してください。";
        }

        let sizeMB =  document.getElementById("max-file-size-value").value * 1048567;
        let fileInput = document.getElementById("file");
        if(fileInput && fileInput.files[0]){
            if(fileInput.files[0].size >= sizeMB){
                u0208Check = true;
                document.getElementById('file-err').classList.remove('d-none');
                let maxSize =  document.getElementById("max-file-size-value").value;
                let strErr = "アップロードファイルの上限を超えるため、登録できません。（最大" + maxSize + "MB）";
                document.getElementById('file-err').innerHTML = strErr;
            } else if(fileInput.files[0].size == 0){
                document.getElementById('u0208-show-err').classList.remove("d-none");
                document.getElementById('u0208-show-err').innerHTML = "ファイルサイズが0バイトのファイルはアップロードできません。";
                u0208Check = true;
            }
        }
        if(!u0208Check){
            document.getElementById("u0208-frm").submit();
        } else {
            $("#loading").addClass("d-none");
        }
    })
});

window.u0208_fncSelectFileAttach = function() {
    if(document.getElementById('u0208-max-file-size-err')){
        document.getElementById('u0208-max-file-size-err').classList.add('d-none');
    }
    document.getElementById('file').click();
}

window.u0208_fncChangeFileAttach = function(){
    if(document.getElementById("file").value.length != 0){
        u0208_fullPath = document.getElementById("file").value;

    } else {
        u0208_fullPath = "";
    }

    if (u0208_fullPath) {
        var startIndex = (u0208_fullPath.indexOf('\\') >= 0 ? u0208_fullPath.lastIndexOf('\\') : u0208_fullPath.lastIndexOf('/'));
        var filename = u0208_fullPath.substring(startIndex);
        if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            filename = filename.substring(1);
        }

        u0208_outFile.setAttribute('title', filename);
        if(filename.length >= 20){
            filename = filename.substring(0, 8) + '...'+ filename.substring(filename.length - 8, filename.length);
        }
        u0208_outFile.innerHTML = filename;
    } else {
        u0208_outFile.innerHTML = 'ファイル未選択';
    }
};

window.checkTitle = function(str){
    if(str.trim().length == 0){
        return 1;
    }

    var noInvalidChars = ['<', '>', '&', '"', "'", '/'];
    for(var i = 0; i < str.length; i++){
        if(noInvalidChars.includes(str[i])){
            return 2;
        }
    }

    return 0;
}
