// Get element for add new record
var maxNumRecord = document.getElementById("max-record").value;
const tempName   = document.getElementById("tempNameOption");
const tempUnit  = document.getElementById("tempUnitOption");
const receptionNo  = document.getElementById("receptionNo").value;
var delArr=[];
window.onload = function(){
    // add new record if empty
    if(maxNumRecord == ""){
        maxNumRecord == 1;
        addNewRecord();
    }
}
// Delete record
window.delRecord = function(numRecord){
    const id = jQuery('#record'+`${ numRecord }`).find(".id").val();
    // Check record just added
    if(id != undefined){
        delArr.push(id);
    }
    jQuery('#record'+`${ numRecord }`).remove();
}

// Check all amount not empty or equal 0
window.allAmountNotEmpty = function(){
    const oldAmounts = $('input[name^="amount"]')
    const newAmounts = $('input[name^="newAmount"]');
    var oldNull = 0;
    var newNull = 0;
    if(oldAmounts.length > 0 || newAmounts.length > 0){
        oldAmounts.each(function(){
            var str = $(this).val();
            if( str.length == 0 || +str.replace(',','') == 0 ){
                oldNull += 1;
            }
        })
        newAmounts.each(function(){
            var str = $(this).val();
            if( str.length == 0 || +str.replace(',','') == 0 ){
                newNull += 1;
            }
        })
        if( oldAmounts.length == oldNull && newAmounts.length == newNull ){
            return false;
        }
    }
    return true;
}
// Save data
window.save = function() {
    clearAllErrMessage();
    if( allAmountNotEmpty() ){
        $('#deletedIds').val(delArr);
        $.ajax({
            url: "/set-quotations/update",
            method: 'post',
            data:jQuery(`#quotationForm`).serialize(),
            beforeSend: function () {
                $("#loading").removeClass("d-none");
            },
            complete: function () {
                $("#loading").addClass("d-none");
            },
            success: function(res) {
                window.location.href = `/receptions/${receptionNo}/finance`;
            },
            error:function(errors) {
                $("#loading").addClass("d-none");
                if(errors.status == 422) {
                    clearAllErrMessage();
                    const messages = errors.responseJSON.message;
                    messages.forEach(message => {

                        if( message.includes("に入力禁止文字が含まれています。")
                            && ( message.includes("unit") || message.includes("newUnit")) ){
                            message =message.replace('に入力禁止文字が含まれています。','|') +'単位に入力禁止文字が含まれています。';
                        }
                        if( message.includes("に入力禁止文字が含まれています。")
                            && (message.includes("name")|| message.includes("newName")) ){
                            message =message.replace('に入力禁止文字が含まれています。','|') +'作業名・品名に入力禁止文字が含まれています。';
                        }

                        // Get error area
                        const ereaId = message.split('|')[0].split('.').join('');
                        const content = message.split('|')[1];

                        // Set error message
                        jQuery(`.`+`${ereaId}`).text(content);
                    });
                }
                if(errors.status == 419) {
                    $("#loading").addClass("d-none");
                    clearAllErrMessage();
                    jQuery(`#alert`).html(errors.responseJSON.message.split('|')[1]);
                    jQuery(`.alert`).show();
                }
            }
        });
    }else{
        $("#loading").addClass("d-none")
        $('.amount-required').html("金額はいずれかの明細で入力してください。");
    }
}

window.addNewRecord = function (){
     maxNumRecord ++;
     var newRecordHTML = `<div id="record${ maxNumRecord }">
            <div class="quotation-record">
                <div class="d-flex row1">
                    <div class="col1">
                        <input class="form-control" type="text" name="newWorkNo[${ maxNumRecord }]" maxlength="7">
                    </div>
                    <div class="col2">
                        <input class="form-control text-end" type="text" name="newQuantity[${ maxNumRecord }]" step="0.01" min = 0 maxlength="6">
                    </div>
                    <div class="d-flex col3">
                        <input class="form-control" list="unit-list-${ maxNumRecord }" type="text" name="newUnit[${ maxNumRecord }]" maxlength="2" autocomplete="off">
                        <datalist id="unit-list-${ maxNumRecord }">`
    newRecordHTML += tempUnit.outerHTML;
    newRecordHTML +=` </datalist>
                    </div>
                </div>
                <div class="d-flex row2">
                    <div class="d-flex col4">
                        <input class="form-control" list="name-list-${ maxNumRecord }" type="text" name="newName[${ maxNumRecord }]" maxlength="10" autocomplete="off">
                        <datalist id="name-list-${ maxNumRecord }">`
    newRecordHTML += tempName.outerHTML;
    newRecordHTML += `</datalist>
                    </div>
                    <div class="col5 last-col">
                        <input class="form-control text-end amount-input" onfocus="amountFormat(this)" onfocusout="unAmountFormat(this)" type="text" name="newAmount[${ maxNumRecord }]" maxlength="9">
                    </div>
                    <div>
                        <a class="btn" onclick="delRecord(${ maxNumRecord })"><i class="bi bi-trash-fill" title="行を削除する"></i></a>
                    </div>
                </div>
            </div>
            <div class="invalid-feedback d-block newWorkNo${ maxNumRecord }"></div>
            <div class="invalid-feedback d-block newQuantity${ maxNumRecord }"></div>
            <div class="invalid-feedback d-block newUnit${ maxNumRecord }"></div>
            <div class="invalid-feedback d-block newName${ maxNumRecord }"></div>
            <div class="invalid-feedback d-block newAmount${ maxNumRecord }"></div>
            <div class="invalid-feedback d-block amount-required"></div>
        <hr class="mt-4">
        </div>`
    jQuery('.quotation-body').append(newRecordHTML);
}

window.clearAllErrMessage = function(){
    jQuery('.invalid-feedback').html('');
    jQuery(`.alert`).hide();
}

jQuery('input.amount-input').on('blur', function() {
    unAmountFormat(this);
});

window.unAmountFormat = function (sel){
    const reg = /^\d+$/;
    if(sel.value != "" && reg.test(sel.value) ){
        const value = sel.value.replace(/,/g, '');
        sel.value = parseFloat(value).toLocaleString('en-US', {
          style: 'decimal',
        });
    }
}

jQuery('input.amount-input').on('focus', function() {
    amountFormat(this);
});

window.amountFormat = function (sel){
    sel.value = sel.value.split(',').join('');
}
