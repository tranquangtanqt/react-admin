$(function() {
    $('#check-cost-submit').on('click', '.submit-btn', function(){
        $("#loading").removeClass("d-none");
        $("#frm-cost").submit();
    });
});
