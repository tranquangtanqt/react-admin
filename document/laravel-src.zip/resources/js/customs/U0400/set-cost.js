var countAdd = 0;
var addArr = [];
var delArr = [];
var updateArr = [];
var typeList = "";
var materialCostList = "";
var constructCostList = "";

$(function() {
    countAdd = $('#max-cost-id').val();
    if($("#count-cost").val() == 0){
        addArr.push(0);
    }
    typeList = $('#type-list').val();
    materialCostList = $('#material-cost-list').val();
    constructCostList = $('#construct-cost-list').val();

    $('input[name^="id_"]').each(function(){
        if(!$('input[name="name[' + $(this).val() +']"]').is(':disabled')){
            updateArr.push($(this).val());
        }
    })

    $('input[name^="amount"]').on('blur', function() {
        unAmountFormat(this);
    });


    $('input[name^="amount"]').on('focus', function() {
        amountFormat(this);
    });
});

window.unAmountFormat = function(element){
    const reg = /^\d+$/;
    if(element.value != "" && reg.test(element.value) ){
        const value = element.value.replace(/,/g, '');
        element.value = parseFloat(value).toLocaleString('en-US', {
        style: 'decimal',
        });
    }
}

window.amountFormat = function(sel){
    sel.value = sel.value.split(',').join('');
}

window.fncAddRecord = function(){
    countAdd++;
    addArr.push(countAdd);
    $('#add-element').append(`
    <div id="record-` + countAdd+ `">
        <hr>
        <div class="row align-items-baseline">
            <div class="col-12 col-md-1 me-md-4 me-lg-0">
                <select class="form-select drop-select form-control form-select me-2 min-w-h u0401-width-select" style="width: 78px" name="type_new[`+ countAdd + `]"
                    onchange="fncTypeUpdate(` + countAdd + `, this)" autofocus>
                    ` + typeList + `
                </select>
            </div>

            <div class="col-6 col-md-2 d-flex u0401-mt-2 pe-0 mt-2 mb-2">
                <input id="name-` + countAdd + `" class="form-control u0401-name" type="text" name="name_new[` + countAdd + `]"
                    value="" maxlength="10" list="u0401-material-cost-list-` + countAdd + `" autocomplete="off">

                <datalist id="u0401-material-cost-list-` + countAdd + `">
                    ` + materialCostList + `
                </datalist>

                <datalist id="u0401-construct-cost-list-` + countAdd + `">
                    ` + constructCostList + `
                </datalist>
            </div>
            <div class="col-4 col-md-2 u0401-mt-2 pe-0 d-flex ms-md-2">
                <input class="form-control u0401-text-right u0401-name u0401-width-122" type="text" name="amount_new[` + countAdd + `]" min="-999999999" max="999999999"
                value="" maxlength="9" onfocus="amountFormat(this)" onfocusout="unAmountFormat(this)">
                <button class="btn" onclick="fncDelRecord(` + countAdd + `, true)"><i class="bi bi-trash-fill" title="原価を削除する"></i></button>
            </div>
        </div>
        <div class="invalid-feedback d-block" id="name_new-err-` + countAdd + `"></div>
        <div class="invalid-feedback d-block" id="type_new-err-` + countAdd + `"></div>
        <div class="invalid-feedback d-block" id="amount_new-err-` + countAdd + `"></div>
    </div>`);
}

window.fncTypeUpdate = function(record, element){
    if(element.value == 1) {
        $("#name-" + record).attr("list", "u0401-material-cost-list-" + record)
    } else if(element.value == 2){
        $("#name-" + record).attr("list", "u0401-construct-cost-list-" + record)
    }
}

window.fncDelRecord = function(record, flagNew){
    if(!flagNew){
        delArr.push(record);
        updateArr = updateArr.filter(item => item != record)
    }
    addArr = addArr.filter(item => item != record)

    $('#record-' + record).remove();
}

//フォームを送信する
window.fncSubmit = function(){
    $('.invalid-feedback').html('');
    $('#show-error').addClass('d-none');
    $('#delele-arr').val(unique(delArr));
    $('#update-arr').val(unique(updateArr));
    $('#add-arr').val(unique(addArr));

    var isAmountEmpty = true;
    var rowCount = $('input[name^="amount"]').length;

    if(rowCount == 0 && delArr.length > 0 && delArr[0] == 0){
        return;
    }

    if(rowCount > 0 || delArr.length > 0){
        $('input[name^="amount"]').each(function(){
            let str = $(this).val();
            if(str.length != 0){
                str = str.replace(/,/g, '');
                str = str.replace(/0/g, '');
                if(str.length !== 0){
                    isAmountEmpty = false;
                    return false;
                }
            }
        })

        if(rowCount > 0 && isAmountEmpty){
            $('#show-error').removeClass('d-none');
            $('#show-error').text("金額はいずれかの明細で入力してください。");
        } else {
            $.ajax({
                url: "/set-cost/change",
                data: $("#frm-cost").serialize(),
                method: 'POST',
                success: function(response){
                    if(response.status == 200){
                        window.location.href = "/receptions/" + $('#reception-no').val() + "/finance";
                    }
                },
                error:function(response){
                    if(response.status == 422){
                        let messages = response.responseJSON.message;
                        messages.forEach(message => {
                            if( message.includes("に入力禁止文字が含まれています。")
                                && ( message.includes("name") || message.includes("name_new")) ){
                                message = message.replace('に入力禁止文字が含まれています。','|') +'原価名称に入力禁止文字が含まれています。';
                            }

                            let arrId = message.split('|')[0].split('.');
                            let id = arrId[0] + "-err-" + arrId[1];
                            let content = message.split('|')[1];
                            jQuery(`#`+`${id}`).text(content);
                        });
                    }

                    if(response.status == 500){
                        $('#show-error').removeClass('d-none');
                        $('#show-error').text(response.responseJSON.message);
                    }
                }
            });
        }
    }
}

//重複を削除する
window.unique = function(arr) {
    return Array.from(new Set(arr)) //
}
