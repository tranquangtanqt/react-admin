const { fromPairs, result } = require("lodash");

window.loadUserSelectionListener = function () {
    $(`input[type=checkbox][id^=select_user_]`).on("change", function () {
        if (this.checked) {
            $("#" + this.id + "-icon").removeClass("d-none");
        } else {
            $("#" + this.id + "-icon").addClass("d-none");
        }
    });
};

window.submitTogglePin = function (event, element) {
    event.preventDefault();
    event.stopPropagation();

    if (!element || !isDOM(element)) {
        throw "The argument should be specified and should be an html element";
    }
    const data = $(element).serializeArray(); // フォームのデータ
    const url = $(element).prop("action"); // url取得

    $.ajax({
        url: url,
        method: "POST",
        dataType: "json",
        data: data,
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            location.reload(true);
        },
        error: function (jqXHR, testStatus, error) {
            alert("ピン留め更新に失敗しました。");
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// スケジュール表示設定画面（週間）のモーダルのAJAX
window.fetchScheduleWeeklySettingModal = function (event, element) {
    event.preventDefault();
    event.stopPropagation();

    const data = $(element).serializeArray(); // フォームのデータ
    const url = $(element).prop("action"); // url取得

    $.ajax({
        url: url,
        dataType: "html",
        data: data,
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            $(`#js-schedule-weekly-setting-modal`).html(result);
            $(`#schedule-weekly-setting-modal`).modal("show");
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            alert(
                "スケジュール表示設定画面（週間）起動に失敗しました。再度試してください。"
            );
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// スケジュール表示設定画面（週間）のサブミットの時
window.submitScheduleWeeklySetting = function (event) {
    $("#loading").removeClass("d-none");

    const data = $(event.target).serializeArray(); // フォームのデータ

    // ユーザが選択されたか
    const hasUser =
        data.filter((item) => item.name.startsWith("selected_users")).length >
        0;

    if (!hasUser) {
        event.preventDefault();
        event.stopPropagation();
        $("#select_users_error").parent().removeClass("d-none");
        $("#loading").addClass("d-none");
        return false;
    }

    $("#loading").addClass("d-none");
    return true;
};

// 通常予定設定画面のモーダルのAJAX
window.fetchScheduleSettingModal = function (event, element) {
    event.preventDefault();
    event.stopPropagation();

    const url = element.dataset.targetRoute;

    const data = {
        init_user_id: element.dataset.userId ?? null,
        init_date: element.dataset.date ?? null,
    };

    $.ajax({
        url: url,
        dataType: "html",
        data: data,
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            $(`#js-schedule-setting-modal`).html(result);
            $(`#schedule-setting-modal`).modal("show");
            $("input[role=datepicker]").datepicker({});
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            alert("通常予定設定画面起動に失敗しました。再度試してください。");
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// 通常予定設定の処理
window.submitScheduleSetting = function (event) {
    event.preventDefault();
    event.stopPropagation();

    const data = $(event.target).serializeArray(); // フォームのデータ
    const url = $(event.target).prop("action"); // url取得
    const errorIdPrefix = "schedule_setting";

    $.ajax({
        url: url,
        method: "POST",
        dataType: "json",
        data: data,
        beforeSend: function () {
            hideErrors(errorIdPrefix);
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            location.reload(true);
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            const errorResponse = JSON.parse(jqXHR.responseText);

            outputErrors(errorIdPrefix, errorResponse); // エラー表示

            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// スケジュール表示設定画面（リスト）のモーダルのAJAX
window.fetchScheduleListSettingModal = function (event, element) {
    event.preventDefault();
    event.stopPropagation();

    const data = $(element).serializeArray(); // フォームのデータ
    const url = $(element).prop("action"); // url取得

    $.ajax({
        url: url,
        dataType: "html",
        data: data,
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            $(`#js-schedule-list-setting-modal`).html(result);
            $("input[role=datepicker]").datepicker({});
            $(`#schedule-list-setting-modal`).modal("show");
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            alert(
                "スケジュール表示設定画面（リスト）起動に失敗しました。再度試してください。"
            );
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// スケジュール表示設定画面（リスト）のサブミットの時
window.submitScheduleListSetting = function (event) {
    const $form = $(event.target).parents("form");
    const data = $form.serializeArray(); // フォームのデータ
    const url = $form.find("#validation_route").data("validationRoute");

    $("#loading").removeClass("d-none");
    validateScheduleListSetting(url, data).then((result) => {
        if (result) {
            $("#loading").removeClass("d-none");
            $form.trigger("submit");
        } else {
            $("#loading").addClass("d-none");
        }
    });

    event.preventDefault();
    event.stopPropagation();
};

async function validateScheduleListSetting(url, data) {
    const errorIdPrefix = "schedule_list_setting";

    try {
        await $.ajax({
            url: url,
            data: data,
            beforeSend: function () {
                hideErrors(errorIdPrefix);
            },
            error: function (jqXHR, testStatus, error) {
                const errorResponse = JSON.parse(jqXHR.responseText);
                outputErrors(errorIdPrefix, errorResponse); // エラー表示
            },
            timeout: ajaxTimeout,
        });

        return true;
    } catch (error) {
        return false;
    }
}
