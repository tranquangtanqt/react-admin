var fileInput = document.getElementById("file");
var outFile = document.getElementById("filename");
var title = document.getElementById('title');
var btnSubmit = document.getElementById('submitForm');

// Handle change file event
fileInput.addEventListener( "change", function(event) {
    var fullPath = this.value;
    if (fullPath) {
        var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
        var fileName = fullPath.substring(startIndex);
        if (fileName.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
            fileName = fileName.substring(1);
        }
    }
    if(fileName.length>=20){
        fileName = fileName.substring(0,8)+'...'+fileName.substring(fileName.length-8,fileName.length);
    }
    outFile.innerHTML = fileName;
});

// Handle submit form
btnSubmit.addEventListener("click", function(event) {
    $("#loading").removeClass("d-none");
    if( document.getElementById("file-size") != null ){
        document.getElementById("file-size").classList.add('d-none');
    }
    title.classList.remove('is-invalid');
    document.getElementById("file-required").classList.add('d-none');
    document.getElementById('title-special').classList.add('d-none');
    document.getElementById('title-required').classList.add('d-none');
    const str = title.value;
    const formData = document.getElementById("frm");
    var inValid = false;
    const noInvalidChars = ['<', '>', '&', '"', "'", '/'];

    if(str.trim().length == 0){
        inValid = true;
        title.classList.add('is-invalid');
        document.getElementById('title-required').classList.remove('d-none');
        document.getElementById('title-special').classList.add('d-none');
    }

    for(var i = 0; i < str.length; i++){
        if(noInvalidChars.includes(str[i])){
            inValid = true;
            title.classList.add('is-invalid');
            document.getElementById('title-required').classList.add('d-none');
            document.getElementById('title-special').classList.remove('d-none');
        }
    }

    if(document.getElementById("file").value.length == 0){
        inValid = true;
        document.getElementById("file-required").classList.remove('d-none');
    }

    if(inValid){
        $("#loading").addClass("d-none")
        event.preventDefault();
        return;
    }else{
        formData.submit();
    }

});
