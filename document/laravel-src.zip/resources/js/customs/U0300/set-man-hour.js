var startTime = document.getElementById('startTime');
var endTime = document.getElementById('endTime');
var manHour = document.getElementById('manHour');
const minTime = '00:00';
// CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
//--const maxTime = '23:59';
const maxTime = '35:59';
const defaultMaxTime = '23:59';
// CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応

window.onload = function(){
    if(manHour.value == ''){
        setManHour();
    }
}

startTime.addEventListener('change',function(){
    startTime.value = autocompeleTime(startTime.value);
    if( validateHHmm(startTime.value)){
        compareTimeWithMinMax(true);
        if(validateHHmm(endTime.value)){
            setManHour();
        }
    }else{
        startTime.value = minTime;
        setManHour();
    }
});

// 工数を算出し設定する。
endTime.addEventListener('change',function(){
    endTime.value = autocompeleTime(endTime.value);
    if( validateHHmm(endTime.value) ){
        compareTimeWithMinMax(false);
        if(validateHHmm(startTime.value)) {
            setManHour();
        }
    }else{
        // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
        //--endTime.value = maxTime;
        endTime.value = defaultMaxTime;
        // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応
        setManHour();
    }
});

// auto complete time input
function autocompeleTime(val){
    if(val.length == 1){
        val = '0'+val+':00';
    }
    if(val.length == 2){
        val = val+':00';
    }
    if(val.length == 3){
        if(+val.substring(0, 1) <= 2) {
            val = val.substring(0, 2)+':'+val.substring(2,3)+'0';
        } else {
            val = '0'+val.substring(0, 1)+':'+val.substring(1,3);

        }
    }
    if(val.length == 4){
        val = val.substring(0, 2)+':'+val.substring(2,4);
    }
    return val;
}

//validate time input
function validateHHmm(val) {
    // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
    //--var isValid = /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/.test(val);
    var isValid = /^([0-2]?[0-9]|3[0-5]):([0-5][0-9])$/.test(val);
    // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応
    return isValid;
}

window.compareTimeWithMinMax = function (boolean){
    var regExp = /(\d{1,2})\:(\d{1,2})/;
    if(boolean){
        if(parseInt(startTime.value.replace(regExp, "$1$2")) > parseInt(maxTime.replace(regExp, "$1$2"))){
            startTime.value = maxTime;
        }
        if(parseInt(startTime.value.replace(regExp, "$1$2")) < parseInt(minTime.replace(regExp, "$1$2"))){
            startTime.value = minTime;
        }
    }else{  
        if(parseInt(endTime.value.replace(regExp, "$1$2")) > parseInt(maxTime.replace(regExp, "$1$2"))){
            endTime.value = maxTime;
        }
        if(parseInt(endTime.value.replace(regExp, "$1$2")) < parseInt(minTime.replace(regExp, "$1$2"))){
            endTime.value = minTime;
        }
    }
}

// 工数を算出し設定する。
window.setManHour =  function () {
    const st = startTime.value.split(':');
    const et = endTime.value.split(':');
    const startHour = parseInt(st[0]);
    const startMinutes = parseInt(st[1]);
    const endHour  = parseInt(et[0]);
    const endMinutes = parseInt(et[1]);

    const numMinutesStart  =  startHour*60 + startMinutes;
    const numMinutesEnd    =  endHour*60 + endMinutes;
    if(numMinutesEnd > numMinutesStart) {
        if(startHour < 12 && endHour > 12) {
            manHour.value = ((numMinutesEnd - numMinutesStart - 60)/60).toFixed(2)
            return;
        }
        if(startHour == 12 && numMinutesEnd > 13*60) {
            manHour.value = ((numMinutesEnd - 13*60)/60).toFixed(2);
            return;
        }
        if(endHour == 12 && startHour < 12){
            manHour.value = ((12*60 - numMinutesStart)/60).toFixed(2);
            return;
        }
        if(startHour < 12 && endHour < 12 || startHour > 12 ){
            manHour.value = ((numMinutesEnd - numMinutesStart)/60).toFixed(2)
            return;
        }
    }
    manHour.value = '';
    return;
}
