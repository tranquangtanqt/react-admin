const { default: SignaturePad } = require('signature_pad');

// Changed flag data in signature area
var changed_flg = false;
var saveButton = document.getElementById('save');
var clearButton = document.getElementById('clear');
var gotoBeforPage = document.getElementById('ok');
var scheduleId = document.getElementById('scheduleId').value;
var canvas = document.getElementById('signature-pad');

// Setting canvas element
var signaturePad = new SignaturePad(canvas, {
                        minWidth: 5,
                        maxWidth: 5,
                        backgroundColor : "rgb(255,255,255)",
});

// Event for PC
canvas.addEventListener('click', function(){
    changed_flg = true;
});

// Event for phone
canvas.addEventListener('touchstart', function(){
    changed_flg = true;
});

// Save sign file handle
saveButton.addEventListener('click', function () {
    // Check changed data
    if(changed_flg == false) {
        $("#loading").addClass("d-none");
        jQuery('#errormodal').modal('show');
        return;
    }
    $.ajax({
        url: "/set-sign/store",
        method: 'post',
        data: {
            _token: $('input[name="_token"]').val(),
            signature : signaturePad.toDataURL('image/png'),
            scheduleId: scheduleId
        },
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        success: function() {
            // お客様控えをダウンロードさせる
            document.getElementById('get-certificate').click();
            // window.open(
            //     `/certificate-customer/${ scheduleId }`,
            //     '_blank' // 新しいウィンドウ（タブ）で開く
            //   );

            // 作業実績情報画面に戻る
            setTimeout(() => {
                document.getElementById('back-btn').click();
            }, 1000);
        },
        error: function () {
            $("#loading").addClass("d-none");
        },
    });
});

clearButton.addEventListener('click', function () {
    changed_flg = false;
    signaturePad.clear();
});

gotoBeforPage.addEventListener('click', function () {
    window.location.href = `/result-info/${ scheduleId }`;
});
