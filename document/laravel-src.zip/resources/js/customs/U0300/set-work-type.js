$(function () {
    $("#u0309-submit .submit-btn").click(function () {
        postFormWorkType();
    });
});
window.openModalWorkType = function (receptionNo = "") {
    $("#setWorkTypeValidError").text("");
    $(".form-select").html("");
    $("#txtReceptionNoSetWorkType").val("");
    $("#txtUpdatedDateSetWorkType").val("");
    $.ajax({
        url: `/set-worktype/${receptionNo}`,
        method: "GET",
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (data) {
            $("#btnShowModalSetworkType").trigger("click");
            $("#txtReceptionNoSetWorkType").val(receptionNo);
            $("#txtUpdatedDateSetWorkType").val(data.updatedDate);
            for (let val of data.codeClasses) {
                if (data?.workType == val.key) {
                    $(".form-select").append(
                        `<option value="${val.key}" selected>${val.value}</option>`
                    );
                } else {
                    $(".form-select").append(
                        `<option value="${val.key}">${val.value}</option>`
                    );
                }
            }
        },

        error: function (data) {},
        complete: function () {
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

//フォームを送信する
window.postFormWorkType = function () {
    $.ajax({
        url: "/set-worktype/update",
        data: $("#frmSetWorkType").serialize(),
        method: "PATCH",
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function (data) {
            $("#closeModalWorktype").trigger("click");
            location.reload(true);
        },
        error: function (data) {
            $("#setWorkTypeValidError").text(data.responseJSON.message);
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};
