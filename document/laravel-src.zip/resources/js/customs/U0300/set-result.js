var btnEdit = document.getElementById('editInfo');
window.contentTemplateSelected = function (id,sel){
    if( sel.value != "" ){
        jQuery('#workContent'+id).val( sel.value );
        jQuery(".select-template").val("");
    }
}

btnEdit.addEventListener('click', function () {
    jQuery('#confirm-edit-modal').modal('show');
});