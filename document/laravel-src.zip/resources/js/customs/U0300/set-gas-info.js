window.onload = function(){
    $('.u0307-submit .submit-btn').click(function(){
        postFormGasInInfo()
    })
}
window.openModalsetGasInfo=function(receptionNo="",nameGas="GasInInfo"){
    $('#dropGasType').change(function(){
        if($(this).val()!=0){
            $('#txtGasTypeName').prop( "disabled", true );
            $('#txtGasTypeName').val('');
        }else{
            $('#txtGasTypeName').prop( "disabled", false );
        }
    })
    $('.invalid-feedback').html('');
    $('#setGasInfoValidErrorAll').html('');
    $('#dropType').html('');
    $('#dropGasType').html('');
    $('#txtReceptionNoGasInfo').val('');
    $('#txtupdatedAt').val('');
    $('#gasInfo').text('');
    $('#typeName').text('');
    $('#gasTypeName').text('');
    $('#quantityName').text('');
    $('#txtQuantity').text('');
    $('#txtDate').text('');
    $('#txtNameGas').val('');
    $('#txtGasTypeName').text('');
    $.ajax({
        url: `/set-gasinfo`,
        data:{'nameGasInfo':nameGas,'receptionNo':receptionNo,'_token': $('input[name="_token"]').val()},
        method: 'POST',
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function(data){
            $('#btnShowModalGasInfo').click();
            $('#gasInfo').text(nameGas=="GasInInfo"?"充塡情報設定":"回収情報設定");
            $('#typeName').text(nameGas=="GasInInfo"?"充塡区分":"回収区分");
            $('#gasTypeName').text(nameGas=="GasInInfo"?"充塡種類":"回収種類");
            $('#quantityName').text(nameGas=="GasInInfo"?"充塡量(Kg)":"回収量(kg)");
            $('#txtQuantity').val(parseFloat(data?.gasInfo?.quantity));
            $('#txtDate').val(convertDate(data?.gasInfo?.dateConvert));
            $('#txtGasTypeName').val(data?.gasInfo?.gas_type_name);
            $('#txtReceptionNoGasInfo').val(receptionNo);
            $('#txtupdatedAt').val(data.updatedAt);
            $('#txtNameGas').val(nameGas);
            for(let val of data.codeClassType){
                if(data?.gasInfo?.type==val.key)
                    $('#dropType').append(`<option value="${val.key}" selected>${val.value}</option>`);
                else
                    $('#dropType').append(`<option value="${val.key}">${val.value}</option>`);
            }
            for(let val of data.codeClassGasType){
                if(data?.gasInfo?.gas_type==val.key)
                    $('#dropGasType').append(`<option value="${val.key}" selected>${val.value}</option>`);
                else
                    $('#dropGasType').append(`<option value="${val.key}">${val.value}</option>`);
            }
            if($('#dropGasType').val()!=0){
                $('#txtGasTypeName').prop( "disabled", true );
                $('#txtGasTypeName').val('');
            }else{
                $('#txtGasTypeName').prop( "disabled", false );
            }
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error:function(data){
            $('#setGasInfoValidErrorAll').text(data.responseJSON.message);
        },
        timeout: ajaxTimeout
    });
}
window.convertDate=function(dateString=""){
    if(dateString!=""){
        let d = new Date(dateString),
        month = "" + (d.getMonth() + 1),
        day = "" + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;
    return [year, month, day].join("/");
    }else{
        return null;
    }
}
//フォームを送信する
window.postFormGasInInfo=function(){
    $.ajax({
        url: `/set-gasinfo/store`,
        data: $("#frmGasInfo").serialize(),
        method: 'POST',
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function(data){
            $('#closeModal').click();
            location.reload(true);
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error:function(data){
            $('.invalid-feedback').html('');
            $('#setGasInfoValidErrorAll').html('');
            if(data.status==422){
                for(pr of data.responseJSON.message){
                    $(`[name=${pr.split('|')[0]}]`).next().text(pr.split('|')[1]);
                }
            }
            if(data.status==500){
                $('#setGasInfoValidErrorAll').text(data.responseJSON.message);
            }
        }
    });
}
