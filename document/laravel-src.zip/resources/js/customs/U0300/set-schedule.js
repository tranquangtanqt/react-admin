const { data } = require("jquery");

// 訪問予定編集のモーダルのAJAX
window.fetchScheduleModal = function (
    event,
    element,
    mode = "edit",
    userId = null,
    date = null
) {
    if (!["read", "edit", "add"].includes(mode)) {
        throw "Only 'read', 'edit', or 'add' is allowed for the mode argument.";
    }

    let data = {};

    if (mode === "add") {
        data.init_user_id = userId;
        data.init_date = date;
    }

    event.preventDefault();
    event.stopPropagation();

    $.ajax({
        url: element.dataset.targetRoute,
        dataType: "html",
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        data: data,
        success: function (result) {
            $(`#js-set-schedule-modal`).html(result);
            $(`#${mode}-schedule-modal`).modal("show");
            if (["edit", "add"].includes(mode)) {
                loadSetScheduleListener(mode);
                $("input[role=datepicker]").datepicker();
            }
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            let pageType = mode === "edit" ? "編集" : "表示";
            alert(
                "訪問予定" +
                    pageType +
                    "画面起動に失敗しました。再度試してください。"
            );
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// 訪問予定の追加・編集を確定する時
window.submitSetSchedule = function (event, element) {
    if (!element || !isDOM(element)) {
        throw "The argument should be specified and should be an html element with 'action' attribute.";
    }

    event.preventDefault();
    event.stopPropagation();

    const data = $(element).serializeArray(); // フォームのデータ
    const url = $(element).prop("action"); // url取得
    const errorIdPrefix = "set_schedule";

    $.ajax({
        url: url,
        method: "POST",
        dataType: "json",
        data: data,
        beforeSend: function () {
            hideErrors(errorIdPrefix);
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            location.reload(true);
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            backToSetScheduleModalFromSetPjMgr();

            const errorResponse = JSON.parse(jqXHR.responseText);

            outputErrors(errorIdPrefix, errorResponse); // エラー表示

            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// 日程の追加・編集の時に、チェックボックスのリスナー
window.loadSetScheduleListener = function (mode) {
    if (!["add", "edit"].includes(mode)) {
        throw "Only 'add' or 'edit' is allowed as the argument.";
    }
    $(`input[type=checkbox][name^=${mode}_schedule_persons]`).on(
        "change",
        function () {
            if (this.checked) {
                $("#" + this.id + "-icon").removeClass("d-none");
            } else {
                $("#" + this.id + "-icon").addClass("d-none");
            }
        }
    );
};

// 予定確認条件設定モーダル取得
window.fetchSetScheduleCheckConditionModal = function (
    event,
    element,
    mode = "edit"
) {
    const formId = mode + "-schedule-modal-form";
    const data = $("#" + formId).serializeArray(); // フォームのデータ
    data.push({ name: "mode", value: mode }); // モードをデータに追加

    if (!["add", "edit"].includes(mode)) {
        throw "Only 'add' or 'edit' is allowed for the mode argument.";
    }

    event.preventDefault();
    event.stopPropagation();

    const errorIdPrefix = "set_schedule";

    $.ajax({
        url: element.dataset.targetRoute,
        dataType: "html",
        data: data,
        beforeSend: function () {
            hideErrors(errorIdPrefix);
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            $(`#js-set-schedule-check-condition-modal`).html(result);
            $(`#${mode}-schedule-modal`).modal("hide");
            $(`#${mode}-schedule-general-error`).addClass("d-none");
            $("input[role=datepicker]").datepicker();
            $(`#set-schedule-check-condition-modal`).modal("show");
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            const errorResponse = JSON.parse(jqXHR.responseText);

            outputErrors(errorIdPrefix, errorResponse); // エラー表示

            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// 予定確認設定モーダル取得
window.fetchSetScheduleCheckModal = function (event) {
    const $form = $("#set-schedule-check-condition-modal-form");
    const data = $form.serializeArray(); // フォームのデータ
    const url = $form.prop("action"); // url取得

    event.preventDefault();
    event.stopPropagation();

    const errorIdPrefix = "check_condition";

    $.ajax({
        url: url,
        dataType: "html",
        data: data,
        beforeSend: function () {
            hideErrors(errorIdPrefix);
            $("#loading").removeClass("d-none");
        },
        success: function (result) {
            $(`#js-set-schedule-check-modal`).html(result); // 予定確認設定モーダルに埋め込む
            $(`#set-schedule-check-condition-modal`).modal("hide"); // 予定確認条件設定モーダルの非表示
            $(`#set-schedule-check-modal`).modal("show"); // 予定確認設定モーダルの表示
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        error: function (jqXHR, testStatus, error) {
            const errorResponse = JSON.parse(jqXHR.responseText);

            outputErrors(errorIdPrefix, errorResponse); // エラー表示

            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
};

// 予定確認設定モーダルより予定確認条件設定モーダルに遷移
window.backToSetScheduleCheckConditionModal = function () {
    $("#set-schedule-check-modal").modal("hide");
    $("#set-schedule-check-condition-modal").modal("show");
};

// 予定確認設定モーダルより訪問予定設定モーダルに遷移
window.backToSetScheduleModal = function (mode) {
    $("#set-schedule-check-modal").modal("hide");
    $(`#${mode}-schedule-modal`).modal("show");
};

// 予定確認条件設定の条件クリア
window.clearScheduleCheckCondition = function () {
    // input値をクリアする
    $("input[id^=check_condition_schedule_date]").val("");
    $("input[id^=check_condition_schedule_slots]")
        .prop("checked", false)
        .trigger("change");
    $("input[id^=check_condition_schedule_persons]")
        .prop("checked", false)
        .trigger("change");
    $("input[id^=internal_persons]").val(0);
    $("input[id^=external_persons]").val(0);
    const errorIdPrefix = "check_condition";
    hideErrors(errorIdPrefix);
};

// 予定確認設定ボタン押下の時
window.setCheckedSchedules = function (event, element) {
    event.preventDefault();
    event.stopPropagation();

    const data = $(element).serializeArray(); // フォームのデータ
    const mode = $(element).find("input[name=mode]").val(); // モード
    const date = $(element).find("input[name=date]").val(); // 日付

    // 日付設定
    $(`#${mode}-schedule-date`).val(date);

    // クリアデータ
    $(`input[type=checkbox][id^=${mode}_schedule_persons-]`)
        .prop("checked", false)
        .trigger("change");

    // バリデーション
    let selectedDataLength = data.filter((item) =>
        item.name.startsWith("date-person-slot-")
    ).length;
    if (selectedDataLength <= 0) {
        // 選択されない場合
        $(element)
            .find("div[id^=check_schedule_error_]")
            .html("訪問担当・時間帯を選択してください。")
            .removeClass("d-none");
        return false;
    } else {
        $(element)
            .find("div[id^=check_schedule_error_]")
            .html("")
            .addClass("d-none");
    }

    // 設定画面に選択されたデータを反映させる
    data.forEach(({ name, value }) => {
        if (name.startsWith("date-person-slot-")) {
            let splittedName = name.split("-");
            let personId = splittedName[4];
            let slotKey = splittedName[5];
            $(`#${mode}_schedule_persons-${personId}-slots-${slotKey}`)
                .prop("checked", true)
                .trigger("change");
        }
    });

    backToSetScheduleModal(mode);
};

// 計上担当設定モーダルより予定設定モーダルに遷移
window.backToSetScheduleModalFromSetPjMgr = function () {
    $("#sche-pjmgr-modal").modal("hide");
    $(`#add-schedule-modal`).modal("show");
};

//予定設定モーダルより 計上担当設定モーダルに遷移
window.goToSetPjMgrFromSetScheduleModal = function (event, mode) {
    event.preventDefault();

    // 日付必須
    if (!$(`#${mode}-schedule-date`).val()) {
        alert("予定日を指定してください。");
        return;
    }

    // 時間帯必須
    selectedSlots = $(
        `input[type=checkbox][name^=add_schedule_persons]:checked`
    );
    if (selectedSlots.length <= 0) {
        alert("時間帯を選択してください。");
        return;
    }

    // 選択された社員時間帯
    internalCheckedSlots = $(
        `input[type=checkbox][name^=${mode}_schedule_persons][data-internal=true]:checked`
    );

    // 社員のユーザID(重複場合もある)
    internalUserIds = internalCheckedSlots
        .map(function () {
            return this.dataset.personId;
        })
        .toArray();

    // 社員のユーザID(重複場なし)
    uniqueInternalUserIds = new Set(internalUserIds);

    // 社員1人選択された場合フォームを送信する
    if (uniqueInternalUserIds.size === 1) {
        $(`#${mode}-schedule-modal form`).submit();
    } else {
        // 選択社員が１人以外の場合（複数社員、あるいは協力会社が選択された場合）計上担当モーダルを表示する
        $(`#${mode}-schedule-modal`).modal("hide");
        $("#sche-pjmgr-modal").modal("show");
    }
};
