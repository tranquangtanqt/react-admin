window.onload = function(){
    var statusVisited = document.getElementById('reception-status-visited');
    if(statusVisited.value != "0"){
        $('#u0302-work-result-openmodal').modal('show');
    }

    document.getElementById('u0302-visited-ok').addEventListener("click", function(event) {
        let receptionNo = $("u0302-reception-no").val();
        $('#u0302-work-result-openmodal').modal('hide');
        $('#u0302-dummy-modal-set-status').modal('show');
    });
}

window.u0302DeleteWorkresult = function(){
    $('#frm-delete-workresult').trigger('submit')();
}

window.u0302ShowModalDeleteManhour = function(manhourId){
    $('#u0302-delete-manhour').modal('show');
    $('#u0302-delete-manhourid').val(manhourId);
}

window.u0302DeleteManhour = function(){
    let manhourId = $('#u0302-delete-manhourid').val();
    $('#frm-delete-manhour-' + manhourId).trigger('submit')();
}

window.u0302ShowModalDeleteSignature = function(){
    $('#u0302-delete-signature').modal('show');
}

window.u0302DeleteSignature = function(){
    $('#frm-delete-signature').trigger('submit')();
}
