$(function() {
    $('#u0306-submit .submit-btn').click(function(){
        postFormPaymentType();
    })
});
window.openModalPaymentType = function(receptionNo=""){
    $('#setPaymentTypeValidError').text('');
    $('.form-select').html('');
    $('#txtReceptionNoSetpaymentType').val('');
    $('#txtTimeNowSetpaymentType').val('');
        $.ajax({
            url: `/set-paymenttype/${receptionNo}`,
            method: 'GET',
            beforeSend: function () {
                $("#loading").removeClass("d-none");
            },
            success: function(data){
                $('#btnShowModalSetpaymentType').click();
                $('#txtReceptionNoSetpaymentType').val(receptionNo);
                $('#txtTimeNowSetpaymentType').val(data.timeNow);
                for(let val of data.codeClasses){
                    if(data?.paymentType == val.key)
                        $('.form-select').append(`<option value="${val.key}" selected>${val.value}</option>`);
                    else
                        $('.form-select').append(`<option value="${val.key}">${val.value}</option>`);
                }
            },
            complete: function () {
                $("#loading").addClass("d-none");
            },
            error:function(data){
                $('#setPaymentTypeValidError').text(data.responseJSON.message);
            },
            timeout: ajaxTimeout,
        });
}

//フォームを送信する
window.postFormPaymentType = function(){
    $.ajax({
        url: '/set-paymenttype/update',
        data: $("#frmSetpaymentType").serialize(),
        method: 'PATCH',
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function(data){
            location.reload(true);
        },
        error:function(data){
            if(data.status == 422){
                $('#setPaymentTypeValidError').text(data.responseJSON.message);
            }
            if(data.status == 500){
                $('#setPaymentTypeValidError').text(data.responseJSON.message);
            }
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        timeout: ajaxTimeout,
    });
}
