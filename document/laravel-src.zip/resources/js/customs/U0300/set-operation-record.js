window.save = function (id) {
    clearAllErrMessage(id);
    $.ajax({
        url: "/set-operation-record/update",
        method: 'POST',
        data:$(`#formoperationRecord`+`${id}`).serialize(),
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        success: function(res) {
            location.reload();
        },
        error:function(errors) {
            $("#loading").addClass("d-none");
            if(errors.status == 422) {
                clearAllErrMessage(id);
                const messages = errors.responseJSON.message;
                messages.forEach(message => {
                        //Get and set error message
                    if(message.includes('record01')) {
                        $('.alertforrecord01'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record02')) {
                        $('.alertforrecord02'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record03')) {
                        $('.alertforrecord03'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record04')) {
                        $('.alertforrecord04'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record05')) {
                        $('.alertforrecord05'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record06')) {
                        $('.alertforrecord06'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record07')) {
                        $('.alertforrecord07'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record08')) {
                        $('.alertforrecord08'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record09')) {
                        $('.alertforrecord09'+`${id}`).html(message.split('|')[1]);
                    }
                    if(message.includes('record10')) {
                        $('.alertforrecord10'+`${id}`).html(message.split('|')[1]);
                    }
                });
            }
            if(errors.status == 419) {
                clearAllErrMessage();
                //show error message
                $(`#alert`+`${id}`).html(errors.responseJSON.message.split('|')[1]);
                $(`.alert`+`${id}`).show();
            }
        }
    });
}

window.clearAllErrMessage = function(id) {
    $('.invalid-feedback').html('');
    $(`.alert`+`${id}`).hide();
}
