window.onload = function () {
    $("[role=datepicker]").datepicker();
    $(".submit-btn").on("click", function () {
        $("#firstDate").text("");
        $("#lastDate").text("");
        $(".alert-danger").attr("style", "display: none");
        $(".alert-danger").text("");
        $(".alert-success").attr("style", "display: none");
        $(".alert-success").text("");
        downloadFile("/output-data/export");
    });
};
window.downloadFile = function (urlToSend) {
    $.ajax({
        url: urlToSend,
        method: "POST",
        data: $("#formPostDevice").serialize(),
        beforeSend: function () {
            $("#loading").removeClass("d-none");
        },
        complete: function () {
            $("#loading").addClass("d-none");
        },
        success: function (data, textStatus, request) {
            var blob = new Blob([data], { type: "application/octetstream" });
            var hearderName = request.getResponseHeader("Content-Disposition");
            var fileName = hearderName.split("filename=")[1];
            var isIE = false || !!document.documentMode;
            if (isIE) {
                window.navigator.msSaveBlob(blob, fileName);
            } else {
                var url = window.URL || window.webkitURL;
                link = url.createObjectURL(blob);
                var a = $("<a />");
                a.attr("download", fileName);
                a.attr("href", link);
                $("body").append(a);
                a[0].click();
                $("body").remove(a);
            }
            $(".alert-success").attr("style", "display: block !important");
            $(".alert-success").text("データ出力ダウンロード");
        },
        error: function (data) {
            if (data.status == 500) {
                $(".alert-danger").attr("style", "display: block !important");
                $(".alert-danger").text(data.responseJSON.message);
            }
            if (data.status == 422) {
                for (let pr of data.responseJSON.message) {
                    dataMessage = pr.split("|");
                    if (dataMessage[0] == "dateStart") {
                        $("#firstDate").text(dataMessage[1]);
                    } else {
                        $("#lastDate").text(dataMessage[1]);
                    }
                }
            }
        },
    });
};
