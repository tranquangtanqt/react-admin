
window.onload = function(){
    $('.submit-btn').click(function(){
    $('#loading').removeClass('d-none');
    })
}