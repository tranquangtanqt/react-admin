<x-layouts.app title="原価設定">
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/U0400/set-cost.css') }}" >
    @endpush

    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">原価設定</div>
        <a class="btn p-0 text-white" href="{{ route('receptions.finance.show', ['reception' =>$receptionNo]) }}">戻る</a>
    </div>

    <p id="show-error" class="alert alert-danger text-center d-none"></p>

    {{-- タブ内容 --}}
    <form id="frm-cost" action="{{ route('set-cost.change') }}" method="post">
        <input type="hidden" id="delele-arr" name="delete_arr" />
        <input type="hidden" id="update-arr" name="update_arr" />
        <input type="hidden" id="add-arr" name="add_arr" />
        <input type="hidden" name="reception_no" id="reception-no" value="{{ $receptionNo }}" />
        <input type="hidden" name="updated_at" value="{{ $costs->max('updated_at') }}">
        <input type="hidden" id="count-cost" name="count_cost" value="{{ $costs->count() }}">
        <input type="hidden" name="max_cost_id" id="max-cost-id" value="{{ $costs->max('id') }}">
        <input type="hidden" id="type-list"
            value="@foreach ($typeList as $type) <option value='{{ $type->key }}'>{{ $type->value }}</option> @endforeach" />
        <input type="hidden" id="material-cost-list"
            value="@foreach ($materialCostList as $materialCost) <option value='{{ $materialCost->value }}'>{{ $materialCost->value }}</option> @endforeach" />
        <input type="hidden" id="construct-cost-list"
            value="@foreach ($constructCostList as $constructCost) <option value='{{ $constructCost->value }}'>{{ $constructCost->value }}</option> @endforeach" />
        <div class="py-2 px-2 px-sm-3">
            <hr>

            <div class="row">
                <div class="col-12 col-md-1 me-md-4 me-lg-0">
                    区分
                </div>
                <div class="col-6 col-md-2">
                    名称
                </div>
                <div class="col-6 col-md-2">
                    金額
                </div>
            </div>
            @csrf

            @php
                $recordNumber = 0;
            @endphp
            @if ($costs->count() > 0)
                @foreach ($costs as $cost)
                    <div id="record-{{ $cost->id }}">
                        <input type="hidden" name="id_[{{ $cost->id }}]" value="{{ $cost->id }}">
                        <hr>

                        <div class="row align-items-baseline">
                            <div class="col-12 col-md-1 me-md-4 me-lg-0">
                                <select class="form-select u0401-width-select" name="type[{{ $cost->id }}]" style="width: 78px"
                                    onchange="fncTypeUpdate({{ $cost->id }}, this)" @if($cost->checked_flag) disabled @endif autofocus >
                                    @foreach ($typeList as $type)
                                        @if ($type->key == $cost->type)
                                            <option value="{{ $type->key }}" selected>{{ $type->value }}</option>
                                        @else
                                            <option value="{{ $type->key }}">{{ $type->value }}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-6 col-md-2 d-flex u0401-mt-2 pe-0 mt-2 mb-2">
                                <input id="name-{{ $cost->id }}" class="form-control u0401-name" type="text" name="name[{{ $cost->id }}]"
                                    value="{{ $cost->name }}" maxlength="10" @if($cost->checked_flag) disabled @endif
                                    @if($cost->type == 2) list="u0401-construct-cost-list-{{ $cost->id }}" @else list="u0401-material-cost-list-{{ $cost->id }}" @endif
                                    autocomplete="off">

                                <datalist id="u0401-material-cost-list-{{ $cost->id }}">
                                    @foreach ($materialCostList as $materialCost)
                                        <option value="{{ $materialCost->value }}">{{ $materialCost->value }}</option>
                                    @endforeach
                                </datalist>

                                <datalist id="u0401-construct-cost-list-{{ $cost->id }}">
                                    @foreach ($constructCostList as $constructCost)
                                        <option value="{{ $constructCost->value }}">{{ $constructCost->value }}</option>
                                    @endforeach
                                </datalist>
                            </div>
                            <div class="col-4 col-md-2 u0401-mt-2 pe-0 d-flex ms-md-2">
                                <input class="form-control u0401-text-right u0401-name u0401-width-122" type="text" name="amount[{{ $cost->id }}]"
                                value="{{ number_format($cost->amount, 0, '', ',') }}" maxlength="9" @if($cost->checked_flag) disabled @endif>
                                @if(!$cost->checked_flag)
                                <button class="btn" onclick="fncDelRecord({{ $cost->id }}, false)"><i class="bi bi-trash-fill" title="行を削除する"></i></button>
                                @endif
                            </div>
                        </div>

                        <x-invalid-feedback id="name-err-{{ $cost->id }}"></x-invalid-feedback>
                        <x-invalid-feedback id="type-err-{{ $cost->id }}"></x-invalid-feedback>
                        <x-invalid-feedback id="amount-err-{{ $cost->id }}"></x-invalid-feedback>
                    </div>

                    @php
                        $recordNumber = $cost->id;
                    @endphp
                @endforeach
            @else
                <div id="record-0">
                    <input type="hidden" name="id_[0]" value="0">
                    <hr>

                    <div class="row align-items-baseline">
                        <div class="col-12 col-md-1 me-md-4 me-lg-0">
                            <select class="form-select u0401-width-select" name="type_new[0]" style="width: 78px"
                                onchange="fncTypeUpdate(0, this)" autofocus >
                                @foreach ($typeList as $type)
                                    <option value="{{ $type->key }}">{{ $type->value }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-6 col-md-2 d-flex u0401-mt-2 pe-0 mt-2 mb-2">
                            <input id="name-0" class="form-control u0401-name" type="text" name="name_new[0]"
                                value="" maxlength="10" list="u0401-material-cost-list-0" autocomplete="off">

                            <datalist id="u0401-material-cost-list-0">
                                @foreach ($materialCostList as $materialCost)
                                    <option value="{{ $materialCost->value }}">{{ $materialCost->value }}</option>
                                @endforeach
                            </datalist>

                            <datalist id="u0401-construct-cost-list-0">
                                @foreach ($constructCostList as $constructCost)
                                    <option value="{{ $constructCost->value }}">{{ $constructCost->value }}</option>
                                @endforeach
                            </datalist>
                        </div>
                        <div class="col-4 col-md-2 u0401-mt-2 pe-0 d-flex ms-md-2">
                            <input class="form-control u0401-text-right u0401-name u0401-width-122" type="text" name="amount_new[0]" value="" maxlength="9">
                            <button class="btn" onclick="fncDelRecord(0, false)"><i class="bi bi-trash-fill" title="行を削除する"></i></button>
                        </div>
                    </div>

                    <x-invalid-feedback id="name_new-err-0"></x-invalid-feedback>
                    <x-invalid-feedback id="type_new-err-0"></x-invalid-feedback>
                    <x-invalid-feedback id="amount_new-err-0"></x-invalid-feedback>
                </div>
            @endif

            <div id="add-element"></div>

            <hr>
            <div class="row">
                <div class="col-md-12">
                    <button class="btn p-0" type="button" onclick="fncAddRecord()">
                        <i class="bi-plus-circle-fill f-16 text-black-50" title="行を追加する"></i>
                    </button>
                </div>
            </div>

            <div>
                <div class="col-md-12">
                    <div class="d-flex justify-content-center py-2 px-2 px-sm-3 mb-3">
                        <button id="av" type="button" class="btn submit-btn btn-save" onclick="fncSubmit()" >{{ __('確定') }}</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    @push('scripts')
        <script src="{{ mix('js/customs/U0400/set-cost.js') }}" ></script>
    @endpush
</x-layouts.app>
