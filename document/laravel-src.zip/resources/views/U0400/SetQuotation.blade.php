<x-layouts.app title="見積設定">
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/U0400/set-quotation.css') }}" >
    @endpush
    {{-- 見積設定ヘッダー --}}
   <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-1 sub-header">
       <div></div>
       <div class="p-0">見積設定</div>
       <a class="btn p-0 text-white" href="{{ route('receptions.finance.show', ['reception' =>$receptionNo]) }}">戻る</a>
   </div>
   <div class="px-2 px-sm-3">
    <form id="quotationForm" action="{{ route('quotations.update') }}" method="post">
        {{ method_field('PATCH') }}
        <div class="mb-4">
            <div class="mb-2">
                <label for="tax">{{ __('消費税区分') }}</label>
            </div>
            <div class="form-group">
                <select class="form-select tax-option" name="tax" id="tax">
                    @if ( $workReport->tax_included_flag == true )
                        <option value="1" selected>消費税込</option>
                        <option value="0">消費税抜</option>
                    @else
                        <option value="0" selected>消費税抜</option>
                        <option value="1">消費税込</option>
                    @endif
                </select>
            </div>
        </div>
        <x-invalid-feedback id="alert" class="p-0"></x-invalid-feedback>
        <hr class="mb-1">
        <div class="quotation-header">
            <div class="d-flex row1">
                <label class="col1" for="No">{{ __('作業Ｎｏ・品番') }}</label>
                <label class="col2" for="Quantity">{{ __('数量') }}</label>
                <label class="col3" for="Unit">{{ __('単位') }}</label>
            </div>
            <div class="d-flex row2">
                <label class="col4" for="Name">{{ __('名称') }}</label>
                <label class="col5" for="Amount">{{ __('金額') }}</label>
            </div>
        </div>
        <hr class="mt-1">
            <div class="quotation-body">
                @csrf
                <input type="hidden" name="updated_at" value="{{ $workReport->updated_at }}" readonly>
                <input type="hidden" name="reception_no" value="{{ $receptionNo }}" id="receptionNo" readonly>
                <input type="hidden" name="deletedIds" id="deletedIds" value="" readonly>
                @foreach ( $quotations as $quotation )
                @php
                    $id = $quotation->id;
                @endphp
                    <input type="hidden" name="updatedAt[{{ $id }}]" value="{{ $quotation->updated_at }}" readonly>
                    <div id="record{{ $id }}">
                        <input type="hidden" class="id" name="id[{{ $id }}]" value="{{ $id }}" readonly>
                        <div class="quotation-record">
                            <div class="d-flex row1">
                                <div class="col1">
                                    <input class="form-control"
                                            type="text"
                                            name="workNo[{{ $id }}]"
                                            value="{{ $quotation->work_no }}"
                                            maxlength="7">
                                </div>
                                <div class="col2">
                                    <input class="form-control text-end"
                                            type="text"
                                            name="quantity[{{ $id }}]"
                                            value="{{ $quotation->quantity == null?"":number_format($quotation->quantity,2) }}"
                                            min = 0
                                            step="0.01"
                                            maxlength="6">
                                </div>
                                <div class="d-flex col3">
                                    <input class="form-control"
                                            type="text"
                                            name="unit[{{ $id }}]"
                                            value="{{ $quotation->unit }}"
                                            maxlength="2"
                                            list="unit-list-{{ $id }}"
                                            autocomplete="off">
                                    <datalist id="unit-list-{{ $id }}">
                                        @foreach ($unitTemplates as $unitTemp)
                                            <option value="{{ $unitTemp->value }}">{{ $unitTemp->value }}</option>
                                        @endforeach
                                    </datalist>
                                </div>
                            </div>
                            <div class="d-flex row2">
                                <div class="d-flex col4">
                                    <input class="form-control"
                                            type="text"
                                            name="name[{{ $id }}]"
                                            value="{{ $quotation->name }}"
                                            maxlength="10"
                                            list="name-list-{{ $id }}"
                                            autocomplete="off">
                                    <datalist id="name-list-{{ $id }}">
                                        @foreach ($nameTemplates as $nameTemp)
                                            <option value="{{ $nameTemp->value }}">{{ $nameTemp->value }}</option>
                                        @endforeach
                                    </datalist>
                                </div>
                                <div class="col5 last-col">
                                    <input class="form-control text-end amount-input"
                                            type="text"
                                            name="amount[{{ $id }}]"
                                            value="{{ $quotation->amount == null?"":number_format($quotation->amount, 0, ',') }}"
                                            maxlength="9">
                                </div>
                                <div>
                                    <a class="btn" onclick="delRecord({{ $id }})"><i class="bi bi-trash-fill" title="行を削除する"></i></a>
                                </div>
                            </div>
                        </div>
                        <x-invalid-feedback class="workNo{{ $id }}"></x-invalid-feedback>
                        <x-invalid-feedback class="quantity{{ $id }}"></x-invalid-feedback>
                        <x-invalid-feedback class="unit{{ $id }}"></x-invalid-feedback>
                        <x-invalid-feedback class="name{{ $id }}"></x-invalid-feedback>
                        <x-invalid-feedback class="amount{{ $id }}"></x-invalid-feedback>
                        <x-invalid-feedback class="amount-required"></x-invalid-feedback>
                        <hr class="mt-4">
                    </div>
                @endforeach
            </div>

        <div class="add-new-btn">
            <a class="btn p-0" onclick="addNewRecord()"><i class="bi-plus-circle-fill f-16 text-black-50" title="行を追加する"></i></a>
        </div>
    </form>
    <div class="d-flex justify-content-center py-2 px-2 px-sm-3 mb-3">
        <button class="btn submit-btn btn-save" onclick="save()" >{{ __('確定') }}</button>
    </div>
    </div>
    <input type="hidden" name="max-record" id="max-record" value="{{ $quotations->max('id') }}" readonly>
    <div class="d-none" id="tempNameOption">
        @foreach ( $nameTemplates as $nameTemp )
            <option value="{{ $nameTemp->value }}">{{ $nameTemp->value }}</option>
        @endforeach
    </div>
    <div class="d-none" id="tempUnitOption">
        @foreach ( $unitTemplates as $unitTemp )
            <option value="{{ $unitTemp->value }}">{{ $unitTemp->value }}</option>
        @endforeach>
    </div>
    @push('scripts')
        <script src="{{ mix('js/U0400/set-quotation.js') }}"></script>
    @endpush
</x-layouts.app>
