<x-layouts.app>
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/U0400/check-cost.css') }}" >
    @endpush

    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">原価チェック</div>
        <a class="btn p-0 text-white" href="{{ route('receptions.finance.show', ['reception' => $receptionNo]) }}">戻る</a>
    </div>

    @if(Session::has('messageErr'))
        <p class="alert alert-danger text-center">{{ Session::get('messageErr') }}</p>
    @endif

    {{-- タブ内容 --}}
    <form id="frm-cost" action="{{ route('check-cost.update') }}" method="post">
        @csrf
        <input type="hidden" name="receptionNo" value="{{ $receptionNo }}">
        <input type="hidden" name="updated_at" value="{{ $costs->max('updated_at') }}">
        <div class="py-2 px-2 px-sm-3">
            <div class="row">
                <div class="col-md-4">
                    <b>{{ $typeList[0]->value }}</b>
                    @foreach ($costs as $cost)
                    @if ($cost->type == 1)
                        <div class="row mt-1">
                            <div class="col-6 col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="{{ $cost->id }}" name="checked_flag[{{ $cost->id }}]"
                                        id="checkbox-{{ $cost->id }}"  @if ($cost->checked_flag) checked @endif @if (!$authFlg) disabled @endif />
                                    <label for="checkbox-{{ $cost->id }}">
                                        {{ $cost->name }}
                                    </label>
                                </div>
                            </div>
                            <div class="col-6 col-md-5 u401-text-right">
                                {{ number_format($cost->amount , 0, '', ',')}} 円
                            </div>
                        </div>
                    @endif
                    @endforeach
                </div>

                <div class="col-md-4 u4000-mt">
                    <b>{{ $typeList[1]->value }}</b>
                    @foreach ($costs as $cost)
                    @if ($cost->type == 2)
                        <div class="row mt-1">
                            <div class="col-6 col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="{{ $cost->id }}" name="checked_flag[{{ $cost->id }}]"
                                            id="checkbox-{{ $cost->id }}" @if ($cost->checked_flag) checked @endif @if (!$authFlg) disabled @endif />
                                    <label for="checkbox-{{ $cost->id }}">
                                        {{ $cost->name }}
                                    </label>
                                </div>
                            </div>
                            <div class="col-6 col-md-5 u401-text-right">
                                {{ number_format($cost->amount , 0, '', ',')}} 円
                            </div>
                        </div>
                    @endif
                    @endforeach
                </div>
                <div class="col-md-4"></div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="d-flex justify-content-center py-2 px-2 px-sm-3 my-3" id="check-cost-submit">
                        @if ($authFlg)
                            <x-submit-button type="button">確定</x-submit-button>
                        @else
                            <x-submit-button disabled>確定</x-submit-button>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </form>

    @push('scripts')
        <script src="{{ mix('js/customs/U0400/check-cost.js') }}" ></script>
    @endpush
</x-layouts.app>
