@props(['modalId' => 'modal',
    'title' => '',
    'btnLabel' => '確定',
    'action' => '#',
    'method' => 'POST',
    'loading' => 'on',
    ])
    <div class="modal fade" id="{{ $modalId }}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="{{ $modalId }}" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content pb-3">
                <div class="modal-header border-bottom-0">
                    <h5 class="modal-title d-flex align-items-center">
                        <span class="me-2">{{ $title }}</span>
                        @isset($titleButton)
                            {{ $titleButton }}
                        @endisset
                    </h5>

                    @if(isset($rightButton))
                        {{ $rightButton }}
                    @else
                        <button type="button" class="btn" data-bs-dismiss="modal" aria-label="back">戻る</button>
                    @endif

                </div>

                @isset($aboveForm)
                    {{ $aboveForm }}
                @endisset

                <x-form method="{{ $method }}" action="{{ $action }}" class="w-100" loading="{{ $loading }}"
                    id="{{ $modalId . '-form' }}"
                    {{ $attributes->filter(fn ($value, $key) => $key == 'onsubmit') }}>
                    <div class="modal-body">

                        {{ $slot }}

                    </div>
                    <div class="modal-footer border-top-0 justify-content-center text-white">
                        @if(isset($bottomButton))
                            {{ $bottomButton }}
                        @else
                            <x-submit-button>{{ $btnLabel }}</x-submit-button>
                        @endif
                    </div>
                </x-form>

            </div>
        </div>
    </div>
