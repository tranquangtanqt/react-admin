@props([
    'id' => '',
    'title' => '',
    'lineTop' => true,
    ])

    <div {{ $attributes->merge(['class' => 'mt-4 my-3'])}}>
        @if($lineTop)
            <hr class="mb-2">
        @endif
        <div id="{{ $id }}">
            <div class="d-flex justify-content-between">
                <h2>{{ $title }}</h2>
                {{ $titleIcon ?? null }}
            </div>
            <div class="mx-3 text-muted">{{ $slot ?? '' }}</div>
        </div>
    </div>
