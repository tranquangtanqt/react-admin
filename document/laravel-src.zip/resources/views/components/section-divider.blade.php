@props([
    'id' => '',
    'title' => '',
    'btnName' => '追加',
    'linkTo' => 'modal',
    'modalId' => '',
    'href' => '#',
    'lineTop' => true,
    'titleIcon' => '',
    'class' => '',
    ])

    <div class="{{ $class ? $class : 'mt-5 mb-3'}}">
        @if($lineTop)
            <hr class="mb-2">
        @endif
        <div id="{{ $id }}" class="d-flex justify-content-between">
            <div class="fw-bold">{{ $title }}{{ $titleIcon }}</div>
            @if($linkTo === 'modal')
                <button type="button" class="btn p-0" data-bs-toggle="modal"
                    data-bs-target="#{{ $modalId }}">{{ $btnName }}</button>
            @endif

            @if($linkTo === 'page')
                <a href="{{ $href }}" class="btn p-0">{{ $btnName }}</a>
            @endif

            @if($linkTo === 'js')
                <button type="button" class="btn p-0"
                {{ $attributes->filter(fn ($value, $key) => in_array($key, ['onclick', 'data-target-route'])) }}
                >{{ $btnName }}</button>
            @endif
        </div>
    </div>
