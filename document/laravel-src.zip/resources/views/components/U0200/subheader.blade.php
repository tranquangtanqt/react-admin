@props([
	'receptionNo' => '',
	])
{{-- 受付情報ヘッダー --}}
<div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
	{{-- 印刷ボタン --}}
	<x-U0200.print-button :receptionNo="$receptionNo"></x-U0200.print-button>
    <div class="p-0">受付情報</div>
    <button class="btn p-0 text-white" onclick="if (window.opener){window.opener.location.reload()};window.close();if(!window.closed){location.href='{{ route('dashboard') }}';}">戻る</button>
</div>
