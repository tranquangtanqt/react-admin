
<style type="text/css">
.dropdown-menu .dropdown-menu{
		margin-left:0.7rem; margin-right:0.7rem; margin-bottom: .5rem;
}
</style>


<script type="text/javascript">
	document.addEventListener("DOMContentLoaded", function(){
		document.querySelectorAll('.header-print').forEach(function(element){
			element.addEventListener('click', function (e) {
			  e.stopPropagation();
			});
            // make it as accordion
            // close all inner dropdowns when parent is closed
            element.querySelectorAll('.navbar .dropdown').forEach(function(everydropdown){
                everydropdown.addEventListener('hidden.bs.dropdown', function () {
                    // after dropdown is hidden, then find all submenus
                        this.querySelectorAll('.submenu').forEach(function(everysubmenu){
                        // hide every submenu as well
                        everysubmenu.style.display = 'none';
                        });
                })
            });

            // サブメニューのオープンクローズ
            element.querySelectorAll('.dropdown-menu a').forEach(function(element){
                element.addEventListener('click', function (e) {
                    let nextEl = this.nextElementSibling;
                    if(nextEl && nextEl.classList.contains('submenu')) {
                        e.preventDefault();
                        console.log(nextEl);
                        if(nextEl.style.display == 'block'){
                            nextEl.style.display = 'none';
                        } else {
                            nextEl.style.display = 'block';
                        }

                    }
                });
            })
		})

	});
    // ドロップダウンクローズ
    function close_dropdown(element){
        // 印刷をクローズ
        document.getElementById('btnHeaderPrint').click();
        if (element){
            // 自身の親をクローズ
            element.parentNode.parentNode.parentNode.firstElementChild.click();
        }
    }
</script>
<ul class="navbar-nav header-print">
    <li class="nav-item dropdown">
        <a class="nav-link p-0 text-white" href="#"  role="button" data-bs-toggle="dropdown" aria-expanded="false" id="btnHeaderPrint">印刷</a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item
                    @if($schedules->isEmpty())
                        disabled
                    @endif
                    " href="#">作業完了証明書（お客様控え）</a>
                <ul class="submenu dropdown-menu border-0 p-0">
                @foreach($schedules as $schedule)
                    <li><a class="dropdown-item" href="/certificate-customer/{{$schedule->id}}?close=true" target=”_blank” onclick="close_dropdown(this);">・{{$schedule->date->format('Y/m/d')}}</a></li>
                @endforeach
                </ul>
            </li>
            <li><a class="dropdown-item" href="{{route('certificate-delivery.index', $reception->no)}}" onclick="close_dropdown(null);">作業完了証明書（納品書）</a></li>

            @if (!userIsPicExternal())
            <li><a class="dropdown-item" href="{{route('certificate-internal.index', $reception->no)}}" onclick="close_dropdown(null);">作業完了証明書（社内用）</a></li>
            @endif
        </ul>
    </li>
</ul>
