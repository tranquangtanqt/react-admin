@props([
'active' => 'info',
])
<div class="row g-0">
    <ul class="nav nav-pills nav-fill" id="info-tab" role="tablist" style="max-width: 400px;">
        <li class="nav-item ps-1" role="presentation">
            <a href="{{ route('info.show', ['reception' => $receptionNo]) }}" class="nav-link {{ $active === 'info' ? 'active' : '' }}" role="tab" aria-controls="info" aria-selected="true">基本情報</a>
        </li>
        <li class="nav-item px-1" role="presentation">
            <a href="{{ route('receptions.schedule-result.show', ['reception' => $receptionNo]) }}" class="nav-link {{ $active === 'schedule-result' ? 'active' : '' }}" role="tab" aria-controls="schedule-result" aria-selected="false">訪問予定・実績</a>
        </li>
        @if (!userIsPicExternal())
        <li class="nav-item pe-1" role="presentation">
            <a href="{{ route('receptions.finance.show', ['reception' => $receptionNo]) }}" class="nav-link {{ $active === 'finance' ? 'active' : '' }}" role="tab" aria-controls="finance" aria-selected="false">金額</a>
        </li>
        @endif
    </ul>
</div>
