<div class="rounded-3 card-frame schedule-card d-flex flex-column justify-content-between mb-4 me-0 mx-sm-3">
    <a href="#" data-target-route="{{ route('set-schedule.show', ['schedule' => $schedule->id]) }}" class="btn p-2 flex-fill d-flex flex-column align-items-stretch" onclick="fetchScheduleModal(event, this, 'read');">
        <div class="d-flex justify-content-between">
            <div class="fw-bold lead">
                {{ $schedule->date->format('Y/m/d') }}
            </div>
            @if ($editable)
            {{-- CHG 20220406 Ishino OT-021 ボタン名変更「編集」->「訪問予定編集」--}}
            <button class="btn bi-pencil-fill f-16 text-black-50" data-target-route="{{ route('set-schedule.edit', ['schedule' => $schedule->id]) }}" onclick="fetchScheduleModal(event, this, 'edit');"
                title="訪問予定を変更する"></button>
            @endif
        </div>
        <div class="d-flex justify-content-evenly my-1">
                @foreach($slotTitles as $key => $value )
                    @php
                        $slotIsUsed = $schedule->labeledSlots->firstWhere('key', $key) != null;
                    @endphp
                    <div class="sche-card-slot" style="background-color:{{ $slotIsUsed ? $slotColors[$key] : '#f0f0f0' }};">
                        <div>{{ $slotIsUsed ? $value : '' }}</div>
                    </div>
                @endforeach
        </div>
        <div class="d-flex justify-content-start align-items-center my-2 px-2">
            @foreach($schedule->namedUsers as $user)
                @if($loop->index == 5)
                    <div class="user-info me-2">
                        <div class="w-100 text-center">他・・・</div>
                    </div>
                @break
                @endif
                <x-user-profile src="{{ avatarByFileId($user->file_id) }}" class="me-3" title="{{ $user->name }}">{{ $user->short_name }}
                </x-user-profile>
            @endforeach
        </div>
        <div class="f-16 flex-fill text-truncate text-truncate-2 my-1 px-2 text-start fw-bold text-primary">
            {{ $schedule->content }}
        </div>
        <div class="my-1">
            <div class="item-name mb-1">作業実績</div>
            <div class="row px-2">
                <div class="col-4 text-center f-12">
                    実績{{ $schedule->has_result ?? 'なし' }}
                </div>
                <div class="col-4 text-center f-12">
                    工数入力{{ $schedule->has_manhour ?? 'なし' }}
                </div>
                <div class="col-4 text-center f-12">
                    署名{{ $schedule->has_sign ?? 'なし' }}
                </div>
            </div>
        </div>

    </a>
    <div class="px-2 py-1 border-top d-flex justify-content-center">
        {{-- CHG 20220406 Ishino OT-021 ボタン名変更「作業実績」->「作業内容入力」--}}
        <a class="card-btn btn p-0 bg-settle text-white px-2" href="{{route('result-info.index', ['scheduleId' => $schedule->id] )}}">作業内容入力</a>
    </div>
</div>
