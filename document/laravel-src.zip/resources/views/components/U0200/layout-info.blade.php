@props([
    'activeTab' => 'info',
    ])
    <x-layouts.app title="受付情報">

        {{-- 受付情報ヘッダー --}}
        <x-U0200.subheader reception-no="{{ $receptionNo }}"></x-U200.subheader>

        {{-- タブナビゲーション --}}
        <x-U0200.info-tabs reception-no="{{ $receptionNo }}" :active="$activeTab"></x-U200.info-tabs>

        {{-- タブ内容 --}}
        <div class="py-2 px-2 px-sm-3" id="tab-content">
            {{ $slot }}
        </div>

        {{-- 通知モーダル --}}
        <x-confirm-modal />

        @push('scripts')
            @if(session('active_modal_id'))
                <script>
                    $(window).on('load', function () {
                        $("#{{ session('active_modal_id') }}").modal('show');
                    });

                </script>
            @endif

            @isset($scriptSlot)
                {{ $scriptSlot }}
            @endisset
        @endpush

    </x-layouts.app>
