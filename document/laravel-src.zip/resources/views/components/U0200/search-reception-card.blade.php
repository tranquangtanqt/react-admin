<div class="card-border card-shadow card-frame rounded mb-4 mx-sm-3" style="{{ $style }}">
    <div class="d-flex flex-column justify-content-between dash-card-width h-100">
        <a href="{{ route('info.show', [ $reception->no ]) }}"
            target="reception"
            class="btn w-100 text-start p-2 pb-1">
            <div class="base-dash-card-height d-flex flex-column justify-content-between">
                <div class="w-100 d-flex flex-column justify-content-between flex-fill min-h-0 p-0">
                    <div class="d-flex flex-column min-h-0">
                        <div class="row justify-content-between">
                            <div class="col-8 text-start f-10 d-flex align-items-start flex-grow-1">
                                @php
                                    $canceled = !is_null($reception->canceled_at);
                                @endphp
                                <div @class([
                                    'me-3',
                                    'text-danger line-through' => $canceled,
                                ]) title="{{ $canceled ? '受付がキャンセルされました。': '受付番号：' . $reception->no }}">{{ $reception->no }}</div>
                                <div class="bg-main px-3 rounded-pill text-center">
                                    {{ $reception->work_type != config('constants.work.none') ? $reception->work_type_name : '' }}
                                </div>
                            </div>
                            @if($warning)
                                <div class="col-4 text-end">
                                    <span title="物件がキャンセルされました。">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </span>
                                </div>
                            @endif
                        </div>
                        <div class="row">
                            <div class="col-6 d-flex align-items-center f-10">
                                <span
                                    class="me-2">受付日</span><span>{{ $reception->date->format('Y/m/d') }}</span>
                            </div>
                            <div class="col-6 d-flex align-items-center f-10">
                                <span
                                    class="me-2">計上担当</span><span>{{ $reception->l2_pjmgr_name ?? $reception->rec_pjmgr_name }}</span>
                            </div>
                        </div>
                        <div class="row min-h-0 my-0">
                            <div class="col f-16 text-start py-1 text-truncate text-truncate-2">
                                {{ $reception->content }}
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="row">
                            <div class="col-7 d-flex align-items-start text-start f-10">
                                <span class="card-item-name">お客様</span>
                                <span class="text-truncate">{{ $reception->field_name }}</span>
                            </div>
                            <div class="col-5 d-flex flex-column f-10">
                                <div class="text-start">
                                    <span class="me-2">TEL</span><span>{{ $reception->field_tel }}</span>
                                </div>
                                <div class="text-start">
                                    <span class="me-2">TEL</span><span>{{ $reception->field_mobile_tel }}</span>
                                </div>
                            </div>
                        </div>

                        <div class="row ">
                            <div class="col d-flex f-10 text-start">
                                <span class="card-item-name">依頼元</span>
                                <span class="text-truncate">{{ $reception->client_name }}</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col d-flex f-10 text-start ">
                                <span class="card-item-name">コメント</span><span
                                    class="text-truncate">{{ $reception->oldestComment?->comment }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>
