@props(['type' => 'submit',
    'class'=>"btn submit-btn"
    ])
    <button type="{{ $type }}" class="{{ $class }}" {{ $attributes }}>{{ $slot }}</button>
