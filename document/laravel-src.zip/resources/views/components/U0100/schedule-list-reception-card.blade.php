<div class="schedule-card schedule-card-height card-border card-shadow card-frame rounded mb-4 mx-sm-3"
    {{ $attributes->filter(fn ($value, $key) => $key == 'style') }}>
    <a href="{{ route('info.show', $schedule->reception_no) }}" target="reception"
        class="btn p-2 flex-fill d-flex flex-column align-items-stretch h-100">
        <div class="text-start f-10">
            {{ $schedule->reception_no }}
        </div>
        <div class="text-start f-12 text-truncate my-1 f-16 text-primary">{{ $schedule->l2Reception->content }}</div>
        <div class="row my-1 f-10 w-100">
            <div class="col-10 list-card-item-grid text-start">
                <div>お客様名</div>
                <div class="text-truncate fw-bold">{{ $schedule->l2Reception->field_name }}</div>
                <div>依頼元</div>
                <div class="text-truncate fw-bold">{{ $schedule->l2Reception->client_name }}</div>
            </div>
            <div class="col-2 d-flex flex-column align-items-center">
                <x-schedule-slot-colored style="background-color: {{ $slotColors[$schedule->slot_type] }};">
                    {{ $slotTitles[$schedule->slot_type] }}</x-schedule-slot-colored>
            </div>
        </div>
        <div class="row f-10 w-100">
            <div class="col list-card-item-grid text-start">
                <div>コメント</div>
                @php
                    $hasComment = strlen($schedule->reception->oldestComment?->comment) > 0;
                @endphp
                <div>
                    <div @class([
                        'text-truncate border rounded-pill bg-success text-white px-2 f-12 d-inline-block' => $hasComment,
                    ]) style="max-width: 100%;">{{ $schedule->reception->oldestComment?->comment }}
                    </div>
                </div>
                <div>訪問担当</div>
                <div class="text-truncate fw-bold">
                    {{ $schedule->namedUsers?->implode('short_name', '、') }}
                </div>
            </div>
        </div>
        <div class="text-start f-12 text-truncate">{{ $schedule->content }}</div>

    </a>
</div>
