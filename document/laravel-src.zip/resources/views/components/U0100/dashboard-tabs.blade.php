@props([
    'active' => 'dashboard',
    ])
    <div class="row g-0 mt-1 px-1 px-sm-3">
        <ul class="nav nav-pills dashboard-tab" id="dashboard-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <a href="{{ route('dashboard') }}"
                    class="nav-link {{ $active === 'dashboard' ? 'active' : '' }}"
                    role="tab" aria-controls="dashboard" aria-selected="true">ダッシュボード</a>
            </li>
            <li class="nav-item" role="presentation">
                <a href="{{ route('on-hold.index') }}"
                    class="nav-link {{ $active === 'onhold' ? 'active' : '' }}"
                    role="tab" aria-controls="onhold" aria-selected="false">保留受付</a>
            </li>
            <li class="nav-item" role="presentation">
                <a href="{{ route('schedule-weekly.index') }}"
                    class="nav-link {{ $active === 'schedule' ? 'active' : '' }}"
                    role="tab" aria-controls="schedule" aria-selected="false">スケジュール</a>
            </li>
            <li class="nav-item" role="presentation">
                <a href="{{ route('search-reception.index') }}"
                    class="nav-link {{ $active === 'search' ? 'active' : '' }}"
                    role="tab" aria-controls="search" aria-selected="false">受付検索</a>
            </li>
        </ul>
    </div>
