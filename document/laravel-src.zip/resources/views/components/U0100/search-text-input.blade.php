<div class="search-form-container">
    <div>{{ $title }}</div>
    <div>
        <input
            {{ $attributes->merge(['class' => 'form-control', 'type' => 'text']) }}>
    </div>
</div>
