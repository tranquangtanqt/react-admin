<div class="drag bg-white card-border card-frame mb-3 mx-1" style="width: 265px;"
    data-target-route="{{ route('set-schedule.create', [$reception]) }}" >
    <a href="{{ route('info.show', $reception) }}" class="btn w-100 p-2 pt-1 m-0 text-start"
        target="reception">
        <div class="d-flex justify-content-between align-items-center">
            <div class="row f-10">
                <div name="reception_no" class="col-4">{{ $reception->no }}</div>
                <div class="col-auto">受付日</div>
                <div class="col-3">
                    {{ $reception->date?->format('Y/m/d') }}</div>
            </div>
            <x-form-button action="{{ route('schedule-weekly.togglePin', $reception) }}"
                onsubmit="submitTogglePin(event, this)" class="btn col-auto text-end p-0 m-0">
                @if($reception->pinned_flag)
                    <i class="bi bi-pin-angle-fill"></i>
                @else
                    <i class="bi bi-pin-angle"></i>
                @endif
            </x-form-button>
        </div>
        <div class="row f-12">
            <p class="col-12 text-truncate text-truncate-2 m-0 text-primary fw-bold" title="{{ $reception->content }}">
                {{ $reception->content }}</p>
        </div>
        <div class="f-10">
            <div class="d-flex">
                <div class="col-3">お客様名</div>
                <div class="col-9 text-truncate fw-bold" title="{{ $reception->field_name }}">
                    {{ $reception->field_name }}</div>
            </div>
            <div class="d-flex">
                <div class="col-3">依頼元</div>
                <div class="col-9 text-truncate fw-bold" title="{{ $reception->client_name }}">
                    {{ $reception->client_name }}</div>
            </div>
            <div class="d-flex">
                <div class="col-3">コメント</div>
                <p class="col-9 text-truncate m-0" title="{{ $reception->oldestComment?->comment }}">
                    {{ $reception->oldestComment?->comment }}</p>
            </div>
        </div>
    </a>
</div>
