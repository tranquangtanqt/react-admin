<x-form-modal modal-id="select-user-modal" title="スケジュール表示設定"
    action="{{ route('schedule-weekly.index') }}" method="GET" btn-label="設定" onsubmit="">

    {{-- 担当者 --}}
    <div class="row">
        <label for="select_user" class="form-label">ユーザー</label>
    </div>

    <div class="schedule-condition-grid">
        @foreach($users as $user)
            {{-- 担当者リスト --}}
            <label for="select_user_{{ $user->id }}" class="d-flex justify-content-center cursom-pointer">
                <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden
                    id="select_user_{{ $user->id }}">
                <x-user-profile src="{{ $user->avatar }}" title="{{ $user->name }}"
                    id="select_user_{{ $user->id }}-icon" :icon="true" :checked="false">
                    {{ $user->short_name }}
                </x-user-profile>
            </label>
        @endforeach
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="select_users_error"></x-invalid-feedback>
    </div>

    <input type="hidden" name="start_date" value="{{ $date }}">

    {{-- javascript --}}
    <script>
    </script>

</x-form-modal>
