<div class="card-border card-shadow card-frame rounded mb-4 mx-sm-3">
    <div class="d-flex flex-column justify-content-between dash-card-width h-100">
        <a href="{{ route('info.show', [$reception->no]) }}" target="reception" class="btn w-100 text-start p-2 pb-1">
            <div class="base-dash-card-height d-flex flex-column justify-content-between">
                <div class="w-100 d-flex flex-column justify-content-between flex-fill min-h-0 p-0">
                    <div class="d-flex flex-column min-h-0">
                        <div class="row justify-content-between">
                            <div class="col-8 text-start f-10 d-flex align-items-start flex-grow-1">
                                @php
                                    $canceled = !is_null($reception->canceled_at);
                                @endphp
                                <div @class([
                                    'me-3',
                                    'text-danger line-through' => $canceled,
                                ]) title="{{ $canceled ? '受付がキャンセルされました。': '受付番号：' . $reception->no }}">{{ $reception->no }}</div>
                                <div class="bg-main px-3 rounded-pill text-center">
                                    {{ $reception->work_type != config('constants.work.none') ? $reception->work_type_name : '' }}
                                </div>
                            </div>
                            @if ($warning)
                                <div class="col-4 text-end">
                                    <span title="物件がキャンセルされました。">
                                        <i class="bi bi-trash-fill text-danger"></i>
                                    </span>
                                </div>
                            @endif
                        </div>
                        <div class="row">
                            <div class="col-6 d-flex align-items-center f-10">
                                <span
                                    class="me-2">受付日</span><span>{{ $reception->date->format('Y/m/d') }}</span>
                            </div>
                            <div class="col-6 d-flex align-items-center justify-content-end f-10">
                                <span
                                    class="me-2">計上担当</span><span>{{ $reception->l2_pjmgr_name ?? ($reception->rec_pjmgr_name ?? '未定') }}</span>
                            </div>
                        </div>
                        <div class="row min-h-0 my-0">
                            <b class="col f-16 text-start py-1 text-truncate text-truncate-2 text-primary">
                                {{ $reception->content }}
                            </b>
                        </div>
                    </div>

                    <div>
                        <div class="row">
                            <div class="col-8 d-flex align-items-start text-start f-10">
                                <span class="card-item-name">お客様</span>
                                <span class="fw-bold f-12 text-truncate"
                                    title="{{ $reception->field_name }}">{{ $reception->field_name }}</span>
                            </div>
                            <div class="col-4 d-flex flex-column f-10">
                                <div class="text-end">
                                    <span>{{ $reception->field_tel }}</span>
                                </div>
                                <div class="text-end">
                                    <span>{{ $reception->field_mobile_tel }}</span>
                                </div>
                            </div>
                        </div>

                        <div class="row ">
                            <div class="col d-flex f-10 text-start">
                                <span class="card-item-name">依頼元</span><span
                                    class="fw-bold f-12 text-truncate">{{ $reception->client_name }}</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col d-flex align-items-center f-10 text-start ">
                                <span class="card-item-name">コメント</span>
                                @php
                                    $hasComment = strlen($reception->oldestComment?->comment) > 0;
                                @endphp
                                <span @class([
                                    'text-truncate border rounded-pill bg-success text-white px-2 mt f-12' => $hasComment,
                                ])>{{ $reception->oldestComment?->comment }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @if ($schedule == 'on')
                <div class="row">
                    <div class="col d-flex f-10 text-start">
                        <span
                            class="card-item-name">訪問日</span><span>{{ $reception->sche_date->format('Y/m/d') }}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col d-flex f-10 text-start">
                        <span
                            class="card-item-name">時間帯</span><span>{{ $reception->slots?->implode('value', '、') }}</span>
                    </div>
                </div>
                <div class="row">
                    <div class="col d-flex f-10 text-start">
                        <span
                            class="card-item-name">訪問担当</span><span>{{ $reception->scheduleUsers?->implode('short_name', '、') }}</span>
                    </div>
                </div>
                <p class="f-16 mb-0 text-truncate text-truncate-2">{{ $reception->sche_content }}
                </p>
            @endif
            @if ($reminder == 'on')
                <p class="f-16 mt-2 mb-0 text-truncate text-truncate-2">{{ $reception->remind_memo }}
                </p>
            @endif
        </a>
        @if ($buttons->isNotEmpty())
            <div class="px-2 py-1 border-top d-flex justify-content-around ">

                {{-- 原価設定ボタン --}}
                @if ($buttons->contains('cost'))
                    <a target="reception" href="{{ route('set-cost.index', $reception) }}"
                        class="card-btn btn btn-settle text-white">
                        <span>原価設定</span>
                    </a>
                @endif

                {{-- 作業実績設定ボタン --}}
                @if ($buttons->contains('result'))
                    <a target="reception"
                        href="{{ route('result-info.index', ['scheduleId' => $reception->schedule_id]) }}"
                        class="card-btn btn btn-settle text-white">
                        <span>作業実績設定</span>
                    </a>
                @endif

                {{-- 計上担当設定ボタン --}}
                @if ($buttons->contains('pjmgr'))
                    <button type="button" class="card-btn btn btn-settle text-white"
                        data-target-route="{{ route('set-project-manager.edit', [$reception]) }}"
                        onclick="fetchSetProjectManagerModal(this);">
                        <span>計上担当設定</span>
                    </button>
                @endif

                {{-- 訪問予定設定ボタン --}}
                @if ($buttons->contains('schedule'))
                    <button type="button" class="card-btn btn btn-settle text-white"
                        data-target-route="{{ route('set-schedule.create', [$reception]) }}"
                        onclick="fetchScheduleModal(event, this, 'add');">
                        <span>訪問予定設定</span>
                    </button>
                @endif

                {{-- 状態設定ボタン --}}
                @if ($buttons->contains('status'))
                    <button type="button" class="card-btn btn btn-settle text-white"
                        data-target-route="{{ route('set-status.edit', [$reception->status]) }}"
                        onclick="fetchSetStatusModal(this);">
                        <span>受付状態変更</span>
                    </button>
                @endif

                {{-- コメント設定ボタン --}}
                @if ($buttons->contains('comment'))
                    <button type="button" class="card-btn btn btn-settle text-white"
                        onclick="openModalComment({{ $reception->no }});">
                        <span>コメント設定</span>
                    </button>
                @endif
            </div>
        @endif
    </div>
</div>
