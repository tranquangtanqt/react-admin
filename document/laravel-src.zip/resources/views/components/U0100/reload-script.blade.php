<script>
        var reloadtime = {{ env('RELOAD_TIME') }}+0;

        if (Number.isInteger(reloadtime)) {
            if (reloadtime < 10000) {
                reloadtime = 10000; // 最低10秒
            }
            //alert(reloadtime);
        } else {
            reloadtime = 300000; // デフォルト5分
        }
        var time = new Date().getTime();

        $(document.body).bind("mousemove keypress", function(e) {
            time = new Date().getTime();
        });

        function refresh() {
            if (new Date().getTime() - time >= reloadtime)
                window.location.reload(true);
            else
                setTimeout(refresh, 10000);
        }

        setTimeout(refresh, 10000);
    </script>