{{-- 更新権限持っている場合 --}}
@can('update', $schedule)
    @php
    $targetRoute = route('schedule-setting.edit', $schedule);
    @endphp
@endcan
<div class="schedule-card schedule-card-height card-border card-shadow card-frame rounded mb-4 mx-sm-3"
    {{ $attributes->filter(fn($value, $key) => $key == 'style') }}>
    <button class="btn p-2 flex-fill d-flex flex-column align-items-stretch w-100 h-100"
        data-target-route="{{ $targetRoute ?? route('schedule-setting.show', $schedule) }}"
        onclick="fetchScheduleSettingModal(event, this);">
        <div class="text-start f-10">件名</div>
        <div class="text-start f-12 text-truncate my-1 f-16 text-primary">{{ $schedule->title }}</div>
        <div class="row my-1 f-10 w-100">
            <div class="col-10 list-card-item-grid text-start">
                <div>予定区分</div>
                <div class="text-truncate">{{ $scheduleTypes[$schedule->schedule_type] }}</div>
            </div>
            <div class="col-2 d-flex flex-column align-items-center">
                <x-schedule-slot-colored style="background-color: {{ $slotColors[$schedule->slot_type] }};">
                    {{ $slotTitles[$schedule->slot_type] }}</x-schedule-slot-colored>
            </div>
        </div>
        <div class="row f-10 w-100">
            <div class="col list-card-item-grid text-start">
                <div>担当</div>
                <div class="text-truncate fw-bold">
                    {{ $schedule->namedUsers?->implode('short_name', '、') }}
                </div>
            </div>
        </div>
        <div class="text-start f-10">内容</div>
        <div class="text-start f-12 text-truncate">{{ $schedule->content }}</div>

    </button>
</div>
