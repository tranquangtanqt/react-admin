@can('updateCost', $reception)
    <x-U0100.reception-card :reception="$reception" :buttons="$buttons">
    </x-U0100.reception-card>
@else
    <x-U0100.reception-card :reception="$reception">
    </x-U0100.reception-card>
@endcan
