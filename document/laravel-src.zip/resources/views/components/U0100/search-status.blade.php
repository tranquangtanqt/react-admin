<div>
    <input type="checkbox" name="{{ $identifier }}[{{ $key }}]" id="check_{{ $identifier }}_{{ $key }}"
        {{ $checked ? 'checked' : '' }} hidden>
    <label for="check_{{ $identifier }}_{{ $key }}">
        <div class="status-box">
            <div class="px-1">
                {{ $slot }}
            </div>
            <i id="check_{{ $identifier }}_{{ $key }}_icon" @class(['bi bi-check-circle-fill selected-icon', 'd-none'=>
                ! $checked
                ])></i>
        </div>
    </label>
</div>
