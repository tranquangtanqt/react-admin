<x-U0100.reception-card :reception="$reception" :buttons="$buttons">
</x-U0100.reception-card>