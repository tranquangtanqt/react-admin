<x-U0100.reception-card :reception="$reception" schedule="on">
</x-U0100.reception-card>
