<x-U0100.reception-card :reception="$reception" reminder="on" :buttons="$buttons">
</x-U0100.reception-card>
