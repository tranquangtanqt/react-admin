<!-- 共通確認ダイアログ -->
@props([
    'modalId' => 'confirmation-modal',
    'title' => '通知',
    ])
    <x-modal modal-id="{{ $modalId }}" title="{{ $title }}" :header-border="true">

        <x-slot name="rightButton">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </x-slot>

        <p data-role="message" class="confirm-msg">{{ $slot }}</p>

        <x-slot name="footer">
            <button type="button" class="btn btn-primary text-white px-4 confirm-ok" data-bs-dismiss="modal" data-role="confirm"
                {{ $attributes->filter(fn ($value, $key) => $key == 'onclick') }}>{{ __('ＯＫ') }}</button>
            <button type="button" class="btn btn-secondary"
                data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
        </x-slot>

    </x-modal>
