@props([
    'method' => 'POST',
    ])
    <form
        method="{{ $method === 'GET' ? 'GET' : 'POST' }}"
        {{ $attributes->filter(fn ($value, $key) => collect(['action', 'onsubmit'])->contains($key)) }}>
        @if($method !== 'GET')
            @csrf
        @endif
        @if(! in_array($method, ['GET', 'POST']))
            @method($method)
        @endif

        {{ $input ?? '' }}

        <button type="submit"
            {{ $attributes->merge(['class' => 'btn'])->filter(fn ($value, $key) => !collect(['action', 'onsubmit', 'method'])->contains($key)) }}
            class="btn">
            {{ $slot }}
        </button>
    </form>
