@props([
    'checked' => false,
    'icon' => false,
    'class' => '',
    ])
    <div class="{{ 'sche-slot ' . $class }}">
        <div>{{ $slot }}</div>
        @if($icon)
            <i {{ $attributes->filter(fn ($value, $key) => $key == 'id') }}
                @class(['bi bi-check-circle-fill selected-icon', 'd-none' => ! $checked ])></i>
        @endif
    </div>
