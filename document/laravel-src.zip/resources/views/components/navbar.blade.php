<?php

use Illuminate\Support\Facades\Auth; ?>
<?php $user = Auth::user(); ?>

<nav class="navbar navbar-expand navbar-dark bg-black">
    <div class="container-fluid">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <div class="nav-link active">
                    <img class="user-icon nav-avatar" src="{{ $user->avatar }}" alt="ユーザーアイコン">
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link active d-flex align-items-center h-100" aria-current="page" href="#">{{ $user->name }}</a>
            </li>
            <li class="nav-item dropdown dropstart d-flex align-items-center">
                <a class="nav-link" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-list" style="font-size: 1.5rem;"></i>
                </a>
                <ul class="dropdown-menu" style="margin:40px -30px 0 0;" aria-labelledby="navbarDropdown">
                    <li>
                        <a class="dropdown-item " href="#" onclick="$('#frm-logout').submit();">
                            <form id="frm-logout" method="post" action="{{ route('logout') }}">
                                ログアウト
                                @csrf
                            </form>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="{{ route('set-password.edit') }}">パスワード変更</a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="{{ route('set-user-info.edit') }}">ユーザー情報設定</a>
                    </li>

                    {{-- システム管理者権限、業務責任者権限の場合 --}}
                    @if (userHasAnyAuths([config('constants.auth.system_admin'),config('constants.auth.manager')]))
                    <li class="d-none d-md-block">
                        <a class="dropdown-item" href="{{ route('output-data.show') }}">データ出力</a>
                    </li>
                    <li class="d-none d-md-block">
                        <a class="dropdown-item" href="{{ route('coop-man-hour-stop-manual.index') }}">運用管理</a>
                    </li>
                    @endif

                    {{-- システム管理者権限の場合 --}}
                    @if (userIsSystemAdmin())
                    <li class="d-none d-md-block">
                        <a class="dropdown-item" href="{{ route('mainte-user.index') }}">ユーザー情報マスタメンテナンス</a>
                    </li>
                    <li class="d-none d-md-block">
                        <a class="dropdown-item" href="{{ route('mainte-auth.index') }}">権限マスタメンテナンス</a>
                    </li>
                    <li class="d-none d-md-block">
                        <a class="dropdown-item" href="{{ route('mainte-code-class.index') }}">コード区分マスタメンテナンス</a>
                    </li>
                    @endif
                </ul>
            </li>
        </ul>
    </div>
</nav>
