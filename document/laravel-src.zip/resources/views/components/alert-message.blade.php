@props([
    'type' => 'success',
    'colors' => [
        'success' => 'primary',
        'error' => 'danger',
    ],
    ])
    <div class="alert-message alert-{{ $colors[$type] }} m-3 px-3 py-2 border border-{{ $colors[$type] }} rounded-1">
        <div class="d-flex justify-content-between align-items-center">
            <p class="my-0 me-4 px-2 py-1">
                {{ $slot }}
            </p>
            <button class="btn p-1 cursor-pointer" onclick="$(this).closest('.alert-message').fadeOut();">
                <i class="bi bi-x f-16"></i>
            </button>
        </div>
    </div>
