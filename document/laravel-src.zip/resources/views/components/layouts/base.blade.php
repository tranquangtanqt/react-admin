@props([
    'title' => '',
    'class' => 'app-body',
    'loading' => 'on',
    ])
    <!DOCTYPE html>
    <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>{{ $title }}</title>

        <link rel="shortcut icon" href="{{ asset('storage/default/favicon.svg') }}">

        <link rel="stylesheet" href="{{ mix('css/app.css') }}">
        @stack('styles')
    </head>

    <body class="{{ $class }}">

        {{ $slot }}

        @if($loading == 'on')
            {{-- 処理中... --}}
            <div id="loading" class="loading d-none">
                <div class="spinner-border text-black" style="width: 2.8rem; height: 2.8rem;" role="status">
                    <span class="visually-hidden">処理中...</span>
                </div>
            </div>
        @endif

        <script src="{{ mix('js/app.js') }}"></script>
        @stack('scripts')
    </body>

    </html>
