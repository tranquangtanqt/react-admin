@props([
    'class' => 'app-body',
    'title' => ''
    ])
    <x-layouts.base :class="$class" :title="$title">
        <div class="d-flex flex-column min-vh-100">
            {{-- ヘッダー --}}
            <x-navbar></x-navbar>

            {{-- 内容 --}}
            <div class="app-content container d-flex flex-column flex-fill px-0 bg-white pb-4">
                {{ $slot }}
            </div>
        </div>

        @if(session()->has('success'))
            <x-alert-message>
                {{ session()->get('success') }}
            </x-alert-message>
        @endif

        @if(session()->has('failure'))
            <x-alert-message type="error">
                {{ session()->get('failure') }}
            </x-alert-message>
        @endif

        @push('scripts')
            <script>
                $(window).on('load', function () {
                    setTimeout(() => {
                        $('.alert-message').fadeOut(1000);
                    }, 3000);
                })

            </script>
        @endpush

    </x-layouts.base>
