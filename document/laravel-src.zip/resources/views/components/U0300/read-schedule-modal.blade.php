@props([
    'title' => '',
    'modalId' => 'read-schedule-modal',
    ])
    <x-modal title="訪問予定" :modalId="$modalId">

        {{-- 担当者と時間帯 --}}
        <div class="row">
            <div class="col-2 text-center text-nowrap">訪問担当</div>
            <div class="col-10 text-center">時間帯</div>
        </div>

        @foreach($persons as $person)
            <div class="row mt-2 mb-3 align-items-center">

                {{-- 担当者リスト --}}
                <div class="col-2 d-flex justify-content-center">
                    <x-user-profile src="{{ $person->avatar }}" title="{{ $person->name }}">{{ $person->short_name }}
                    </x-user-profile>
                </div>

                {{-- 時間帯リスト --}}
                <div class="col-10 d-flex align-items-center justify-content-center">
                    @foreach($slots as $slot)

                        @php
                            $checked = $schedule->scheduleDetails?->where('user_id', $person->id)?->where('slot_type',
                            $slot->key)?->isNotEmpty() ? 'checked' : '' ;
                        @endphp

                        <x-schedule-slot class="me-2 me-sm-4"
                            id="read_schedule_persons-{{ $person->id }}-slots-{{ $slot->key }}-icon" :icon="true"
                            :checked="$checked">
                            {{ $slot->value }}
                        </x-schedule-slot>

                    @endforeach
                </div>

            </div>

        @endforeach

    </x-modal>
