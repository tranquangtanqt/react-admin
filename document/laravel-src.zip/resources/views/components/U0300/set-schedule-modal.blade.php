<x-form-modal modal-id="{{ $mode }}-schedule-modal" title="訪問予定設定" action="{{ $action }}"
    method="{{ $mode == 'edit' ? 'PATCH' : 'POST' }}"
    onsubmit="submitSetSchedule(event, this);">

    {{-- 削除ボタン --}}
    @if($mode == 'edit')
        @can('deleteSchedule', $reception)
            <x-slot name="titleButton">
                <x-form method="DELETE" id="set-schedule-delete-form"
                    action="{{ route('set-schedule.delete', ['schedule' => $schedule->id]) }}"
                    onsubmit="submitSetSchedule(event, this);">
                    <input type="hidden" name="updated_at"
                        value="{{ $schedule->updated_at?->toDateTimeString() }}">
                    <button type="submit" class="btn" onclick="
                        let message = '訪問予定を削除します。作業実績（工数、署名）が登録されている場合、その情報も削除されます。よろしいですか。';
                        confirmSubmitFromModal(event, message, '{{ $mode }}-schedule-modal', 'set-schedule-delete-form');
                        ">
                        <i class="bi bi-trash-fill" title="訪問予定を削除する"></i>
                    </button>
                </x-form>
            </x-slot>
        @endcan
    @endif

    {{-- 予定確認設定ボタン --}}
    <x-slot name="aboveForm">
        <div class="text-white text-center">
            <button type="btn" class="btn submit-btn"
                data-target-route="{{ route('set-schedule-check-condition.index') }}"
                onclick="fetchSetScheduleCheckConditionModal(event, this, '{{ $mode }}')">予定確認設定</button>
        </div>
    </x-slot>

    @if($mode === 'edit')
        <input type="hidden" name="edit_schedule_id" value="{{ $schedule->id }}">
        <input type="hidden" name="edit_updated_at" value="{{ $schedule->updated_at?->toDateTimeString() }}">
    @endif

    {{-- 初期値 --}}
    @if($mode === 'add')
        @php
            $scheduleDate = $initDate->format('Y/m/d') ?? now()->format('Y/m/d');
            $scheduleContent = '';
        @endphp
    @elseif($mode === 'edit')
        @php
            $scheduleDate = $schedule->date?->format('Y/m/d');
            $scheduleContent = $schedule->content;
        @endphp
    @endif

    {{-- 予定日 --}}
    <label for="{{ $mode }}-schedule-date" class="form-label">予定日付</label>
    <div class="row">
        <div class="col-auto">
            <x-date-input name="{{ $mode }}_schedule_date" id="{{ $mode }}-schedule-date" value="{{ $scheduleDate }}"
                required />
        </div>
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="set_schedule_{{ $mode }}_schedule_date_error"></x-invalid-feedback>
    </div>

    {{-- 担当者と時間帯 --}}
    <div class="row mt-3">
        <div class="col-2 text-center text-nowrap">訪問担当</div>
        <div class="col-10 text-center">時間帯</div>
    </div>

    @foreach($persons as $person)
        <div class="row mt-2 align-items-center">

            {{-- 担当者リスト --}}
            <div class="col-2 d-flex justify-content-center">
                <input type="hidden" name="{{ $mode }}_schedule_persons[{{ $person->id }}][id]"
                    data-person-id="{{ $person->id }}" value="{{ $person-> id }}">
                <x-user-profile src="{{ $person->avatar }}" title="{{ $person->name }}">{{ $person->short_name }}
                </x-user-profile>
            </div>

            {{-- 時間帯リスト --}}
            <div class="col-10 d-flex align-items-center justify-content-center">
                @foreach($slots as $slot)

                    @if($mode === 'add')
                        @php
                            $checked = $person->id === $initUserId ? 'checked' : '' ;
                        @endphp
                    @elseif($mode === 'edit')
                        @php
                            $checked = $schedule->scheduleDetails?->where('user_id', $person->id)?->where('slot_type',
                            $slot->key)?->isNotEmpty() ? 'checked' : '' ;
                        @endphp
                    @endif

                    <input type="checkbox"
                        name="{{ $mode }}_schedule_persons[{{ $person->id }}][slots][{{ $slot->key }}]"
                        id="{{ $mode }}_schedule_persons-{{ $person->id }}-slots-{{ $slot->key }}" value="1"
                        data-person-id="{{ $person->id }}" hidden {{ $checked }}
                        data-internal="{{ $person->is_external ? 'false' : 'true' }}">
                    <label for="{{ $mode }}_schedule_persons-{{ $person->id }}-slots-{{ $slot->key }}"
                        class="cursor-pointer">
                        <x-schedule-slot class="me-2 me-sm-4"
                            id="{{ $mode }}_schedule_persons-{{ $person->id }}-slots-{{ $slot->key }}-icon"
                            :icon="true" :checked="$checked">
                            {{ $slot->value }}
                        </x-schedule-slot>
                    </label>
                @endforeach
            </div>

        </div>

    @endforeach

    <div class="row d-none">
        <x-invalid-feedback id="set_schedule_{{ $mode }}_schedule_slots_error"></x-invalid-feedback>
    </div>

    {{-- 内容 --}}
    <label for="{{ $mode }}_schedule-content" class="form-label mt-3">詳細</label>
    {{-- CHG 20220406 Ishino OT-018 詳細の必須入力を任意入力に変更（required属性を削除） --}}
    <textarea class="form-control" name="{{ $mode }}_schedule_content" id="{{ $mode }}_schedule-content"
        rows="4">{{ $scheduleContent }}</textarea>

    {{-- バリデーションメッセージ:内容 --}}
    <div class="row d-none">
        <x-invalid-feedback id="set_schedule_{{ $mode }}_schedule_content_error"></x-invalid-feedback>
    </div>

    {{-- バリデーションメッセージ:共通エラー --}}
    <div class="row mt-2 d-none">
        <x-invalid-feedback id="set_schedule_general_error_message_error"></x-invalid-feedback>
    </div>

    @if ($shouldSetPjMgr ?? false)

        {{-- 計上担当項目 --}}
        <input type="hidden" id="pjmgr-id" name="pjmgr_id" value="{{ $initPjMgrId ?? '' }}">

        {{-- 計上担当を設定可能な時に下の確定ボタンを以下の方を利用する --}}
        <x-slot name="bottomButton">
            <x-submit-button onclick="goToSetPjMgrFromSetScheduleModal(event, '{{ $mode }}')">確定</x-submit-button>
        </x-slot>

    @endif
</x-form-modal>
