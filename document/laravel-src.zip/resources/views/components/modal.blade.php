@props([
    'modalId' => 'modal',
    'title' => '',
    'headerBorder' => false,
    ])
    <div class="modal fade" id="{{ $modalId }}" tabindex="-1" aria-labelledby="{{ $modalId }}" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header {{ $headerBorder ? '' : 'border-bottom-0' }}">
                    <h5 class="modal-title d-flex align-items-center">
                        <span class="me-2">{{ $title }}</span>
                    </h5>
                    @if (isset($rightButton))
                            {{ $rightButton }}
                    @else
                        <button type="button" class="btn" data-bs-dismiss="modal" aria-label="back">戻る</button>
                    @endif
                </div>

                <div class="modal-body">
                    {{ $slot }}
                </div>

                @isset($footer)
                    <div class="modal-footer">
                        {{ $footer }}
                    </div>
                @endisset

            </div>
        </div>
    </div>
