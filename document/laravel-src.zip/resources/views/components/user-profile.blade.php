@props([
    'checked' => false,
    'icon' => false,
    'class' => '',
    'title' => '',
    'src' => asset('/storage/default/user_profile.jpg'),
    ])
    <div class="{{ 'user-info ' . $class }}">
        <img class="user-icon" src="{{ $src }}"
            alt="ユーザーアイコン">
        <div class="w-100 text-center text-truncate mt-1" title="{{ $title }}">
            {{ $slot }}
        </div>
        @if($icon)
        <i {{ $attributes->filter(fn ($value, $key) => $key == 'id') }}
            @class(['bi bi-check-circle-fill selected-icon', 'd-none' => ! $checked ])></i>
        @endif
    </div>
