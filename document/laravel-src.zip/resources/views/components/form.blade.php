@props([
    'method' => 'POST',
    'loading' => 'on',
    ])

    <form
        method="{{ $method === 'GET' ? 'GET' : 'POST' }}"
        {{ $attributes }}
        {{ $attributes->merge(['onsubmit' => $loading=='on' ? "$('#loading').removeClass('d-none');" : ""]) }}
        >
        @if($method !== 'GET')
            @csrf
        @endif
        @if(! in_array($method, ['GET', 'POST']))
            @method($method)
        @endif

        {{ $slot }}

    </form>
