<x-layouts.app title="運用管理">
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div></div>
        <div class="p-0">工数連携停止・手動連携</div>
        <a class="btn p-0 text-white" href="{{ route('dashboard') }}">戻る</a>
    </div>
    <hr>
    @if(Session::has('messageErr'))
        <p class="alert alert-danger text-center">{{ Session::get('messageErr') }}</p>
    @endif
    @if(Session::has('messageSuccess'))
        <p class="alert alert-success text-center">{{ Session::get('messageSuccess') }}</p>
    @endif
    <div class="m-2">
        <p>工数連携状態</p>
        <form action="{{ route('coop-man-hour-stop-manual.update')}}" method="POST" class="m-4">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
            <p>以下をチェックして確認すると自動での工数連携が停止します。<br/>チェックを外して確定すると自動での工数連携が再開します</p>
            <div class="form-check">
                <input type="checkbox" class="form-check-input" name="check" {{$checkBox==1?"checked":""}} id="checkboxForm">
                <label class="form-check-label" for="checkboxForm">工数連携停止</label>
            </div>
            <x-submit-button >確定</x-submit-button>
        </form>
    </div>
    <hr/>
        <div class="m-2">
            <p>工数手動出力</p>
            <form action="{{ route('coop-man-hour-stop-manual.store')}}" method="POST" class="m-4">
                <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
                <p>Ｌ2に連携する工数を出力します。<br/> 出力後はＬ2のオペレーションマネージャーにて処理を実行し、データの取り込みを実施してください。</p>
                <x-submit-button >実行</x-submit-button>
            </form>
        </div>
    <hr>
@push('scripts')
    <script src="{{ mix('js/U0700/coop-man-hour-stop-manual.js') }}" ></script>
@endpush
</x-layouts.app>
