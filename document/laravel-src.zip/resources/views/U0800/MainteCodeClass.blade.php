<x-layouts.app title="コード区分マスタメンテナンス">
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/U0800/mainte-code-class.css') }}" />
    @endpush

    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">コード区分マスタメンテナンス</div>
        <a class="btn p-0 text-white" href="{{ route('dashboard') }}">戻る</a>
    </div>

    @if(Session::has('message'))
        <p class="alert alert-success text-center">{{ Session::get('message') }}</p>
    @endif

    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3">
        <div class="row">
            <div class="col-md-12">
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-md-1">
                <label for="code" class="form-label">識別コード</label>
            </div>
            <div class="col-md-3">
                <select class="form-select" name="code" id="code">
                    @if($identifierCodes)
                        @foreach($identifierCodes as $identifier)
                            @if($identifierCodesFirst->code == $identifier->code)
                                <option selected value="{{ $identifier->code }}">{{ $identifier->name }}</option>
                            @else
                                <option value="{{ $identifier->code }}">{{ $identifier->name }}</option>
                            @endif
                        @endforeach
                    @endif
                </select>
            </div>
            <div class="col-md-4 d-flex justify-content-center" id="choose-identifier-code">
                <x-submit-button type="button">選択</x-submit-button>
            </div>
        </div>
        @if($identifierCodes)
            <div class="row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col-md-1">
                    <label for="code" class="form-label">説明</label>
                </div>
                <div class="col-md-11">
                    <p>{{ $identifierCodesFirst->description }}</p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 mb-3">
                    <a class="btn p-0 float-end"
                        href="{{ route('set-mainte-code-class.show-code-class', ['code' => $identifierCodesFirst->code, 'page' => $page]) }}">追加</a>
                </div>
            </div>
            <div div class="row">
                <div class="col-md-12">
                    <table id="u0803-table" class="table table-bordered u0803-table">
                        <thead>
                            <tr class="border-top-0 border-solid-1">
                                <th class="border-start-0">キー</th>
                                <th>値</th>
                                <th>表示順</th>
                                <th>数値１</th>
                                <th>数値２</th>
                                <th>数値３</th>
                                <th rowspan="2" class="border-end-0">編集・削除</th>
                            </tr>
                            <tr class="border-top-0 border-solid-2">
                                <th colspan="2" class="border-start-0">文字１</th>
                                <th colspan="2">文字２</th>
                                <th colspan="2">文字３</th>
                            </tr>
                        </thead>
                        @foreach($codeClass as $codeCl)
                            <tbody>
                                <tr>
                                    <td class="border-start-0">{{ $codeCl->key }}</td>
                                    <td>{{ $codeCl->value }}</td>
                                    <td>{{ $codeCl->display_order }}</td>
                                    <td>{{ $codeCl->number1 }}</td>
                                    <td>{{ $codeCl->number2 }}</td>
                                    <td>{{ $codeCl->number3 }}</td>
                                    <td rowspan="2" class="border-end-0">
                                        <div class="float-start">
                                            <a class="btn p-0"
                                                href="{{ route('set-mainte-code-class.show-code-class', ['code' => $identifierCodesFirst->code, 'id' => $codeCl->id, 'page' => $page]) }}">編集</a>
                                        </div>
                                        <div class="float-start ms-2">
                                            <form id="u0803-frm-{{ $codeCl->id }}"
                                                action="{{ route('mainte-code-class.delete', ['id' => $codeCl->id, 'page' => $page]) }}"
                                                method="POST">
                                                @csrf
                                                @method('delete')
                                                <button type="button" u0803-data-id="{{ $codeCl->id }}"
                                                    class="btn p-0 u0803-open-modal" data-bs-toggle="modal"
                                                    data-bs-target="#u0803_openmodal">
                                                    削除
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="border-start-0">
                                        @if(is_null($codeCl->string1))
                                            &nbsp;
                                        @else
                                            {{ $codeCl->string1 }}
                                        @endif
                                    </td>
                                    <td colspan="2">{{ $codeCl->string2 }}</td>
                                    <td colspan="2">{{ $codeCl->string3 }}</td>
                                </tr>
                            </tbody>
                        @endforeach
                    </table>
                </div>
            </div>
        @endif

        @if($identifierCodes)
            {{ $codeClass->links() }}
        @endif

        <div class="modal fade" tabindex="-1" id="u0803_openmodal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">{{ __('通知') }}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>{{ __('コード区分を削除します。よろしいですか。') }}
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary"
                            id="u0803-ok">{{ __('ＯＫ') }}</button>
                        <button class="btn btn-secondary"
                            data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                        <input type="hidden" value="" id="u0803-id">
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
        <script src="{{ mix('js/U0800/mainte-code-class.js') }}"></script>
    @endpush
</x-layouts.app>
