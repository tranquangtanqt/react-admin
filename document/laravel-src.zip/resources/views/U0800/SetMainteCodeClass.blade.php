<x-layouts.app>
    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">コード区分マスタメンテナンス</div>
        <a class="btn p-0 text-white" href="{{ route('mainte-code-class.show-identifier', ['code' => $code, 'page' => $page]) }}">戻る</a>
    </div>

    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3">
        @if(Session::has('messageErr'))
            <p class="alert alert-danger text-center">{{ Session::get('messageErr') }}</p>
        @endif
        <form id="u0803-frm" method="POST" action="{{ $action }}" enctype="application/x-www-form-urlencoded">
            @csrf
            <input type="hidden" name="page" value="{{ $page }}">
            <div class="row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-1">
                    <label class="form-label">識別コード</label>
                </div>
                <div class="col-md-11">
                    <label class="form-label">{{ $identifierCodes->name }}</label>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-1">
                    <label class="form-label">説明</label>
                </div>
                <div class="col-md-11">
                    <label class="form-label">{{ $identifierCodes->description }}</label>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="key" class="form-label">キー</label>
                    <input type="text" class="form-control @error('key') is-invalid @enderror"
                        id="key" value="{{ old('key', $codeClass->key) }}" name="key" maxlength="20">
                    @error('key')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>

                <div class="col-md-3 mb-3">
                    <label for="value" class="form-label">値</label>
                    <input type="text" class="form-control @error('value') is-invalid @enderror"
                        id="value" value="{{ old('value', $codeClass->value) }}" name="value" maxlength="10">
                    @error('value')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>

                <div class="col-md-3 mb-3">
                    <label for="display_order" class="form-label">表示順</label>
                    <input type="text" class="form-control @error('display_order') is-invalid @enderror"
                        id="display_order" value="{{ old('display_order', $codeClass->display_order) }}" name="display_order" maxlength="20">
                    @error('display_order')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="number1" class="form-label">数値１</label>
                    <input type="text" class="form-control @error('number1') is-invalid @enderror"
                        id="number1" value="{{ old('number1', $codeClass->number1) }}" name="number1" maxlength="13">
                    @error('number1')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>

                <div class="col-md-3 mb-3">
                    <label for="number2" class="form-label">数値２</label>
                    <input type="text" class="form-control @error('number2') is-invalid @enderror"
                        id="number2" value="{{ old('number2', $codeClass->number2) }}" name="number2" maxlength="13">
                    @error('number2')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>

                <div class="col-md-3 mb-3">
                    <label for="number3" class="form-label">数値３</label>
                    <input type="text" class="form-control @error('number3') is-invalid @enderror"
                        id="number3" value="{{ old('number3', $codeClass->number3) }}" name="number3" maxlength="13">
                    @error('number3')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 mb-3">
                    <label for="string1" class="form-label">文字１</label>
                    <input type="text" class="form-control @error('string1') is-invalid @enderror"
                        id="string1" value="{{ old('string1', $codeClass->string1) }}" name="string1" maxlength="20">
                    @error('string1')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 mb-3">
                    <label for="string2" class="form-label">文字２</label>
                    <input type="text" class="form-control @error('string2') is-invalid @enderror"
                        id="string2" value="{{ old('string2', $codeClass->string2) }}" name="string2" maxlength="20">
                    @error('string2')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 mb-3">
                    <label for="string3" class="form-label">文字３</label>
                    <input type="text" class="form-control @error('string3') is-invalid @enderror"
                        id="string3" value="{{ old('string3', $codeClass->string3) }}" name="string3" maxlength="20">
                    @error('string3')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 offset-md-3 d-flex justify-content-center" id="u0803-submit">
                    <x-submit-button>確定</x-submit-button>
                </div>
            </div>
        </form>
    </div>

    @push('scripts')
        <script src="{{ mix('js/U0800/mainte-code-class.js') }}"></script>
    @endpush
</x-layouts.app>
