<x-layouts.app>
    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">権限マスタメンテナンス</div>
        <a class="btn p-0 text-white" href="{{ route('mainte-auth.index', ['page' => $page]) }}">戻る</a>
    </div>

    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3">
        <form id="frm-auth" method="POST" action="{{ route('set-mainte-auth.update') }}" enctype="application/x-www-form-urlencoded">
            @csrf
            @method('patch')
            <input type="hidden" value="{{ $user->user_id }}" name="user_id">
            <input type="hidden" value="{{ $page }}" name="page">
            <div class="row">
                <div class="col-md-2">
                    <p>ログインＩＤ</p>
                </div>
                <div class="col-md-10">
                    <p>{{ $user->login_id }}</p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <p>氏名</p>
                </div>
                <div class="col-md-10">
                    <p>{{ $user->name }}</p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 mb-3">
                    <label class="form-label">権限</label>
                    @foreach ($codeClassArr as $codeClass)
                        <div class="form-check ms-5">
                            <input class="form-check-input" type="checkbox" value="{{ $codeClass['key'] }}" name="code_classes[]"
                                id="checkbox-{{ $codeClass['key'] }}" @if ($codeClass['flag']) checked @endif>
                            <label class="form-check-label" for="checkbox-{{ $codeClass['key'] }}">
                                {{ $codeClass['value'] }}
                            </label>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 offset-md-3 d-flex justify-content-center" id="u0802-submit">
                    <x-submit-button type="button">確定</x-submit-button>
                </div>
            </div>
        </form>
    </div>

    @push('scripts')
        <script src="{{ mix('js/U0800/set-mainte-auth.js') }}"></script>
    @endpush
</x-layouts.app>
