<x-layouts.app>
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/U0800/mainte-auth.css') }}" >
    @endpush

    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">権限マスタメンテナンス</div>
        <a class="btn p-0 text-white" href="{{ route('dashboard') }}">戻る</a>
    </div>

    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3">
        @if(Session::has('message'))
            <p class="alert alert-success text-center">{{ Session::get('message') }}</p>
        @endif
        <table id="u0802-table" class="table table-striped table-hover table-bordered table-layout-fixed">
            <thead>
                <tr class="border-top-0 border-solid-2">
                    <th class="border-start-0 width-185">ログインＩＤ</th>
                    <th class="width-185">氏名</th>
                    <th>権限</th>
                    <th class="border-end-0 width-100">編集・削除</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $user)
                <tr>
                    {{-- ユーザーマスタ．ログインＩＤ --}}
                    <td title="{{ $user->login_id}}" class="border-start-0">
                        <span class="ellipsis-text">{{ $user->login_id}}</span>
                    </td>
                    {{-- ユーザーマスタ．氏名 --}}
                    <td title="{{ $user->name}}">
                        <span class="ellipsis-text">{{ $user->name}}</span>
                    </td>
                    {{-- 権限マスタ．権限区分に紐づくコード区分マスタ．値 --}}
                    <td>
                        @php
                            $strAuthKey = $user->auth_class;
                            $filtered = $codeclass->filter(function($values) use ($strAuthKey) {
                                return str_contains($strAuthKey, $values->key );
                            });

                            $arr = array();
                            foreach($filtered as $item){
                                array_push($arr, $item->value);
                            }
                            $authValue = implode("、",$arr);
                        @endphp
                        <span class="ellipsis-text" title="{{ $authValue }}">{{ $authValue }}</span>
                    </td>
                    <td class="border-end-0">
                        <div class="float-start">
                            <a class="btn p-0" href="{{ route('set-mainte-auth.show', ['id' => $user->id, 'page' => $page]) }}">編集</a>
                        </div>
                        <div class="float-start ms-2">
                            <form id="u0802-frm-{{ $user->id }}" action="{{ route('mainte-auth.delete', ['id' => $user->id, 'page' => $page]) }}" method='POST'>
                                @csrf
                                @method('delete')
                                <button type="button" u0802-data-id="{{$user->id}}" class="btn p-0 u0802-open-modal"
                                    data-bs-toggle="modal" data-bs-target="#u0802_openmodal" @if($user->auth_class == null) disabled @endif>
                                    削除
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        {{ $users->links() }}

        <div class="modal fade" tabindex="-1" id="u0802_openmodal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-bottom-0">
                        <h5 class="modal-title">{{ __('通知') }}</h5>
                    </div>
                    <div class="modal-body">
                        <p>{{ __('権限を削除します。よろしいですか。') }}</p>
                    </div>
                    <div class="modal-footer border-top-0 d-flex justify-content-between text-white">
                        <button class="btn u0802-custom-btn" id="u0802-ok">{{ __('ＯＫ') }}</button>
                        <button class="btn u0802-custom-btn ms-2" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                        <input type="hidden" value="" id="u0802-id">
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
        <script src="{{ mix('js/U0800/mainte-auth.js') }}" ></script>
    @endpush
</x-layouts.app>
