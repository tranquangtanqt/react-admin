<x-layouts.app>
    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">ユーザー情報マスタメンテナンス</div>
        <a class="btn p-0 text-white" href="{{ route('mainte-user.index', ['page' => $page]) }}">戻る</a>
    </div>

    @if(Session::has('messageErr'))
        <p class="alert alert-danger text-center">{{ Session::get('messageErr') }}</p>
    @endif

    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3">
        <form id="frm-mainte-user" method="post" action="{{ $action }}" enctype="application/x-www-form-urlencoded">
            @csrf
            @if ($flgProcess == 1)
                @method('post')
            @else
                @method('patch')
            @endif
            <input type="hidden" name="page" value="{{ $page }}">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="login-id" class="form-label">ログインＩＤ</label>
                    <input type="text" class="form-control @error('login_id') is-invalid @enderror"
                        id="login-id" value="{{ old('login_id', $user->login_id) }}" name="login_id" maxlength="20">
                    @error('login_id')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>

                <div class="col-md-3 mb-3">
                    <label for="name" class="form-label">氏名</label>
                    <input type="text" class="form-control @error('name') is-invalid @enderror"
                        id="name" value="{{ old('name', $user->name) }}" name="name" maxlength="20">
                    @error('name')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>

                <div class="col-md-3 mb-3">
                    <label for="short-name" class="form-label">略称</label>
                    <input type="text" class="form-control @error('short_name') is-invalid @enderror"
                        id="short-name" value="{{ old('short_name', $user->short_name) }}" name="short_name" maxlength="4">
                    @error('short_name')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-5 mb-3">
                    <label for="email" class="form-label">メールアドレス</label>
                    <input type="email" class="form-control @error('email') is-invalid @enderror"
                        id="email" value="{{ old('email', $user->email) }}" name="email" maxlength="254">
                    @error('email')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-2 mb-3">
                    <label for="external-company-id" class="form-label">{{ $externalCompanyName }}</label>
                    <input type="text" class="form-control @error('external_company_id') is-invalid @enderror"
                        id="external-company-id" value="{{ old('external_company_id', $user->external_company_id) }}"
                        name="external_company_id" maxlength="10">
                    @error('external_company_id')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
                <div class="col-md-3 mb-3">
                    <label for="external-user-id" class="form-label">{{ $externalUserName }}</label>
                    <input type="text" class="form-control @error('external_user_id') is-invalid @enderror"
                        id="external-user-id" value="{{ old('external_user_id', $user->external_user_id) }}"
                        name="external_user_id" maxlength="20">
                    @error('external_user_id')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 offset-md-4 d-flex justify-content-center" id="u0801-submit">
                    <x-submit-button type="button">確定</x-submit-button>
                </div>
            </div>
        </form>
    </div>

    @push('scripts')
        <script src="{{ mix('js/U0800/set-mainte-user.js') }}"></script>
    @endpush
</x-layouts.app>
