<x-layouts.app title="受付検索">
    <x-U0100.dashboard-tabs active="search"></x-U0100.dashboard-tabs>
    <div class="py-2 px-2 px-sm-3 my-3">
        <x-form action="{{ route('search-reception.index') }}" method="POST">
            <div class="border-top border-bottom py-2 mb-2">
                検索条件
            </div>

            {{-- 受付日 --}}
            <div class="search-form-container">
                <div>受付日</div>
                <div>
                    <div class="d-flex align-items-center justify-content-between">
                        <x-date-input name="start_date"
                            value="{{ old('start_date') ?? $searchParams['start_date'] ?? '' }}"
                            style="width: 9.1rem" />
                        <span>〜</span>
                        <x-date-input name="end_date"
                            value="{{ old('end_date') ?? $searchParams['end_date'] ?? '' }}"
                            style="width: 9.1rem" />
                    </div>
                    @error('start_date')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                    @error('end_date')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>

            {{-- 状態 --}}
            <div class="my-1 d-flex align-items-center flex-wrap">
                <div style="width: 90px">状態</div>
                <div class="d-flex">
                    <div class="status-list">
                        @foreach($statusTypes as $status)
                            @php
                                $checked = old("status")[$status->key] ?? collect(array_keys($searchParams['status'] ??
                                []))->contains($status->key);
                            @endphp
                            <x-U0100.search-status identifier="status" key="{{ $status->key }}" :checked="$checked">
                                {{ $status->value }}
                            </x-U0100.search-status>
                        @endforeach
                    </div>
                </div>
            </div>

            {{-- お客様名 --}}
            <x-U0100.search-text-input
                value="{{ old('field_name') ?? $searchParams['field_name'] ?? '' }}"
                name="field_name" title="お客様名" />

            {{-- お客様住所 --}}
            <x-U0100.search-text-input
                value="{{ old('field_address') ?? $searchParams['field_address'] ?? '' }}"
                name="field_address" title="お客様住所" />

            {{-- 表示順 --}}
            <div class="search-form-container">
                <div>表示順</div>
                <div>
                    <select class="form-select" name="order" required>
                        <option value="desc"
                            {{ (old('order') ?? $searchParams['order'] ?? '') == 'desc' ? 'selected' : '' }}>
                            受付番号（降順）</option>
                        <option value="asc"
                            {{ (old('order') ?? $searchParams['order'] ?? '') == 'asc' ? 'selected' : '' }}>
                            受付番号（昇順）</option>
                    </select>
                </div>
            </div>
            {{-- その他条件開くかのフラグ --}}

            <input type="hidden" name="detail" value="{{ old('detail') ?? $detail }}"
                id="detail-search-flag">

            @php
                $detail = old('detail') ?? $detail;
            @endphp

            {{-- その他条件ヘッダ --}}
            <div class="collapse {{ $detail ? '' : 'show' }} detail-search border-top border-bottom py-2 mt-2"
                onclick="$('#detail-search-flag').val('true');">
                <span>他条件</span>
                <button class="btn p-0 m-0" type="button" data-bs-toggle="collapse" data-bs-target=".detail-search">
                    <i class="bi bi-caret-down-fill text-settle"></i>
                </button>
            </div>

            {{-- その他条件内容 --}}
            <div
                class="detail-search collapse {{ !$detail ? '' : 'show' }} border-top border-bottom py-2 mt-2">

                {{-- 受付経過日数 --}}
                <div class="search-form-container">
                    <div>受付経過日数</div>
                    <div>
                        <div class="d-flex align-items-center justify-content-between">
                            <input name="elapsed_days_min" type="number" class="form-control"
                                value="{{ old('elapsed_days_min') ?? $searchParams['elapsed_days_min'] ?? '' }}"
                                style="width: 9.1rem" min="0">
                            <span>〜</span>
                            <input name="elapsed_days_max" type="number" class="form-control"
                                value="{{ old('elapsed_days_max') ?? $searchParams['elapsed_days_max'] ?? '' }}"
                                style="width: 9.1rem" min="0">
                        </div>
                        @error('elapsed_days_min')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                        @error('elapsed_days_max')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                    </div>
                </div>

                {{-- 完了日 --}}
                <div class="search-form-container">
                    <div>完了日</div>
                    <div>
                        <div class="d-flex align-items-center justify-content-between">
                            <x-date-input name="complete_start_date"
                                value="{{ old('complete_start_date') ?? $searchParams['complete_start_date']  ?? '' }}"
                                style="width: 9.1rem" />
                            <span>〜</span>
                            <x-date-input name="complete_end_date"
                                value="{{ old('complete_end_date') ?? $searchParams['complete_end_date']  ?? '' }}"
                                style="width: 9.1rem" />
                        </div>
                        @error('complete_start_date')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                        @error('complete_end_date')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                    </div>
                </div>

                {{-- 状態詳細 --}}
                <div class="my-1 d-flex align-items-center flex-wrap">
                    <div style="width: 90px">状態詳細</div>
                    <div class="d-flex">
                        <div class="status-list">
                            @foreach($statusDetailTypes as $status)
                                @php
                                    $identifier = 'status_detail';
                                    $checked = old($identifier)[$status->key] ??
                                    collect(array_keys($searchParams[$identifier] ?? []) ??
                                    [])->contains($status->key);
                                @endphp
                                <x-U0100.search-status identifier="{{ $identifier }}" key="{{ $status->key }}"
                                    :checked="$checked">
                                    {{ $status->string1 ?? $status->value }}
                                </x-U0100.search-status>
                            @endforeach
                        </div>
                    </div>
                </div>

                {{-- 計上担当 --}}
                <div class="search-form-container">
                    <div>計上担当</div>
                    <div class="d-flex">
                        @php
                            $pjmgrInputName = 'selected_pjmgr_id';
                            $selectedPjmgrId = old($pjmgrInputName) ?? $searchParams[$pjmgrInputName] ?? null;
                            $selectedPjmgr = $pjmgrUsers->where('id', $selectedPjmgrId)->first();
                        @endphp
                        <input type="hidden" name="{{ $pjmgrInputName }}" value="{{ $selectedPjmgrId }}"
                            id="{{ $pjmgrInputName }}">
                        <div id="selected_pjmgr_display_box">
                            <x-user-profile src="{{ avatarByFileId($selectedPjmgr?->file_id) }}" class="me-2"
                                title="{{ $selectedPjmgr->name ?? '未選択' }}">
                                {{ $selectedPjmgr->short_name ?? '未選択' }}
                            </x-user-profile>
                        </div>

                        <button class="btn" type="button" data-bs-toggle="collapse"
                            data-bs-target="#pjmgr-user-select-container">
                            <i class="bi bi-caret-down-fill text-settle"></i>
                        </button>

                    </div>
                </div>
                <div class="search-form-container mb-2">
                    <div></div>
                    <div class="">
                        <div class="collapse mt-3" id="pjmgr-user-select-container">
                            <div class="pjmgr-grid">
                                @foreach($pjmgrUsers as $user)
                                    @php
                                        $pjmgrUserInputId = "select_user_pjmgr_" . $user->id;
                                        $checked = $selectedPjmgrId == $user->id;
                                    @endphp
                                    <div class="d-flex justify-content-center">
                                        <input type="checkbox" id="{{ $pjmgrUserInputId }}"
                                            name="{{ $pjmgrUserInputId }}" value="1" data-user-id="{{ $user-> id }}"
                                            data-img-src="{{ $user->avatar }}" data-name="{{ $user->name }}"
                                            data-short-name="{{ $user->short_name }}" hidden>
                                        <label for="{{ $pjmgrUserInputId }}" class="cursor-pointer">
                                            <x-user-profile src="{{ $user->avatar }}" class="me-2"
                                                title="{{ $user->name }}" id="{{ $pjmgrUserInputId }}_icon"
                                                :icon="true" :checked="$checked">
                                                {{ $user->short_name }}
                                            </x-user-profile>
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>


                {{-- 訪問担当 --}}
                <div class="search-form-container">
                    <div>訪問担当</div>
                    <div class="d-flex">
                        @php
                            $picInputName = 'selected_pic_id';
                            if (userIsPicExternal()) {
                                $selectedPicId = auth()->user()->id;
                            } else {
                                $selectedPicId = old($picInputName) ?? $searchParams[$picInputName] ?? null;
                            }
                            $selectedPic = $picUsers->where('id', $selectedPicId)->first();
                        @endphp
                        <input type="hidden" name="{{ $picInputName }}" value="{{ $selectedPicId }}"
                            id="{{ $picInputName }}">
                        <div id="selected_pic_display_box">
                            <x-user-profile src="{{ avatarByFileId($selectedPic?->file_id) }}" class="me-2"
                                title="{{ $selectedPic->name ?? '未選択' }}">
                                {{ $selectedPic->short_name ?? '未選択' }}
                            </x-user-profile>
                        </div>

                        @if(!userIsPicExternal())
                            <button class="btn" type="button" data-bs-toggle="collapse"
                                data-bs-target="#pic-user-select-container">
                                <i class="bi bi-caret-down-fill text-settle"></i>
                            </button>
                        @endif

                    </div>
                </div>
                @if(!userIsPicExternal())
                    <div class="search-form-container mb-2">
                        <div></div>
                        <div class="">
                            <div class="collapse mt-3" id="pic-user-select-container">
                                <div class="pjmgr-grid">
                                    @foreach($picUsers as $user)
                                        @php
                                            $picUserInputId = "select_user_pic_" . $user->id;
                                            $checked = $selectedPicId == $user->id;
                                        @endphp
                                        <div class="d-flex justify-content-center">
                                            <input type="checkbox" id="{{ $picUserInputId }}"
                                                name="{{ $picUserInputId }}" value="1"
                                                data-user-id="{{ $user-> id }}" data-img-src="{{ $user->avatar }}"
                                                data-name="{{ $user->name }}"
                                                data-short-name="{{ $user->short_name }}" hidden>
                                            <label for="{{ $picUserInputId }}" class="cursor-pointer">
                                                <x-user-profile src="{{ $user->avatar }}" class="me-2"
                                                    title="{{ $user->name }}" id="{{ $picUserInputId }}_icon"
                                                    :icon="true" :checked="$checked">
                                                    {{ $user->short_name }}
                                                </x-user-profile>
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

                <x-U0100.search-text-input
                    value="{{ old('field_tel') ?? $searchParams['field_tel'] ?? '' }}"
                    name="field_tel" title="お客様TEL" />

                <x-U0100.search-text-input
                    value="{{ old('client_name') ?? $searchParams['client_name'] ?? '' }}"
                    name="client_name" title="依頼元名" />

                <x-U0100.search-text-input
                    value="{{ old('client_address') ?? $searchParams['client_address'] ?? '' }}"
                    name="client_address" title="依頼元住所" />

                <x-U0100.search-text-input
                    value="{{ old('no') ?? $searchParams['no'] ?? '' }}"
                    name="no" title="受付番号" />

                <x-U0100.search-text-input
                    value="{{ old('related_pj_no') ?? $searchParams['related_pj_no'] ?? '' }}"
                    name="related_pj_no" title="関連PJ番号" />

                <x-U0100.search-text-input
                    value="{{ old('device_type') ?? $searchParams['device_type'] ?? '' }}"
                    name="device_type" title="機種" />

                <x-U0100.search-text-input
                    value="{{ old('device_no') ?? $searchParams['device_no'] ?? '' }}"
                    name="device_no" title="機番" />

                <div>
                    <button class="btn p-0 m-0" type="button" data-bs-toggle="collapse" data-bs-target=".detail-search"
                        onclick="$('#detail-search-flag').val('');">
                        <i class="bi bi-caret-up-fill text-settle"></i>
                    </button>
                </div>

            </div>

            <div class="d-flex justify-content-center mt-3">
                <x-submit-button>検索</x-submit-button>
            </div>

        </x-form>

        {{-- 検索結果 --}}
        @if($searched)
            <div class="my-4">
                <div class="border-top border-bottom py-2">
                    検索結果
                </div>
                <div class="d-flex flex-wrap mt-3 justify-content-center justify-content-sm-start">
                    @forelse($receptions as $reception)
                        <x-U0200.search-reception-card :reception="$reception" :styles="$styles" />
                    @empty
                        該当する受付がありません。
                    @endforelse
                </div>
            </div>
        @endif
    </div>

    @push('scripts')
        <script>
            // 画面が起動した後に訪問予定関連制御を動かせる
            $(window).on("load", function () {

                // 日付選択datepicker
                $('input[role=datepicker]').datepicker();

                // 受付状態・状態詳細条件制御
                $(`input[type=checkbox][id^=check_status_]`).on("change", function () {
                    if (this.checked) {
                        $("#" + this.id + "_icon").removeClass("d-none");
                    } else {
                        $("#" + this.id + "_icon").addClass("d-none");
                    }
                });


                // 計上担当・訪問担当条件の制御
                $(`input[type=checkbox][id^=select_user_]`).on("change", function () {
                    const splittedId = this.id.split('_');
                    splittedId.pop();
                    const startOfId = splittedId.join('_');
                    const identifier = splittedId[2];
                    if (this.checked) {
                        $(`input[type=checkbox][id^=${startOfId}]`)
                            .not(this)
                            .prop('checked', false)
                            .trigger('change'); // 他のチェックボックスのチェックを外す
                        $(`#${this.id}_icon`).removeClass("d-none"); // 対象担当者チェック
                        $(`#selected_${identifier}_id`).val($(this).data('userId'));
                        $(`#selected_${identifier}_display_box`)
                            .find('img').attr('src', $(this).data('imgSrc')) // 画像設定
                            .next().html($(this).data('shortName')) // 略名設定
                            .attr('title', $(this).data('name')); // 氏名設定

                    } else {
                        $(`#selected_${identifier}_id`).val('');
                        $(`#${this.id}_icon`).addClass("d-none"); // 対象担当者チェック外す

                        // 画像リセット
                        let $selectedUsers = $(
                            `input[type=checkbox][id^=select_user_${identifier}_]:checked`);
                        if ($selectedUsers.length <= 0) {
                            $(`#selected_${identifier}_display_box`)
                                .find('img').attr('src',
                                    '{{ asset('/storage/default/user_profile.jpg') }}'
                                )
                                .next().html('未設定') // 略名設定
                                .attr('title', '未設定');
                        }
                    }
                });
            });

        </script>
    @endpush
</x-layouts.app>
