<x-layouts.app>
    @push('styles')
    <style>
        .border-title {
            border-top: 1px groove;
            border-bottom: 1px groove
        }
    </style>
    @endpush
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div></div>
        <div class="p-0">{{ __('連携エラー通知') }}</div>
        <a class="btn p-0 text-white" href="{{ route('dashboard') }}">戻る</a>
    </div>

    @if(Session::has('messageErr'))
        <p class="alert alert-danger text-center">{{ Session::get('messageErr') }}</p>
    @endif

    <div class="d-flex flex-column ms-3 mb-2 f-12 ">
        {{ $batchStatus->created_at->format('Y/m/d') }}
    </div>
    <div class="d-flex flex-column p-2 mb-3 me-3 ms-3 border-title">
        {{ __('連携処理名') }}
    </div>
    <div class="d-flex flex-column p-2 mb-3 me-3 ms-3">
        {{ $batchStatus->process_name }}
    </div>

    <div class="d-flex flex-column p-2 mb-3 me-3 ms-3 border-title">
        {{ __('備考') }}
    </div>
    <div class="d-flex flex-column p-2 mb-4 me-3 ms-3">
        {{ $batchStatus->notification }}
    </div>

    <div class="d-flex flex-column p-2 my-4 me-3 ms-3 border-title">
        {{ __('エラーの原因を解消した場合、以下のボタンをクリックしてください。') }}<br>
        {{ __('※エラーとなってロックされていた処理のロックが解除されます。原因が解消されるまで、クリックしないでください。') }}
    </div>

    {{-- エラー原因解消済ボタン --}}
    <div class="text-center">
        <x-form method="POST" id="form-resolved" action="{{ route('error-notification.update') }}">
            <input type="hidden" name="processId" value="{{ $batchStatus->process_id }}" />
            <x-submit-button type="button" data-bs-toggle="modal" data-bs-target="#openconfirm">エラー原因解消済</x-submit-button>
        </x-form>
    </div>

    <!-- 確認ダイアログ -->
    <div class="modal fade" id="openconfirm" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('通知') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="confirm-msg">エラーの原因は解消済みですか。</p>
                    <p class="confirm-msg">エラーとなってロックされていた処理のロックが解除されます。</p>
                    <p class="confirm-msg">よろしいですか。</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary confirm-ok" data-bs-dismiss="modal" onclick="document.getElementById('form-resolved').submit();">{{ __('ＯＫ') }}</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
