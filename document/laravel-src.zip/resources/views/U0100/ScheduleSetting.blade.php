<x-form-modal modal-id="schedule-setting-modal" title="予定設定" action="{{ $action }}"
    method="{{ $mode === 'add' ? 'POST' : 'PATCH' }}"
    onsubmit="submitScheduleSetting(event);">

    {{-- 削除ボタン --}}
    @if($mode == 'edit')
        @can('delete', $schedule)
            <x-slot name="titleButton">
                <x-form method="DELETE" id="schedule-setting-delete-form"
                    action="{{ route('schedule-setting.delete', ['schedule' => $schedule->id]) }}"
                    onsubmit="submitScheduleSetting(event);">
                    <input type="hidden" name="updated_at"
                        value="{{ $schedule->updated_at?->toDateTimeString() }}">
                    <button type="submit" class="btn" onclick="
                        let message =  '予定を削除します。よろしいですか。';
                        confirmSubmitFromModal(event, message, 'schedule-setting-modal', 'schedule-setting-delete-form');
                        ">
                        <i class="bi bi-trash-fill" title="予定を削除する"></i>
                    </button>
                </x-form>
            </x-slot>
        @endcan
    @endif

    @if($mode === 'edit')
        <input type="hidden" name="updated_at" value="{{ $schedule->updated_at?->toDateTimeString() }}">
    @endif

    {{-- 初期値 --}}
    @if( $mode === 'add' )
        @php
            $scheduleDate = $initDate->format('Y/m/d') ?? now()->format('Y/m/d'); // 初期日付
            $scheduleTitle = '';
            $scheduleContent = '';
        @endphp
    @elseif($mode === 'edit')
        @php
            $scheduleDate = $schedule->date?->format('Y/m/d');
            $scheduleTitle = $schedule->title;
            $scheduleContent = $schedule->content;
        @endphp
    @endif

    {{-- 予定日 --}}
    <label for="schedule-setting-date" class="form-label">日付</label>
    <div class="row">
        <div class="col-auto">
            <x-date-input name="date" id="schedule-setting-date" value="{{ $scheduleDate }}" required />
        </div>
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_date_error"></x-invalid-feedback>
    </div>

    {{-- 予定区分 --}}
    <label for="schedule-setting-type" class="form-label mt-3">予定区分</label>
    <div class="row">
        <div class="col-auto">
            <select class="form-select" name="type" id="schedule-setting-type">
                @foreach($scheduleTypes as $type)
                    <option value="{{ $type->key }}"
                        {{ $mode === 'edit' && $schedule->schedule_type  === $type->key ? 'selected' : '' }}>
                        {{ $type->value }}</option>
                @endforeach
            </select>
        </div>
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_type_error"></x-invalid-feedback>
    </div>

    {{-- 時間帯 --}}
    <div class="row mt-3">
        <label for="slots" class="form-label">時間帯</label>
    </div>

    {{-- 時間帯リスト --}}
    <div class="schedule-condition-grid">
        @foreach($slots as $slot)

            @php
                $checked = $mode == 'add' ? false : $scheduleSlots->where('slot_type', $slot->key)->isNotEmpty();
            @endphp

            <input type="checkbox" name="slots[{{ $slot->key }}]" id="schedule_setting_slots_{{ $slot->key }}"
                value="1" hidden {{ $checked ? 'checked' : '' }}>
            <label for="schedule_setting_slots_{{ $slot->key }}" class="d-flex justify-content-center cursor-pointer">
                <x-schedule-slot id="schedule_setting_slots_{{ $slot->key }}-icon" :icon="true" :checked="$checked">
                    {{ $slot->value }}
                </x-schedule-slot>
            </label>
        @endforeach
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_slots_error"></x-invalid-feedback>
    </div>

    {{-- ユーザ --}}
    <div class="row mt-3">
        <label for="persons" class="form-label">ユーザー</label>
    </div>

    <div class="schedule-condition-grid">
        @foreach($persons as $person)

            @php
                $checked = $mode == 'add' ? $initUserId == $person->id : $schedulePersons->where('user_id',
                $person->id)->isNotEmpty();
            @endphp

            {{-- 担当者リスト --}}
            <label for="schedule_setting_persons_{{ $person->id }}"
                class="d-flex justify-content-center cursor-pointer">
                <input type="checkbox" name="persons[{{ $person->id }}]" value="1" hidden
                    id="schedule_setting_persons_{{ $person->id }}"
                    {{ $checked ? 'checked' : '' }}>
                <x-user-profile src="{{ $person->avatar }}" title="{{ $person->name }}"
                    id="schedule_setting_persons_{{ $person->id }}-icon" :icon="true" :checked="$checked">
                    {{ $person->short_name }}
                </x-user-profile>
            </label>

        @endforeach
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_persons_error"></x-invalid-feedback>
    </div>

    {{-- 件名 --}}
    <label for="schedule-setting-title" class="form-label mt-3">件名</label>
    <input class="form-control" name="title" id="schedule-setting-title" required maxlength="20"
        value="{{ $scheduleTitle }}">

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_title_error"></x-invalid-feedback>
    </div>

    {{-- 内容 --}}
    <label for="schedule-setting-content" class="form-label mt-3">内容</label>
    <textarea class="form-control" name="content" id="schedule-setting-content" maxlength="100"
        rows="4">{{ $scheduleContent }}</textarea>

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_content_error"></x-invalid-feedback>
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_updated_at_error"></x-invalid-feedback>
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="schedule_setting_general_error_message_error"></x-invalid-feedback>
    </div>

    {{-- javascript --}}
    <script>
        $(`input[type=checkbox][id^=schedule_setting_]`).on("change", function () {
            if (this.checked) {
                $("#" + this.id + "-icon").removeClass("d-none");
            } else {
                $("#" + this.id + "-icon").addClass("d-none");
            }
        });

    </script>
</x-form-modal>
