<x-form-modal modal-id="schedule-weekly-setting-modal" title="スケジュール表示設定"
    action="{{ route('schedule-weekly.index') }}" method="POST" btn-label="設定"
    onsubmit="submitScheduleWeeklySetting(event);">

    {{-- 担当者 --}}
    <div class="row">
        <label for="select_user" class="form-label">ユーザー</label>
    </div>

    <div class="schedule-condition-grid">
        @foreach($users as $user)

            @php
                $checked = collect($selectedUserIds)->contains($user->id);
            @endphp

            {{-- 担当者リスト --}}
            <label for="select_user_{{ $user->id }}" class="d-flex justify-content-center cursor-pointer">
                <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1"
                    hidden {{ $checked ? 'checked' : '' }}
                    id="select_user_{{ $user->id }}">
                <x-user-profile src="{{ $user->avatar }}" title="{{ $user->name }}"
                    id="select_user_{{ $user->id }}-icon" :icon="true" :checked="$checked">
                    {{ $user->short_name }}
                </x-user-profile>
            </label>
        @endforeach
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="select_users_error">ユーザーを選択してください。</x-invalid-feedback>
    </div>

    <input type="hidden" name="start_date" value="{{ $date ?? now() }}">

    {{-- javascript --}}
    <script>
        loadUserSelectionListener();

    </script>

</x-form-modal>
