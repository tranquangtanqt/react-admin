<x-layouts.app title="スケジュール（リスト）">
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/customs/U0100/schedule-weekly.css') }}">
    @endpush

    {{-- ダッシュボードタブ --}}
    <x-U0100.dashboard-tabs active="schedule"></x-U0100.dashboard-tabs>
    {{-- スケジュール --}}
    <div id='sched-main' class='mx-1 my-3 d-flex flex-column flex-fill align-items-stretch'>
        {{-- スケジュールヘッダ --}}
        <div class="d-flex justify-content-between mt-1 mx-sm-2">
            <div class="d-flex align-items-center justify-content-between justify-content-sm-start flex-grow-1">
                <x-form-button method="POST" action="{{ route('schedule-list.index') }}"
                    class="rounded-pill bg-secondary text-white badge py-2 px-4 me-1 me-sm-3">
                    <x-slot name="input">
                        <input type="hidden" name="start_date" value="{{ now() }}">
                        @foreach ($selectedUsers as $user)
                            <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden checked>
                        @endforeach
                    </x-slot>
                    <span>今日</span>
                </x-form-button>
                <div class="d-flex flex-column align-items-center justify-content-between flex-sm-row mx-3 flex-grow-1 flex-sm-grow-0">
                    @if (count($dateRangeStrings) > 1)
                        <span>{{ $dateRangeStrings[0] ?? '' }}</span>
                        <span class="d-none d-sm-inline-block mx-1">〜</span>
                        <span>{{ $dateRangeStrings[1] ?? '' }}</span>
                    @else
                        <span>{{ $dateRangeStrings[0] ?? '' }}</span>
                    @endif
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center">
                <x-form-button method="POST" action="{{ route('schedule-weekly.index') }}"
                    class="btn-sm btn-outline-secondary px-4">
                    <x-slot name="input">
                        <input type="hidden" name="start_date" value="{{ $dateRange->startDate }}">
                        @foreach ($selectedUsers as $user)
                            <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden checked>
                        @endforeach
                    </x-slot>
                    <span>週</span>
                </x-form-button>
                <a href="#" class="btn btn-secondary btn-sm mx-1 text-nowrap">リスト</a>
            </div>
        </div>
        {{-- スケジュールボディ --}}
        <div class="sched-body">
            {{-- 絞り込みボタン --}}
            <div class="d-flex justify-content-center my-3">
                <x-form-button action="{{ route('schedule-list-setting.show') }}" method="POST"
                    class="btn submit-btn" onsubmit="fetchScheduleListSettingModal(event, this);">
                    <x-slot name="input">
                        @foreach ($selectedUsers as $user)
                            <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden checked>
                        @endforeach
                        <input type="hidden" name="start_date" value="{{ $dateRange->startDate }}">
                        <input type="hidden" name="end_date" value="{{ $dateRange->endDate }}">
                    </x-slot>
                    <span>絞り込み</span>
                </x-form-button>
            </div>

            <div class="px-1">
                @foreach ($dateRange as $date)
                    <hr class="mb-1">
                    <div class="mb-4" data-user-id="{{ auth()->user()->id }}"
                        data-date="{{ $date->format('Y/m/d') }}"
                        data-target-route="{{ route('schedule-setting.create') }}"
                        onclick="fetchScheduleSettingModal(event, this);">
                        <h2>
                            {{ $date->format('Y/m/d') }}
                        </h2>
                    </div>

                    @php
                        // 日付に対する日程
                        $schedulesByDate = $schedules->filter(fn($sched) => $sched->date->startOfDay()->equalTo($date->startOfDay()));
                        $prevSlotType = ''; // 全開の時間帯区分仮箱
                    @endphp

                    <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                        @foreach ($schedulesByDate as $sched)
                            @php
                                $shouldBreak = !$loop->first && $sched->slot_type != $prevSlotType; // 時間帯が全開と異なる場合改行
                                $prevSlotType = $sched->slot_type;
                            @endphp
                            @if ($shouldBreak)
                                <div style="width: 100%;"></div>
                            @endif
                            @if ($sched->reception_no)
                                <x-U0100.schedule-list-reception-card :schedule="$sched"
                                    :slotTitles="$slotTitles" :slotColors="$slotColors"
                                    :slots="$arrayOfSlots" />
                            @else
                                <x-U0100.schedule-list-general-card :schedule="$sched"
                                    :slots="$arrayOfSlots"
                                    :slotTitles="$slotTitles" :slotColors="$slotColors"
                                    :scheduleTypes="$arrayOfScheduleTypes" />
                            @endif
                        @endforeach
                    </div>
                @endforeach
            </div>
        </div>

        {{-- スケジュール表示設定画面（週間）モーダル --}}
        <div id="js-schedule-list-setting-modal"></div>
        {{-- 通常予定設定画面モーダル --}}
        <div id="js-schedule-setting-modal"></div>

        {{-- 通知モーダル --}}
        <x-confirm-modal />

        @push('scripts')
            {{-- 以下Javascript設定 --}}
            {{-- 以下画面リロード設定 --}}
            <x-U0100.reload-script />
        @endpush
</x-layouts.app>
