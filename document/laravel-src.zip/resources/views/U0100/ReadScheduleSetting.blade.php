<x-modal modal-id="schedule-setting-modal" title="予定詳細">

    {{-- 初期値 --}}
    @php
        $scheduleDate = $schedule->date?->format('Y/m/d');
        $scheduleTitle = $schedule->title;
        $scheduleContent = $schedule->content;
    @endphp

    {{-- 予定日 --}}
    <label for="schedule-setting-date" class="form-label">日付</label>
    <div class="row">
        <div class="col-auto">
            <p class="card px-3 py-2 border-1 m-0">{{ $scheduleDate }}</p>
        </div>
    </div>

    {{-- 予定区分 --}}
    <label for="schedule-setting-type" class="form-label mt-3">予定区分</label>
    <div class="row">
        <div class="col-auto">
            <p class="card px-3 py-2 border-1 m-0">{{ $scheduleTypes->value }}</p>
        </div>
    </div>


    {{-- 時間帯 --}}
    <div class="row mt-3">
        <label for="slots" class="form-label">時間帯</label>
    </div>

    {{-- 時間帯リスト --}}
    <div class="schedule-condition-grid">
        @foreach ($slots as $slot)
            <label for="schedule_setting_slots_{{ $slot->key }}" class="d-flex justify-content-center">
                <x-schedule-slot id="schedule_setting_slots_{{ $slot->key }}-icon" :icon="true"
                    :checked="true">
                    {{ $slot->value }}
                </x-schedule-slot>
            </label>
        @endforeach
    </div>

    {{-- ユーザ --}}
    <div class="row mt-3">
        <label for="persons" class="form-label">ユーザー</label>
    </div>

    <div class="schedule-condition-grid">
        @foreach ($schedulePersons as $person)
            {{-- 担当者リスト --}}
            <label for="schedule_setting_persons_{{ $person->id }}" class="d-flex justify-content-center">
                <x-user-profile src="{{ $person->avatar }}" title="{{ $person->name }}"
                    id="schedule_setting_persons_{{ $person->id }}-icon" :icon="true" :checked="true">
                    {{ $person->short_name }}
                </x-user-profile>
            </label>
        @endforeach
    </div>

    {{-- 件名 --}}
    <label for="schedule-setting-title" class="form-label mt-3">件名</label>
    <p class="card px-3 py-2 border-1 m-0">{{ $scheduleTitle }}</p>

    {{-- 内容 --}}
    <label for="schedule-setting-content" class="form-label mt-3">内容</label>
    <p class="sched-content--show card">{!! nl2br(e($scheduleContent)) !!}</p>
</x-modal>
