<x-layouts.app title="スケジュール（週間）">
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/customs/U0100/schedule-weekly.css') }}">
    @endpush

    {{-- ダッシュボードタブ --}}
    <x-U0100.dashboard-tabs active="schedule"></x-U0100.dashboard-tabs>

    <div class="d-flex flex-fill flex-row my-3">
        {{-- サイドボード --}}
        <div id='sideboard' class='sideboard mx-1 d-none d-md-flex flex-shrink-0 flex-column'>
            {{-- サイドボードヘッダ --}}
            <div class='sideboard-top text-end mt-1'>
                <button class="btn p-1" onclick="
                    $('.sideboard-body').toggleClass('d-none', 10000);
                    $(this).find('[role=collapse]').toggleClass('d-none');
                    $(this).find('[role=expand]').toggleClass('d-none')">
                    <i role="collapse" class="bi bi-chevron-left"></i>
                    <i role="expand" class="bi bi-chevron-right d-none"></i>
                </button>
            </div>
            {{-- サイドボードボディ --}}
            <div class='sideboard-body'>

                {{-- サイドボードカート --}}
                {{-- ピン留め受付 --}}
                @if ($pinnedReceptions->isNotEmpty())
                    <div class="mb-4">
                        <x-section-divider class="mt-0 mb-3" id="pinned-receptioins" title="ピン留め" link-to="none"> </x-section-divider>
                        @foreach ($pinnedReceptions as $reception)
                            <x-U0100.schedule-reception-card :reception="$reception"></x-U0100.schedule-reception-card>
                        @endforeach
                    </div>
                @endif

                {{-- 新規受付 --}}
                @if ($newReceptions->isNotEmpty())
                    <div class="mb-4">
                        <x-section-divider id="new-receptioins" title="新規受付" link-to="none"> </x-section-divider>
                        @foreach ($newReceptions as $reception)
                            <x-U0100.schedule-reception-card :reception="$reception"></x-U0100.schedule-reception-card>
                        @endforeach
                    </div>
                @endif

                {{-- 保留受付 --}}
                @if ($onHoldReceptions->isNotEmpty())
                    <div class="mb-4">
                        <x-section-divider id="on-hold-receptions" title="保留" link-to="none"> </x-section-divider>
                        @foreach ($onHoldReceptions as $reception)
                            <x-U0100.schedule-reception-card :reception="$reception"></x-U0100.schedule-reception-card>
                        @endforeach
                    </div>
                @endif

                {{-- 対象データがない場合 --}}
                @php
                    $noData = $onHoldReceptions->isEmpty() && $newReceptions->isEmpty() && $pinnedReceptions->isEmpty();
                @endphp
                @if ($noData)
                    <p class="text-center">対象受付情報がありません。</p>
                @endif
            </div>
        </div>

        {{-- スケジュール --}}
        <div id='sched-main' class='mx-1 d-flex flex-column flex-fill align-items-stretch'>
            {{-- スケジュールヘッダ --}}
            <div class="d-flex justify-content-between mt-1">
                <div class="d-flex align-items-center justify-content-between justify-content-sm-start flex-grow-1">
                    <x-form-button method="POST" action="{{ route('schedule-weekly.index') }}"
                        class="rounded-pill bg-secondary text-white badge py-2 px-4 me-1 me-sm-3">
                        <x-slot name="input">
                            <input type="hidden" name="start_date" value="{{ now() }}">
                            @foreach ($selectedUsers as $user)
                                <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden
                                    checked>
                            @endforeach
                        </x-slot>
                        <span>今日</span>
                    </x-form-button>
                    <x-form-button method="POST" action="{{ route('schedule-weekly.index') }}" class="ps-2 pe-1">
                        <x-slot name="input">
                            <input type="hidden" name="start_date" value="{{ $dateRange->startDate->subDays(7) }}">
                            @foreach ($selectedUsers as $user)
                                <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden
                                    checked>
                            @endforeach
                        </x-slot>
                        <i class="bi bi-chevron-left"></i>
                    </x-form-button>
                    <div class="d-flex flex-column align-items-center justify-content-between flex-sm-row mx-3">
                        <span>{{ $dateRange->startDate->format('Y/m/d') }}</span>
                        <span class="d-none d-sm-inline-block mx-1">〜</span>
                        <span>{{ $dateRange->endDate->format('Y/m/d') }}</span>
                    </div>
                    <x-form-button method="POST" action="{{ route('schedule-weekly.index') }}" class="ps-1 pe-2 me-2">
                        <x-slot name="input">
                            <input type="hidden" name="start_date" value="{{ $dateRange->startDate->addDays(7) }}">
                            @foreach ($selectedUsers as $user)
                                <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden
                                    checked>
                            @endforeach
                        </x-slot>
                        <i class="bi bi-chevron-right"></i>
                    </x-form-button>
                </div>
                <div class="d-flex justify-content-end align-items-center">
                    <a href="#" class="btn btn-sm btn-secondary px-4">週</a>
                    <x-form-button class="btn-outline-secondary btn-sm mx-1" method="POST"
                        action="{{ route('schedule-list.index') }}">
                        <x-slot name="input">
                            <input type="hidden" name="start_date" value="{{ $dateRange->startDate }}">
                            <input type="hidden" name="end_date" value="{{ $dateRange->endDate }}">
                            @foreach ($selectedUsers as $user)
                                <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden
                                    checked>
                            @endforeach
                        </x-slot>
                        <span class="text-nowrap">リスト</span>
                    </x-form-button>
                </div>
            </div>
            {{-- スケジュールボディ --}}
            <div class="sched-body">
                {{-- 絞り込みボタン --}}
                <div class="d-flex justify-content-center my-3">
                    @if (!userIsPicExternal())
                        <x-form-button action="{{ route('schedule-weekly-setting.show') }}" method="POST"
                            class="btn submit-btn" onsubmit="fetchScheduleWeeklySettingModal(event, this);">
                            <x-slot name="input">
                                @foreach ($selectedUsers as $user)
                                    <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden
                                        checked>
                                @endforeach
                                <input type="hidden" name="date" value="{{ $dateRange->startDate }}">
                            </x-slot>
                            <span>絞り込み</span>
                        </x-form-button>
                    @endif
                </div>
                {{-- スケジュールテーブル --}}
                <table id="sched-weekly-table" class="table table-bordered sched-weekly-table">

                    <thead class="bg-main">
                        {{-- テーブルヘッダ --}}
                        <tr>
                            <th scope="col" class="sched-user-col">
                            </th>

                            @foreach ($dateRange as $date)
                                <th scope="col" @class([
                                    'sched-weekly-header',
                                    'bg-info' => $date->isToday(),
                                    'text-info' => $date->isSaturday(),
                                    'text-danger' => $date->isSunday(),
                                ])>
                                    <div class="d-flex justify-content-center justify-content-sm-between align-items-center">
                                        <div class="sched-header-font">{{ $date->day }}</div>
                                        <div class="d-none d-sm-block">{{ $date->isoFormat('ddd') }}</div>
                                    </div>
                                </th>
                            @endforeach

                        </tr>
                    </thead>
                    @foreach ($selectedUsers as $user)
                        <tbody>
                            {{-- テーブルボディ --}}
                            <tr>
                                <td scope="row" class="align-middle">
                                    <div class="d-flex justify-content-center">
                                        <x-user-profile class="position-static" src="{{ $user->avatar }}">
                                            {{ $user->short_name }}
                                        </x-user-profile>
                                    </div>
                                </td>

                                @foreach ($dateRange as $date)
                                    @php
                                        $schedulesByUserDate = $schedules->where('user_id', $user->id)->filter(fn($sched) => $sched->date->startOfDay()->equalTo($date->startOfDay()));
                                    @endphp

                                    <td @class([
                                        'drop',
                                        'bg-info' => $date->isToday(),
                                        ])
                                        data-user-id="{{ $user->id }}"
                                        data-date="{{ $date->format('Y/m/d') }}"
                                        data-target-route="{{ route('schedule-setting.create') }}"
                                        onclick="fetchScheduleSettingModal(event, this);">

                                        <div name="date" class="d-none">
                                            {{ $date->format('Y/m/d') }}
                                        </div>
                                        @foreach ($schedulesByUserDate as $sched)
                                            <div style="margin-bottom: {{ $loop->last ? '1rem' : '0' }}">
                                                {{-- 関連受付情報がある場合 --}}
                                                @if ($sched->reception_no)
                                                    <a href="{{ route('info.show', $sched->reception_no) }}"
                                                        onclick="event.stopPropagation();" target="reception"
                                                        class="btn m-0 p-0 w-100">
                                                        <div class="sched-card-weekly">
                                                            <div class="sched-card-tag"
                                                                style="background-color: {{ $slotColors[$sched->slot_type] }}">
                                                                {{ $slotTitles[$sched->slot_type] }}
                                                            </div>
                                                            <div class="word-break-all text-truncate text-truncate-4">
                                                                {{ $sched->field_name }}
                                                            </div>
                                                        </div>
                                                    </a>

                                                    {{-- 関連受付情報がない場合 --}}
                                                @else
                                                    {{-- 更新権限持っている場合 --}}
                                                    @can('update', $sched)
                                                        @php
                                                            $targetRoute = route('schedule-setting.edit', $sched);
                                                        @endphp
                                                    @else
                                                        @php
                                                            $targetRoute = route('schedule-setting.show', $sched);
                                                        @endphp
                                                    @endcan
                                                    <button class="btn m-0 p-0 w-100"
                                                        onclick="fetchScheduleSettingModal(event, this);"
                                                        data-target-route="{{ $targetRoute }}">
                                                        <div class="sched-card-weekly">
                                                            <div class="sched-card-tag"
                                                                style="background-color: {{ $slotColors[$sched->slot_type] }}">
                                                                {{ $slotTitles[$sched->slot_type] }}
                                                            </div>
                                                            <div class="word-break-all text-truncate text-truncate-4">
                                                                {{ $sched->title }}
                                                            </div>
                                                        </div>
                                                    </button>
                                                @endif
                                            </div>
                                        @endforeach
                                    </td>
                                @endforeach
                            </tr>
                        </tbody>
                    @endforeach
                </table>
            </div>
        </div>
    </div>

    {{-- 訪問予定設定画面モーダル --}}
    <div id="js-set-schedule-modal"></div>
    {{-- 予定確認条件設定画面モーダル --}}
    <div id="js-set-schedule-check-condition-modal"></div>
    {{-- 予定確認設定画面モーダル --}}
    <div id="js-set-schedule-check-modal"></div>
    {{-- スケジュール表示設定画面（週間）モーダル --}}
    <div id="js-schedule-weekly-setting-modal"></div>
    {{-- 通常予定設定画面モーダル --}}
    <div id="js-schedule-setting-modal"></div>

    {{-- 通知モーダル --}}
    <x-confirm-modal />

    @push('scripts')
        {{-- 以下Javascript設定 --}}
        {{-- 以下画面リロード設定 --}}
        <x-U0100.reload-script />

        <script>
            // 画面が起動した後に訪問予定関連制御を動かせる
            $(window).on("load", function() {
                // loadSetScheduleListener("add"); // 訪問予定追加用
                // ドラッグ要素の設定
                $(".drag").draggable({
                    helper: 'clone', //クローン（残像）を出す設定
                    start: function() {
                        $(this).hide(); //ドラッグ中はクローン元を消す
                    },
                    stop: function() {
                        $(this).show() //移動後にクローン元（移動済み）を表示させる
                    }
                });

                // ドロップ要素の設定
                $(".drop").droppable({
                    //ドロップOKの要素を指定
                    accept: ".drag",
                    // ドロップ受け入れ要素指定
                    tolerance: "pointer",
                    // ホバー時のクラス
                    hoverClass: "drop-highlight",
                    //ドロップ時の動作
                    drop: function(event, ui) {

                        // ドラッグオブジェクト
                        const element = ui.draggable.get(0);

                        // ドロップオブジェクト
                        const target = event.target;

                        // 対象ユーザー
                        const userId = target.dataset.userId;

                        // 対象日付
                        const date = target.dataset.date;

                        // 訪問予定モーダル取得
                        fetchScheduleModal(event, element, 'add', userId, date);

                    }
                });
            });
        </script>
    @endpush
</x-layouts.app>
