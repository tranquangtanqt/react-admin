<x-form-modal modal-id="schedule-list-setting-modal" title="スケジュール表示設定"
    action="{{ route('schedule-list.index') }}" method="POST" btn-label="設定"
    onsubmit="$('#loading').removeClass('d-none');">

    <div class="d-none" id="validation_route"
        data-validation-route="{{ route('schedule-list-setting.validation') }}"></div>

    {{-- 予定日 --}}
    <div class="row">
        <label for="schedule_date" class="form-label">予定日付</label>
    </div>

    <div class="row gx-0 gx-sm-3 align-items-center justify-content-between justify-content-sm-start flex-nowrap">
        <div class="col-auto">
            <x-date-input name="start_date" id="schedule_list_setting_schedule_date_start"
                value="{{ $startDate->format('Y/m/d') }}" required />
        </div>
        <div class="col-auto"><span>〜</span></div>
        <div class="col-auto">
            <x-date-input name="end_date" id="schedule_list_setting_schedule_date_end"
                value="{{ $endDate->format('Y/m/d') }}" required />
        </div>
    </div>
    <div class="row d-none">
        <x-invalid-feedback id="schedule_list_setting_start_date_error"></x-invalid-feedback>
        <x-invalid-feedback id="schedule_list_setting_end_date_error"></x-invalid-feedback>
        <x-invalid-feedback id="schedule_list_setting_date_error"></x-invalid-feedback>
    </div>


    @if(userIsPicExternal())
        <input type="checkbox" name="selected_users[{{ auth()->user()->id }}]" value="1" hidden checked
            id="select_user_{{ auth()->user()->id }}">
    @else
        {{-- ユーザ --}}
        <div class="row mt-3">
            <label for="select_user" class="form-label">ユーザー</label>
        </div>
        <div class="schedule-condition-grid">
            @foreach($users as $user)

                @php
                    $checked = collect($selectedUserIds)->contains($user->id);
                @endphp

                {{-- 担当者リスト --}}
                <label for="select_user_{{ $user->id }}" class="d-flex justify-content-center cursor-pointer">
                    <input type="checkbox" name="selected_users[{{ $user->id }}]" value="1" hidden
                        {{ $checked ? 'checked' : '' }}
                        id="select_user_{{ $user->id }}">
                    <x-user-profile src="{{ $user->avatar }}" title="{{ $user->name }}"
                        id="select_user_{{ $user->id }}-icon" :icon="true" :checked="$checked">
                        {{ $user->short_name }}
                    </x-user-profile>
                </label>
            @endforeach
        </div>
    @endif

    <div class="row d-none">
        <x-invalid-feedback id="schedule_list_setting_selected_users_error"></x-invalid-feedback>
    </div>

    <x-slot name="bottomButton">
        <x-submit-button onclick="submitScheduleListSetting(event);">確定</x-submit-button>
    </x-slot>

    {{-- javascript --}}
    <script>
        loadUserSelectionListener();

    </script>

</x-form-modal>
