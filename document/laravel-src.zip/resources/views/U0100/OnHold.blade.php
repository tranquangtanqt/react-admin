<x-layouts.app title="保留受付">
    <x-U0100.dashboard-tabs active="onhold"></x-U0100.dashboard-tabs>
    <div class="px-2 px-sm-3">

        {{-- 日程調整（お客様要因） --}}
        @if($customerSchedulingReceptions->isNotEmpty())
        <x-section-divider-dashboard id="customer-scheduling" title="日程調整（お客様要因）">
        </x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($customerSchedulingReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

        {{-- 日程調整（自社要因） --}}
        @if($selfSchedulingReceptions->isNotEmpty())
        <x-section-divider-dashboard id="self-scheduling" title="日程調整（自社要因）">
        </x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($selfSchedulingReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

        {{-- 点検後様子見 --}}
        @if($observingReceptions->isNotEmpty())
        <x-section-divider-dashboard id="observing" title="点検後様子見" > </x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($observingReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

        {{-- 見積保留 --}}
        @if($quotationReceptions->isNotEmpty())
        <x-section-divider-dashboard id="quotation" title="見積保留"> </x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($quotationReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

        {{-- 部品納期未定 --}}
        @if($partsWaitingReceptions->isNotEmpty())
        <x-section-divider-dashboard id="parts-waiting" title="部品納期未定">
        </x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($partsWaitingReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

        {{-- 中間期 --}}
        @if($interphaseReceptions->isNotEmpty())
        <x-section-divider-dashboard id="interphase" title="中間期">
        </x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($interphaseReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

        {{-- メーカー対応 --}}
        @if($makerSupportReceptions->isNotEmpty())
        <x-section-divider-dashboard id="maker-support" title="メーカー対応" ></x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($makerSupportReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

        {{-- 定期点検 --}}
        @if($periodicReceptions->isNotEmpty())
        <x-section-divider-dashboard id="periodic" title="定期点検" > </x-section-divider-dashboard>
        <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-md-start">
            @foreach($periodicReceptions as $reception)
            <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
            @endforeach
        </div>
        @endif

    </div>

    {{-- 訪問予定追加・追加モーダル --}}
    <div id="js-set-schedule-modal"></div>

    {{-- 予定確認条件設定 --}}
    <div id="js-set-schedule-check-condition-modal"></div>

    {{-- 予定確認設定 --}}
    <div id="js-set-schedule-check-modal"></div>

    {{-- 受付状態設定モーダル --}}
    <div id="js-set-status-modal"></div>

    {{-- コメント設定モーダル --}}
    @include('U0200.SetComment')

    @push('scripts')
    {{-- 以下Javascript設定 --}}
    {{-- 以下画面リロード設定 --}}
    <x-U0100.reload-script/>
    @endpush
</x-layouts.app>
