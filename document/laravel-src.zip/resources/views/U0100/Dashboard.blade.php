<x-layouts.app title="ダッシュボード">
    <x-U0100.dashboard-tabs active="dashboard"></x-U0100.dashboard-tabs>

    <div class="px-2 px-sm-3">

        {{-- 連携エラー --}}
        @if ($errorBatches->isNotEmpty())
            <x-section-divider-dashboard id="error-messages" title="連携エラー通知">
                <x-slot name="titleIcon">
                    <i class="bi bi-exclamation-circle-fill text-danger mx-2"></i>
                </x-slot>
                － システム連携にてエラーが発生しました。ご確認してください。
            </x-section-divider-dashboard>
            <div class="mb-5">
                @foreach ($errorBatches as $error)
                    <a href="{{ route('error-notification.index', $error->process_id) }}"
                        class="btn text-start p-2 mb-3 card-border card-shadow card-frame rounded d-block">
                        <div class="f-12 mb-1">
                            {{ $error->created_at->format('Y/m/d H:m') }}
                        </div>
                        <p class="m-0">
                            {{ $error->process_name }}
                        </p>
                    </a>
                @endforeach
            </div>
        @endif

        {{-- リマインダー --}}
        @if ($reminderReceptions->isNotEmpty())
            <x-section-divider-dashboard id="reminders" title="リマインダー">
                ー リマインダー付きの受付があります。訪問予定調整などの必要なアクションを行ってください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($reminderReceptions as $reception)
                    <x-U0100.reminder-reception-card :reception="$reception"> </x-U0100.reminder-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 新規受付 --}}
        @if ($newReceptions->isNotEmpty())
            <x-section-divider-dashboard id="new-reception" title="新規受付">
                － L2で受付登録がありました。注意事項のコメントや、訪問予定の調整をしてください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($newReceptions as $reception)
                    <x-U0100.new-reception-card :reception="$reception">
                    </x-U0100.new-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 計上担当未定 --}}
        @if ($pjmgrUnsetReceptions->isNotEmpty())
            <x-section-divider-dashboard id="pjmgr-unset-reception" title="計上担当未定">
                － 計上担当が決まっていません。設定し、L2に登録をしてもらってください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($pjmgrUnsetReceptions as $reception)
                    <x-U0100.pjmgr-unset-reception-card :reception="$reception">
                    </x-U0100.pjmgr-unset-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 計上担当未定 --}}
        @if ($pjmgrSetReceptions->isNotEmpty())
            <x-section-divider-dashboard id="pjmgr-set-reception" title="計上担当決定">
                ー 計上担当はM3にて設定されました。L2にも計上担当を登録してください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($pjmgrSetReceptions as $reception)
                    <x-U0100.pjmgr-set-reception-card :reception="$reception">
                    </x-U0100.pjmgr-set-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 原価明細未確認 --}}
        @if ($costUncheckedReceptions->isNotEmpty())
            <x-section-divider-dashboard id="cost-unchecked-reception" title="原価明細未確認">
                ー 原価が確認されていません。ご確認してください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($costUncheckedReceptions as $reception)
                    <x-U0100.cost-unchecked-reception-card :reception="$reception">
                    </x-U0100.cost-unchecked-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 訪問予定（本日） --}}
        @if ($todayVisitReceptions->isNotEmpty())
            <x-section-divider-dashboard id="today-visit-reception" title="訪問予定（本日）">
                ー 本日の訪問予定があります。準備等を行い、訪問してください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($todayVisitReceptions as $reception)
                    <x-U0100.today-visit-reception-card :reception="$reception">
                    </x-U0100.today-visit-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 訪問予定（実績未入力） --}}
        @if ($noInputVisitReceptions->isNotEmpty())
            <x-section-divider-dashboard id="no-input-visit-reception" title="訪問予定（実績未入力）">
                ー 実績が未入力の訪問予定があります。実績を入力してください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($noInputVisitReceptions as $reception)
                    <x-U0100.no-input-visit-reception-card :reception="$reception">
                    </x-U0100.no-input-visit-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 訪問済 --}}
        @if ($visitedReceptions->isNotEmpty())
            <x-section-divider-dashboard id="visited-reception" title="訪問済">
                @if (userIsManager())
                    ー 昨日以前の訪問済の受付がありますが、内容確認や訪問予定調整などをされていないようです。計上担当にご確認してください。
                @else
                    ー 訪問済の受付があります。実績確認や訪問予定調整をしてください。
                @endif
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($visitedReceptions as $reception)
                    <x-U0100.visited-reception-card :reception="$reception">
                    </x-U0100.visited-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 訪問予定（後日） --}}
        @if ($nextVisitReceptions->isNotEmpty())
            <x-section-divider-dashboard id="next-visit-reception" title="訪問予定（後日）">
                ー 後日の訪問予定があります。準備等をしてください。
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($nextVisitReceptions as $reception)
                    <x-U0100.next-visit-reception-card :reception="$reception">
                    </x-U0100.next-visit-reception-card>
                @endforeach
            </div>
        @endif

        {{-- 入力完了 --}}
        @if ($inputCompleteReceptions->isNotEmpty())
            <x-section-divider-dashboard id="input-complete-reception" title="入力完了">
                @if (userIsManager())
                    ー 実績入力が完了しました。内容をご確認して上で状態を「入力チェック済」に変更してください。
                @else
                    ー 実績入力が完了しました。業務管理者が内容を確認しています。
                @endif
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($inputCompleteReceptions as $reception)
                    <x-U0100.reception-card :reception="$reception">
                    </x-U0100.reception-card>
                @endforeach
            </div>
        @endif

        {{-- 入力チェック済 --}}
        @if ($inputCheckedReceptions->isNotEmpty())
            <x-section-divider-dashboard id="input-checked-reception" title="入力チェック済">
                @if (userIsManager())
                    ー 入力チェック済受付があります。L2入力支援の方が内容を確認し、L2に入力しています。
                @else
                    ー 入力チェック済みがあります。実績をL2にて入力してください。
                @endif
            </x-section-divider-dashboard>
            <div class="d-flex flex-wrap mb-5 justify-content-center justify-content-sm-start">
                @foreach ($inputCheckedReceptions as $reception)
                    <x-U0100.reception-card :reception="$reception">
                    </x-U0100.reception-card>
                @endforeach
            </div>
        @endif

    </div>

    {{-- 計上担当設定モーダル --}}
    <div id="js-set-project-manager-modal"></div>

    {{-- 訪問予定追加・追加モーダル --}}
    <div id="js-set-schedule-modal"></div>

    {{-- 予定確認条件設定 --}}
    <div id="js-set-schedule-check-condition-modal"></div>

    {{-- 予定確認設定 --}}
    <div id="js-set-schedule-check-modal"></div>

    {{-- 受付状態設定モーダル --}}
    <div id="js-set-status-modal"></div>

    {{-- コメント設定モーダル --}}
    @include('U0200.SetComment')

    @push('scripts')
        {{-- 以下Javascript設定 --}}
        {{-- 以下画面リロード設定 --}}
        <x-U0100.reload-script />
    @endpush
</x-layouts.app>
