@push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0600/output-data.css') }}" />
@endpush
<x-layouts.app title="データ出力">
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div></div>
        <div class="p-0">データ出力</div>
        <a class="btn p-0 text-white" href="{{ route('dashboard') }}">戻る</a>
    </div>
    <div class="px-2">
        <p class="alert alert-danger text-center d-none"></p>
        <p class="alert alert-success text-center d-none"></p>
        <div class=" mb-2">充填回収情報出力</div>
        <form method="POST" action="/output-data/export" id="formPostDevice">
            <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
            <div class="ms-4">交付年月日</div>
            <div class="d-flex  align-items-baseline ms-4">
                <div class="w-180">
                    <x-date-input class="style-width form-control" name="dateStart" id="dateStart"
                        style="width:100% !important" autocomplete="off" />
                    <x-invalid-feedback id="firstDate"></x-invalid-feedback>
                </div>
                <p class="mx-2">～</p>
                <div class="w-180">
                    <x-date-input class="style-width form-control" name="dateEnd" id="dateEnd"
                        style="width:100% !important" autocomplete="off" />
                    <x-invalid-feedback id="lastDate"></x-invalid-feedback>
                </div>
            </div>
            <div class="d-flex justify-content-center mt-4 pb-4">
                <x-submit-button type="button">出力</x-submit-button>
            </div>
            <hr>
        </form>
    </div>
    @push('scripts')
        <script src="{{ mix('js/U0600/output-data.js') }}"></script>
    @endpush
</x-layouts.app>
