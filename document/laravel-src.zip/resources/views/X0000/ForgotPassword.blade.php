<x-layouts.base class="unauthenticated-body">
    @push('styles')
        <style>
            .border-title {
                border-top: 1px groove;
                border-bottom: 1px groove
            }

        </style>
    @endpush
    <div class="unauthenticated-card bg-white rounded border border-secondary px-2 py-3">
        <x-form method="POST" action="{{ route('password-reset.update') }}" class="w-100">
            <div class="d-flex flex-column align-items-center">
                <div class="d-flex flex-column align-items-center p-3">
                    <div class="mx-auto p-2 fw-bold">メンテナンス業務管理システム</div>
                </div>
            </div>
            <div class="d-flex flex-column align-items-left p-2 mb-3 me-3 ms-3 border-title">
                <p class="m-0 ms-3">パスワード再設定</p>
            </div>
            <div class="d-flex flex-column align-items-left p-3">
                登録されたパスワードを再設定します。
            </div>
            <div class="d-flex flex-column align-items-center">
                @csrf
                <input id="key" type="hidden" name="key" value="{{ $key }}" readonly>
                <div class="w-75 mb-4">
                    <label
                        for="user_id">{{ __('新しいパスワード') }}</label>
                    <div class="w-100">
                        <input id="password" type="password" maxlength="20" class="form-control form-login"
                            name="password" autofocus>
                        @error('password')
                            @foreach($errors->get('password') as $error )
                                <x-invalid-feedback>{{ $error }}</x-invalid-feedback>
                            @endforeach
                        @enderror
                    </div>
                </div>
                <div class="w-75 mb-4">
                    <label
                        for="password_confirm">{{ __('新しいパスワード - 確認') }}</label>
                    <div class="w-100">
                        <input id="password_confirm" type="password" maxlength="20" class="form-control form-login"
                            name="password_confirm" autofocus>
                        @error('password_confirm')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                    </div>
                </div>
                <div class="w-75 m-4">
                    <div class="w-100 mb-3">
                        <x-submit-button>パスワード再設定</x-submit-button>
                    </div>
                </div>
            </div>
        </x-form>
    </div>
</x-layouts.base>
