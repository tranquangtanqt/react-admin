<x-layouts.base class="unauthenticated-body">
    @push('styles')
        <style>
            .border-title {
                border-top: 1px groove;
                border-bottom: 1px groove
            }

        </style>
    @endpush
    <div class="unauthenticated-card bg-white rounded border border-secondary px-2 py-3">
        <div class="d-flex flex-column align-items-center">
            <div class="d-flex flex-column align-items-center p-3">
                <div class="mx-auto p-2 fw-bold">
                    {{ __('メンテナンス業務管理システム') }}
                </div>
            </div>
        </div>
        <div class="d-flex flex-column align-items-left p-2 mb-3 me-3 ms-3 border-title">
            <p class="m-0 ms-3">
                {{ __('パスワード再設定 エラー') }}
            </p>
        </div>
        <div class="d-flex flex-column align-items-left p-3">
            <p>{{ __('パスワード再設定の期限が切れてしまっているかURLに誤りがあります。') }}
            </p>
            <p>{{ __('パスワードの再設定を行う場合は、以下のリンクから再度メールを送信してください。') }}
            </p>
        </div>
        <div class="d-flex flex-column align-items-center mb-5">
            <a href="{{ route('password-forgot.index') }}"
                class="mx-auto">{{ __('IDやパスワードを忘れてしまった場合') }}</a>
        </div>
    </div>
</x-layouts.base>
