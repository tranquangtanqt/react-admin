<x-layouts.base class="login-bg" title="ログイン">
    <div class="unauthenticated-card bg-white rounded border px-2 py-3 login-frame">
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="d-flex flex-column align-items-center">
                <div class="d-flex flex-column align-items-center p-3">
                    <img class="login-logo" src="{{ asset('/storage/default/app_logo.jpg') }}">
                    <div class="mx-auto p-2 display-6 mt-3">Ｍ３システム</div>
                    <div class="mx-auto small">Mitani-const Maintenance Management</div>
                </div>
                @if (session()->has('errors'))
                    <div class="w-75 mb-2 text-center">
                        <span class="text-danger" role="alert">
                            {{ session('errors')->first() }}
                        </span>
                    </div>
                @endif

                <div class="w-75 mb-4">
                    <label for="login_id">{{ __('ユーザーID') }}</label>

                    <div class="w-100">
                        <input id="login_id" type="login_id"
                            class="form-control form-login @error('login_id') is-invalid @enderror" name="login_id"
                            value="{{ old('login_id') }}" required autocomplete="login_id" autofocus>

                        @error('login_id')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="w-75 mb-4">
                    <label for="password">{{ __('パスワード') }}</label>

                    <div class="w-100">
                        <input id="password" type="password"
                            class="form-control form-login @error('password') is-invalid @enderror" name="password"
                            autocomplete="current-password" required autofocus>

                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="w-75 m-4">
                    <div class="w-100 mb-3">
                        <button type="submit" class="btn btn-settle w-100 text-white">
                            {{ __('ログイン') }}
                        </button>
                    </div>
                </div>

                <a href="{{ route('password-forgot.index') }}" class="mb-4 mx-auto">IDやパスワードを忘れてしまった場合</a>
            </div>
        </form>
    </div>
</x-layouts.base>
