<x-layouts.base class="unauthenticated-body">
    @push('styles')
        <style>
            .border-title {
                border-top: 1px groove;
                border-bottom: 1px groove
            }

        </style>
    @endpush
    <div class="unauthenticated-card bg-white rounded border border-secondary px-2 py-3">
        <x-form method="POST" action="{{ route('password-forgot.store') }}" class="w-100">
            <div class="d-flex flex-column align-items-center">
                <div class="d-flex flex-column align-items-center p-3">
                    <div class="mx-auto p-2 fw-bold">
                        {{ __('メンテナンス業務管理システム') }}
                    </div>
                </div>
            </div>
            <div class="d-flex flex-column align-items-center p-2 mb-3 me-3 ms-3 border-title">
                {{ __('ユーザID、パスワードを忘れてしまった場合') }}
            </div>
            <div class="d-flex flex-column align-items-center p-3">
                <p class="m-0">
                    {{ __('登録されたメールアドレスを入力し、「送信」のボタンをクリックしてください。') }}
                </p>
                <p>{{ __('ユーザーID、パスワード再設定URLを登録メール に送信します。') }}
                </p>
            </div>
            <div class="d-flex flex-column align-items-center">
                <div class="w-75 mb-2">
                    <label
                        for="email">{{ __('メールアドレス') }}</label>
                    <div class="w-100">
                        <input id="email" type="text" maxlength="254" class="form-control form-login" name="email"
                            value="{{ old('email') }}" autocomplete="email" autofocus>
                        @error('email')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                    </div>
                </div>
                <div class="w-75 m-4">
                    <div class="w-100 mb-4">
                        <x-submit-button>送信</x-submit-button>
                    </div>
                </div>
            </div>
        </x-form>
    </div>
</x-layouts.base>
