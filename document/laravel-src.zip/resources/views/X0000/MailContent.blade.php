<!DOCTYPE html>
<html>
<head>
</head>
<body>
    @for ($i = 1; $i < count($details); $i++)
        <div>{!! $details[$i] !!}</div>
    @endfor
</body>
</html>
