<x-layouts.app title="ユーザー情報設定">
@push('styles')
<link rel="stylesheet" href="{{ mix('css/X0600/set-user-info.css') }}">
@endpush
    {{--ユーザー情報設定--}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">{{ __('ユーザー情報設定') }}</div>
        <a  class="btn p-0 text-white" href="{{ route('dashboard') }}">{{ __('戻る') }}</a>
    </div>
    <div class="py-2 px-2 px-sm-3">
    <x-form method="POST" action="{{ route('set-user-info.update') }}" class="w-100" enctype="multipart/form-data">
        {{ method_field('PATCH') }}
        @csrf
        <div class="upload-image mb-4 file-choice">
            <div>
                <label class="mb-2" for="choise-file">{{ __('プロフィール画像') }}</label>
            </div>
            <div class="w-100">
                <div style="d-block">
                    <div>
                        @if($user == null)
                            <img id="userImg" class="user-image ms-4 mt-4" src="{{ url('storage/default/user_profile.jpg') }}" alt="user image">
                        @else
                            <img id="userImg" class="user-image ms-4 mt-4"  src="data:image/png;base64, {{ stream_get_contents($user->file) }}" alt="user image">
                        @endif
                        <a id="deleteImg" class="btn"><i class="bi bi-trash-fill" title="プロフィール画像を削除する"></i></a>
                    </div>
                    <div class="change-btn">
                        <a class="btn" onclick="document.getElementById('file').click();">画像変更</a>
                    </div>
                    <input type="file" id="file" style="display: none;" name="file" accept="image/*"/>
                    <x-invalid-feedback id="alert"></x-invalid-feedback>
                    @error('file')
                        <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                    @enderror
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-center py-2 px-2 px-sm-3 mb-3">
            <x-submit-button class="btn submit-btn btn-save" id="save">確定</x-submit-button>
        </div>
    </x-form>
    </div>
    {{--Confirm delete modal--}}
    <x-confirm-modal modalId="confirm-delete" onclick="confirmDelete();">
        <p>{{ __('プロフィール画像を削除します。よろしいですか。') }}</p>
    </x-confirm-modal>

@push('scripts')
<script src="{{ mix('js/X0600/set-user-info.js') }}"></script>
@endpush
</x-layouts.app>
