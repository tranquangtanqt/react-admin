<x-layouts.app title="パスワード変更">
    <div class="sub-header sub-header-grid py-1">
        <div></div>
        <div class="p-0 d-flex align-items-center justify-content-center"><span>パスワード変更</span></div>
        @if(session()->has('from_login'))
            <div></div>
        @else
            <div class="text-end pe-2 py-0">
                <a class="btn text-end text-white" href="{{ route('dashboard') }}">戻る</a>
            </div>
        @endif
    </div>
    <div class="mt-2 px-3">
        <div>
            @if(session()->has('password_expired'))
                <p class="my-0">パスワードの更新時期です。</p>
                <p class="mt-1 mb-3">パスワードを変更してください。</p>
                <a class="" href="{{ route('dashboard') }}">後で変更する</a>
            @endif
        </div>

        <div class="mt-3">
            <x-form class="w-100" action="{{ route('set-password.update') }}">

                <div class="my-2 pt-2">
                    <label for="password" class="form-label">現在パスワード</label>
                    <input class="form-control" type="password" name="password" id="password" value=""
                        style="max-width: 400px;" required>
                </div>
                @error('password')
                    <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                @enderror

                <div class="my-2 pt-2">
                    <label for="new_password" class="form-label">新しいパスワード</label>
                    <input class="form-control" type="password" name="new_password" id="new_password" value=""
                        style="max-width: 400px;" required>
                </div>
                @error('new_password')
                    <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                @enderror

                <div class="my-2 pt-2">
                    <label for="new_password_confirmation" class="form-label">新しいパスワード - 確認</label>
                    <input class="form-control" type="password" name="new_password_confirmation"
                        id="new_password_confirmation" value="" style="max-width: 400px;" required>
                </div>
                @error('new_password_confirmation')
                    <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                @enderror

                <div class="my-3 pt-3 text-center">
                    <x-submit-button>確定</x-submit-button>
                </div>

            </x-form>
        </div>
    </div>
</x-layouts.app>
