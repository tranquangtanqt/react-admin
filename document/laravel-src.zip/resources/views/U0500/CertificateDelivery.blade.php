<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>作業完了証明書　兼　フロン類充填・回収証明書（納品書）</title>
        <style>
            html, body {
                background-color: #fff;
                color: black;
                font-family: ipagothic;
                font-weight: 100;
                height: 100vh;
                margin: 28.9mm 0 10mm 0 !important;
                position: relative;
            }

            #u0502-body header {
                position: fixed;
                top: -15mm;
                left: 8.5mm;
            }

            .text-normal {
                font-weight: normal;
            }
            .text-wrap{
                word-wrap: break-word;
            }
            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }
            .content {
                margin: auto;
                width: 193mm;
                font-size: 8pt;
            }
            .text-padding {
                padding: 1px;
            }
            .padding-top {
                padding-top: 1mm;
            }
            .padding-bottom {
                padding-bottom: 1mm;
            }
            .padding-left {
                padding-left: 1mm;
            }
            .padding-right{
                padding-right: 1mm;
            }
            .title {
                font-size: 14pt;
                text-align: center;
            }
             /*Text-align*/
            .align-L{
                text-align: left;
            }
            .align-R{
                text-align: right;
            }
            .align-C{
                text-align: center;
            }
            /* Set Float*/
            .float-L{
                float: left;
            }
            .float-R{
                float: right;
            }

            /* Set width col*/
            .col-5{
                width: 5mm;
            }
            .col-8{
                width: 8mm;
            }
            .col-10{
                width: 10mm;
            }
            .col-13{
                width: 13mm;
            }
            .col-15{
                width: 15mm;
            }
            .col-17 {
                width: 17mm;
            }
            .col-18 {
                width: 18mm;
            }
            .col-20{
                width: 20mm;
            }
            .col-25{
                width: 25mm;
            }
            .col-30{
                width: 30mm;
            }
            .col-35 {
                width: 35mm;
            }
            .col-40{
                width: 40mm;
            }
            .col-44{
                width: 44mm;
            }
            .col-45{
                width: 45mm;
            }
            .col-50{
                width: 50mm;
            }
            .col-52{
                width: 52mm;
            }
            .col-55{
                width: 55mm;
            }
            .col-60{
                width: 60mm;
            }
            .col-65{
                width: 65mm;
            }
            .col-80{
                width: 80mm;
            }
            .col-90 {
                width: 90mm;
            }
            .col-100 {
                width: 100mm;
            }

            .col-110{
                width: 110mm;
            }
            .col-130 {
                width: 130mm;
            }
            .col-140 {
                width: 140mm;
            }
            .col-150{
                width: 150mm;
            }
            .col-155{
                width: 155mm;
            }
            .col-160{
                width: 160mm;
            }
            .col-170 {
                width: 170mm;
            }

            .col-180{
                width: 180mm;
            }

            /* Border */
            .border-bottom{
                border-bottom: 1px solid black;
            }
            .border-top{
                border-top: 1px solid black;
            }

            .border-right{
                border-right: 1px solid black;
            }
            .border-left{
                border-left: 1px solid black;
            }

            .table-border , .table-border th , .table-border td
            {
                border: 1px solid black;
                border-collapse: collapse;
            }
            .border-all {
                border: 1px solid black;
            }
            .vertical-align-top {
                vertical-align: top;
            }
            .vertical-align-bottom {
                vertical-align: bottom;
            }
            .f-6 {
                font-size: 6px;
            }
            .f-8 {
                font-size: 8px;
            }
            .f-9 {
                font-size: 9px;
            }
            .h-9 {
                height: 9mm;
            }
            .h-24 {
                height: 24mm;
            }
            #u0502-body table tr td {
                padding-top: 1mm;
            }
            .ellipsis-text {
                display: inline-block;
                text-overflow: ellipsis !important;
                overflow: hidden;
                white-space: nowrap;
                width: 100%;
            }

            .col-188 {
                width: 188mm;
            }
            .col-108 {
                width: 108mm;
            }
            .col-168 {
                width: 168mm;
            }
            .col-190 {
                width: 190mm;
            }
            .col-193 {
                width: 193mm;
            }
            .u0502-company-info {
                position: absolute;
                margin-left: 112mm;
                padding-top: 32mm;
            }
            .pos-relative {
                position: relative;
            }
            .pos-absolute {
                position: absolute;
            }
            .u0502-qrcode {
                position: absolute;
                right: 2mm;
                padding-top: 5mm;
            }
            .m-top--1 {
                margin-top: -1px;
            }
            .m-left-15 {
                margin-left: 15mm
            }
            .u0502-remark {
                height: 16mm;
                overflow-wrap: break-word;
                padding-right: 3mm !important;
            }
            .u0502-work_detail {
                word-break: break-word;
            }
            .p-right-0-1 {
                padding-right: 0.1mm !important
            }
        </style>
    </head>
    <body id="u0502-body">
        <header>
            <div class="content text-normal">
                <div class="title">
                    作業完了証明書　兼　フロン類充填・回収証明書（納品書）
                </div>
                <table class="col-188">
                    <tr>
                        <td class="col-15">整理番号</td>
                        <td class="col-30">{{ $dataHeader->no }}</td>
                        <td class="col-20">商談番号</td>
                        <td class="col-108"> {{ $dataHeader->related_pj_no }}</td>
                    </tr>
                    <tr>
                        <td class="col-15">受付日</td>
                        <td class="col-30">{{ $dataHeader->l2_date }}</td>
                        <td class="col-20">計上担当</td>
                        <td class="col-108">{{ $pjMgrName }}</td>
                    </tr>
                    <tr>
                        <td class="col-15 vertical-align-top">受付内容</td>
                        <td class="col-168 vertical-align-top text-wrap h-9" colspan="3">
                            <div style="height: 8mm; overflow: hidden;">{{ $dataHeader->receptions_content }}</div>
                        </td>
                    </tr>
                </table>

                <table class="col-190 border-all" cellpadding="0" cellspacing="0">
                    <!-- row 1 -->
                    <tr>
                        <td class="col-20 vertical-align-top border-all padding-left" rowspan="3">お客様</td>
                        <td class="col-100 padding-left">{{ $dataHeader->field_address }}</td>
                        <td class="col-8"></td>
                        <td class="col-10">TEL</td>
                        <td class="col-44">{{ mb_substr($dataHeader->field_tel, 0, 13) }}</td>
                        <td class="col-8 border-right"></td>
                    </tr>
                    <tr>
                        <td class="col-100 padding-left">{{ $dataHeader->field_name }}</td>
                        <td class="col-8">様</td>
                        <td class="col-10">TEL</td>
                        <td class="col-44">{{ mb_substr($dataHeader->field_mobile_tel, 0, 13) }}</td>
                        <td class="col-8 border-right"></td>
                    </tr>
                    <tr>
                        <td class="col-100"></td>
                        <td class="col-8"></td>
                        <td class="col-10 padding-bottom">担当</td>
                        <td class="col-44 padding-bottom">{{ mb_substr($dataHeader->field_person_name, 0, 15) }}</td>
                        <td class="col-8 padding-bottom">様</td>
                    </tr>
                </table>
            </div>
        </header>

        <div class="content text-normal main pos-relative">
            <div class="u0502-company-info">
                <img src="storage/default/company_info.png" class="h-24"/>
                <div class="u0502-qrcode">
                    <img src="data:image/png;base64, {{ base64_encode(QrCode::size(60)->generate($qrcodeurl->string1)) }} ">
                </div>
            </div>
            <table class="col-190 border-bottom border-left border-right" cellpadding="0" cellspacing="0">
                <!-- row 2 -->
                <tr>
                    <td class="col-20 vertical-align-top border-right padding-left" rowspan="3">ご依頼元</td>
                    <td class="col-100 padding-left">{{ $dataHeader->client_address }}</td>
                    <td class="col-8">&nbsp;</td>
                    <td class="col-10">TEL</td>
                    <td class="col-44">{{ mb_substr($dataHeader->client_tel, 0, 13) }}</td>
                    <td class="col-8 align-C">{{ $dataHeader->client_billing_deadline }}</td>
                </tr>
                <tr>
                    <td class="col-100 padding-left">{{ $dataHeader->client_name }}</td>
                    <td class="col-8">様</td>
                    <td class="col-10">FAX</td>
                    <td class="col-44">{{ mb_substr($dataHeader->client_fax, 0, 13) }}</td>
                    <td class="col-8 border-right">&nbsp;</td>
                </tr>
                <tr>
                    <td class="col-100">&nbsp;</td>
                    <td class="col-8">&nbsp;</td>
                    <td class="col-10 padding-bottom">担当</td>
                    <td class="col-44 padding-bottom">{{ mb_substr($dataHeader->client_person_name, 0, 15) }}</td>
                    <td class="col-8 border-right padding-bottom">様</td>
                </tr>

                <!-- row 3 -->
                <tr>
                    <td class="col-20 vertical-align-top border-all padding-left" rowspan="2">ご請求先</td>
                    <td class="col-100 border-top padding-left">{{ $dataHeader->billing_name }}</td>
                    <td class="col-8 border-top">様</td>
                    <td class="col-10 border-top">TEL</td>
                    <td class="col-44 border-top">{{ mb_substr($dataHeader->billing_tel, 0, 13) }}</td>
                    <td class="col-8 border-top border-right">&nbsp;</td>
                </tr>
                <tr>
                    <td class="col-100">&nbsp;</td>
                    <td class="col-8">&nbsp;</td>
                    <td class="col-10 padding-bottom">FAX</td>
                    <td class="col-44 padding-bottom">{{ mb_substr($dataHeader->billing_fax, 0, 13) }}</td>
                    <td class="col-8">&nbsp;</td>
                </tr>
            </table>

            <div class="header pos-relative">
                <table class="col-190 border-left m-top--1" cellpadding="0" cellspacing="0">
                    <tr>
                        <td class="col-20 border-right vertical-align-top padding-left p-right-0-1" rowspan="2">充塡量・種類</td>
                        <td class="col-15 padding-left">{{ $dataHeader->gas_in_type }}</td>
                        <td class="col-15 align-R border-right padding-right">{{ $dataHeader->gas_in_date }}</td>
                        <td class="col-20 border-right vertical-align-top padding-left align-C" rowspan="2">回収量・種類</td>
                        <td class="col-15 padding-left">{{ $dataHeader->gas_out_type }}</td>
                        <td class="col-15 align-R border-right padding-right padding-left">{{ $dataHeader->gas_out_date }}</td>
                        <td class="col-80 vertical-align-top padding-left" rowspan="3">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="col-15 padding-left padding-bottom">{{ $dataHeader->gas_in_gas_type }}</td>
                        <td class="col-15 border-right align-R padding-right padding-bottom">{{ $dataHeader->gas_in_quantity }} Kg</td>
                        <td class="col-15 padding-left padding-bottom">{{ $dataHeader->gas_out_gas_type }}</td>
                        <td class="col-15 border-right align-R padding-right padding-bottom padding-left">{{ $dataHeader->gas_out_quantity }}  Kg</td>
                    </tr>

                    <tr>
                        <td class="col-20 border-top border-right border-bottom vertical-align-top padding-left">備考</td>
                        <td class="border-top border-right border-bottom vertical-align-top padding-left padding-bottom u0502-remark" colspan="5">
                                {{ $dataHeader->remark }}
                        </td>
                    </tr>
                </table>

                <table class="col-193">
                    <tr>
                        <td class="col-18 vertical-align-top">作業区分</td>
                        <td class="col-52 vertical-align-top">{{ $dataHeader->work_report_work_type }}</td>
                        <td class="col-110 f-9">
                           当社は、お客様よりお知らせいただいた個人情報を、製品の修理・サービス業務の履行のため、製品や修理・
                           サービスの品質管理・維持・向上のため、お客様にとって有益と考える情報をお届けするために使用致します。
                           尚、当社のグループ関連会社とお客様の個人情報を共同利用する場合があります。
                        </td>
                    </tr>
                </table>

                <table class="col-190">
                    <tr>
                        <td class="col-50">作業が完了したことを認めます。</td>
                        <td class="col-140">{{ $dataHeader->work_report_payment_type }}</td>
                    </tr>
                </table>
            </div>

            @php
                $scheduleTemp = -1;
            @endphp
            @for($i = 0; $i < count($dataBody); $i++)

                {{-- loop 1--}}
                @if ($scheduleTemp != $dataBody[$i]->schedule_id)
                <hr style="border: 0.1mm solid black !important;">
                    <table class="col-190">
                        <tr>
                            <td class="col-20">作業日</td>
                            <td class="col-140" colspan="3">{{ $dataBody[$i]->schedule_date }}</td>
                            <td class="col-10">署名</td>
                            @if ( $dataBody[$i]->digital_flag )
                            <td class="col_20 float-R">{{ $dataBody[$i]->signed_at }}</td>
                            @else
                            <td class="col_20 float-R">&nbsp;</td>
                            @endif
                        </tr>

                        <tr>
                            <td class="col-20">ＫＹポイント</td>
                            <td class="col-30">{{ $dataBody[$i]->ky_point_type }}</td>
                            <td class="col-30">ワンポイント対策</td>
                            <td class="">{{ $dataBody[$i]->one_point }}</td>
                            <td class="col-30" colspan="2" rowspan="2">
                                @if ($dataBody[$i]->digital_flag)
                                    @if ($dataBody[$i]->file)
                                        <img height="40px" width="120px" src="data:image/png;base64, {{ stream_get_contents($dataBody[$i]->file) }}">
                                    @endif
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <td class="col-20 vertical-align-top">サービスマン</td>
                            <td class="col-140 vertical-align-top" colspan="3">
                                <div class="ellipsis-text">
                                    <span>{{ $dataBody[$i]->user_name }}</span>
                                </div>
                            </td>
                        </tr>
                    </table>
                @endif
                <hr class="m-left-15" style="border: 0.1mm solid black !important;">
                {{-- loop 2--}}
                <table cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="padding: 0; margin: 0">
                            <table clas="col-193" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td class="col-15">&nbsp;</td>
                                    <td class="col-10">系統</td>
                                    <td class="col-60" colspan="2">{{ $dataBody[$i]->group_name }}</td>
                                    <td class="col-10">機種</td>
                                    <td class="col-35">{{ $dataBody[$i]->device_type }}</td>
                                    <td class="col-10">機番</td>
                                    <td class="col-50">{{ $dataBody[$i]->device_no }}</td>
                                </tr>
                            </table>
                            <table clas="col-190" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td class="col-15">&nbsp;</td>
                                    <td class="col-20 vertical-align-top">作業内容</td>
                                    <td class="col-155">
                                        <div style="width: 155mm; overflow-wrap: break-word;">
                                            <span>{{ $dataBody[$i]->work_detail }}</span>
                                        </div>

                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                {{-- end loop 2--}}
                @php
                    $scheduleTemp = $dataBody[$i]->schedule_id;
                @endphp
            @endfor

            @if ($quotation)
            {{-- quotation start --}}
            <hr style="border: 0.1mm solid black !important;">
            <div class="quotation">
                @for($i = 0 ; $i < count($quotation); $i++)
                    @if ($i == 0)
                        <table class="col-190" cellpadding="0" cellspacing="0">
                            <tr>
                                <td class="col-20">作業No・品番</td>
                                <td class="col-20">{{ $quotation[$i]->work_no }}</td>
                                <td class="col-10">数量</td>
                                <td class="col-10 align-R">{{ number_format($quotation[$i]->quantity , 2) }}</td>
                                <td class="col-10">&nbsp;</td>
                                <td class="col-20">{{ $quotation[$i]->unit }}</td>
                                <td class="col-10">金額</td>
                                <td class="col-20 align-R">{{ number_format($quotation[$i]->amount) }}円</td>
                                <td class="col-10">&nbsp;</td>
                                <td class="col-20">作業名・品名</td>
                                <td class="col-40">{{ $quotation[$i]->name }}</td>
                            </tr>
                        </table>
                    @else
                        <table class="col-190" cellpadding="0" cellspacing="0">
                            <tr>
                                <td class="col-20">&nbsp;</td>
                                <td class="col-20">{{ $quotation[$i]->work_no }}</td>
                                <td class="col-10">&nbsp;</td>
                                <td class="col-10 align-R">{{ number_format($quotation[$i]->quantity , 2) }}</td>
                                <td class="col-10">&nbsp;</td>
                                <td class="col-20">{{ $quotation[$i]->unit }}</td>
                                <td class="col-10">&nbsp;</td>
                                <td class="col-20 align-R">{{ number_format($quotation[$i]->amount) }}円</td>
                                <td class="col-30">&nbsp;</td>
                                <td class="col-40">{{ $quotation[$i]->name }}</td>
                            </tr>
                        </table>
                    @endif
                @endfor
                <table class="col-190" cellpadding="0" cellspacing="0">
                    <tr>
                        <td class="col-55">&nbsp;</td>
                        <td class="col-40 align-R">小計({{ $quotation[0]->tax_included_flag_name }})</td>
                        <td class="col-25 align-R">{{ number_format($totalAmount) }}円</td>
                        <td class="col-75">&nbsp;</td>
                    </tr>
                </table>
            </div>
            @endif
            {{-- quotation end --}}

            @php
                $temp = -1;
                $array_records =[];
            @endphp
            <hr style="border: 0.1mm solid black !important;">
            @for($i = 0; $i < count($dataFooter); $i++)
                @php
                    $recordsId = $dataFooter[$i]->records_id;
                @endphp
                @if( $temp !== $recordsId)
                    @if (!in_array($recordsId, $array_records))
                        <table cellpadding="0" cellspacing="0">
                            <tr>
                                <td style="padding: 0; margin: 0">
                                    <table class="col-190" cellpadding="0" cellspacing="0">
                                        <tr>
                                            @if ($i == 0)
                                                <td class="col-15">運転記録</td>
                                            @else
                                                <td class="col-15">&nbsp;</td>
                                            @endif
                                            <td class="col-10">系統 - {{ $recordsId  }}</td>
                                            <td class="col-55">{{ $dataFooter[$i]->group_name }}</td>
                                            <td class="col-10">機種</td>
                                            <td class="col-45">{{ $dataFooter[$i]->device_type }}</td>
                                            <td class="col-10">機番</td>
                                            <td class="col-45">{{ $dataFooter[$i]->device_no }}</td>
                                        </tr>
                                    </table>

                                    <table class="col-190" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td class="col-15">&nbsp;</td>
                                            <td class="col-10">ＨＰ</td>
                                            @if ($dataFooter[$i]->record01 == null)
                                                <td class="col-17 align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 align-R">{{ $dataFooter[$i]->record01 }} MPa</td>
                                            @endif
                                            <td class="col-10">&nbsp;</td>

                                            <td class="col-10">ＬＰ</td>
                                            @if ($dataFooter[$i]->record02 == null)
                                                <td class="col-17 align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 align-R">{{ $dataFooter[$i]->record02 }} MPa</td>
                                            @endif
                                            <td class="col-10">&nbsp;</td>

                                            <td class="col-15">総合電流</td>
                                            @if ($dataFooter[$i]->record03 == null)
                                                <td class="col-17 align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 align-R">{{ number_format($dataFooter[$i]->record03, 1) }} A&nbsp;</td>
                                            @endif
                                            <td class="col-5">&nbsp;</td>

                                            <td class="col-10">電圧</td>
                                            @if ($dataFooter[$i]->record04 == null)
                                                <td class="col-17 align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 align-R">{{ number_format($dataFooter[$i]->record04, 0) }} V&nbsp;</td>
                                            @endif

                                            <td class="col-10">&nbsp;</td>

                                            <td class="col-10">過熱度</td>
                                            @if ($dataFooter[$i]->record05 == null)
                                                <td class="col-17 align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 align-R">{{ number_format($dataFooter[$i]->record05, 1) }} &#8451;</td>
                                            @endif
                                        </tr>
                                    </table>

                                    <table class="col-190" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td class="col-15">&nbsp;</td>
                                            <td class="col-10 padding-bottom">吸込</td>
                                            @if ($dataFooter[$i]->record06 == null)
                                                <td class="col-17 padding-bottom align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 padding-bottom align-R">{{ number_format($dataFooter[$i]->record06, 1) }} &#8451;&nbsp;</td>
                                            @endif
                                            <td class="col-10">&nbsp;</td>

                                            <td class="col-10 padding-bottom">吹出</td>
                                            @if ($dataFooter[$i]->record07 == null)
                                                <td class="col-17 padding-bottom align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 padding-bottom align-R">{{ number_format($dataFooter[$i]->record07, 1) }} &#8451;&nbsp;</td>
                                            @endif
                                            <td class="col-10">&nbsp;</td>

                                            <td class="col-15 padding-bottom">外気温</td>
                                            @if ($dataFooter[$i]->record08 == null)
                                                <td class="col-17 padding-bottom align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 padding-bottom align-R">{{ number_format($dataFooter[$i]->record08, 1) }} &#8451;</td>
                                            @endif
                                            <td class="col-5">&nbsp;</td>

                                            <td class="col-10 padding-bottom">吸入</td>
                                            @if ($dataFooter[$i]->record09 == null)
                                                <td class="col-17 padding-bottom align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 padding-bottom align-R">{{ number_format($dataFooter[$i]->record09, 1) }} &#8451;</td>
                                            @endif
                                            <td class="col-10">&nbsp;</td>

                                            <td class="col-10 padding-bottom">吐出</td>
                                            @if ($dataFooter[$i]->record10 == null)
                                                <td class="col-17 padding-bottom align-R">&nbsp;</td>
                                            @else
                                                <td class="col-17 padding-bottom align-R">{{ number_format($dataFooter[$i]->record10, 1) }} &#8451;</td>
                                            @endif
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                        <hr class="m-left-15" style="border: 0.1mm solid black !important;">

                        @php
                            $temp = $recordsId;
                            array_push($array_records, $recordsId);
                        @endphp
                    @endif
                @endif
            @endfor
        </div>

        <script type="text/php">
            if (isset($pdf)) {
                $x = 550;
                $y = 10;
                $text = "{PAGE_NUM}/{PAGE_COUNT}";
                $font = null;
                $size = 10;
                $color = array(0, 0, 0);
                $word_space = 0.0;  //  default
                $char_space = 0.0;  //  default
                $angle = 0.0;   //  default
                $pdf->page_text($x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle);
            }
        </script>
    </body>
</html>
