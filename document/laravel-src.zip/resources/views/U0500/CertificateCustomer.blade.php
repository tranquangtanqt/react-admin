<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style type="text/css">
        html, body {
            background-color: #fff;
            color: black;
            font-family: ipagothic;
            font-weight: 100;
            margin: 0.5rem;
        }

        .text-normal {
            font-weight: normal;
        }

        .text-end {
            text-align: right;
        }
        .print_base {
            width: 430px;
            font-size: 12px;
            font-weight: bold;
        }

        .print_title {
            font-size: 15px;
            text-align: center;
        }

        .print_client {
            font-size: 14px;
        }

        .print_item_title_size {
            width: 100px;
        }

        .print_table td {
            padding: 2px;
        }

        .print_item_indent {
            padding-left: 15px !important;
        }

        .imgData {
            width: 200px;
            border: 0.1rem solid;
        }

        .gas_info {
            text-align: left;
            margin-left: 20px;
        }

        .company-info {
            position: relative;
            padding-left: 15px !important;
            width: 95%;
        }

        .company-info img {
            width: 100%;
            height: auto;
        }

        .company-info .sign {
            position: absolute;
            bottom: 5px;
            right: 10px;
        }


        @media print {
            button {
                display: none !important;
            }
        }

        .mb-0 {
            margin-bottom: 0;
        }

        .p-0 {
            padding: 0;
        }

        .table {
            width: 100%;
            margin-bottom: 1rem;
            vertical-align: top;
            /* table-layout:fixed;
            word-break: break-word; */
        }

        .pt-2 {
            margin-top: 0.5rem;
        }

    </style>
    <title>作業完了証明書（お客様控え）</title>
</head>
<body>

    <div class="print_base">
        <div class="print_title">作業完了証明書　兼　フロン類充塡・回収証明書（お客様控え）</div>
        <div class="text-end pr-2">{{$schedule->reception_no}}</div>

        <table class="print_table mb-0">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size"></th>
                    <th scope="col" class="p-0"></th>
                </tr>
            </thead>
            <tbody>
                <tr class="print_client">
                    <td scope="row">お客様名</td>
                    <td scope="row">
                        <div>{{$l2reception->field_name}}　様</div>
                    </td>
                </tr>
            </tbody>
        </table>

        {{-- <table class="table print_table" style="table-layout: fixed"> --}}
        <table class="table print_table">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size"></th>
                    <th scope="col" class="p-0"></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td scope="row" class="print_item_indent">発行日</td>
                    <td scope="row">
                        <div>{{date('Y/m/d H:i:s');}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">受付日</td>
                    <td scope="row">
                        <div>{{$l2reception->date->format('Y/m/d')}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">系統</td>
                    <td scope="row">
                        <div>{{$device->groupname}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">機種</td>
                    <td scope="row">
                        <div>{{$device->device_type}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">機番</td>
                    <td scope="row">
                        <div>{{$device->device_no}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">納入日</td>
                    <td scope="row">
                        <div>{{$device->delivery_date ? \Carbon\Carbon::parse($device->delivery_date)->format('Y/m/d') : null;}}</div>
                    </td>
                </tr>
            </tbody>
        </table>

        {{-- ライン --}}
        <div style="border-top: 0.1rem solid;"></div>

        <table class="table print_table" style="table-layout: fixed; width: 100%;">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size" style="width: 24%;"></th>
                    <th scope="col" class="p-0"></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">作業が完了したことを認めます。 {{$workreport->payment_type_name}}</td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">作業日</td>
                    <td scope="row">
                        <div>{{$schedule->date->format('Y/m/d')}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">作業内容</td>
                </tr>
                <tr >
                    <td scope="row" class="print_item_indent" colspan="2">
                    <div style="overflow-wrap: break-word;">
                        {{$device->work_detail}}
                    </div>
                    </td>
                </tr>
                @if($signature)
                <tr>
                    <td scope="row" class="print_item_indent">署名</td>
                    <td scope="row">
                        <div>{{$signature->signed_at ? \Carbon\Carbon::parse($signature->signed_at)->format('Y/m/d') : null;}} </div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">
                        <img class="imgData" src='{{$imgData}}' alt='' />
                    </td>
                </tr>
                @endif
            </tbody>
        </table>

        {{-- ライン --}}
        <div style="border-top: 0.1rem solid; margin-bottom: 0.5rem;"></div>

        <table class="table print_table">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size"></th>
                    <th scope="col" class="p-0" style="width: 99%;"></th>
                </tr>
            </thead>
            <tbody>
                @if($gasininfo)
                <tr>
                    <td scope="row" class="print_item_indent">充填</td>
                    <td scope="row">
                        <div>{{$gasininfo->type_name}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">
                        <span class="gas_info">{{$gasininfo->date->format('Y/m/d')}}</span>
                        <span class="gas_info">種類：{{$gasininfo->gas_type_name_view}}</span>
                        <span class="gas_info">量：{{$gasininfo->quantity}}Kg</span>
                    </td>
                </tr>
                @endif
                @if($gasoutinfo)
                <tr>
                    <td scope="row" class="print_item_indent">回収</td>
                    <td scope="row">
                        <div>{{$gasoutinfo->type_name}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">
                        <span class="gas_info">{{$gasoutinfo->date->format('Y/m/d')}}</span>
                        <span class="gas_info">種類：{{$gasoutinfo->gas_type_name_view}}</span>
                        <span class="gas_info">量：{{$gasoutinfo->quantity}}Kg</span>
                    </td>
                </tr>
                @endif
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">備考</td>
                </tr>
                <tr>
                    <td scope="row" colspan="2">
                        <span class="print_item_indent">{{$workreport->remark}}</span>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">発行者</td>
                    <td scope="row">
                        <div>{{ auth()->user()->name }}</div>
                    </td>
                </tr>
            </tbody>
        </table>

        {{-- 会社情報＆QRコード --}}
        <div class="text-center company-info">
            <img src="{{ Storage::path('public/default/company_info.png') }}">
            @if($qrcodeurl)
            <div style="width: 70px; position: absolute; top: 50px; right: 10px;">
                <img src="data:image/png;base64, {{ base64_encode(QrCode::size(60)->generate($qrcodeurl->string1)) }} ">
            </div>
            @endif
        </div>
    </div>


</body>
</html>
