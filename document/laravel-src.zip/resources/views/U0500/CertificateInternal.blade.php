<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>【関係者外秘】作業完了報告書　兼　フロン類充塡・回収証明書（社内確認）</title>
        <!-- Styles -->
        <style>
             html, body {
                background-color: #fff;
                color: black;
                font-family: ipagothic;
                font-weight: 100;
                height: 100vh;
                margin: 28.2mm 0 0 0;
            }
            header{
                position: fixed;
                top:-23mm;
            }
            .text-normal {
                font-weight: normal;
            }
            .clearfix::after {
                content: "";
                clear: both;
                display: table;
            }
            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }
            .content {
                margin-left: 12mm;
                width: 190mm;
                font-size: 8pt;
                word-wrap: break-word!important;
            }

            .content-header {
                margin-left: 12mm;
                width: 190mm;
                font-size: 8pt;
                word-wrap: break-word!important;
            }
            .break-word{
                word-wrap: break-word;
            }
            .title {
                font-size: 14pt;
                text-align: center;
            }
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }
            /*Text-align*/
            .align-L{
                text-align: left;
            }
            .align-R{
                text-align: right;
            }
            .align-C{
                text-align: center;
            }

            /* Set Float*/
            .float-L{
                float: left;
            }
            .float-R{
                float: right;
            }

            /* Set width col*/
            .col_5{
                width: 5mm;
            }
            .col_8{
                width: 8mm;
            }
            .col_10{
                width: 10mm;
            }
            .col_14{
                width: 14.5mm;
            }
            .col_15{
                width: 15mm;
            }
            .col_20{
                width: 20mm;
            }
            .col_25{
                width: 25mm;
            }
            .col_30{
                width: 30mm;
            }
            .col_35{
                width: 35mm;
            }
            .col_40{
                width: 40mm;
            }
            .col_44{
                width: 44mm;
            }
            .col_45{
                width: 45mm;
            }
            .col_50{
                width: 50mm;
            }
            .col_60{
                width: 60mm;
            }
            .col_65{
                width: 65mm;
            }
            .col_70{
                width: 70mm;
            }
            .col_80{
                width: 80mm;
            }
            .col_90{
                width: 90mm;
            }
            .col_100{
                width: 100mm;
            }
            .col_110{
                width: 110mm;
            }
            .col_130{
                width: 130mm;
            }
            .col_140{
                width: 140mm;
            }
            .col_145{
                width: 145mm;
            }
            .col_150{
                width: 150mm;
            }
            .col_160{
                width: 160mm;
            }
            .col_180{
                width: 180mm;
            }
            .col-R{
                float: right;
            }
            /* Set width %*/
            .width-10{
                width: 10%;
            }
            .width-20{
                width: 20%;
            }
            .width-30{
                width: 30%;
            }
            .width-35{
                width: 35%;
            }
            .width-40{
                width: 40%;
            }
            .width-50{
                width: 50%;
            }
            .width-60{
                width: 60%;
            }
            .width-70{
                width: 70%;
            }
            .width-80{
                width: 80%;
            }
            .width-90{
                width: 90%;
            }
            .width-100{
                width: 100%;
            }

            /* Border */
            .border-bottom{
            border-bottom: 1px solid black!important;
            }
            .border-top{
            border-top: 1px solid black!important;
            }

            .table-border , .table-border th , .table-border td
            {
                border: 1px solid black;
                border-collapse: collapse;
                vertical-align: text-top;
                word-break: break-word;
            }
            .table-noborder , .table-noborder th , .table-noborder td{
                border:none;
                border-collapse: collapse;
                vertical-align: text-top;
                word-break: break-word;
            }
            .table-noborder-top , .table-noborder-top th , .table-noborder-top td{
                border-bottom: 1px solid black;
                border-left: 1px solid black;
                border-right: 1px solid black;
                border-collapse: collapse;
                vertical-align: text-top;
                word-break: break-word;
            }
            /* Page num*/
            .pagenum:before {
                content: counter(page);
            }
        </style>
    </head>
    <body>
        <header >
            <div class="content-header text-normal" >
                <h1 class="title" >
                    【関係者外秘】作業完了報告書　兼　フロン類充塡・回収証明書（社内確認）
                </h1>
                <table class="table-noborder">
                    <tr>
                        <td class="col_20">整理番号</td>
                        <td class="col_30">{{ $receptionNo }}</td>
                        <td class="col_20">商談番号</td>
                        <td class="col_110">{{ $dataheader->related_pj_no }}</td>
                    </tr>
                    <tr>
                        <td class="col_20">受付日</td>
                        <td class="col_30">{{ $dataheader->receptions_date }}</td>
                        <td class="col_20">計上担当</td>
                        <td class="col_110">{{ $pjMgrName }}</td>
                    </tr>
                    <tr>
                        <td class="col_20">受付内容</td>
                        <td class="col_160" colspan="3" >
                            <div style="height: 8mm; overflow: hidden;">{{ $dataheader->receptions_content }}</div>
                            <div style="height: 2mm; overflow: hidden;"></div>
                        </td>
                    </tr>
                </table>
                <table class="table-noborder" style="width: 190.4mm">
                    <tr>
                        <td class="col_20" style="border: 1px solid black">お客様</td>
                        <td class="col_160" colspan="4" style="border: 1px solid black;">
                            <table class="table-noborder col_160">
                                <tr>
                                    <td class="col_100">{{ $dataheader->field_address }}</td>
                                    <td class="col_8">&nbsp;</td>
                                    <td class="col_10">TEL</td>
                                    <td class="col_44">{{ mb_substr($dataheader->field_tel, 0, 13) }}</td>
                                    <td class="col_8">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="col_100">{{ $dataheader->field_name }}</td>
                                    <td class="col_8">様</td>
                                    <td class="col_10">TEL</td>
                                    <td class="col_44">{{ mb_substr($dataheader->field_mobile_tel, 0, 13) }}</td>
                                    <td class="col_8">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="col_100">&nbsp;</td>
                                    <td class="col_8">&nbsp;</td>
                                    <td class="col_10">担当</td>
                                    <td class="col_44">{{ mb_substr($dataheader->field_person_name, 0, 15) }}</td>
                                    <td class="col_8">様</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </div>
        </header>

        <main class="content text-normal" style=" margin-top:-5.4mm" >
            <div id="header-top">
                <table class="table-noborder" style="width: 190.4mm;">
                    <tbody>
                        <tr>
                            <td class="col_20" style="border: 1px solid black">ご依頼元</td>
                            <td class="col_160" colspan="4" style="border: 1px solid black">
                                <table class="table-noborder col_160">
                                    <tr>
                                        <td class="col_100">{{ $dataheader->client_address }}</td>
                                        <td class="col_8">&nbsp;</td>
                                        <td class="col_10">TEL</td>
                                        <td class="col_44">{{ mb_substr($dataheader->client_tel, 0, 13) }}</td>
                                        <td class="col_8">{{ $dataheader->client_billing_deadline }}</td>
                                    </tr>
                                    <tr>
                                        <td class="col_100">{{ $dataheader->client_name }}</td>
                                        <td class="col_8">様</td>
                                        <td class="col_10">FAX</td>
                                        <td class="col_44">{{ mb_substr($dataheader->client_fax, 0, 13) }}</td>
                                        <td class="col_8">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="col_100">&nbsp;</td>
                                        <td class="col_8">&nbsp;</td>
                                        <td class="col_10">担当</td>
                                        <td class="col_44">{{ mb_substr($dataheader->client_person_name, 0, 15) }}</td>
                                        <td class="col_8">様</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr >
                            <td class="col_20" style="border: 1px solid black">ご請求先</td>
                            <td class="col_160" colspan="4" style="border: 1px solid black">
                                <table class="table-noborder col_160">
                                    <tr>
                                        <td class="col_100">{{ $dataheader->billing_name }}</td>
                                        <td class="col_8">様</td>
                                        <td class="col_10">TEL</td>
                                        <td class="col_44">{{ mb_substr($dataheader->billing_tel, 0, 13) }}</td>
                                        <td class="col_8">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="col_100">&nbsp;</td>
                                        <td class="col_8">&nbsp;</td>
                                        <td class="col_10">FAX</td>
                                        <td class="col_44">{{ mb_substr($dataheader->billing_fax, 0, 13) }}</td>
                                        <td class="col_8">&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td class="col_20" style="border: 1px solid black">充塡量・種類</td>
                            <td class="col_30" style="border: 1px solid black">
                                <table class="table-noborder width-100">
                                    <tr>
                                        <td class="col_15" style="border: none;">{{ $dataheader->type_in }}</td>
                                        <td class="col_15" style="border: none;text-align:right">{{ $dataheader->gin_date }}</td>
                                    </tr>
                                    <tr>
                                        @if( $dataheader->gas_type_out ==="その他")
                                        <td class="col_15" style="border: none;">{{ $dataheader->gas_in_name }}</td>
                                        @else
                                        <td class="col_15" style="border: none;">{{ $dataheader->gas_type_in }}</td>
                                        @endif
                                        <td class="col_15" style="border: none;text-align:right;">{{ $dataheader->quantity_in }} Kg&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                            <td class="col_20" style="border: 1px solid black">回収量・種類</td>
                            <td class="col_30" style="border: 1px solid black">
                                <table class="table-noborder width-100">
                                    <tr>
                                        <td class="col_15" style="border: none;">{{ $dataheader->type_out }}</td>
                                        <td class="col_15" style="border: none;text-align:right">{{ $dataheader->gout_date }}</td>
                                    </tr>
                                    <tr>
                                        @if( $dataheader->gas_type_out ==="その他")
                                        <td class="col_15" style="border: none;">{{ $dataheader->gas_out_name}}</td>
                                        @else
                                        <td class="col_15" style="border: none;">{{ $dataheader->gas_type_out }}</td>
                                        @endif
                                        <td class="col_15" style="border: none;text-align:right;">{{ $dataheader->quantity_out }} Kg&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                            <td class="col_80" rowspan="2" style="position: relative">
                                <div class="text-center company-info">
                                    <img src="storage/default/company_info.png" style="position: absolute; height:24mm"/>
                                    <div class="sign" style="position: absolute; right: 0mm; top:12mm; right: 2mm;">
                                        <img src="data:image/png;base64, {{ base64_encode(QrCode::size(70)->generate($qrcode)) }} ">
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="col_20" style="height: 20mm; border: 1px solid black;">備考</td>
                            <td class="col_80" colspan="3" style="border: 1px solid black">{{ $dataheader->remark }}</td>
                        </tr>
                    </tbody>
                </table>
                <table class="table-noborder width-100">
                    <tr>
                        <td class="col_20">作業区分</td>
                        <td class="col_160">{{ $dataheader->reports_work_type }}</td>

                    </tr>
                </table>

                {{-- 工数合計 --}}
                <div class="clearfix width-100 align-R" style="margin-top: 2mm;">
                    <span style="display: inline-block; padding: 0;">工数合計： </span><span style="display: inline-block; padding:0; width: 60px;"> {{ $manHourTotal ?? 0.00 }}H </span>
                </div>

                <hr style="border: 0.1mm solid black !important;">


                @php
                    $cnt_cost=0; // 原価件数
                    $cnt_quot=0; // 見積件数
                    for($i=0 ; $i < count($dataheadermain); $i ++){
                        if($dataheadermain[$i]->coust_id != ''){$cnt_cost=$cnt_cost+1;}
                        if($dataheadermain[$i]->quotations_id != ''){$cnt_quot=$cnt_quot+1;}
                    }
                @endphp
                {{-- 見積 --}}
                @if ($cnt_quot > 0)
                <div class="clearfix width-100" style="margin-top: 2mm">
                    <table clas="table-noborder width-100">
                        @php
                            $temp = -1;
                            $array_quotations =[];
                        @endphp
                        @for($i=0 ; $i < count($dataheadermain); $i ++)
                            @php
                                $quotationsId = $dataheadermain[$i]->quotations_id;
                            @endphp
                            @if( $temp === $quotationsId )
                            @else
                                @if($i===0)
                                    <tr>
                                        <td class="col_20">作業No・品番</td>
                                        <td class="col_20">{{ $dataheadermain[$i]->work_no }}</td>
                                        <td class="col_10">数量</td>
                                        <td class="col_20 align-R">{{ $dataheadermain[$i]->quotations_quantity }}</td>
                                        <td class="col_10">{{ $dataheadermain[$i]->quotations_unit }}</td>
                                        <td class="col_10 align-R">金額</td>
                                        <td class="col_25 align-R">{{ number_format($dataheadermain[$i]->quotations_amount) }}円</td>
                                        <td class="col_25">作業名・品名</td>
                                        <td class="col_40" style="padding-right: 2mm;">{{ $dataheadermain[$i]->quotations_name }}</td>
                                    </tr>
                                @else
                                    @if (!in_array($quotationsId,$array_quotations) )
                                        <tr>
                                            <td class="col_20"></td>
                                            <td class="col_20">{{ $dataheadermain[$i]->work_no }}</td>
                                            <td class="col_10"></td>
                                            <td class="col_20 align-R">{{ $dataheadermain[$i]->quotations_quantity }}</td>
                                            <td class="col_10">{{ $dataheadermain[$i]->quotations_unit }}</td>
                                            <td class="col_10"></td>
                                            <td class="col_25 align-R">{{ number_format($dataheadermain[$i]->quotations_amount) }}円</td>
                                            <td class="col_25"></td>
                                            <td class="col_40" style="padding-right: 2mm;">{{ $dataheadermain[$i]->quotations_name }}</td>
                                        </tr>
                                    @endif
                                @endif
                            @endif
                            @php
                                $temp = $quotationsId;
                                array_push($array_quotations,$quotationsId);
                            @endphp
                        @endfor
                        <tr>
                            @if ($dataheadermain[0]->tax_included_flag===True)
                                <td colspan="6" class="col_130 align-R">小計(消費税込)</td>
                            @else
                                <td colspan="6" class="col_130 align-R">小計(消費税抜)</td>
                            @endif
                            <td class="col_20 align-R">{{ number_format($dataheadermain[0]->total_amount) }}円</td>
                            <td></td>
                            <td></td>
                        </tr>
                    </table>
                </div>
                <hr style="border: 0.1mm solid black !important;">
                @endif

                {{-- 原価 --}}
                @if ($cnt_cost > 0)
                <div class="clearfix width-100" style="margin-top: 2mm">
                    <table clas="table-noborder">
                        <tbody>
                            @php
                                $temp = -1;
                                $array_cost =[];
                            @endphp
                            @for($i=0 ; $i < count($dataheadermain); $i ++)
                                @php
                                    $costId = $dataheadermain[$i]->coust_id;
                                @endphp
                                @if( $temp === $costId )
                                @else
                                    @if($i===0)
                                        <tr>
                                            <td class="col_20">原価種類区分</td>
                                            <td class="col_25">{{ $dataheadermain[$i]->type_costs }}</td>
                                            <td class="col_20">原価名</td>
                                            <td class="col_60">{{ $dataheadermain[$i]->costs_name }}</td>
                                            <td class="col_20">金額</td>
                                            <td class="col_30 align-R" style="padding-right: 2mm;">{{ number_format($dataheadermain[$i]->costs_amount) }}円</td>
                                        </tr>
                                    @else
                                        @if (!in_array($costId,$array_cost) )
                                            <tr>
                                                <td class="col_20"></td>
                                                <td class="col_25">{{ $dataheadermain[$i]->type_costs }}</td>
                                                <td class="col_20"></td>
                                                <td class="col_60">{{ $dataheadermain[$i]->costs_name }}</td>
                                                <td class="col_20"></td>
                                                <td class="col_30 align-R" style="padding-right: 2mm;">{{ number_format($dataheadermain[$i]->costs_amount) }}円</td>
                                            </tr>
                                        @endif
                                    @endif
                                @endif
                                @php
                                    $temp = $costId;
                                    array_push($array_cost,$costId);
                                @endphp
                            @endfor
                        </tbody>
                    </table>
                </div>
                <hr style="border: 0.1mm solid black !important;">
                @endif

                <div class="clearfix col_180">
                    <p>作業が完了したことを認めます。
                        @if ( $dataheader->payment_type )
                        <span style="margin-left:10mm">({{ $dataheader->payment_type }})</span>
                        @endif
                    </p>
                </div>
                <hr style="border: 0.1mm solid black !important;">
            </div>
            <div id="body">
                @php
                    $temp =-1;
                    $scheduleId=1;
                @endphp
                @for($i = 0; $i < count($dataBody); $i++)
                    @php
                        $scheduleId =  $dataBody[$i]->schedule_id;
                    @endphp
                    @if ($temp === $scheduleId)
                    @else
                        <div class="col_185" title="{{ $dataBody[$i]->schedule_id }}">
                            <table clas="table-noborder col_185">
                                <tbody>
                                    <tr>
                                        <td class="col_20">作業日</td>
                                        <td class="col_130" colspan="3">{{ $dataBody[$i]->schedule_date }}</td>
                                        <td class="col_10">署名</td>
                                        @if ( $dataBody[$i]->digital_flag )
                                        <td class="col_30 float-R">{{ $dataBody[$i]->signed_at }}</td>
                                        @else
                                        <td class="col_30 float-R">&nbsp;</td>
                                        @endif
                                        <td class="col_5">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="col_20">ＫＹポイント</td>
                                        <td class="col_30">{{ $dataBody[$i]->ky_point_type }}</td>
                                        <td class="col_30">ワンポイント対策</td>
                                        <td class="col_60">{{ $dataBody[$i]->one_point }}</td>
                                        <td class="col_40" colspan="2" rowspan="2">
                                        @if ($dataBody[$i]->digital_flag)
                                            @if ($dataBody[$i]->file)
                                                <img width="100%" src="data:image/png;base64, {{ stream_get_contents($dataBody[$i]->file) }}">
                                            @endif
                                        @endif
                                        </td>
                                        <td class="col_5">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td class="col_20">サービスマン</td>
                                        <td class="col_130" colspan="3">{{ $dataBody[$i]->user_name }}</td>
                                        <td class="col_5">&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table clas="table-noborder col_185">
                                @for($j=0; $j< count($dataBody); $j++)
                                    @if ($scheduleId === $dataBody[$j]->schedule_id)
                                    <tr>
                                        <td class="col_20">&nbsp;</td>
                                        <td class="col_165">
                                            <hr style="border: 0.1mm solid black !important;">
                                            <table clas="table-noborder col_165">
                                                <colgroup>
                                                <col class="col_10"/>
                                                <col class="col_5"/>
                                                <col class="col_5"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_5"/>
                                                </colgroup>
                                                <tbody>
                                                    <tr style="vertical-align: text-top;">
                                                        <td class="col_10">系統</td>
                                                        <td class="col_70" colspan="8">{{ $dataBody[$j]->group_name }}</td>
                                                        <td class="col_10">機種</td>
                                                        <td class="col_30" colspan="3">{{ $dataBody[$j]->device_type }}</td>
                                                        <td class="col_10">機番</td>
                                                        <td class="col_30" colspan="3">{{ $dataBody[$j]->device_no }}</td>
                                                        <td class="col_5">&nbsp;</td>
                                                    </tr>
                                                    <tr style="vertical-align: text-top;">
                                                        <td class="col_15" colspan="2">作業内容</td>
                                                        <td class="col_145" colspan="16" style="word-break: break-word;">{{ $dataBody[$j]->work_detail }}</td>
                                                        <td class="col_5">&nbsp;</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    @endif
                                @endfor
                            </table>
                        </div>
                        <hr style="border: 0.1mm solid black !important;">
                    @endif
                    @php
                        $temp = $scheduleId ;
                    @endphp
                @endfor
                @php
                    $temp = -1;
                    $array_records =[];
                @endphp
                @if ($dataOperation)
                    <table class="table-noborder col_185">
                        @for($i=0 ; $i < count($dataOperation); $i ++)
                            @php
                                $recordsId = $dataOperation[$i]->records_id;
                            @endphp
                            @if( $temp === $recordsId )
                            @else
                                @if (!in_array($recordsId,$array_records) )
                                    @if($i===0)
                                    <tr>
                                        <td class="col_20">運転記録</td>
                                        <td class="col_165">
                                        <table id="Record_{{ $recordsId }}" class="table-noborder col_165">
                                            <colgroup>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_5"/>
                                                </colgroup>
                                            <tbody>
                                                <tr>
                                                    <td class="col_10">&nbsp;系統</td>
                                                    <td class="col_70" colspan="7">{{ $dataOperation[$i]->group_name }}</td>
                                                    <td class="col_10 ">機種</td>
                                                    <td class="col_30" colspan="3">{{ $dataOperation[$i]->device_type }}</td>
                                                    <td class="col_10">機番</td>
                                                    <td class="col_30" colspan="3">{{ $dataOperation[$i]->device_no }}</td>
                                                    <td class="col_5">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="col_10">&nbsp;ＨＰ</td>
                                                    @if ($dataOperation[$i]->record01 == null)
                                                        <td class="col_20 align-R" colspan="2">MPa</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record01, 2) }} MPa</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;ＬＰ</td>
                                                    @if ($dataOperation[$i]->record02 == null)
                                                        <td class="col_20 align-R" colspan="2">MPa</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record02, 2) }} MPa</td>
                                                    @endif
                                                    <td class="col_20" colspan="2">&nbsp;総合電流</td>
                                                    @if ($dataOperation[$i]->record03 == null)
                                                        <td class="col_20 align-R" colspan="2">Ａ&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record03, 1) }} Ａ&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;電圧</td>
                                                    @if ($dataOperation[$i]->record04 == null)
                                                        <td class="col_20 align-R" colspan="2">Ａ&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record04) }} Ｖ&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;過熱度</td>
                                                    @if ($dataOperation[$i]->record05 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record05,1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_5">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="col_10">&nbsp;吸込</td>
                                                    @if ($dataOperation[$i]->record06 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record06, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;吹出</td>
                                                    @if ($dataOperation[$i]->record07 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record07, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_20" colspan="2">&nbsp;外気温</td>
                                                    @if ($dataOperation[$i]->record08 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record08, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;吸入</td>
                                                    @if ($dataOperation[$i]->record09 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record09, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;吐出</td>
                                                    @if ($dataOperation[$i]->record10 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record10, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_5">&nbsp;</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                @else
                                <tr>
                                    <td class="col_20"></td>
                                    <td class="col_165">
                                        <hr style="border: 0.1mm solid black !important;">
                                        <table id="divice_{{ $recordsId }}" class="table-noborder col_165">
                                            <colgroup>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_10"/>
                                                <col class="col_5"/>
                                                </colgroup>
                                            <tbody>
                                                <tr>
                                                    <td class="col_10">&nbsp;系統</td>
                                                    <td class="col_70" colspan="7">{{ $dataOperation[$i]->group_name }}</td>
                                                    <td class="col_10 ">機種</td>
                                                    <td class="col_30" colspan="3">{{ $dataOperation[$i]->device_type }}</td>
                                                    <td class="col_10">機番</td>
                                                    <td class="col_30" colspan="3">{{ $dataOperation[$i]->device_no }}</td>
                                                    <td class="col_5">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="col_10">&nbsp;ＨＰ</td>
                                                    @if ($dataOperation[$i]->record01 == null)
                                                        <td class="col_20 align-R" colspan="2">MPa</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record01, 2) }} MPa</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;ＬＰ</td>
                                                    @if ($dataOperation[$i]->record02 == null)
                                                        <td class="col_20 align-R" colspan="2">MPa</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record02, 2) }} MPa</td>
                                                    @endif
                                                    <td class="col_20" colspan="2">&nbsp;総合電流</td>
                                                    @if ($dataOperation[$i]->record03 == null)
                                                        <td class="col_20 align-R" colspan="2">Ａ&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record03, 1) }} Ａ&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;電圧</td>
                                                    @if ($dataOperation[$i]->record04 == null)
                                                        <td class="col_20 align-R" colspan="2">Ａ&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record04) }} Ｖ&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;過熱度</td>
                                                    @if ($dataOperation[$i]->record05 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record05,1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_5">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="col_10">&nbsp;吸込</td>
                                                    @if ($dataOperation[$i]->record06 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record06, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;吹出</td>
                                                    @if ($dataOperation[$i]->record07 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record07, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_20" colspan="2">&nbsp;外気温</td>
                                                    @if ($dataOperation[$i]->record08 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record08, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;吸入</td>
                                                    @if ($dataOperation[$i]->record09 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record09, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_10">&nbsp;吐出</td>
                                                    @if ($dataOperation[$i]->record10 == null)
                                                        <td class="col_20 align-R" colspan="2">&#8451;&nbsp;</td>
                                                    @else
                                                        <td class="col_20 align-R" colspan="2">{{ number_format($dataOperation[$i]->record10, 1) }} &#8451;&nbsp;</td>
                                                    @endif
                                                    <td class="col_5">&nbsp;</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                @endif

                                @endif
                            @endif
                            @php
                                $temp = $recordsId ;
                                array_push($array_records,$recordsId);
                            @endphp
                        @endfor

                    </table>
                <hr style="border: 0.1mm solid black !important;">
                @endif
            </div>
        </main>
    </body>
</html>
