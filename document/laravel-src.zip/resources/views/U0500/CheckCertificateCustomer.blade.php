<x-layouts.base title="作業完了証明書(お客様控え)確認">
    @push('styles')
    <style type="text/css">
        body {
            background-color: white !important;
        }

        .print_base {
            max-width: 430px;
            padding: 0.5rem;
            font-size: 12px;
            font-weight: bold;
        }

        .print_title {
            font-size: 14px;
        }

        .print_client {
            font-size: 14px;
        }

        .print_item_title_size {
            width: 100px;
        }

        .print_table td {
            padding: 2px;
        }

        .print_item_indent {
            padding-left: 15px !important;
        }

        .gas_info {
            float: left;
            margin-left: 20px;
        }
    </style>
    @endpush
    <div class="print_base">
        <div class="print_title"><span>作業完了証明書　兼　フロン類充塡・回収証明書</span><span style="display: inline-block;">（お客様控え）</span></div>
        <div class="text-end pr-2">{{$schedule->reception_no}}</div>

        <table class="table table-borderless print_table mb-0">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size"></th>
                    <th scope="col" class="p-0"></th>
                </tr>
            </thead>
            <tbody>
                <tr class="print_client">
                    <td scope="row">お客様名</td>
                    <td scope="row">
                        <div>{{$l2reception->client_name}}　様</div>
                    </td>
                </tr>
            </tbody>
        </table>

        <table class="table table-borderless print_table">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size"></th>
                    <th scope="col" class="p-0"></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td scope="row" class="print_item_indent">受付日</td>
                    <td scope="row">
                        <div>{{$l2reception->date->format('Y/m/d')}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">系統</td>
                    <td scope="row">
                        <div>{{$device->groupname}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">機種</td>
                    <td scope="row">
                        <div>{{$device->device_type}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">機番</td>
                    <td scope="row">
                        <div>{{$device->device_no}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">納入日</td>
                    <td scope="row">
                        <div>{{$device->delivery_date ? \Carbon\Carbon::parse($device->delivery_date)->format('Y/m/d') : null;}}</div>
                    </td>
                </tr>
            </tbody>
        </table>

        {{-- ライン --}}
        <div style="border-top: 0.1rem solid;"></div>

        <table class="table table-borderless print_table">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size"></th>
                    <th scope="col" class="p-0"></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    {{-- <td scope="row" class="print_item_indent" colspan="2">作業が完了したことを認めます。 {{$workreport->payment_type_name}}</td> --}}
                    <td scope="row" class="print_item_indent" colspan="2">作業が完了したことを認めます。 {{$workreport->payment_type_name}}</td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent">作業日</td>
                    <td scope="row">
                        <div>{{$schedule->date->format('Y/m/d')}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">作業内容</td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">{{$device->work_detail}}</td>
                </tr>
            </tbody>
        </table>

        {{-- ライン --}}
        <div style="border-top: 0.1rem solid;"></div>

        <table class="table table-borderless print_table">
            <thead>
                <tr>
                    <th scope="col" class="p-0 print_item_title_size"></th>
                    <th scope="col" class="p-0"></th>
                </tr>
            </thead>
            <tbody>
                @if($gasininfo)
                <tr>
                    <td scope="row" class="print_item_indent">充填</td>
                    <td scope="row">
                        <div>{{$gasininfo->type_name}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">
                        <div class="gas_info">{{$gasininfo->date->format('Y/m/d')}}</div>
                        <div class="gas_info">種類：{{$gasininfo->gas_type_name_view}}</div>
                        <div class="gas_info">量：{{$gasininfo->quantity}}Kg</div>
                    </td>
                </tr>
                @endif
                @if($gasoutinfo)
                <tr>
                    <td scope="row" class="print_item_indent">回収</td>
                    <td scope="row">
                        <div>{{$gasoutinfo->type_name}}</div>
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">
                        <div class="gas_info">{{$gasoutinfo->date->format('Y/m/d')}}</div>
                        <div class="gas_info">種類：{{$gasoutinfo->gas_type_name_view}}</div>
                        <div class="gas_info">量：{{$gasoutinfo->quantity}}Kg</div>
                    </td>
                </tr>
                @endif
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">備考</td>
                </tr>
                <tr>
                    <td scope="row" class="print_item_indent" colspan="2">{{$workreport->remark}}</td>
                </tr>
            </tbody>
        </table>

        {{--確認ボタン--}}
        <a href="{{ route('set-sign.show',$schedule) }}" class="btn modal-footer border-top-0 justify-content-center text-white">
            <button type="submit" class="btn submit-btn" onclick="this.blur();">
                {{ __('確認') }}
            </button>
        </a>
    </div>
</x-layouts.base>
