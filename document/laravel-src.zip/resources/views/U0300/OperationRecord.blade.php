<x-layouts.app title="運転記録情報">
    @push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0300/set-operation-record.css') }}" >
    @endpush
    {{-- 署名設定 --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">{{ __('運転記録情報')}}</div>
        <a  class="btn p-0 text-white" href="{{ route('receptions.schedule-result.show', ['reception' =>$receptionNo]) }}">{{ __('戻る') }}</a>
    </div>

    <!-- 備考 -->
    @foreach ( $operationRecords as $operationRecord )
        @php
            // Get id of operation record
            $deviceId = $operationRecord->device_id;
            // Format number for operation records
            $record01 = $operationRecord->record01 == null ? null : number_format($operationRecord->record01, 2);
            $record02 = $operationRecord->record02 == null ? null : number_format($operationRecord->record02, 2);
            $record03 = $operationRecord->record03 == null ? null : number_format($operationRecord->record03, 1);
            $record04 = $operationRecord->record04 == null ? null : number_format($operationRecord->record04, 0);
            $record05 = $operationRecord->record05 == null ? null : number_format($operationRecord->record05, 1);
            $record06 = $operationRecord->record06 == null ? null : number_format($operationRecord->record06, 1);
            $record07 = $operationRecord->record07 == null ? null : number_format($operationRecord->record07, 1);
            $record08 = $operationRecord->record08 == null ? null : number_format($operationRecord->record08, 1);
            $record09 = $operationRecord->record09 == null ? null : number_format($operationRecord->record09, 1);
            $record10 = $operationRecord->record10 == null ? null : number_format($operationRecord->record10, 1);
        @endphp
    <div class="d-flex flex-column px-2 px-sm-3 mb-3">
        <hr class="m-0">
        <div>
        @can('updateOperation', $reception)
            <a class="p-0 btn float-end" data-bs-toggle="modal" data-bs-target="#operationRecord{{ $deviceId }}">
                <i class="bi-pencil-fill f-16 text-black-50" title="運転記録を編集する"></i>
            </a>
        @endcan
        </div>
            <div class="row mb-2">
                <div class="col-12 col-md-4">
                    <div>
                        <label class="lable-title">{{ __('系統') }}</label>
                        <label class="ms-2">{{ $operationRecord->group_name == null? '未設定': $operationRecord->group_name}}</label>
                    </div>
                </div>
                <div class="col-12 col-md-3">
                    <div>
                        <label class="lable-title" >{{ __('機種') }}</label>
                        <label class="ms-2">{{ $operationRecord->device_type }}</label>
                    </div>
                </div>
                <div class="col-12 col-md-5">
                    <label class="lable-title">{{ __('機番')}}</label>
                    <label class="ms-2">{{ $operationRecord->device_no }}</label>
                </div>
            </div>
            <div class="grid-container">
                <div class="item1">
                    <label class="lable-title">{{ __('ＨＰ') }}</label>
                    <label class="lable-title text-end">{{ $record01 }}</label><label class="ms-1">MPa</label>
                </div>
                <div class="item2">
                    <label class="lable-title">{{ __('ＬＰ') }}</label>
                    <label class="lable-title text-end">{{ $record02 }}</label><label class="ms-1">MPa</label>
                </div>
                <div class="item3">
                    <label class="lable-title">{{ __('総合電流') }}</label>
                    <label class="lable-title text-end">{{ $record03 }}</label><label class="ms-1">A</label>
                </div>
                <div class="item4">
                    <label class="lable-title">{{ __('電圧') }}</label>
                    <label class="lable-title text-end">{{ $record04 }}</label><label class="ms-1">V</label>
                </div>
                <div class="item5">
                    <label class="lable-title">{{ __('過熱度') }}</label>
                    <label class="lable-title text-end">{{ $record05 }}</label><label class="ms-1"><sup>o</sup>Ⅽ</label>
                </div>
                <div class="item6">
                    <label class="lable-title">{{ __('吸込') }}</label>
                    <label class="lable-title text-end">{{ $record06 }}</label><label class="ms-1"><sup>o</sup>Ⅽ</label>
                </div>
                <div class="item7">
                    <label class="lable-title">{{ __('吹出') }}</label>
                    <label class="lable-title text-end">{{ $record07 }}</label><label class="ms-1"><sup>o</sup>Ⅽ</label>
                </div>
                <div class="item8">
                    <label class="lable-title">{{ __('外気温') }}</label>
                    <label class="lable-title text-end">{{ $record08 }}</label><label class="ms-1"><sup>o</sup>Ⅽ</label>
                </div>
                <div class="item9">
                    <label class="lable-title">{{ __('吸入') }}</label>
                    <label class="lable-title text-end">{{ $record09 }}</label><label class="ms-1"><sup>o</sup>Ⅽ</label>
                </div>
                <div class="item10">
                    <label class="lable-title">{{ __('吐出') }}</label>
                    <label class="lable-title text-end">{{ $record10 }}</label><label class="ms-1"><sup>o</sup>Ⅽ</label>
                </div>
            </div>
        </div>

        {{-- Operation record modal --}}
        <div class="modal fade" id="operationRecord{{ $deviceId }}" tabindex="-1"
             aria-labelledby="device" aria-modal="true" role="dialog" style="display: none;">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-bottom-0">
                        <h5 class="modal-title">運転記録設定</h5>
                        <button type="button" class="btn" data-bs-dismiss="modal" aria-label="back">戻る</button>
                    </div>
                    <div class="modal-body">
                        <div>
                            <label>{{ __('系統') }}</label>
                            <label class="ms-2">{{ $operationRecord->group_name == null? '未設定': $operationRecord->group_name }}</label>
                        </div>
                        <div>
                            <label>{{ __('機種') }}</label>
                            <label class="ms-2">{{ $operationRecord->device_type }}</label>
                        </div>
                        <div>
                            <label>{{ __('機番') }}</label>
                            <label class="ms-2">{{ $operationRecord->device_no }}</label>
                        </div>
                        <hr>
                        <form id="formoperationRecord{{ $deviceId }}" action="" method="post">
                            <div class="alert{{ $deviceId }} mb-2" style="display:none" >
                                <x-invalid-feedback id="alert{{ $deviceId }}"></x-invalid-feedback>
                            </div>
                            <div class="edit-able">
                                @csrf
                                {{ method_field('PATCH') }}
                                <input type="hidden" name="operationId" id="operation" value="{{ $operationRecord->id }}" readonly>
                                <input type="hidden" name="device_id" value="{{ $operationRecord->device_id }}" readonly>
                                <input type="hidden" name="updated_at" value="{{ $operationRecord->updated_at }}" readonly>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('ＨＰ') }}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record01" value="{{ $record01 }}" min=0 step=0.01 maxlength="7">
                                    <label class="ms-2 pt-2">MPa</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord01{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('ＬＰ')}}</label>
                                    <input class="form-control w-25 ms-2 text-end"  type="text" name="record02" value="{{ $record02 }}" min=0 step=0.01 maxlength="7">
                                    <label class="ms-2 pt-2">MPa</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord02{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('総合電流') }}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record03" value="{{ $record03 }}" min=0 step=0.1 maxlength="5">
                                    <label class="ms-2 pt-2">A</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord03{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('電圧') }}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record04" value="{{ $record04 }}" min=0 maxlength="3">
                                    <label class="ms-2 pt-2">V</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord04{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('過熱度')}}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record05" value="{{ $record05 }}" min=0 step=0.1 maxlength="5">
                                    <label class="ms-2 pt-2"><sup>o</sup>Ⅽ</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord05{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('吸込')}}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record06" value="{{ $record06 }}" min=0 step=0.1 maxlength="5">
                                    <label class="ms-2 pt-2"><sup>o</sup>Ⅽ</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord06{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('吹出')}}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record07" value="{{ $record07 }}" min=0 step=0.1 maxlength="5">
                                    <label class="ms-2 pt-2"><sup>o</sup>Ⅽ</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord07{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('外気温')}}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record08" value="{{ $record08 }}" min=0 step=0.1 maxlength="5">
                                    <label class="ms-2 pt-2"><sup>o</sup>Ⅽ</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord08{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex mb-2">
                                    <label class="lable-title pt-2">{{ __('吸入')}}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record09" value="{{ $record09 }}" min=0 step=0.1 maxlength="5">
                                    <label class="ms-2 pt-2"><sup>o</sup>Ⅽ</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord09{{ $deviceId }}"></x-invalid-feedback>
                                <div class="d-flex">
                                    <label class="lable-title pt-2">{{ __('吐出') }}</label>
                                    <input class="form-control w-25 ms-2 text-end" type="text" name="record10" value="{{ $record10 }}" min=0 step=0.1 maxlength="5">
                                    <label class="ms-2 pt-2"><sup>o</sup>Ⅽ</label>
                                </div>
                                <x-invalid-feedback class="alertforrecord10{{ $deviceId }}"></x-invalid-feedback>
                            </div>
                        </form>
                        </div>
                        <div class="modal-footer border-top-0 justify-content-center text-white">
                            <div class="btn-save">
                                <button class="btn submit-btn p-0" onclick="save('{{ $deviceId }}')">確定</button>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    @endforeach
    @push('scripts')
        <script src="{{ mix('js/U0300/set-operation-record.js') }}" ></script>
    @endpush
</x-layouts.app>
