<x-form-modal modal-id="set-schedule-check-condition-modal" title="予定確認条件設定"
    action="{{ route('set-schedule-check.index') }}" method="GET" btn-label="設定"
    onsubmit="fetchSetScheduleCheckModal(event);" :mode="$mode">

    <x-slot name="rightButton">
        <div class="d-flex">
            <button class="btn" onclick="clearScheduleCheckCondition();">条件クリア</button>
            <button type="button" class="btn" aria-label="back" onclick="
                $('#set-schedule-check-condition-modal').modal('hide');
                $('#{{ $mode }}-schedule-modal').modal('show');
            ">戻る</button>
        </div>
    </x-slot>

    {{-- モード --}}
    <input type="hidden" name="mode" value="{{ $mode }}">

    {{-- 予定日 --}}
    <div class="row mt-3">
        <label for="check_condition_schedule_date" class="form-label">予定日付</label>
    </div>

    @php
         $scheduleDate ??= now()->format('Y/m/d'); // 初期日付
    @endphp

    <div class="row gx-0 gx-sm-3 align-items-center justify-content-between justify-content-sm-start flex-nowrap">
        <div class="col-auto">
            <x-date-input name="start_date" id="check_condition_schedule_date_start" value="{{ $scheduleDate }}" required/>
        </div>
        <div class="col-auto"><span>〜</span></div>
        <div class="col-auto">
                <x-date-input name="end_date" id="check_condition_schedule_date_end" value="{{ $scheduleDate }}" required/>
        </div>
    </div>
    <div class="row d-none">
        <x-invalid-feedback id="check_condition_start_date_error"></x-invalid-feedback>
        <x-invalid-feedback id="check_condition_end_date_error"></x-invalid-feedback>
        <x-invalid-feedback id="check_condition_date_error"></x-invalid-feedback>
    </div>

    {{-- 時間帯 --}}
    <div class="row mt-3">
        <label for="slots" class="form-label">時間帯</label>
    </div>

    {{-- 時間帯リスト --}}
    <div class="schedule-condition-grid">
        @foreach($slots as $slot)

            @php
                $checked = $selectedSlots->contains($slot->key) ? 'checked' : '';
            @endphp

            <input type="checkbox" name="schedule_slots[{{ $slot->key }}]"
                id="check_condition_schedule_slots_{{ $slot->key }}" value="1" hidden {{ $checked }}>
            <label for="check_condition_schedule_slots_{{ $slot->key }}" class="d-flex justify-content-center cursor-pointer">
                <x-schedule-slot id="check_condition_schedule_slots_{{ $slot->key }}-icon"
                    :icon="true" :checked="$checked">
                    {{ $slot->value }}
                </x-schedule-slot>
            </label>
        @endforeach
    </div>
    <div class="row d-none">
        <x-invalid-feedback id="check_condition_schedule_slots_error"></x-invalid-feedback>
    </div>

    {{-- 担当者 --}}
    <div class="row mt-3">
        <label for="persons" class="form-label">担当者</label>
    </div>

    <div class="schedule-condition-grid">
        @foreach($persons as $person)
            @php
                $checked = $selectedPersonIds->contains($person->id) ? 'checked' : '';
            @endphp

            {{-- 担当者リスト --}}
            <label for="check_condition_schedule_persons_{{ $person->id }}" class="d-flex justify-content-center cursor-pointer">
                <input type="checkbox" name="schedule_persons[{{ $person->id }}]" value="1" hidden
                    id="check_condition_schedule_persons_{{ $person->id }}" {{ $checked }}>
                <x-user-profile src="{{ $person->avatar }}" title="{{ $person->name }}"
                    id="check_condition_schedule_persons_{{ $person->id }}-icon" :icon="true" :checked="$checked">
                    {{ $person->short_name }}
                </x-user-profile>
            </label>

        @endforeach
    </div>

    <div class="row d-none">
        <x-invalid-feedback id="check_condition_schedule_persons_error"></x-invalid-feedback>
    </div>

    {{-- 社内人数 --}}
    <div class="row mt-3">
        <label for="internal_persons" class="form-label">社内人数</label>
    </div>
    <div class="row">
        <div class="col-4">
            <input class="form-control" type="number" name="internal_persons" id="internal_persons" min="0"
                max="99" value="0" required>
        </div>
    </div>
    <div class="row d-none">
        <x-invalid-feedback id="check_condition_internal_persons_error"></x-invalid-feedback>
    </div>

    {{-- 協力会社人数 --}}
    <div class="row mt-3">
        <label for="external_persons" class="form-label">協力会社人数</label>
    </div>
    <div class="row">
        <div class="col-4">
            <input class="form-control" type="number" name="external_persons" id="external_persons" min="0"
                max="99" value="0" required>
        </div>
    </div>
    <div class="row d-none">
        <x-invalid-feedback id="check_condition_external_persons_error"></x-invalid-feedback>
    </div>

    {{-- javascript --}}
    <script>

        $(`input[type=checkbox][id^=check_condition_schedule_]`).on("change", function () {
            if (this.checked) {
                $("#" + this.id + "-icon").removeClass("d-none");
            } else {
                $("#" + this.id + "-icon").addClass("d-none");
            }
        });
    </script>

</x-form-modal>
