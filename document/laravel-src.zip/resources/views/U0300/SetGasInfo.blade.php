{{-- @include('U0300.SetGasInfo')を追加しopenModalsetGasInfo(receptionNo,typeGas)を呼び出することができます --}}
{{-- typeGas="GasOutInfo" 又は typeGas="GasInInfo" --}}
@push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0300/set-gas-info.css') }}" />
@endpush
<div class="modal fade" id="modalpopupGasInfo"  aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" >
        <div class="modal-content" >
            <div class="modal-header border-bottom-0" >
                <h5 class="modal-title" id="gasInfo">充塡情報設定</h5>
                <button type="button" class="btn" data-bs-dismiss="modal" id="closeModal" aria-label="back">戻る</button>
            </div>
            <form method="POST" id="frmGasInfo">
                @csrf
                <input hidden  name="receptionNo" id="txtReceptionNoGasInfo">
                <input hidden  name="updatedAt" id="txtupdatedAt">
                <input hidden  name="nameGas" id="txtNameGas">
                <div class="modal-body">
                <x-invalid-feedback id="setGasInfoValidErrorAll"></x-invalid-feedback>
                    <div class=" row">
                        <div class="col-6">
                            <div class="">
                                <span id="typeName">充塡区分</span>
                                <select class="form-select valid-add" id="dropType" name="type">
                                </select>
                                <x-invalid-feedback></x-invalid-feedback>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="">
                                <span id="gasTypeName">充塡種類</span>
                                <select class="form-select valid-add" id="dropGasType" name="gasType">
                                </select>
                                <x-invalid-feedback ></x-invalid-feedback>
                            </div>
                        </div>
                        <div class="col-6">
                            <br/>
                            <div class="" id="dropGastypeName">
                                <input type="text" id="txtGasTypeName" maxlength="7" class="form-control valid-add" name="gastypename"/>
                                <x-invalid-feedback ></x-invalid-feedback>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="">
                                <span id="quantityName">充塡量(Kg)</span>
                                <input type="number" id="txtQuantity" class="form-control valid-add text-end" name="quantity" title=""/>
                                <x-invalid-feedback></x-invalid-feedback>
                            </div>
                            <div class="">
                                <span id="dateName">交付年月日</span>
                                <x-date-input id="txtDate" class="form-control valid-add" style="width:100% !important" autocomplete="off" name="date"/>
                                <x-invalid-feedback ></x-invalid-feedback>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top-0 justify-content-center text-white d-flex u0307-submit">
                    <x-submit-button type="button">確定</x-submit-button>
                </div>
            </form>
        </div>
    </div>
</div>
<button id="btnShowModalGasInfo" type="button" data-bs-toggle="modal"  hidden data-bs-target="#modalpopupGasInfo">
  </button>
@push('scripts')
    <script src="{{ mix('js/U0300/set-gas-info.js') }}" ></script>
@endpush
