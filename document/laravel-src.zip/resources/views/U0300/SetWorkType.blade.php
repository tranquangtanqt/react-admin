{{-- @include('U0300.SetWorkType')を追加しopenModalWorkType(receptionNo)を呼び出することができます --}}
<div class="modal fade" id="modalpopupSetWorkType"  aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" >
        <div class="modal-content" >
            <div class="modal-header border-bottom-0" >
                <h5 class="modal-title">作業区分確定</h5>
                <button type="button" class="btn" data-bs-dismiss="modal" id="closeModalWorktype" aria-label="back">戻る</button>
            </div>
            <form method="POST" id="frmSetWorkType">
                @csrf
                <input hidden  name="receptionNo" id="txtReceptionNoSetWorkType">
                <input hidden  name="updatedDate" id="txtUpdatedDateSetWorkType">
                <div class="modal-body">
                    <select class="form-select w-50" name="value">
                      </select>
                      <x-invalid-feedback id="setWorkTypeValidError"></x-invalid-feedback>
                </div>
                <div class="modal-footer border-top-0 justify-content-center text-white d-flex" id="u0309-submit">
                    <x-submit-button type="button">確定</x-submit-button>
                </div>
            </form>
        </div>
    </div>
</div>
<button id="btnShowModalSetworkType" type="button" data-bs-toggle="modal"  hidden data-bs-target="#modalpopupSetWorkType">
  </button>
@push('scripts')
    <script src="{{ mix('js/U0300/set-work-type.js') }}" ></script>
@endpush