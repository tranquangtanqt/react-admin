<x-layouts.app>
@push('styles')
<link rel="stylesheet" href="{{ mix('css/U0300/set-sign-file.css') }}" >
@endpush
    {{-- 署名ファイル設定ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">{{ __('署名ファイル設定') }}</div>
        <a  class="btn p-0 text-white" href="{{ route('result-info.index', ['scheduleId' => $scheduleId ]) }}">{{ __('戻る') }}</a>
    </div>

    <div class="py-2 px-2 px-sm-3">
        <x-form method="POST" action="{{ route('set-sign-file.store') }}" enctype="multipart/form-data" class="w-100">
        @csrf
        {{-- Title --}}
        <div class="w-25 mb-4 file-title">
            <input type="hidden" name="scheduleId" value="{{ $scheduleId }}" readonly>
            <label class="mb-2" for="title">{{ __('タイトル') }}</label>
            <div class="w-100">
                <input id="title" type="text" maxlength="20"
                    class="form-control"
                    value="{{ old('title') }}"
                    name="title">
                    <x-invalid-feedback id="title-required" class="d-none">タイトルを入力してください。</x-invalid-feedback>
                    <x-invalid-feedback id="title-special" class="d-none">タイトルに入力禁止文字が含まれています。</x-invalid-feedback>
            </div>
        </div>
        {{-- File --}}
        <div class="w-100 mb-4 file-choice">
            <label class="mb-2" for="choise-file">{{ __('ファイル') }}</label>
            <div class="d-flex w-100">
                <div>
                    <button type="button" class="btn custom-btn" id="loadFile"
                            onclick="document.getElementById('file').click();">
                    {{ __('選択') }}
                    </button>
                    <input type="file" id="file" style="display: none;" name="file" />
                </div>
                <div class="w-100">
                    <p class="mt-2 ms-3" id="filename">ファイル未選択</p>
                </div>
            </div>
            <div>
                @error('file')
                <x-invalid-feedback id="file-size">{{ $message }}</x-invalid-feedback>
                @enderror
                <x-invalid-feedback id="file-required" class="d-none">ファイルを選択してください。</x-invalid-feedback>
            </div>
        </div>

        <div class="d-flex justify-content-center py-2 px-2 px-sm-3 mb-3">
            <x-submit-button id="submitForm" >確定</x-submit-button>
        </div>
    </x-form>
    </div>
@push('scripts')
    <script src="{{ mix('js/U0300/set-sign-file.js') }}"></script>
@endpush
</x-layouts.app>
