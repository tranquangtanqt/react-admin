<x-layouts.app title="作業実績設定">
@push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0300/set-result.css') }}">
@endpush

{{-- 作業実績設定 --}}
<div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
    <div class="p-0"></div>
    <div class="p-0">{{ __('作業実績設定') }}</div>
    <a  class="btn p-0 text-white" href="{{route('result-info.index', ['scheduleId' => $scheduleId ])}}">{{ __('戻る') }}</a>
</div>
@if ( $allowEdit == true )
    <div class="px-2 px-sm-3">
    <hr>
    <x-form method="{{ $method }}" action="{{ $actions }}" class="w-100">
        <input type="hidden" name="scheduleId" id="scheduleId" value="{{ $scheduleId }}" readonly>
        <input type="hidden" name="updated_at" value="{{ $workResult->updated_at }}" readonly>
        <div class="mb-3">
            <label class="lable-title">{{ __('日付') }}</label>
            <label class="lable-date" for="sysdate">{{ date('Y/m/d',strtotime($schedule->date)) }}</label>
        </div>

        <hr>

        {{-- ＫＹポイント --}}
        <div class="mb-3 d-flex">
            <label class="lable-center">{{ __('ＫＹポイント') }}</label>
            <select class="form-select ms-2 ky-select" name ="kyPoint">
                @if ($workResult->ky_point_type == null)
                    @if (old('kyPoint') != null)
                        @foreach ( $templateKYPonts as $kytemp )
                            @if ( $kytemp->key == old('kyPoint') )
                                <option value="{{ $kytemp->key }}" selected>{{ $kytemp->value }}</option>
                            @else
                                <option value="{{ $kytemp->key }}">{{ $kytemp->value }}</option>
                            @endif
                        @endforeach
                    @else
                        @foreach ( $templateKYPonts as $kytemp )
                            <option value="{{ $kytemp->key }}">{{ $kytemp->value }}</option>
                        @endforeach
                    @endif
                @else
                    @foreach ($templateKYPonts as $kytemp)
                        @if ($kytemp->key == $workResult->ky_point_type || $kytemp->key == old('kyPoint'))
                            <option value="{{ $kytemp->key }}" selected>{{ $kytemp->value }}</option>
                        @else
                            <option value="{{ $kytemp->key }}">{{ $kytemp->value }}</option>
                        @endif
                    @endforeach
                @endif
            </select>
        </div>

        {{-- ワンポイント対策 --}}
        <div class="mb-3">
            <label class="mb-2">{{ __('ワンポイント対策') }}</label>
            <div class="input-area">
                <input id="onePoint" type="text" maxlength="20"
                    class="form-control form-login"
                    value="{{ old('onePoint', $workResult->one_point) }}"
                    name="onePoint"
                    autofocus>
            </div>
            @error('onePoint')
                <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
            @enderror
        </div>

        @foreach ( $workResultDetails as $detail )
        <hr>
        <input type="hidden" name="updatedAt[{{ $detail->device_id }}]" value="{{ $detail->updated_at }}" readonly>
        <input type="hidden" name="detailId[{{ $detail->device_id }}]" value="{{ $detail->id }}" readonly>
        <input type="hidden" name="deviceId[{{ $detail->device_id }}]" value="{{ $detail->device_id }}" readonly>
        <div class="mb-3">
            <label class="lable-title">{{ __('系統') }}</label>
            <label class="ms-2" for="sysdate">{{ $detail->group_name == null? '未設定' : $detail->group_name }}</label>
        </div>
        <div class="mb-3">
            <label class="lable-title">{{ __('機種') }}</label>
            <label class="ms-2" for="sysdate">{{ $detail->device_type }}</label>
        </div>
        <div class="mb-3">
            <label class="lable-title">{{ __('機番') }}</label>
            <label class="ms-2" for="sysdate">{{ $detail->device_no }}</label>
        </div>

        {{-- 作業内容 --}}
        <div class="mb-3" >
            <label class="mb-2">{{ __('作業内容') }}</label>
            <div class="d-flex">
                <div class="flex-grow-1">
                    <textarea   class="form-control"
                                id="workContent{{ $detail->device_id }}"
                                name="workContent[{{ $detail->device_id }}]"
                                maxlength="100" rows="4">{{ old('workContent.'.$detail->device_id, $detail->work_detail) }}</textarea>
                </div>
                <div class="w-0">
                    <select class="select-template" onchange="contentTemplateSelected({{ $detail->device_id }},this)">
                        <option value="" selected disabled hidden></option>
                        @foreach ( $templateWorkContents as $templateContent )
                            <option value="{{ $templateContent->value }}">{{ $templateContent->value }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            @error('workContent.'.$detail->device_id)
                <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
            @enderror
        </div>
        @endforeach

        {{-- 作業実績入力完了 --}}
        <hr>
        {{-- CHG 20220412 Ishino OT-031 作業実績入力完了チェック表示変更対応 --}}
        <div class="d-flex justify-content-center py-2 px-2 px-sm-3 mb-3">
            @if ($workResult->entry_complete_flag == true || old('completeFlag') != null)
                <input type="checkbox" name="completeFlag" class="m-1" checked>
            @else
                <input type="checkbox" name="completeFlag" class="m-1">
            @endif
            <label for="date">{{ __('作業が完了した場合にチェックしてください。') }}</label>
        </div>

        @if (session('error'))
            <x-invalid-feedback>{{ session('error') }}</x-invalid-feedback>
        @endif

        <div class="d-flex justify-content-center py-2 px-2 px-sm-3 mb-3">
            <x-submit-button>{{ __('確定') }}</x-submit-button>
        </div>
    </x-form>

    </div>
    <div class="modal fade" tabindex="-1" id="confirm-edit-modal" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('通知') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                    <div class="modal-body">
                        <p>{{ __('日付、時間帯、訪問担当の変更は訪問予定情報の変更となります。') }}</p>
                        <p>{{ __('訪問予定情報を変更しますか。') }}</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary text-white px-4 confirm-ok"
                            data-target-route="{{ route('set-schedule.edit', ['schedule' => $schedule->id]) }}"
                            onclick="$('#confirm-edit-modal').modal('hide');fetchScheduleModal(event, this, 'edit');">
                            ＯＫ
                        </button>
                        <button class="btn btn-secondary" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                    </div>
            </div>
        </div>
    </div>


    {{-- 訪問予定追加・追加モーダル --}}
    <div id="js-set-schedule-modal"></div>

    {{-- 予定確認条件設定 --}}
    <div id="js-set-schedule-check-condition-modal"></div>

    {{-- 予定確認設定 --}}
    <div id="js-set-schedule-check-modal"></div>

@endif

@push('scripts')
    <script src="{{ mix('js/U0300/set-result.js') }}" ></script>
@endpush
</x-layouts.app>
