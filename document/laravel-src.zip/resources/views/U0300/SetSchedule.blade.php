<x-U0300.set-schedule-modal :schedule="$schedule ?? null" :reception="$reception ?? null" :persons="$persons" :slots="$slots" :mode="$mode"
    :initDate="$initDate ?? null" :initUserId="$initUserId ?? null" :shouldSetPjMgr="$shouldSetPjMgr ?? false" :initPjMgrId="$initPjMgrId ?? null">
</x-U0300.set-schedule-modal>

@if ($shouldSetPjMgr ?? false)
    <x-modal modal-id="sche-pjmgr-modal" title="計上担当設定">
        <x-slot name="rightButton">
            <button type="button" class="btn" aria-label="back"
                onclick="backToSetScheduleModalFromSetPjMgr()">戻る</button>
        </x-slot>

        <div class="border-top">
            <p class="my-2">
                <span>計上担当未設定です。</span>
                <br>
                <span>計上担当を登録する場合は以下から一人選択してください。</span>
            </p>

            <div class="mt-4" id="pjmgr-user-select-container">
                <div class="pjmgr-grid">
                    @foreach ($pjMgrUsers as $user)
                        @php
                            $pjmgrUserInputId = 'set-pjmgr-user-' . $user->id;
                            $checked = $initPjMgrId == $user->id;
                        @endphp

                        <div class="d-flex justify-content-center">
                            <input type="checkbox" id="{{ $pjmgrUserInputId }}" name="{{ $pjmgrUserInputId }}"
                                value="1" data-person-id="{{ $user->id }}" hidden {{ $checked ? 'checked' : '' }}>
                            <label for="{{ $pjmgrUserInputId }}" class="cursor-pointer">
                                <x-user-profile src="{{ $user->avatar }}" class="me-2"
                                    title="{{ $user->name }}" id="{{ $pjmgrUserInputId }}-icon" :icon="true"
                                    :checked="$checked">
                                    {{ $user->short_name }}
                                </x-user-profile>
                            </label>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        <x-slot name="footer">
            <div class="d-flex flex-grow-1 justify-content-center text-white">
                <x-submit-button onclick="$('#{{ $mode }}-schedule-modal form').submit()">確定</x-submit-button>
            </div>
        </x-slot>

    </x-modal>

    {{-- javascript --}}
    <script>
        // 時間帯を選択する際に以下を実行
        $(`input[type=checkbox][name^=add_schedule_persons]`).on(
            "change",
            function() {
                // 最初の選択された時間帯(社員のみ)
                firstCheckedSlots = $(`input[type=checkbox][name^=add_schedule_persons][data-internal=true]:checked`)
                    .first();

                // 計上担当項目(#pjmgr-id)の値を更新
                if (firstCheckedSlots.length > 0) {

                    // 最初の選択された担当者のID
                    selectedFirstPersonId = firstCheckedSlots.data('personId');

                    $('#pjmgr-id').val(selectedFirstPersonId);

                    // 計上担当モーダルの選択状態を更新
                    $(`input[type=checkbox][id=set-pjmgr-user-${selectedFirstPersonId}]`)
                        .prop('checked', true)
                        .trigger('change');

                    // 最初の選択された時間帯(社員のみ)がない場合リセットする
                } else {
                    $('#pjmgr-id').val('');
                    $(`input[type=checkbox][id^=set-pjmgr-user-]`)
                        .prop('checked', false)
                        .trigger('change');
                }

            }
        );

        $(`input[type=checkbox][id^=set-pjmgr-user-]`).on("change", function() {
            const splittedId = this.id.split('-');
            splittedId.pop();
            const startOfId = splittedId.join('-');
            if (this.checked) {
                $(`input[type=checkbox][id^=${startOfId}]`)
                    .not(this)
                    .prop('checked', false)
                    .trigger('change'); // 他のチェックボックスのチェックを外す
                $(`#${this.id}-icon`).removeClass("d-none"); // 対象担当者チェック
            } else {
                $(`#${this.id}-icon`).addClass("d-none"); // 対象担当者チェック外す
            }

            // 計上担当項目を更新する
            selectedPjMgr = $(`input[type=checkbox][id^=set-pjmgr-user-]:checked`).first();
            $('#pjmgr-id').val(selectedPjMgr.data('personId'));
        });
    </script>
@endif
