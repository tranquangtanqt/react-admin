<x-layouts.app title="工数設定">
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/U0300/set-man-hour.css') }}">
    @endpush
    {{-- 工数設定ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">{{ __('工数設定') }}</div>
        <a  class="btn p-0 text-white" href="{{ route('result-info.index', ['scheduleId' => $schudule->id ]) }}">{{ __('戻る') }}</a>
    </div>

    <div class="px-2 px-sm-4">
        <hr>
        @error('linkedL2')
            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
        @enderror
        <x-form method="POST" action="{{ $action }}" class="w-100">
            @if ( Str::contains($action, 'update') )
                {{ method_field('PATCH') }}
            @endif
            <input type="hidden" value="{{ $schudule->id }}" name="schedule_id" readonly>
            <div class="mb-3">
                <label class="lable-title">{{ __('日付') }}</label>
                <label class="ms-5" for="sysdate">
                    {{ $schudule->date == null? date( "Y/m/d" ): date('Y/m/d', strtotime($schudule->date)) }}
                </label>
            </div>
            @php
                // CHG START 20220404 Ishino OT-034 35:59まで入力可能とする対応
                //$startTime = $manHour->start_time == null? null:date( 'H:i',strtotime($manHour->start_time) );
                //$endTime = $manHour->end_time == null? null:date( 'H:i',strtotime($manHour->end_time) );
                $startTime = $manHour->start_time == null? null:substr($manHour->start_time,0,2).':'.substr($manHour->start_time,-2,2);
                $endTime = $manHour->end_time == null? null:substr($manHour->end_time,0,2).':'.substr($manHour->end_time,-2,2);
                // CHG E N D 20220404 Ishino OT-034 35:59まで入力可能とする対応
            @endphp
            <div class="mb-4">
                <label class="lable-title">{{ __('時間') }}</label>
                <div>
                    <div class="d-flex input-time">
                        <input  type ="text"
                                class="form-control sm-input @error('startTime') is-invalid @enderror"
                                id="startTime"
                                name="startTime"
                                value="{{ old('startTime',$startTime) }}"
                                autocomplete="off">
                        <div class="ms-4 me-4 pt-1">～</div>
                        <input  type ="text"
                                class="form-control sm-input @error('endTime') is-invalid @enderror"
                                id="endTime"
                                name="endTime"
                                value="{{ old('endTime',$endTime) }}"
                                autocomplete="off">
                    </div>
                    <div>
                        @error('startTime')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                        @error('endTime')
                            <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                        @enderror
                    </div>
                </div>

            </div>

            <div class="mb-4">
                <label class="lable-title">{{ __('工数') }}</label>
                <div class="input-area">
                    <input  type="text" id="manHour"
                            class="form-control text-end sm-input @error('manHour') is-invalid @enderror"
                            value="{{ old('manHour',$manHour->man_hour) }}"
                            name="manHour">
                </div>
                @error('manHour')
                    <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                @enderror
            </div>

            <div class="mb-4">
                <label class="mb-2">{{ __('作業区分') }}</label>
                <div class="w-25 input-area">
                    <select class="form-select w-15 md-select" name="work">
                        @if ( $isRelatedL2 == 1 )
                            <option value="{{ $works->key }}" selected>{{ $works->value }}</option>
                        @else
                            @if( $manHour->work_class == null )
                                <option value="" selected></option>
                                @foreach ( $works as $work )
                                    <option value="{{ $work->key }}">{{ $work->value }}</option>
                                @endforeach
                            @else
                                <option value=""></option>
                                @foreach ( $works as $work )
                                    @if( $manHour->work_class == $work->key )
                                        <option value="{{ $work->key }}" selected>{{ $work->value }}</option>
                                    @else
                                        <option value="{{ $work->key }}">{{ $work->value }}</option>
                                    @endif
                                @endforeach
                            @endif
                        @endif
                    </select>
                </div>
                @error('work')
                    <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                @enderror
            </div>

            <div class="mb-2">
                <label class="mb-2">{{ __('作業内訳')}}</label>
                <div class="w-50 input-area">
                    <select class="form-select w-15 mb-1 me-2 sm-select" name="workClass">
                        @if( $manHour->work_type == null )
                            <option value="" selected></option>
                            @foreach ( $workClasses as $workClass )
                                <option value="{{ $workClass->key }}">{{ $workClass->value }}</option>
                            @endforeach
                        @else
                            <option value=""></option>
                            @foreach ( $workClasses as $workClass )
                                @if( $manHour->work_type == $workClass->key )
                                    <option value="{{ $workClass->key }}" selected>{{ $workClass->value }}</option>
                                @else
                                    <option value="{{ $workClass->key }}">{{ $workClass->value }}</option>
                                @endif
                            @endforeach
                        @endif
                    </select>

                    <select class="form-select w-15 lg-select" name="workDetail">
                        @if( $manHour->work_detail == null )
                            <option value="" selected></option>
                            @foreach ( $workDetails as $workDetail )
                                <option value="{{ $workDetail->key }}">{{ $workDetail->value }}</option>
                            @endforeach
                        @else
                            <option value=""></option>
                            @foreach ( $workDetails as $workDetail )
                                @if( $manHour->work_detail== $workDetail->key )
                                    <option value="{{ $workDetail->key }}" selected>{{ $workDetail->value }}</option>
                                @else
                                    <option value="{{ $workDetail->key }}">{{ $workDetail->value }}</option>
                                @endif
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>

            <div class="mb-2">
                <label class="lable-title">{{ __('作業内容') }}</label>
                <div class="col">
                    <textarea class="form-control text-area w-100 @error('workContent') is-invalid @enderror"
                              id="title"type="text"
                              name="workContent"
                              maxlength="100">{{ old('workContent',$manHour->work_content) }}</textarea>
                </div>
                @error('workContent')
                    <x-invalid-feedback>{{ $message }}</x-invalid-feedback>
                @enderror
            </div>

            <div class="d-flex justify-content-center py-4 px-2 px-sm-3">
                <x-submit-button>確定</x-submit-button>
            </div>
        </x-form>
    </div>
@push('scripts')
    <script src="{{ mix('js/U0300/set-man-hour.js') }}" ></script>
@endpush
</x-layouts.app>
