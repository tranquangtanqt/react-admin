{{-- @include('U0300.SetPaymentType')を追加しopenModalPaymentType(receptionNo)を呼び出することができます --}}
<div class="modal fade" id="modalpopupSetPaymentType" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" >
        <div class="modal-content" >
            <div class="modal-header border-bottom-0" >
                <h5 class="modal-title">有償無償確定</h5>
                <button type="button" class="btn" data-bs-dismiss="modal" id="closeModalPaymenttype" aria-label="back">戻る</button>
            </div>
            <form  id="frmSetpaymentType">
                @csrf
                <input hidden  name="receptionNo" id="txtReceptionNoSetpaymentType">
                <input hidden  name="timeNow" id="txtTimeNowSetpaymentType">
                <div class="modal-body">
                    <select class="form-select w-50" name="value">
                      </select>
                      <x-invalid-feedback id="setPaymentTypeValidError"></x-invalid-feedback>
                </div>
                <div class="modal-footer border-top-0 justify-content-center text-white d-flex" id="u0306-submit">
                    <x-submit-button type="button">確定</x-submit-button>
                </div>
            </form>
        </div>
    </div>
</div>
<button id="btnShowModalSetpaymentType" type="button" data-bs-toggle="modal"  hidden data-bs-target="#modalpopupSetPaymentType">
  </button>
@push('scripts')
    <script src="{{ mix('js/U0300/set-payment-type.js') }}" ></script>
@endpush
