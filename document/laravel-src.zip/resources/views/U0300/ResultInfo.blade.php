<x-layouts.app title="作業実績情報">
    @push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0300/result-info.css') }}">
    @endpush

    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">作業実績情報</div>
        <a class="btn p-0 text-white" href="{{ route('receptions.schedule-result.show', ['reception' => $schedule->reception_no]) }}">戻る</a>
    </div>

    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3 mb-5 pb-5">
        @if(Session::has('message'))
        <p class="alert alert-success text-center">{{ Session::get('message') }}</p>
        @endif

        <input type="hidden" id="u0302-reception-no" value="{{ $schedule->reception_no }}">

        <hr class="mb-2">
        <div class="row mb-2">
            <div class="d-flex align-items-center">
                <div class="col-3 col-md-1">
                    <b>作業実績</b>
                </div>
                <div class="col-9 col-md-11">
                    <div class="d-flex justify-content-start align-items-center">
                        @can('deleteResult', $schedule)
                            <form id="frm-delete-workresult" action="{{ route('result-info.work-result.delete', ['receptionNo' => $schedule->reception_no, 'scheduleId' => $schedule->id]) }}" method="POST">
                                @csrf
                                @method('delete')

                                <button type="button" class="btn p-0 me-3" data-bs-toggle="modal" data-bs-target="#u0302-delete-work-result">
                                    <i class="bi bi-trash-fill" title="実績を削除する"></i>
                                </button>

                            </form>
                        @endcan
                        @can('updateResult', $schedule)
                            <a class="btn bi-pencil-fill f-16 text-black-50 p-0 ms-3" href="{{ route('set-result.show', ['scheduleId' => $schedule->id]) }}"></a>
                        @endcan
                    </div>
                </div>
            </div>
        </div>

        <div class="px-sm-3">
            <div class="row my-3">
                <div class="col-3 col-md-1">
                    日付
                </div>
                <div class="col-9 col-md-11">
                    {{ date('Y/m/d',strtotime($schedule->date)) }}
                </div>
            </div>

            @if($workResult != null)
            <div class="row">
                <div class="col-md-12">
                    ＫＹポイント
                </div>
                <div class="col-md-12">
                    <p>{{ $workResult->ky_point_name }}</p>
                </div>
                <div class="col-md-12">
                    ワンポイント対策
                </div>
                <div class="col-md-12">
                    <p>{{ $workResult->one_point }}</p>
                </div>
            </div>
            @endif

            @if($workResultDetails != null)
            @for ($i = 0; $i < count($workResultDetails); $i++) @if ($i==0) @if($workResult==null) <div class="row mt-3">
                @else
                <div class="row">
                    @endif
                    @else
                    <div class="row mt-3">
                        @endif

                        <div class="col-3 col-md-1">
                            系統
                        </div>
                        <div class="col-9 col-md-11">
                            {{ $workResultDetails[$i]->name }}
                        </div>
                        <div class="col-3 col-md-1">
                            機種
                        </div>
                        <div class="col-9 col-md-11">
                            {{ $workResultDetails[$i]->device_type }}
                        </div>
                        <div class="col-3 col-md-1">
                            機番
                        </div>
                        <div class="col-9 col-md-11">
                            {{ $workResultDetails[$i]->device_no }}
                        </div>
                        <div class="col-12 col-md-12">
                            作業内容
                        </div>
                        <div class="col-12 col-md-12 u0302-overflow-wrap">
                            {{ $workResultDetails[$i]->work_detail }}
                        </div>
                    </div>
                    @endfor
                    @endif
                </div>

                {{-- ※訪問担当（協力会社）の権限を持つユーザーは、工数のセクションを表示しない。 --}}
                @if (!$flgAuth['visiter-cooperating-company'])
                <hr class="mb-2">
                <div class="row mb-3">
                    <div class="d-flex align-items-center mb-3">
                        <div class="col-3 col-md-1">
                            <b>工数</b>
                        </div>
                        <div class="col-9 col-md-11">
                            @can('updateManHour', $schedule)
                                <a class="btn p-0 bi-plus-circle-fill f-16 text-black-50" href="{{ route('set-man-hour.show', ['scheduleId' => $schedule->id, 'userId' => auth()->user()->id]) }}"></a>
                            @endcan
                        </div>
                    </div>

                    @if ($manhours != null)
                    <div class="d-flex flex-wrap px-sm-4">
                        @foreach ($manhours as $manhour)
                        <div class="card-border card-shadow mb-3 me-4">
                            <div class="d-flex flex-column justify-content-between dash-card-width h-100 p-1 text-start">
                                <div class="u0302-base-dash-card-height d-flex flex-column justify-content-between">
                                    <div class="w-100 d-flex flex-column justify-content-between flex-fill min-h-0 p-0">
                                        <div class="d-flex flex-column min-h-0">
                                            <div class="row">
                                                <div class="col-4 d-flex align-items-center f-10">
                                                    <span class="me-2">日付</span><span> {{ date('Y/m/d',strtotime($manhour->date)) }}</span>
                                                </div>
                                                <div class="col-4 d-flex align-items-center f-10">
                                                    <span class="me-1">{{ substr($manhour->start_time, 0, 2) }}:{{ substr($manhour->start_time, 2, 4) }}</span>
                                                    <span>~</span>
                                                    <span class="ms-1">{{ substr($manhour->end_time, 0, 2) }}:{{ substr($manhour->end_time, 2, 4)}}</span>
                                                </div>
                                                <div class="col-4 d-flex align-items-center justify-content-end">
                                                    @if ($manhour->user_id == auth()->user()->id)
                                                    @if (($flgAuth['visiter'] || userIsSystemAdmin()) && $displayControl['reception_status'])
                                                    <a class="btn p-0 f-10" href="{{ route('set-man-hour.show', ['scheduleId' => $manhour->schedule_id, 'userId' => $manhour->user_id]) }}">
                                                        <i class="bi-pencil-fill f-16 text-black-50" title="工数を編集する"></i>
                                                    </a>
                                                    @endif
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-3 mt-2">
                                                    @if($manhour->file == null)
                                                    <x-user-profile src="{{ url('storage/default/user_profile.jpg') }}" class="user-image" title="{{ $manhour->name }}"> {{ $manhour->short_name }} </x-user-profile>
                                                    @else
                                                    <x-user-profile src="data:image/png;base64, {{ stream_get_contents($manhour->file) }}" class="user-image" title="{{ $manhour->name }}"> {{ $manhour->short_name }} </x-user-profile>
                                                    @endif
                                                </div>
                                                <div class="col-8 f-10">
                                                    <div class="row">
                                                        <div class="col-4">
                                                            <div class="text-start">
                                                                <span>工数</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="text-start">
                                                                <span>{{ $manhour->man_hour }}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-4">
                                                            <div class="text-start">
                                                                <span>作業区分</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="text-start">
                                                                <span>{{ $manhour->work_class }}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-4">
                                                            <div class="text-start">
                                                                <span>作業内訳</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="text-start">
                                                                <span>{{ $manhour->work_type }}</span>
                                                            </div>
                                                            <div class="text-start">
                                                                <span>{{ $manhour->work_detail }} </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-4">
                                                            <div class="text-start">
                                                                <span>作業内容</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="text-start">
                                                                <span class="u0302-ellipsis-text">{{ $manhour->work_content }}</span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-4 pe-0">
                                                            <div class="text-start">
                                                                <span>Ⅼ２連携状態</span>
                                                            </div>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="text-start">
                                                                <span>{{ $manhour->coop_type }}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-1 f-10 d-flex align-items-center p-1">
                                                    @if ($manhour->user_id == auth()->user()->id)
                                                    @if (($flgAuth['visiter'] || userIsSystemAdmin()) && $displayControl['reception_status'])
                                                    @if ($displayControl['reception_status_delete'])
                                                    <form id="frm-delete-manhour-{{ $manhour->id }}" action="{{ route('result-info.manhour.delete', ['manhourId' => $manhour->id]) }}" method="POST">
                                                        @csrf
                                                        @method('delete')
                                                        <button type="button" class="btn p-0 float-end" onclick="u0302ShowModalDeleteManhour({{ $manhour->id }})">
                                                            <i class="bi bi-trash-fill" title="工数を削除する"></i>
                                                        </button>
                                                    </form>
                                                    @endif
                                                    @endif
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    @endif

                </div>
                @endif
                <hr class="mb-2">
                <div class="row mb-3">
                    <div class="d-flex align-items-center">
                        <div class="col-3 col-md-1">
                            <b>署名</b>
                        </div>
                        <div class="col-9 col-md-11">
                            @can('updateSignature', $schedule)
                            <div class="dropdown" id="u0302-dropdown-menu">
                                <button class="btn p-0 bi-pencil-fill f-16 text-black-50" type="button" id="u0302-dropdown-menu-button" data-bs-toggle="dropdown" aria-expanded="false">
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="u0302-dropdown-menu-button">
                                    <li><a class="dropdown-item" href="{{ route('check-certificate-customer.show', ['schedule' => $schedule->id]) }} ">電子署名</a></li>
                                    <li><a class="dropdown-item" href="{{ route('set-sign-file.show', ['scheduleId' => $schedule->id]) }}">署名ファイル</a></li>
                                </ul>
                            </div>
                            @endcan
                        </div>
                    </div>
                </div>

                @if($signature != null)
                @if ($signature->digital_flag)
                <div class="row ms-sm-1">
                    <div class="col-md-12">
                        <form id="frm-delete-signature" action="{{ route('result-info.signature.delete', ['signatureId' => $signature->id, 'fileId' => $signature->file_id]) }}" method="POST">
                            @csrf
                            @method('delete')
                            {{ date('Y/m/d',strtotime($signature->signed_at)) }}
                            @if (($flgAuth['any'] || userIsSystemAdmin()) && $displayControl['reception_status'])
                            @if ($displayControl['reception_status_delete'])
                            <button type="button" class="btn p-0" onclick="u0302ShowModalDeleteSignature()">
                                <i class="bi bi-trash-fill" title="署名を削除する"></i>
                            </button>
                            @endif
                            @endif
                        </form>
                    </div>
                </div>
                <div class="row ms-sm-1">
                    <div class="col-md-12">
                        <div class="d-flex flex-wrap">
                            <div class="card-border">
                                <div class="d-flex flex-column justify-content-between u0302-dash-card-width h-100 p-2 text-start">
                                    <div class="u0302-base-dash-card-height d-flex flex-column justify-content-between">
                                        <div class="w-100 d-flex flex-column justify-content-between flex-fill min-h-0 p-0">
                                            <div class="d-flex flex-column min-h-0">
                                                <img height="150" src=" {{ route('image.show',$signature->file_id) }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @else
                <div class="row ms-sm-1">
                    <div class="col-md-12 ">
                        {{ date('Y/m/d',strtotime($signature->signed_at)) }}
                    </div>
                </div>
                <div class="row ms-sm-1">
                    <div class="col-10 col-md-3">
                        <input type="text" class="form-control" id="u0302-signature-title" value="{{ $signature->title }}" name="u0302_signature_title" readonly>
                    </div>
                    <div class="col-2 col-md-2">
                        @if ($displayControl['reception_status_delete'])
                        @if (($flgAuth['any'] || userIsSystemAdmin()) && $displayControl['reception_status'])
                        <form id="frm-delete-signature" action="{{ route('result-info.signature.delete', ['signatureId' => $signature->id, 'fileId' => $signature->file_id]) }}" method="POST">
                            @csrf
                            @method('delete')
                            <button type="button" class="btn" onclick="u0302ShowModalDeleteSignature()">
                                <i class="bi bi-trash-fill" title="署名を削除する"></i>
                            </button>
                        </form>
                        @endif
                        @endif
                    </div>
                </div>
                @endif
                @endif

            </div>

            {{-- START
        ・作業実績設定画面から遷移した場合に、受付状態が訪問済みとなっている場合は以下の確認メッセージを表示する。
        「続けて受付状態を変更しますか。」（OK、キャンセル）
        OKを選択時は受付情報画面に遷移して、受付状態の編集クリック時と同様の動作をし、受付状態の変更を実施可能とする。

    --}}
            <input type="hidden" name="reception_status_visited" id="reception-status-visited" value="{{ $displayControl['reception_status_visited'] }}">

            <div class="modal fade" tabindex="-1" id="u0302-work-result-openmodal" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header border-bottom-0">
                            <h5 class="modal-title">{{ __('通知') }}</h5>
                        </div>
                        <div class="modal-body">
                            <p>{{ __('続けて受付状態を変更しますか。') }}</p>
                        </div>
                        <div class="modal-footer border-top-0 d-flex justify-content-between text-white">
                            <button class="btn u0302-custom-btn" id="u0302-visited-ok">{{ __('ＯＫ') }}</button>
                            <button class="btn u0302-custom-btn ms-2" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                        </div>
                    </div>
                </div>
            </div>

            {{-- END --}}

            {{-- 作業実績.削除 START --}}
            <div class="modal fade" tabindex="-1" id="u0302-delete-work-result" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header border-bottom-0">
                            <h5 class="modal-title">{{ __('通知') }}</h5>
                        </div>
                        <div class="modal-body">
                            <p>{{ __('作業実績とそれに紐づく工数、署名を削除します。よろしいですか。') }}</p>
                        </div>
                        <div class="modal-footer border-top-0 d-flex justify-content-between text-white">
                            <button class="btn u0302-custom-btn" onclick="u0302DeleteWorkresult()">{{ __('ＯＫ') }}</button>
                            <button class="btn u0302-custom-btn ms-2" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                            <input type="hidden" value="" id="">
                        </div>
                    </div>
                </div>
            </div>
            {{-- 作業実績.削除 END --}}

            {{-- 工数.削除 START --}}
            <div class="modal fade" tabindex="-1" id="u0302-delete-manhour" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header border-bottom-0">
                            <h5 class="modal-title">{{ __('通知') }}</h5>
                        </div>
                        <div class="modal-body">
                            <p>{{ __('工数を削除します。よろしいですか。') }}</p>
                        </div>
                        <div class="modal-footer border-top-0 d-flex justify-content-between text-white">
                            <button class="btn u0302-custom-btn" onclick="u0302DeleteManhour()">{{ __('ＯＫ') }}</button>
                            <button class="btn u0302-custom-btn ms-2" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                            <input type="hidden" value="" id="u0302-delete-manhourid">
                        </div>
                    </div>
                </div>
            </div>
            {{-- 工数.削除 END --}}

            {{-- 署名.削除 START --}}
            <div class="modal fade" tabindex="-1" id="u0302-delete-signature" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header border-bottom-0">
                            <h5 class="modal-title">{{ __('通知') }}</h5>
                        </div>
                        <div class="modal-body">
                            <p>{{ __('署名を削除します。よろしいですか。') }}</p>
                        </div>
                        <div class="modal-footer border-top-0 d-flex justify-content-between text-white">
                            <button class="btn u0302-custom-btn" onclick="u0302DeleteSignature()">{{ __('ＯＫ') }}</button>
                            <button class="btn u0302-custom-btn ms-2" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                        </div>
                    </div>
                </div>
            </div>
            {{-- 署名.削除 END --}}

            @push('scripts')
            <script src="{{ mix('js/U0300/result-info.js') }}"></script>
            @endpush
</x-layouts.app>
