<x-U0300.read-schedule-modal
    :schedule="$schedule"
    :persons="$persons" :slots="$slots">
</x-U0300.read-schedule-modal>
