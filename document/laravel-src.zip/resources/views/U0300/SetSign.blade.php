<x-layouts.app title="署名設定">
    @push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0300/set-sign.css') }}">
    @endpush
    {{-- 署名設定ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">{{ __('署名設定') }}</div>
        <a id="back-btn" class="btn p-0 text-white" href="{{ route('result-info.index', ['scheduleId' => $scheduleId ]) }}">{{ __('戻る') }}</a>
    </div>

    <div class="py-2 px-2 px-sm-3">
        <div class="mb-3 date-lable">
            <label for="date">{{ __('日付') }}</label>
            <label class="ms-5" for="sysdate">{{ date("Y/m/d") }}</label>
        </div>

        {{-- Signature area--}}
        <div>
            @csrf
            <input id="scheduleId" type="hidden" name="scheduleId" value="{{ $scheduleId }}" readonly>
            <div class="alert alert-success signature-area" style="display:none"></div>
            <div class="signature-area">
                <canvas id="signature-pad" class="signature-pad" width=600 height=240></canvas>
            </div>
            <br>
            <div class="d-flex justify-content-center flex-wrap">
                <button class="btn submit-btn mb-2" id="save">{{ __('確定') }}</button>
                <button class="btn submit-btn ms-sm-4" id="clear">{{ __('クリア') }}</button>
            </div>
        </div>

        {{-- 作業完了証明書ダウンロード --}}
        <a id="get-certificate" href="/certificate-customer/{{$scheduleId}}?close=true" target=”_blank” style="display:none"></a>
    </div>

    {{--Error modal --}}
    <div class="modal fade" tabindex="-1" id="errormodal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-bottom-0">
                    <h5 class="modal-title">{{ __('通知') }}</h5>
                </div>
                <div class="modal-body">
                    <p>{{ __('署名されていません。破棄して元の画面に戻りますか。？') }}</p>
                </div>
                <div class="modal-footer border-top-0 d-flex justify-content-between text-white">
                    <button class="btn custom-btn" id="ok">ＯＫ</button>
                    <button class="btn custom-btn ms-2" data-bs-dismiss="modal">いいえ</button>
                </div>
            </div>
        </div>
    </div>
    @push('scripts')
    <script src="{{ mix('js/U0300/set-sign.js') }}"></script>
    @endpush
</x-layouts.app>
