<x-modal modal-id="set-schedule-check-modal" title="予定確認設定">

    <x-slot name="rightButton">
        <button type="button" class="btn" aria-label="back" onclick="backToSetScheduleModal('{{ $mode }}')">戻る</button>
    </x-slot>

    <div class="text-white text-center">
        <button type="btn" class="btn submit-btn" onclick="backToSetScheduleCheckConditionModal()">条件再設定</button>
    </div>

    <hr class="mt-4">
    <div class="mb-2" role="title">条件</div>
    <div class="mb-1 text-truncate">
        <span>訪問担当：</span><span
            title="{{ $selectedPersons->implode('short_name', '、') }}">{{ $selectedPersons->implode('short_name', '、') }}</span>
    </div>
    <div class="mb-1">
        <span>日付範囲：</span><span>{{ $startDate . ' 〜 ' . $endDate }}</span>
    </div>
    <div class="mb-1 text-truncate">
        <span>時間帯：</span><span>{{ $selectedSlots->implode('value', '、') }}</span>
    </div>
    <div class="mb-1">
        <span>社内人数：</span><span>{{ $internalPersons }}人</span>
    </div>
    <div class="mb-1">
        <span>協力会社人数：</span><span>{{ $externalPersons }}人</span>
    </div>
    <hr>

    <div class="mt-4">
        @foreach($dateRange as $date)
            @php
                $formattedDateId = $date->format('Ymd');
                $dateData = $searchedDataArray[$date->format('Y/m/d')];
            @endphp

            <form action="#" onsubmit="setCheckedSchedules(event, this);" class="my-3">
                <h5 class="text-center">{{ $date->format('Y/m/d') }}</h5>
                <input type="hidden" name="date" value="{{ $date->format('Y/m/d') }}">
                <input type="hidden" name="mode" value="{{ $mode }}">

                {{-- 選択肢テーブル --}}
                <table class="w-100 mt-3">
                    <thead>
                        <tr>
                            <th class="fw-normal"></th>
                            @foreach($slots as $slot)
                                @php
                                    $slotId = "date-slot-$formattedDateId-$slot->key";
                                @endphp
                                <th class="fw-normal text-center">
                                    <div class="d-flex justify-content-center">
                                        <x-schedule-slot id="{{ $slotId }}" :icon="true" :checked="false">
                                            {{ $slot->value }}
                                        </x-schedule-slot>
                                    </div>
                                </th>
                            @endforeach
                        </tr>
                    </thead>
                    <tbody>

                        @foreach($persons as $person)
                            @php
                                $personId = "date-person-$formattedDateId-$person->id";
                            @endphp
                            <tr class="border-bottom">
                                <th class="fw-normal text-center py-2">
                                    <x-user-profile src="{{ $person->avatar }}" title="{{ $person->name }}" :icon="true" id="{{ $personId }}">
                                        {{ $person->short_name }}
                                    </x-user-profile>
                                </th>
                                @foreach($slots as $slot)
                                    @php
                                        $personSlotId = "date-person-slot-$formattedDateId-$person->id-$slot->key" ;
                                        $personSlotData = $dateData->where('user_id', $person->id)->where('slot_type', $slot->key)->first();
                                    @endphp
                                    <td class="text-center">
                                        <div class="sche-candidate">
                                            <label for="{{ $personSlotId }}" @class(["cursor-pointer",
                                                'matched' => $personSlotData['matched'],
                                            ])>
                                                <span class="">
                                                    {{ $personSlotData['count'] }}
                                                </span>
                                                <input type="checkbox" id="{{ $personSlotId }}" name="{{ $personSlotId }}" value="1" hidden>
                                            </label>
                                        </div>
                                    </td>
                                @endforeach
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <x-invalid-feedback id="check_schedule_error_{{ $date->format('Ymd') }}" class="d-none"></x-invalid-feedback>

                <div class="d-flex justify-content-center my-4">
                    <x-submit-button>設定</x-submit-button>
                </div>
            </form>
        @endforeach
    </div>

    <script>
        $(`input[type=checkbox][id^=date-person-slot-]`).on("change", function () {

            let splittedId = this.id.split('-');
            let date = splittedId[3];
            let personId = splittedId[4];
            let slotKey = splittedId[5];

            if (this.checked) {
                $(this).closest("label").addClass("selected");
                $(`#date-person-${date}-${personId}`).removeClass("d-none"); // 対象時間帯チェック
                $(`#date-slot-${date}-${slotKey}`).removeClass("d-none"); // 対象担当者チェック
            } else {
                $(this).closest("label").removeClass("selected");
                if (!$(`input[id^=date-person-slot-${date}-${personId}]:checked`).length) {
                    $(`#date-person-${date}-${personId}`).addClass("d-none");
                }
                if (!$(`input[id^=date-person-slot-${date}-][id$=-${slotKey}]:checked`).length) {
                    $(`#date-slot-${date}-${slotKey}`).addClass("d-none");
                }
            }
        });


    </script>

</x-modal>
