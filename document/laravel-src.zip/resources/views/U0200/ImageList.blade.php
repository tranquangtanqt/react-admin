<x-layouts.app title="画像一覧">
    @push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0200/image-list.css') }}">
    @endpush

    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">画像一覧</div>
        <a class="btn p-0 text-white" href="{{ route('receptions.show', ['reception' =>$receptionNo]) }}">戻る</a>
    </div>

    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3" id="tab-content">
        <div class="row">
            <div class="col-md-12">
                @if(Session::has('message'))
                <p id="u0208-show-success" class="alert alert-success text-center">{{ Session::get('message') }}</p>
                @endif
                @if(Session::has('messageErr'))
                <p id="u0208-show-error-server" class="alert alert-danger text-center">{{ Session::get('messageErr') }}</p>
                @endif
                <p id="u0208-show-error" class="alert alert-danger text-center d-none"></p>
                @can('updateAttachment', $reception)
                    <button class="btn p-0 float-end bi-plus-circle-fill f-16 text-black-50" onclick="fncU0208SelectFile()" title="画像を追加する"></button>
                    <form id="u0208-frm-photo" action="{{ route('image-list.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input type="file" id="u0208-file" name="u0208File" accept=".gif,.jpg,.jpeg,.png;capture=camera" class="d-none" />
                        <input type="hidden" name="u0208ReceptionNo" value="{{ $receptionNo }}" />
                        <input type="hidden" name="u0208MaxFileSize" id="u0208-max-file-size-value" value="{{ $maxFileSize }}" />
                    </form>
                @endcan
            </div>
        </div>
        <div class="row mt-2">
            @foreach ($photos as $photo)
                @if ($photo->public_flag || !userIsPicExternal())
                    <div class="col-4 col-sm-4 col-md-2 pb-3">
                        <div class="card">
                            <a href="{{ route('image.show', $photo->file_id) }}" data-lightbox="image">
                                <img class="img-thumbnail object-cover u0208-height-200" src="data:image/png;base64, {{ $photo->thumbnail }}">
                            </a>
                            @can('updateAttachment', $reception)
                                <div class="card-footer u0208-card-footer text-center">
                                    <form id="frm{{$photo->id}}" action="{{ route('image-list.delete', ['reception' => $receptionNo, 'id' => $photo->id]) }}" method="POST">
                                        @csrf
                                        @method('delete')
                                        <button type="button" data-id="{{$photo->id}}" class="btn p-0 open-modal" data-bs-toggle="modal" data-bs-target="#openmodal">
                                            <i class="bi bi-trash-fill btn" title="画像を削除する"></i>
                                        </button>
                                        <input type="hidden" name="receptionNo" value="{{ $receptionNo }}" />
                                    </form>
                                </div>
                            @endcan
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    </div>

    <div class="modal fade" tabindex="-1" id="openmodal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-bottom-0">
                    <h5 class="modal-title">{{ __('通知') }}</h5>
                </div>
                <div class="modal-body">
                    <p>{{ __('画像を削除します。よろしいですか。') }}</p>
                </div>
                <div class="modal-footer border-top-0 d-flex justify-content-between text-white">
                    <button class="btn u0208-custom-btn" id="ok">{{ __('ＯＫ') }}</button>
                    <button class="btn u0208-custom-btn ms-2" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                    <input type="hidden" value="" id="photo-id">
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
    <script src="{{ mix('js/U0200/image-list.js') }}"></script>
    @endpush
</x-layouts.app>
