<x-U0200.layout-info active-tab="schedule-result" reception-no="{{ $reception->no }}">

    {{-- 訪問予定・実績 --}}
    <div class="mb-5" id="schedule-results" role="tabpanel" aria-labelledby="schedule-results-tab">
        <!-- 訪問予定 start -->
        @can('createOrUpdateSchedule', $reception)
            {{-- CHG 20220406 Ishino OT-021 ボタン名変更「追加」->「訪問予定追加」--}}
            <x-section-divider class="mt-3 mb-3" id="schedule-section" title="訪問予定" link-to="none" :line-top="false">
                <x-slot name="titleIcon">
                    <button type="button" class="btn ms-4 py-0 bi-plus-circle-fill f-16 text-black-50"
                    data-target-route="{{ route('set-schedule.create', [$reception]) }}"
                    onclick="fetchScheduleModal(event, this, 'add');"
                    title="訪問予定を追加する"></button>
                </x-slot>
            </x-section-divider>
        @else
            <x-section-divider class="mt-3" id="schedule-section" title="訪問予定" link-to="none" :line-top="false">
            </x-section-divider>
        @endcan

        <div class="d-flex flex-wrap mt-3 justify-content-center justify-content-sm-start px-sm-1">
            @forelse($schedules as $schedule)
                <x-U0200.schedule-card :schedule="$schedule" reception-no="{{ $reception->no }}"
                    :slotTitles="$slotTitles" :slotColors="$slotColors" :editable="$canEditSchedule">
                </x-U0200.schedule-card>
            @empty
                <p>訪問予定がありません。</p>
            @endforelse
        </div>

        {{-- 訪問予定追加・追加モーダル --}}
        <div id="js-set-schedule-modal"></div>

        {{-- 訪問予定表示モーダル --}}
        <div id="js-read-schedule-modal"></div>

        {{-- 予定確認条件設定 --}}
        <div id="js-set-schedule-check-condition-modal"></div>

        {{-- 予定確認設定 --}}
        <div id="js-set-schedule-check-modal"></div>

        <!-- 訪問予定 end-->

        <!-- 有償・無償 start -->
        <x-section-divider id="payment-section" title="有償・無償" link-to="none">
        </x-section-divider>
        @if($workReport)
            <div class="border-black border text-center mx-4" style="width:200px;">
                <span class="my-2 d-inline-block">
                    {{ $workReport->payment_type_name }}
                </span>
                @can('updatePaymentType', $reception)
                    <button type="button" class="btn bi-pencil-fill f-16 text-black-50 ms-2" onclick="openModalPaymentType({{ $reception->no }});" title="有償・無償を変更する"></button>
                @endcan
            </div>
        @endif
        @include('U0300.SetPaymentType')
        <!-- 有償・無償 end -->

        <!-- 充填・回収情報 start -->
        <x-section-divider id="update-gas-in-out" title="充填・回収情報" link-to="none">
        </x-section-divider>
        <div class="w-100 px-sm-4">
            <table class="table table-hover w-100">
                <tbody>
                    <tr>
                        <th style="width:20%"></th>
                        <th style="width: 20%">区分</th>
                        <th style="width: 20%">種類</th>
                        <th style="width: 20%">量</th>
                        <th style="width: 10%; white-space: nowrap;">交付年月日</th>
                        <th style="width: 5%"></th>
                    </tr>
                    <tr class="align-baseline">
                        <td>充填</td>
                        <td>{{ $gasIn?->in_type_name }}</td>
                        <td>{{ $gasIn?->gas_type_name_edit }}</td>
                        <td>{{ $gasIn?->quantity ? preg_replace("/\.?0+$/","", $gasIn?->quantity) . 'Kg' : '' }}</td>
                        <td>{{ $gasIn?->date?->format('Y/m/d') }}</td>
                        <td>
                        @can('updateGas', $reception)
                            <button type="button" class="btn  ps-4 bi-pencil-fill f-16 text-black-50" onclick="openModalsetGasInfo({{ $reception->no }})" title="充填情報を編集する"></button>
                        @endcan
                        </td>
                    </tr>
                    <tr class="align-baseline">
                        <td>回収</td>
                        <td>{{ $gasOut?->out_type_name }}</td>
                        <td>{{ $gasOut?->gas_type_name_edit }}</td>
                        <td>{{ $gasOut?->quantity ? preg_replace("/\.?0+$/","", $gasOut?->quantity) . 'Kg' : '' }}</td>
                        <td>{{ $gasOut?->date?->format('Y/m/d') }}</td>
                        <td>
                        @can('updateGas', $reception)
                            <button type="button" class="btn  ps-4 bi-pencil-fill f-16 text-black-50" onclick="openModalsetGasInfo({{ $reception->no }}, 'GasOutInfo')" title="回収情報を編集する"></button>
                        @endcan
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- 充填・回収情報 end -->

        <x-section-divider id="operation-record" title="運転記録" link-to="none">
        </x-section-divider>
        <div class="col-md-6 col-sm-auto px-sm-4">
            <table class="table table-hover">
                <tbody>
                    <tr>
                        <th class="text-center">機器件数</th>
                        <th class="text-center">入力済数</th>
                        <th></th>
                    </tr>
                    <tr class="align-baseline">
                        <td class="text-center">{{ $device_cnt }}</td>
                        <td class="text-center">{{ $op_record_cnt }}</td>
                        <td class="text-end">
                            <a href="{{ route('operation-record.show', $reception) }}"
                                class="btn  ps-4 bi-pencil-fill f-16 text-black-50" title="運転記録を編集する"></a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!-- 運転記録 end -->

        <!-- 作業区分 start -->
        <x-section-divider id="work-type-section" title="作業区分" link-to="none">
        </x-section-divider>
        <div class="border-black border text-center mx-4" style="width:200px;">
            <span class="my-2 d-inline-block">
                {{ $workReport->work_type_name }}
            </span>
            @can('updateWorkType', $reception)
                <button type="button" class="btn bi-pencil-fill f-16 text-black-50 ms-2" onclick="openModalWorkType({{ $reception->no }});" title="作業区分を変更する"></button>
            @endcan
        </div>

        {{-- 作業区分設定モーダル --}}
        @include('U0300.SetWorkType')
        <!-- 作業区分 end -->

        {{-- 充填回収設定モーダル --}}
        @can('updateGas', $reception)
        @include('U0300.SetGasInfo')
        @endcan
        <!-- 充填回収 end -->

    </div>

    <x-slot name="scriptSlot">

        <script>
            // 画面が起動した後に訪問予定関連制御を動かせる
            $(window).on("load", function () {
                loadSetScheduleListener("add"); // 訪問予定追加用
                loadSetScheduleListener("edit"); // 訪問予定編集用
            });

            $('input[role=datepicker]').datepicker({
                minDate: 0,
            });

        </script>

    </x-slot>

    </x-U200.layout-info>
