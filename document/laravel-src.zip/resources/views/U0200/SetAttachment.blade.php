<x-layouts.app title="添付ファイル設定">
    @push('styles')
        <link rel="stylesheet" href="{{ mix('css/U0200/set-attachment.css') }}" >
    @endpush

    {{-- 受付情報ヘッダー --}}
    <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
        <div class="p-0"></div>
        <div class="p-0">添付ファイル設定</div>
        <a class="btn p-0 text-white" href="{{ route('receptions.show', ['reception' => $receptionNo]) }}">戻る</a>
    </div>

    <p id="u0208-show-err" class="alert alert-danger text-center d-none"></p>
    {{-- タブ内容 --}}
    <div class="py-2 px-2 px-sm-3">
        <form id="u0208-frm" method="POST" action="{{ route('set-attachment.store')}}" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="receptionNo" value="{{ $receptionNo }}"/>
            <input type="hidden" name="u0208_max_file_size" id="max-file-size-value" value="{{ $maxFileSize }}"/>

            <div class="row">
                <div class="col-11 col-md-4 mb-3">
                    <label for="title" class="form-label">タイトル</label>
                    <input type="text" class="form-control" id="title" value="{{ old('title', $file->title) }}" name="title" maxlength="20">
                    <x-invalid-feedback id="title-err"></x-invalid-feedback>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-12 mb-3">
                    <label class="form-label">ファイル</label>
                    <div class="d-flex">
                        <div>
                            <input type="button" class="form-control btn u02081-choose-btn" id="loadFile" value="選択" onclick="u0208_fncSelectFileAttach()" />
                            <input type="file" id="file" style="display: none;" name="file" onchange="u0208_fncChangeFileAttach()"/>
                        </div>

                        <div id="filename" class="pt-2 ms-2">
                            <span>ファイル未選択</span>
                        </div>
                    </div>
                    <div>
                        <x-invalid-feedback id="file-err" style="font-size: 0.875em"></x-invalid-feedback>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-4 offset-4 col-md-6 offset-md-3 d-flex justify-content-center" id="u0208-submit">
                    <x-submit-button type="button">確定</x-submit-button>
                </div>
            </div>
        </form>
    </div>

    @push('scripts')
        <script src="{{ mix('js/U0200/set-attachment.js') }}"></script>
    @endpush
</x-layouts.app>
