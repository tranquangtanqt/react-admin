<x-layouts.app title="受付基本情報">
   @push('styles')
   <style type="text/css">
      <!--
      @media(min-width: 768px) {

         /* 電話番号リンク表示 */
         a[href^="tel:"] {
            pointer-events: none;
            text-decoration: none;
         }
      }
      -->
   </style>
   @endpush
   <div class="d-flex justify-content-between py-2 px-2 px-sm-3 mb-3 sub-header">
      <div></div>
      <div class="p-0">受付基本情報</div>
      <a class="btn p-0 text-white" href="{{ route('info.show', ['reception' =>$reception]) }}">戻る</a>
   </div>
   <div class="m-2 px-sm-4">
      <div class="row">
         <div class="col-lg-2 col-3">
            受付番号
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{$reception->no}}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            受付日
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ date('Y/m/d', strtotime($reception->date)) }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            受付担当
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->name != null ? $reception->name:'-' }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            依頼内容
         </div>
      </div>
      <div class="m-3 text-break">
         {{ $reception->content }}
      </div>
      <hr>
      <div class="row">
         <div class="col-lg-2 col-3">
            ご住所
            <a href="https://maps.google.com/?q={{ $reception->field_address }}" target="_blank" rel="noopener noreferrer" class="bi bi-geo-alt"></a>
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->field_address }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            お客様名
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{$reception->field_name }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            TEL
         </div>
         <div class="col-lg-10 col-9 text-break">
            <a href="tel:{{ $reception->field_tel }}">{{ $reception->field_tel }}</a>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            TEL
         </div>
         <div class="col-lg-10 col-9 text-break">
            <a href="tel:{{ $reception->field_mobile_tel }}">{{ $reception->field_mobile_tel }}</a>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            担当
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->field_person_name }}
         </div>
      </div>
      <hr>
      <div class="row">
         <div class="col-lg-2 col-3">
            ご住所
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->client_address }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            ご依頼元
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->client_name }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            TEL
         </div>
         <div class="col-lg-10 col-9 text-break">
            <a href="tel:{{ $reception->client_tel }}">{{ $reception->client_tel }}</a>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            FAX
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->client_fax }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            担当
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->client_person_name }}
         </div>
      </div>
      <div class="row">
         <div class="col-lg-2 col-3">
            請求締日
         </div>
         <div class="col-lg-10 col-9 text-break">
            {{ $reception->client_billing_deadline }}
         </div>
      </div>
   </div>
</x-layouts.app>
