<x-U0200.layout-info active-tab="finance" reception-no="{{ $reception->no }}">

    {{-- 金額 --}}
    <div class="mb-5" id="finance" role="tabpanel" aria-labelledby="finance-tab">
        <!-- 原価 start -->
        <x-section-divider class="mt-3 mb-3" id="cost-section" title="原価" link-to="none" :line-top="false">
            <x-slot name="titleIcon">
                <div class="d-inline-block ms-4">
                    <div class="d-flex align-items-center">
                        @can('updateCost', $reception)
                            <a href="{{ route('set-cost.index', $reception->no) }}" class="btn me-2 py-0 bi-pencil-fill f-16 text-black-50" title="原価を編集する"></a>
                        @endcan
                        @if (userIsInputSupport())
                            <a href="{{ route('check-cost.index', $reception) }}" class="btn py-0 bi bi-check-circle-fill f-16 text-black-50" title="原価をチェックする"></a>
                        @endif
                    </div>
                </div>
            </x-slot>
        </x-section-divider>

    <div class="d-flex justify-content-start col-md-6 col-sm-auto px-sm-4 flex-column">
        @if($manHourTotal > 0)
        <div class="bg-light p-2 flex-grow-1 d-flex justify-content-between align-items-center rounded">
            <span>工数計</span>
            <span class="f-16 fw-bold">{{ $manHourTotal ?? 0.00 }} H</span>
        </div>
        @endif
        @if(!$costs->isEmpty())
        <div class="bg-light p-2 flex-grow-1 d-flex justify-content-between align-items-center rounded mt-2">
            <span>原価計</span>
            <span class="f-16 fw-bold">{{ number_format($costsSum) }}円</span>
        </div>
        @endif
    </div>
    @if(!$costs->isEmpty())
    <div class="col-md-6 col-sm-auto px-sm-4 mt-4">
        <table class="table table-hover">
            <tbody>
                <tr>
                    <th style="width:auto;"></th>
                    <th style="width:auto;">名称</th>
                    <th class="text-end" style="width:auto;">金額</th>
                </tr>
                @php
                    $cost_id="-";
                @endphp
                @foreach($costs as $cost)
                <tr>
                    @if($cost_id != $cost->type_name)
                        <td>{{ $cost->type_name }}</td>
                    @else
                        <td></td>
                    @endif
                    <td class="word-break-all">{{ $cost->name }}</td>
                    <td class="word-break-all text-end">{{ number_format($cost->amount) }}円</td>
                </tr>
                @php
                $cost_id=$cost->type_name;
                @endphp
                @endforeach
            </tbody>
        </table>
    </div>
    @endif
    <!-- 原価 end -->

    <!-- 見積 start -->
    @can('updateQuotation', $reception)
        <x-section-divider id="quotation-section" title="見積" link-to="none">
            <x-slot name="titleIcon">
                <a href="{{ route('quotations.show', $reception)}}" class="btn ms-4 py-0 bi-pencil-fill f-16 text-black-50" title="見積を編集する"></a>
            </x-slot>
        </x-section-divider>
    @else
        <x-section-divider id="quotation-section" title="見積" link-to="none">
        </x-section-divider>
    @endcan

    @if(!$quotations->isEmpty())
    <div class="col-md-6 col-sm-auto px-sm-4 mt-4">
        <div class="bg-light p-2 flex-grow-1 d-flex justify-content-between align-items-center rounded mt-2">
            <span>小計（{{ $workReport->tax_included_flag ? '消費税込' : '消費税抜' }}）</span>
            <span class="f-16 fw-bold">{{ number_format($quotationSum) }}円</span>
        </div>
    </div>
    <div class="col-md-12 col-sm-auto px-sm-4 mt-4">
        <div class="p-2 rounded-0 mt-4 border-bottom border-end-0 fw-bold like-table-hover">
            <div class="row">
                <div class="col-4 col-sm-3 px-2">作業番号・品番</div>
                <div class="col-4 col-sm-2 px-2 text-end">数量</div>
                <div class="col-4 col-sm-3 px-2 text-end">金額</div>
                <div class="col col-sm px-2">作業名・品名</div>
            </div>
        </div>
        @foreach($quotations as $quotation)
            <div class="p-2 border-bottom like-table-hover">
                <div class="row">
                    <div class="col-4 col-sm-3 px-2">{{$quotation->work_no}}</div>
                    <div class="col-4 col-sm-2 px-2 text-end">{{preg_replace("/\.?0+$/","",$quotation->quantity)}}{{$quotation->unit}}</div>
                    <div class="col-4 col-sm-3 px-2 text-end">{{number_format($quotation->amount)}}円</div>
                    <div class="col col-sm px-2">{{$quotation->name}}</div>
                </div>
            </div>
        @endforeach
    </div>
    @endif
    <!-- 見積 end -->
    </div>

    </x-U200.layout-info>
