<x-form-modal modal-id="set-project-manager-modal" title="計上担当設定"
    action="{{ route('set-project-manager.update', [$reception]) }}" method="POST"
    btn-label="確定" onsubmit="submitSetProjectManager(event, this);">

    {{-- 更新日 --}}
    <input type="hidden" name="updated_at" value="{{ $reception->updated_at }}">

    {{-- 計上担当者 --}}
    <div class="border-top">
        <div class="row mt-2">
            <label for="project-manager-id" class="form-label">計上担当者</label>
        </div>

        <input type="hidden" name="pjmgr-user-id" value="{{ $pjmgrId }}" id="set-pjmgr-user-mgr-id">

        <div>
            <div class="d-inline-flex border p-2">
                <div class="pjmgr-container">
                    @if($existPjmgr)
                        @if($pjmgrFileId)
                            <x-user-profile src="{{ avatarByFileId($pjmgrFileId) }}"
                                class="me-2" title="{{ $pjmgrName }}">
                                {{ $pjmgrShortName }}
                            </x-user-profile>
                        @else
                            <x-user-profile class="me-2" title="{{ $pjmgrName }}">
                                {{ $pjmgrShortName }}
                            </x-user-profile>

                        @endif
                    @else
                        <i class="bi bi-exclamation-circle-fill text-danger me-2"></i>
                        <span>{{ $pjmgrShortName }}</span>
                    @endif
                </div>
                @if(!$existL2Pjmgr)
                    <button class="btn" type="button" data-bs-toggle="collapse"
                        data-bs-target="#pjmgr-user-select-container">
                        <i class="bi bi-caret-down-fill text-settle"></i>
                    </button>
                @endif
            </div>
            @if(!$existL2Pjmgr)
                <div class="collapse mt-3" id="pjmgr-user-select-container">
                    <div class="pjmgr-grid">
                        @foreach($pjmgrUsers as $user)
                            @php
                                $pjmgrUserInputId = "set-pjmgr-user-mgr-" . $user->id;
                                $checked = $pjmgrId == $user->id;
                            @endphp
                            {{-- {{ $pjmgrId . $user->id }} --}}
                            <div class="d-flex justify-content-center">
                                <input type="checkbox" id="{{ $pjmgrUserInputId }}" name="{{ $pjmgrUserInputId }}"
                                    value="1" data-person-id="{{ $user-> id }}" hidden
                                    {{ $checked ? 'checked' : '' }}>
                                <label for="{{ $pjmgrUserInputId }}" class="cursor-pointer">
                                    <x-user-profile src="{{ $user->avatar }}" class="me-2"
                                        title="{{ $user->name }}" id="{{ $pjmgrUserInputId }}-icon" :icon="true"
                                        :checked="$checked">
                                        {{ $user->short_name }}
                                    </x-user-profile>
                                </label>
                            </div>
                        @endforeach
                    </div>
                    <button class="btn" type="button" data-bs-toggle="collapse"
                        data-bs-target="#pjmgr-user-select-container">
                        <i class="bi bi-caret-up-fill text-settle"></i>
                    </button>
                </div>
            @endif
        </div>
    </div>


    <div class="row my-1">
        <x-invalid-feedback id="set-pjmgr-pjmgr-user-id-error" class="d-none"></x-invalid-feedback>
    </div>


    {{-- ダッシュボード表示担当 --}}
    <div class="border-top mt-3">
        <div class="row mt-2">
            <label for="display-user-id" class="form-label">ダッシュボード表示担当</label>
        </div>

        <input type="hidden" name="display-user-id" value="{{ $reception->display_user_id }}"
            id="set-pjmgr-user-display-id">

        <div>
            <div class="d-inline-flex border p-2">
                <div class="pjmgr-container">
                    @if($reception->display_user_id)
                        @if($reception->disp_file_id)
                            <x-user-profile
                                src="{{ route('image.show', $reception->disp_file_id) }}"
                                class="me-2" title="{{ $reception->disp_name }}">
                                {{ $reception->disp_short_name }}
                            </x-user-profile>

                        @else
                            <x-user-profile class="me-2" title="{{ $reception->disp_name }}">
                                {{ $reception->disp_short_name }}
                            </x-user-profile>
                        @endif
                    @else
                        <span>未定</span>
                    @endif
                </div>
                <button class="btn" type="button" data-bs-toggle="collapse"
                    data-bs-target="#display-user-select-container">
                    <i class="bi bi-caret-down-fill text-settle"></i>
                </button>
            </div>
            </button>
            <div class="collapse mt-3" id="display-user-select-container">
                <div class="pjmgr-grid">
                    @foreach($displayUsers as $user)
                        @php
                            $displayUserInputId = "set-pjmgr-user-display-" . $user->id;
                            $checked = $user->id == $reception->display_user_id;
                        @endphp
                        <div class="d-flex justify-content-center">
                            <input type="checkbox" id="{{ $displayUserInputId }}" name="{{ $displayUserInputId }}"
                                data-person-id="{{ $user-> id }}" value="1" hidden
                                {{ $checked ? 'checked' : '' }}>
                            <label for="{{ $displayUserInputId }}" class="cursor-pointer">
                                <x-user-profile src="{{ $user->avatar }}" title="{{ $user->name }}"
                                    id="{{ $displayUserInputId }}-icon" :icon="true" :checked="$checked">
                                    {{ $user->short_name }}
                                </x-user-profile>
                            </label>
                        </div>
                    @endforeach
                </div>
                <button class="btn" type="button" data-bs-toggle="collapse"
                    data-bs-target="#display-user-select-container">
                    <i class="bi bi-caret-up-fill text-settle"></i>
                </button>
            </div>
        </div>

        <div class="row my-3">
            <x-invalid-feedback id="set-pjmgr-general-message-error" class="d-none"></x-invalid-feedback>
            <x-invalid-feedback id="set-pjmgr-updated_at-error" class="d-none"></x-invalid-feedback>
        </div>
    </div>

    {{-- javascript --}}
    <script>
        $(`input[type=checkbox][id^=set-pjmgr-user-]`).on("change", function () {
            const splittedId = this.id.split('-');
            splittedId.pop();
            const startOfId = splittedId.join('-');
            if (this.checked) {
                $(`input[type=checkbox][id^=${startOfId}]`)
                    .not(this)
                    .prop('checked', false)
                    .trigger('change'); // 他のチェックボックスのチェックを外す
                $(`#${this.id}-icon`).removeClass("d-none"); // 対象担当者チェック
                $(`#${startOfId}-id`).val($(this).data('personId'));
            } else {
                $(`#${startOfId}-id`).val('');
                $(`#${this.id}-icon`).addClass("d-none"); // 対象担当者チェック外す
            }
        });

    </script>

</x-form-modal>
