<x-U0200.layout-info active-tab="info" reception-no="{{ $reception->no }}">
    @push('styles')
    {{-- 画像表示用 --}}
    <link rel="stylesheet" href="{{ mix('css/U0200/image-list.css') }}">
    @endpush
    <div class="mb-5" id="basic-info" role="tabpanel" aria-labelledby="basic-info-tab">
        {{-- 基本情報 --}}

        <!-- 受付情報 -->
        <div class="card-border card-shadow card-frame rounded my-3 p-1 mx-sm-4">
            <a href="{{ route('main-info.show', [ $reception->no ]) }}" class="btn w-100 text-start p-2">
                <div class="row">
                    <div class="col text-start justify-content-between f-14">
                        <span class="card-item-name">受付</span>
                        @php
                        $canceled = !is_null($status->canceled_at);
                        @endphp
                        <span @class([ 'me-4' , 'text-danger line-through'=> $canceled,
                            ]) title="{{ $canceled ? '受付がキャンセルされました。': '受付番号：' . $reception->no }}">{{ $reception->no }}</span>
                        <span>{{ $l2Reception->date->format('Y/m/d') }}</span>
                    </div>
                    @if($warning)
                    <div class="col text-end">
                        <span title="物件がキャンセルされました。">
                            <i class="bi bi-trash-fill text-danger"></i>
                        </span>
                    </div>
                    @endif
                </div>

                <div class="row min-h-0 mb-1">
                    <div class="col f-16 text-start pb-1 text-truncate text-truncate-2 text-primary fw-bold">
                        {{$l2Reception->content}}
                    </div>
                </div>

                <div class="row min-h-0">
                    <div class="col d-flex align-items-start text-start f-14">
                        <span class="card-item-name info-page">ご住所</span><span>{{ $l2Reception->field_address }}</span>
                    </div>
                </div>

                <div class="row min-h-0">
                    <div class="col d-flex align-items-start text-start f-14">
                        <span class="card-item-name info-page">お客様</span><span class="fw-bold">{{ $l2Reception->field_name }}</span>
                    </div>
                </div>

                <div class="row min-h-0">
                    <div class="col d-flex align-items-start text-start f-14">
                        <span class="card-item-name info-page">TEL</span><span>{{ $l2Reception->field_tel }}</span>
                    </div>
                </div>

                <div class="row min-h-0">
                    <div class="col d-flex align-items-start text-start f-14">
                        <span class="card-item-name info-page">TEL</span><span>{{ $l2Reception->field_mobile_tel }}</span>
                    </div>
                </div>

                <div class="row min-h-0">
                    <div class="col d-flex align-items-start text-start f-14">
                        <span class="card-item-name info-page">担当</span><span>{{ $l2Reception->field_person_name }}</span>
                    </div>
                </div>

                <div class="row min-h-0">
                    <div class="col d-flex align-items-start text-start f-14">
                        <span class="card-item-name info-page">ご依頼元</span><span class="fw-bold">{{ $l2Reception->client_name }}</span>
                    </div>
                </div>

                <div class="row min-h-0">
                    <div class="col d-flex align-items-start text-start f-14">
                        <span class="card-item-name info-page">担当</span><span>{{ $l2Reception->client_person_name }}</span>
                    </div>
                </div>
            </a>

        </div>

        <!-- 関連PJ -->
        <x-section-divider id="related-project-section" title="関連PJ" link-to="none">
        </x-section-divider>
        <div class="px-4">{{ $reception->related_pj_no ?? 'ー' }}</div>

        <!-- 受付状態 -->
        @canany(['update', 'restore'], $status)
        <x-section-divider id="project-status-section" title="状態" link-to="none">
            <x-slot name="titleIcon">
                <button type="button" class="btn ms-4 py-0 bi-pencil-fill f-16 text-black-50" data-target-route="{{ route('set-status.edit', [$status]) }}" onclick="fetchSetStatusModal(this);" title="状態を変更する"></button>
            </x-slot>
        </x-section-divider>
        @else
        <x-section-divider id="project-status-section" title="状態" link-to="none"></x-section-divider>
        @endcanany

        <div class="px-4">
            <img class="img-fluid col-md-6" src="{{ $statusImagePath }}" alt="{{ $status->label }}">
        </div>
        @if ($status?->status_type == config('constants.status.on_hold'))
        <div class="p-2 ms-5 mt-3">
            <div class="d-flex">
                <div style="width: 100px">
                    保留詳細
                </div>
                <div>
                    {{ $status?->detail_label }}
                </div>
            </div>
            <div class="d-flex">
                <div style="width: 100px">
                    リマインド
                </div>
                <div>
                    {{ $status?->remind_date?->format('Y/m/d') }}
                </div>
            </div>
            <div class="d-flex">
                <div style="width: 100px">
                </div>
                <div>
                    {{ $status?->remind_memo }}
                </div>
            </div>
        </div>
        @endif
        {{-- 受付状態設定モーダル --}}
        <div id="js-set-status-modal"></div>

        <!-- コメント -->
        @can('createComment', $reception)
        <x-section-divider id="comment-section" title="コメント" link-to="none">
            <x-slot name="titleIcon">
                <button type="button" class="btn ms-4 py-0 bi-plus-circle-fill f-16 text-black-50" onclick="openModalComment({{ $reception->no }});" title="コメントを追加する"></button>
            </x-slot>
        </x-section-divider>
        @else
        <x-section-divider id="comment-section" title="コメント" link-to="none"></x-section-divider>
        @endcan
        @if(!$comments->isEmpty())
        <div class="d-flex flex-column px-4">
            @foreach($comments as $comment)
            <div class="d-flex flex-row">
                <div style="width:40px;" class="m-2"></div>
                <div class="flex-fill d-flex flex-row">
                    <div class="f-12 flex-fill d-flex align-items-end" style="height:24px;">{{$comment->created_at->format('Y/m/d H:i')}}</div>
                </div>
                <div style="width:30px;"></div>
            </div>
            <div class="d-flex flex-row align-items-center">
                {{-- アイコン --}}
                @if($comment->user_file_id)
                <x-user-profile src="{{ route('image.show', $comment->user_file_id ) }}" class="me-2" style="width:100px" title="{{ $comment->name }}">
                    <div style="width:40px;">{{ $comment->short_name }}</div>
                </x-user-profile>
                @else
                <x-user-profile class="me-2" title="{{ $comment->name }}">
                    <div style="width:40px;">{{ $comment->short_name }}</div>
                </x-user-profile>
                @endif

                <div class="bg-success text-white px-3 py-1 info-comment">
                    <div>{{ $comment->comment }}</div>
                </div>

                <div class="d-flex align-items-center ms-2">
                    @if ($comment->created_by == Auth::id())
                    <div style="width:30px;">
                        {{--編集ボタン--}}
                        <x-form id="frm{{$comment->id}}" action="#" method="POST" class="m-0">
                            <button type="button" data-id="{{$comment->id}}" class="btn p-1 open-modal bi-pencil-fill" data-bs-toggle="modal" onclick="openModalComment({{ $reception->no }}, {{ $comment->id }}); event.preventDefault();" title="コメントを編集する">
                            </button>
                            <input type="hidden" name="receptionNo" value="{{ $reception->no }}" />
                        </x-form>
                    </div>
                    <div style="width:30px;">
                        {{--削除ボタン--}}
                        <x-form method="DELETE" id="form-comment-delete{{$comment->id}}" action="{{ route('comment.delete', $comment->id) }}">
                            <button type="button" class="btn p-1 confirm-comment-delete" data-bs-toggle="modal" data-bs-target="#openconfirm" value="{{$comment->id}}" title="コメントを削除する">
                                <i class="bi bi-trash-fill btn p-0"></i>
                            </button>
                        </x-form>
                    </div>
                    @else
                    <div style="width:30px;"></div>
                    @endif
                </div>
            </div>
            <x-invalid-feedback id="commentValidError{{$comment->id}}"></x-invalid-feedback>
            <div class="m-2"></div>

            @endforeach
        </div>
        @endif

        {{-- コメント設定モーダル --}}
        @include('U0200.SetComment')

        <!-- 計上担当 -->
        @can('updateProjectManager', $reception)
        <x-section-divider id="project-manager-section" title="計上担当" link-to="none">
            <x-slot name="titleIcon">
                <button type="button" class="btn ms-4 py-0 bi-pencil-fill f-16 text-black-50" data-target-route="{{ route('set-project-manager.edit', [$reception]) }}" onclick="fetchSetProjectManagerModal(this);" title="計上担当を変更する"></button>
            </x-slot>
        </x-section-divider>
        @else
        <x-section-divider id="project-manager-section" title="計上担当" link-to="none"></x-section-divider>
        @endcan

        <div class="px-4 py-2">
            {{-- 計上担当者 --}}
            <div>
                @if( $pjmgrName )
                @if($pjmgrFileId)
                <img class="user-icon" src="{{ route('image.show', $pjmgrFileId) }}" alt="ユーザーアイコン">
                @else
                <img class="user-icon" src="{{ asset('/storage/default/user_profile.jpg') }}" alt="ユーザーアイコン">
                @endif
                <span>{{ $pjmgrName }}</span>
                @elseif($reception->person_emp_code)
                <span>L2にて設定</span>
                @else
                <i class="bi bi-exclamation-circle-fill text-danger"></i>
                <span>担当者未定</span>
                @endif
            </div>

            {{-- ダッシュボード表示担当者 --}}
            @if( $reception->disp_name )
            <div class="mt-3">
                <div><span>ダッシュボード表示担当</span></div>
                <div class="ps-3 mt-2">
                    @if($reception->disp_file_id)
                    <img class="user-icon" src="{{ route('image.show', $reception->disp_file_id) }}" alt="ユーザーアイコン">
                    @else
                    <img class="user-icon" src="{{ asset('/storage/default/user_profile.jpg') }}" alt="ユーザーアイコン">
                    @endif
                    <span>{{ $reception->disp_name }}</span>
                </div>
            </div>
        </div>
        @endif
    </div>

    {{-- 計上担当設定モーダル --}}
    <div id="js-set-project-manager-modal"></div>

    <!-- 請求先 start -->
    @can('updateBilling', $reception)
    <x-section-divider id="billing-section" title="請求先" link-to="none">
        <x-slot name="titleIcon">
            <button type="button" class="btn ms-4 py-0 bi-pencil-fill f-16 text-black-50" data-bs-toggle="modal" data-bs-target="#billing-modal" title="請求先を編集する"></button>
        </x-slot>
    </x-section-divider>
    @else
    <x-section-divider id="billing-section" title="請求先" link-to="none">
    </x-section-divider>
    @endcan

    @if($reception->billing_name != '' or $reception->billing_tel != '' or $reception->billing_fax != '')
    <div class="card-border mx-4 p-3 rounded-0 border-1">

        <div class="row">
            <div class="col-lg-2 col-3">請求先名</div>
            <div class="col-lg-10 col-9 text-break">{!! nl2br(e($reception->billing_name)) !!}</div>
        </div>
        <div class="row">
            <div class="col-lg-2 col-3">請求先TEL</div>
            <div class="col-lg-10 col-9 text-break">{!! nl2br(e($reception->billing_tel)) !!}</div>
        </div>
        <div class="row">
            <div class="col-lg-2 col-3">請求先FAX</div>
            <div class="col-lg-10 col-9 text-break">{!! nl2br(e($reception->billing_fax)) !!}</div>
        </div>
    </div>
    @endif

    @can('updateBilling', $reception)
    <!-- 請求先モーダル -->
    <x-form-modal modal-id="billing-modal" title="請求先" action="{{ route('billing.update', ['reception' => $reception->no]) }}">
        <input type="hidden" name="updated_at" value="{{ $reception->updated_at?->toDateTimeString() }}">
        <div class="row">
            <div class="col">
                <div class="">
                    <span id="billingname">請求先名</span>
                    <input type="text" id="billing_name" class="form-control valid-add" name="billing_name" title="" value="{{ old('billing_name', $reception->billing_name) }}" maxlength="20">
                    @error('billing_name')
                    <div class="invalid-feedback fw-normal d-block">{{ $message }}</div>
                    @enderror
                </div>
                <br>
                <div class="">
                    <span id="billingtel">請求先TEL</span>
                    <input type="text" id="billing_tel" class="form-control valid-add" name="billing_tel" title="" value="{{ old('billing_tel', $reception->billing_tel) }}" maxlength="15">
                    @error('billing_tel')
                    <div class="invalid-feedback fw-normal d-block">{{ $message }}</div>
                    @enderror
                </div>
                <br>
                <div class="">
                    <span id="billingfax">請求先FAX</span>
                    <input type="text" id="billing_fax" class="form-control valid-add" name="billing_fax" title="" value="{{ old('billing_fax', $reception->billing_fax) }}" maxlength="15">
                    @error('billing_fax')
                    <div class="invalid-feedback fw-normal d-block">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
        @error('billing', 'billing')
        <div class="text-danger">{{ $message }}</div>
        @enderror
        @if(session()->has('billing_update_error'))
        <div class="text-danger">{{ session('billing_update_error') }}</div>
        @endif
    </x-form-modal>
    @endcan
    <!-- 請求先 end -->

    <!-- 系統 -->
    @can('updateGroup', $reception)
    <x-section-divider id="group-section" title="系統" link-to="none">
        <x-slot name="titleIcon">
            <a href="{{ route('set-group.show', $reception) }}" class="btn ms-4 py-0 bi-pencil-fill f-16 text-black-50" title="系統を編集する"></a>
        </x-slot>
    </x-section-divider>
    @else
    <x-section-divider id="group-section" title="系統" link-to="none">
    </x-section-divider>
    @endcan
    @if(!$groups->isEmpty())
    <div class="col-md-6 col-sm-auto ps-4">
        <table class="table table-hover">
            <tbody>
                @foreach($groups as $group)
                <tr>
                    <td>{{ $group->name }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    @endif

    <!-- 機器情報 -->
    @can('updateDevice', $reception)
    <x-section-divider id="device-section" title="機器情報" link-to="none">no) }}">
        <x-slot name="titleIcon">
            <a href="{{ route('set-device.show', $reception->no) }}" class="btn ms-4 py-0 bi-pencil-fill f-16 text-black-50" title="機器情報を編集する"></a>
        </x-slot>
    </x-section-divider>
    @else
    <x-section-divider id="device-section" title="機器情報" link-to="none">
    </x-section-divider>
    @endcan
    @if(!$devices->isEmpty())
    <div class="col-md-6 col-sm-auto px-4">
        @php
        $group_id="-";
        @endphp
        <table class="table table-hover">
            <tbody>
                <tr>
                    <th style="width:auto;">系統</th>
                    <th style="width:auto;">機種</th>
                    <th style="width:auto;">機番</th>
                </tr>
                @foreach($devices as $device)
                <tr>
                    @if($group_id != $device->group_id)
                    <td>{{ isset($device->group_id) ? $device->group_name : '系統未設定' }}</td>
                    @else
                    <td></td>
                    @endif
                    <td class="word-break-all">{{ $device->device_type }}</td>
                    <td class="word-break-all">{{ $device->device_no }}</td>
                </tr>
                @php
                $group_id=$device->group_id;
                @endphp
                @endforeach
            </tbody>
        </table>
    </div>
    @endif

    <!-- 画像 -->
    @can('updateAttachment', $reception)
    <x-section-divider id="photo-section" title="画像" link-to="none" onclick="fncU0208SelectFile()">
        <x-slot name="titleIcon">
            <button type="button" class="btn ms-4 py-0 bi-plus-circle-fill f-16 text-black-50" onclick="fncU0208SelectFile()" title="画像を追加する"></button>
        </x-slot>
    </x-section-divider>
    @else
    <x-section-divider id="photo-section" title="画像" link-to="none">
    </x-section-divider>
    @endcan
    <x-invalid-feedback id="photoValidError"></x-invalid-feedback>
    <div class="row ps-sm-4">
        @php
        $photo_count = 0;
        @endphp
        @foreach ($photos as $photo)
        @if ($photo->public_flag || !userIsPicExternal())
        @php
        ++$photo_count;
        if($photo_count > 11){break;}
        @endphp
        <div class="d-flex justify-content-center justify-content-sm-start col-sm-4 col-md-1 pb-3">
            <div class="card">
                <a href="{{ route('image.show', $photo->file_id) }}" data-lightbox="image">
                    <img class="img-thumbnail object-cover" src="data:image/png;base64, {{ $photo->thumbnail }}">
                </a>
                @can('updateAttachment', $reception)
                <div class="card-footer u0208-card-footer text-center p-0">
                    {{-- 削除ボタン --}}
                    <x-form method="DELETE" id="form-photo-delete{{$photo->id}}" action="{{ route('photo.delete', $photo->id) }}">
                        <button type="button" class="btn p-1 confirm-photo-delete" data-bs-toggle="modal" data-bs-target="#openconfirm" value="{{$photo->id}}" title="画像を削除する">
                            <i class="bi bi-trash-fill btn p-0"></i>
                        </button>
                    </x-form>
                </div>
                @endcan
            </div>
        </div>
        @endif
        @endforeach
    </div>
    @if ($photo_count > 11)
    <div class="row">
        <div class="col text-end">
            <a class="btn p-0" href="{{route('image-list.index', $reception->no)}}">全て見る</a>
        </div>
    </div>
    @endif
    <form id="u0208-frm-photo" action="{{ route('image-list.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="file" id="u0208-file" name="u0208File" accept=".gif,.jpg,.jpeg,.png;capture=camera" class="d-none" />
        <input type="hidden" name="u0208ReceptionNo" value="{{ $reception->no }}" />
        <input type="hidden" name="u0208MaxFileSize" id="u0208-max-file-size-value" value="{{ $maxFileSize }}" />
        <input type="hidden" name="u0208BackUrl" value="{{ route('info.show', $reception->no) }}#photo-section" />
    </form>

    <!-- 添付ファイル -->
    @can('updateAttachment', $reception)
    <x-section-divider id="file-section" title="添付ファイル" link-to="none">
        <x-slot name="titleIcon">
            <a href="{{ route('set-attachment.create', $reception->no) }}" class="btn ms-4 py-0 bi-plus-circle-fill f-16 text-black-50" title="添付ファイルを追加する"></a>
        </x-slot>
    </x-section-divider>
    @else
    <x-section-divider id="file-section" title="添付ファイル" link-to="none">
    </x-section-divider>
    @endcan

    <div class="d-flex flex-md-row flex-column flex-wrap ps-4">
        @foreach ($attachments as $attachment)
        <div class="d-flex col-md-6 pe-4">

            <div class="card-border p-1 m-1 rounded-0 border-1 flex-fill d-flex flex-column">
                <a href="{{ route('file.download', $attachment->file_id) }}" download class="btn p-0 text-start m-0 rounded-0">{{$attachment->title}}</a>
            </div>

            @if (!userIsPicExternal())
            <x-form method="POST" id="form-attachment-update{{$attachment->id}}" action="{{ route('attachment.update', $attachment->id) }}">
                <button type="button" class="btn p-1 confirm-attachment-update" data-bs-toggle="modal" data-bs-target="#openconfirm" value="{{$attachment->id}}" data-public-flag="{{$attachment->public_flag}}">
                    <i class="bi bi-eye{{$attachment->public_flag==true ? '' : '-slash'}} btn p-0" title="添付ファイルを{{ $attachment->public_flag ? '非公開' : '公開' }}する"></i>
                </button>
            </x-form>
            {{-- 削除ボタン --}}
            @can('updateAttachment', $reception)
            <x-form method="DELETE" id="form-attachment-delete{{$attachment->id}}" action="{{ route('attachment.delete', $attachment->id) }}">
                <button type="button" class="btn p-1 confirm-attachment-delete" data-bs-toggle="modal" data-bs-target="#openconfirm" value="{{$attachment->id}}">
                    <i class="bi bi-trash-fill btn p-0" title="添付ファイルを削除する"></i>
                </button>
            </x-form>
            @endcan
            @else
            <div class="align-self-center m-1">&#149;</div>
            <div class="align-self-center m-1"></div>
            @endif
        </div>
        @endforeach
    </div>

    <!-- 備考 start -->
    @can('updateRemark', $reception)
    <x-section-divider id="remark-section" title="お客様向け備考" link-to="none">
        <x-slot name="titleIcon">
            <button type="button" class="btn ms-4 py-0 bi-pencil-fill f-16 text-black-50" data-bs-toggle="modal" data-bs-target="#remark-modal" title="備考を編集する"></button>
        </x-slot>
    </x-section-divider>
    @else
    <x-section-divider id="remark-section" title="お客様向け備考" link-to="none">
    </x-section-divider>
    @endcan

    @if($reception->workReport?->remark)
    <div class="card-border mx-4 p-3 rounded-0 border-1">{!! nl2br(e($reception->workReport?->remark)) !!}</div>
    @endif

    @can('updateRemark', $reception)
    <!-- 備考モーダル -->
    <x-form-modal modal-id="remark-modal" title="お客様向け備考" action="{{ route('remark.update', ['reception' => $reception->no]) }}">
        <input type="hidden" name="updated_at" value="{{ $reception->workReport?->updated_at?->toDateTimeString() }}">
        <textarea class="form-control rounded-0" name="remark" id="remark-input" rows="6">{{ old('remark', $reception->workReport?->remark) }}</textarea>
        @error('remark', 'remark')
        <div class="text-danger">{{ $message }}</div>
        @enderror
        @if(session()->has('remark_update_error'))
        <div class="text-danger">{{ session('remark_update_error') }}</div>
        @endif
    </x-form-modal>
    <!-- 備考 end -->
    @endcan

    <!-- 共通確認ダイアログ -->
    <div class="modal fade" id="openconfirm" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('通知') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="confirm-msg">よろしいですか。</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary confirm-ok" data-bs-dismiss="modal" onclick="alert('OK');">{{ __('ＯＫ') }}</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('キャンセル') }}</button>
                </div>
            </div>
        </div>
    </div>

    <x-slot name="scriptSlot">
        <script src="{{ mix('js/U0200/image-list.js') }}"></script>
        <script>
            // コメント削除確認用
            $('.confirm-comment-delete').click(function() {
                var id = $(this).val();
                $('.confirm-msg').html('コメントを削除します。よろしいですか。');
                $('.confirm-ok').removeAttr("onclick")
                $('.confirm-ok').click(function() {
                    deleteComment(id);
                });
            });
            // コメント削除
            window.deleteComment = function(commentid = "") {
                targetForm = $("#form-comment-delete" + commentid);
                event.preventDefault();
                event.stopPropagation();
                $.ajax({
                    url: targetForm.attr('action'),
                    type: "post",
                    dataType: "html",
                    data: targetForm.serializeArray(),
                    beforeSend: function() {
                        $("#loading").removeClass("d-none");
                    },
                    success: function(data) {
                        $("#loading").addClass("d-none");
                    },
                    error: function(data) {
                        $("#loading").addClass("d-none");
                        if (data.status == 422) {
                            $('#commentValidError' + commentid).text(data.responseJSON.message);
                        }
                        if (data.status == 500) {
                            $('#commentValidError' + commentid).text(data.responseJSON.message);
                        }
                    },
                    complete: function() {
                        location.reload(); // 画面再表示
                    },
                    timeout: ajaxTimeout
                });
            }
            // 画像削除確認用
            $('.confirm-photo-delete').click(function() {
                var id = $(this).val();
                $('.confirm-msg').html('画像を削除します。よろしいですか。');
                $('.confirm-ok').removeAttr("onclick")
                $('.confirm-ok').click(function() {
                    deletePhoto(id);
                });
            });
            // 画像削除
            window.deletePhoto = function(photoid = "") {
                targetForm = $("#form-photo-delete" + photoid);
                event.preventDefault();
                event.stopPropagation();
                $.ajax({
                    url: targetForm.attr('action'),
                    type: "post",
                    dataType: "html",
                    data: targetForm.serializeArray(),
                    beforeSend: function() {
                        $("#loading").removeClass("d-none");
                    },
                    success: function(data) {
                        $("#loading").addClass("d-none");
                    },
                    error: function(data) {
                        $("#loading").addClass("d-none");
                        if (data.status == 422) {
                            $('#photoValidError').text(data.responseJSON.message);
                        }
                        if (data.status == 500) {
                            $('#photoValidError').text(data.responseJSON.message);
                        }
                    },
                    complete: function() {
                        location.reload(); // 画面再表示
                    },
                    timeout: ajaxTimeout
                });
            }
            // 添付ファイル更新確認用
            $('.confirm-attachment-update').click(function() {
                var id = $(this).val();
                if ($(this).attr('data-public-flag') == '1') {
                    $('.confirm-msg').html('添付ファイルを非公開に変更します。よろしいですか。');
                } else {
                    $('.confirm-msg').html('添付ファイルを公開に変更します。よろしいですか。');
                }
                $('.confirm-ok').removeAttr("onclick")
                $('.confirm-ok').click(function() {
                    updateAttachment(id);
                });
            });
            // 添付ファイル更新
            window.updateAttachment = function(attachmentid = "") {
                targetForm = $("#form-attachment-update" + attachmentid);
                event.preventDefault();
                event.stopPropagation();
                $.ajax({
                    url: targetForm.attr('action'),
                    type: "post",
                    dataType: "html",
                    data: targetForm.serializeArray(),
                    beforeSend: function() {
                        $("#loading").removeClass("d-none");
                    },
                    success: function(data) {
                        $("#loading").addClass("d-none");
                    },
                    error: function(data) {
                        $("#loading").addClass("d-none");
                        if (data.status == 422) {
                            $('#attachmentValidError' + attachmentid).text(data.responseJSON.message);
                        }
                        if (data.status == 500) {
                            $('#attachmentValidError' + attachmentid).text(data.responseJSON.message);
                        }
                    },
                    complete: function() {
                        location.reload(); // 画面再表示
                    },
                    timeout: ajaxTimeout
                });
            }
            // 添付ファイル削除確認用
            $('.confirm-attachment-delete').click(function() {
                var id = $(this).val();
                $('.confirm-msg').html('添付ファイルを削除します。よろしいですか。');
                $('.confirm-ok').removeAttr("onclick")
                $('.confirm-ok').click(function() {
                    deleteAttachment(id);
                });
            });
            // 添付ファイル削除
            window.deleteAttachment = function(attachmentid = "") {
                targetForm = $("#form-attachment-delete" + attachmentid);
                event.preventDefault();
                event.stopPropagation();
                $.ajax({
                    url: targetForm.attr('action'),
                    type: "post",
                    dataType: "html",
                    data: targetForm.serializeArray(),
                    beforeSend: function() {
                        $("#loading").removeClass("d-none");
                    },
                    success: function(data) {
                        $("#loading").addClass("d-none");
                    },
                    error: function(data) {
                        $("#loading").addClass("d-none");
                        if (data.status == 422) {
                            $('#attachmentValidError' + attachmentid).text(data.responseJSON.message);
                        }
                        if (data.status == 500) {
                            $('#attachmentValidError' + attachmentid).text(data.responseJSON.message);
                        }
                    },
                    complete: function() {
                        location.reload(); // 画面再表示
                    },
                    timeout: ajaxTimeout
                });
            }
        </script>
    </x-slot>

    </x-U200.layout-info>