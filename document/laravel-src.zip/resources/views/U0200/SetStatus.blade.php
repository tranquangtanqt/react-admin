<x-form-modal modal-id="set-status-modal" title="受付状態変更"
    action="{{ route('set-status.update', [$currentStatus]) }}" method="PATCH"
    btn-label="確定"
    onsubmit="submitSetStatus(event, this, {{ json_encode($currentStatus->status_type) }} == {{ config('constants.status.will_visit') }}, {{ config('constants.status.work_done') }});">

    {{-- 更新日 --}}
    <input type="hidden" name="updated_at" value="{{ $currentStatus->updated_at }}">

    {{-- 変更前の状態区分 --}}
    <input type="hidden" name="prev_status_type" value="{{ $currentStatus->status_type }}">

    {{-- 状態区分 --}}
    <div class="row mt-2">
        <label for="set-status-status-type" class="form-label">状態区分</label>
    </div>
    <div class="row">
        <div class="col-auto">
            <select class="form-select" name="status_type" id="set-status-status-type" required>
                @foreach($statuses as $status)
                    <option value="{{ $status->key }}"
                        {{ $currentStatus->status_type  === $status->key ? 'selected' : '' }}>
                        {{ $status->value }}</option>
                @endforeach
            </select>
        </div>
        <div class="ms-3 col-auto d-flex align-items-center">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="cancel"
                    {{ $isCanceled ? 'checked' : '' }} value="1" id="cancel" disabled="true">
                <label class="form-check-label" for="cancel">
                    受付キャンセル
                </label>
            </div>
        </div>
    </div>

    <div class="row  d-none">
        <x-invalid-feedback id="set_status_status_type_error"></x-invalid-feedback>
    </div>

    @if($containsOnHold)
        <div role="on-hold-detail" @class([ 'd-none'=> $currentStatus->status_type != config('constants.status.on_hold')
            ])>
            {{-- 状態詳細区分 --}}
            <div class="row mt-3">
                <label for="set-status-status-detail-type">状態詳細区分</label>
            </div>
            <div class="row">
                <div class="col-auto">
                    <select class="form-select" name="status_detail_type" id="set-status-status-detail-type">
                        <option value=""></option>
                        @foreach($statusDetails as $status)
                            <option value="{{ $status->key }}"
                                {{ $currentStatus->status_detail_type  === $status->key ? 'selected' : '' }}>
                                {{ $status->value }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="row d-none">
                <x-invalid-feedback id="set_status_status_detail_type_error"></x-invalid-feedback>
            </div>

            {{-- リマインド日付 --}}
            <div class="row mt-3">
                <label for="set-status-remind-date" class="form-label">リマインド日付</label>
            </div>
            <div class="row">
                <div class="col-auto">
                    <x-date-input name="remind_date" id="set-status-remind-date"
                        value="{{ $currentStatus->remind_date?->format('Y/m/d') }}" />
                </div>
            </div>

            <div class="row d-none">
                <x-invalid-feedback id="set_status_remind_date_error"></x-invalid-feedback>
            </div>

            {{-- リマインドメモ --}}
            <div class="row mt-3">
                <label for="set-status-remind-memo" class="form-label">リマインドメモ</label>
            </div>
            <div class="row">
                <div class="col-12">
                    <textarea class="form-control" name="remind_memo" id="remind-memo"
                        rows="4">{!! nl2br(e($currentStatus->remind_memo)) !!}</textarea>
                </div>
            </div>

            <div class="row d-none">
                <x-invalid-feedback id="set_status_remind_memo_error"></x-invalid-feedback>
            </div>
        </div>
    @endif
    <div class="row mt-2 d-none">
        <x-invalid-feedback id="set_status_general_error_message_error"></x-invalid-feedback>
        <x-invalid-feedback id="set_status_updated_at_error"></x-invalid-feedback>
    </div>

    <x-slot name="bottomButton">
        @if($canUpdate)
            <x-submit-button>確定</x-submit-button>
        @endif
        @if($canRestore)
            <x-submit-button class="btn submit-btn mt-3" type="button"
                data-target-route="{{ route('set-status.restore', [$currentStatus]) }}"
                data-updated-at="{{ $currentStatus->updated_at }}"
                onclick="restoreStatus(this)">引き戻し</x-submit-button>
        @endif
    </x-slot>

    {{-- javascript --}}
    @if($containsOnHold || $activateCancelInput)
        <script>
            var activateCancelInput = @json($activateCancelInput);
            var onHold = "{{ config('constants.status.on_hold') }}";
            var workDone = "{{ config('constants.status.work_done') }}";
            $('#set-status-status-type').on('change', function () {
                if (this.value != onHold) {
                    $('div[role=on-hold-detail]').addClass('d-none');
                } else {
                    $('div[role=on-hold-detail]').removeClass('d-none');
                }

                // キャンセルinputが有効の時
                if (activateCancelInput) {
                    if (this.value == workDone) {
                        $('#cancel').attr('disabled', false);
                    } else {
                        $('#cancel').prop('checked', false).attr('disabled', true);
                        $('#cancel').attr('disabled', true);
                    }
                }
            })

        </script>
    @endif

</x-form-modal>
