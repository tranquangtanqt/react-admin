@push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0200/set-device.css') }}" />
@endpush
<x-layouts.app title="機器情報設定">
    <div class="sub-header sub-header-grid py-1">
        <div></div>
        <div class="p-0 text-center">機器情報設定</div>
        <div class="pe-3 text-end">
            <a class="btn p-0 text-white"
                href="{{ route('receptions.show', ['reception' =>$receptionNo]) }}">戻る</a>
        </div>
    </div>
    <p class="alert alert-danger text-center errorAll" style="display: none"></p>
    <p class="m-2">系統/機種/機番</p>
    <p class="m-2">※代表機器を先頭のオプションで選択</p>
    <form method="POST" id="formPostDevice">
        <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
        <input type="text" hidden name="receptionNo" id="receptionNoData" value="{{ $receptionNo }}" />
        <input type="text" hidden id="dropdownData"
            value="@foreach ($setGroups as $setGroup) <option value='{{ $setGroup->id }}'>{{ $setGroup->name }}</option> @endforeach " />
        <div class="col-lg-8 col-md-12 m-2" id="formDevices">
            <input type="text" hidden id="deleteData" name="idDelete" />
            <input type="text" hidden name="updatedAt" value="{{ $updatedAt }}" />
            <input type="text" hidden name="countRow" value="{{ $countRow }}" />

            @php($num=1)
                <div class="device-data" count="0"></div>
                @if($setDevices->isEmpty())
                    <div class="d-flex mb-2 align-items-baseline device-data" count="1">
                        <div class="d-flex flex-column">
                            <div class="d-flex align-items-center deviceCustomer">
                                <input type="radio" checked id="html" class="me-1 radioCheckBoxRepresent"
                                    name="representFlag" value="1">
                                <select class="form-select drop-select form-control form-select me-2 min-w-h"
                                    name="groupIdNew[1]" aria-label=".form-select-sm example" autofocus>
                                    <option value=""></option>
                                    @foreach($setGroups as $setGroup)
                                        <option value="{{ $setGroup->id }}">{{ $setGroup->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class='invalid-feedback d-block'></div>
                        </div>
                        <div class="d-flex me-2 dateDevice deviceCustomer flex-column width-200">
                            <input type="text" class="form-control nameDevice min-w-200" maxlength="20"
                                deviceTypeNew="1" name="deviceTypeNew[1]" value="">
                            <div class='invalid-feedback d-block'></div>
                        </div>
                        <div class="d-flex dateDevice deviceCustomer align-items-baseline">
                            <div class="width-200">
                                <input type="text" idDevice='' class="form-control nameDevice min-w-200" maxlength="20"
                                    deviceNoNew="1" name="deviceNoNew[1]">
                                <div class='invalid-feedback d-block'></div>
                            </div>
                            <i class="bi bi-trash-fill removeDevice btn" isNew="true" title="機器情報を削除する"></i>
                        </div>
                    </div>
                @else
                    @foreach($setDevices as $setDevice)
                        <div class="d-flex mb-2 align-items-baseline device-data" count="{{ $num }}">
                            <div class="d-flex flex-column">
                                <div class="d-flex align-items-center deviceCustomer">
                                    <input type="radio" id="html"
                                        {{ $setDevice->represent_flag==true?'checked':'' }}
                                        class="me-1 radioCheckBoxRepresent" name="representFlag" value="{{ $num }}">
                                    <select class="form-select drop-select form-control form-select me-2 min-w-h"
                                        name="groupId[{{ $num }}]" aria-label=".form-select-sm example" autofocus>
                                        <option value=""></option>
                                        @foreach($setGroups as $setGroup)
                                            @if($setDevice->group_id==$setGroup->id)
                                                <option value="{{ $setGroup->id }}" selected>{{ $setGroup->name }}
                                                </option>
                                            @else
                                                <option value="{{ $setGroup->id }}">{{ $setGroup->name }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </div>
                                <x-invalid-feedback></x-invalid-feedback>
                            </div>
                            <div class="d-flex me-2 dateDevice deviceCustomer flex-column width-200">
                                <input type="text" class="form-control nameDevice min-w-200" maxlength="20"
                                    deviceType="{{ $num }}" name="deviceType[{{ $num }}]"
                                    value="{{ $setDevice->device_type }}">
                                <x-invalid-feedback></x-invalid-feedback>
                            </div>
                            <div class="d-flex dateDevice deviceCustomer align-items-baseline">
                                <div class="width-200">
                                    <input type="text" idDevice={{ $setDevice->id }} maxlength="20"
                                        class="form-control nameDevice min-w-200" deviceNo="{{ $num }}"
                                        name="deviceNo[{{ $num }}]" value="{{ $setDevice->device_no }}">
                                    <x-invalid-feedback></x-invalid-feedback>
                                </div>
                                <i class="bi bi-trash-fill removeDevice btn" isNew="false"
                                    idDevice={{ $setDevice->id }} title="機器情報を削除する"></i>
                            </div>
                            <input type="text" id="updateID" hidden name="idUpdate[{{ $num }}]"
                                value="{{ $setDevice->id }}" />
                        </div>
                        @php($num++)
                        @endforeach
                    @endif
        </div>
        <div class="btn ms-3" id="addDevice">
            <i class="bi-plus-circle-fill f-16 text-black-50" title="行を追加する"></i>
        </div>
        <div class="text-center" id="u0207-submit">
            <x-submit-button type="button">確定</x-submit-button>
        </div>
    </form>
    <div class="modal fade popupSetDevice" id="modalpopup" aria-hidden="true" data-bs-backdrop="static"
        data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title d-flex align-items-center">
                        <span class="me-2">通知</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form class="w-100" method="POST" id="frm">
                    <div class="modal-body">
                        既にこの機器情報に対する作業内容、運転記録がある場合、削除されます。よろしいですか。
                    </div>
                    <div class="modal-footer">
                        {{-- <div class="d-flex flex-nowrap justify-content-around pb-15"> --}}
                        <button type="button" class="btn btn-primary" id="okClick">ＯＫ</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                            id="closeModal">キャンセル</button>
                        {{-- </div> --}}
                    </div>
                </form>
            </div>
        </div>
    </div>

    <button id="btnShowModal" type="button" data-bs-toggle="modal" hidden data-bs-target="#modalpopup"></button>
    @push('scripts')
        <script src="{{ mix('js/U0200/set-device.js') }}"></script>
    @endpush
</x-layouts.app>
