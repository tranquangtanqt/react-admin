@push('styles')
    <link rel="stylesheet" href="{{ mix('css/U0200/set-group.css') }}" />
@endpush
<x-layouts.app title="系統設定">
    <div class="sub-header sub-header-grid py-1">
        <div></div>
        <div class="p-0 text-center">系統設定</div>
        <div class="pe-3 text-end">
            <a class="btn p-0 text-white"
                href="{{ route('receptions.show', ['reception' =>$receptionNo]) }}">戻る</a>
        </div>
    </div>

    <p class="m-2">系統/納入日</p>
    <p class="alert alert-danger text-center errorAll" style="display: none"></p>

    <form id="formPostGroup">
        @csrf
        <input type="text" hidden name="receptionNo" id="receptionNoData" value="{{ $receptionNo }}" />
        <div class="col-lg-6 col-md-12 m-2" id="formGroups">
            <input type="text" hidden id="deleteData" name="idDelete" />
            <input type="text" hidden name="countRow" value="{{ $countRow }}" />
            <input type="text" hidden name="updatedAt" value="{{ $updatedAt }}" />
            <input type="text" hidden id="deliveryDate"
                value="{{ $deliveryDate!=null?date('Y/m/d',strtotime($deliveryDate)):'' }}" />
            @php($num=1)
                <div class="group-data" count="0"></div>
                @if($setGroups->isEmpty())
                    <div class="d-flex mb-2 align-items-baseline group-data" count="1">
                        <div class="d-flex flex-column w-100 me-2">
                            <input type="text" class="form-control nameGroup" maxlength="20" style="min-width:200px"
                                nameType="1" name="nameNew[1]" autofocus>
                            <div class='invalid-feedback d-block'></div>
                        </div>
                        <div class="d-flex align-items-baseline dateGroup">
                            <div class="d-flex flex-column">
                                <input type="text" id="picker" role="datepicker" placeholder="YYYY/MM/DD"
                                    deliveryDateNew="1" name="deliveryDateNew[1]"
                                    value="{{ $deliveryDate!=null ? date('Y/m/d',strtotime($deliveryDate)) : '' }}"
                                    class="picker form-control datepicker me-2">
                                <div class='invalid-feedback d-block'></div>
                            </div>
                            <i class="bi bi-trash-fill removeGroup btn" isNew="true" title="系統を削除する"></i>
                        </div>
                    </div>
                @else
                    @foreach($setGroups as $setGroup)
                        <div class="d-flex mb-2 align-items-baseline group-data" count="{{ $num }}">
                            <div class="d-flex flex-column w-100 me-2">
                                <input type="text" idGroup={{ $setGroup->id }} class="form-control nameGroup"
                                    maxlength="20" style="min-width:200px" name="name[{{ $num }}]" nameType="{{ $num }}"
                                    value="{{ $setGroup->name }}" autofocus>
                                <x-invalid-feedback></x-invalid-feedback>
                            </div>
                            <div class="d-flex align-items-baseline dateGroup">
                                <div class="d-flex flex-column">
                                    <x-date-input name="deliveryDate[{{ $num }}]" class="me-2 picker" autocomplete="off"
                                        deliveryDate="{{ $num }}"
                                        value="{{ $setGroup->delivery_date!=null ? date('Y/m/d',strtotime($setGroup->delivery_date)) : '' }}" />
                                    <x-invalid-feedback></x-invalid-feedback>
                                </div>
                                <i class="bi bi-trash-fill removeGroup btn" isNew="false" title="系統を削除する"></i>
                            </div>
                            <input type="text" id="updateID" hidden name="idUpdate[{{ $num }}]"
                                value="{{ $setGroup->id }}" />
                        </div>
                        @php($num++)
                        @endforeach
                    @endif
        </div>
        <div class="btn" id="addGroup">
            <i class="bi-plus-circle-fill f-16 text-black-50" title="行を追加する"></i>
        </div>
        <div class="text-center" id="u0206-submit">
            <x-submit-button type="button">確定</x-submit-button>
        </div>
    </form>

    <div class="modal fade popupSetGroup" id="modalpopup" aria-hidden="true" data-bs-backdrop="static"
        data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title d-flex align-items-center">
                        <span class="me-2">通知</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="frm">
                    <div class="modal-body">
                        既にこの系統を設定済みの機器情報がある場合、系統が未設定となります。よろしいですか。
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="okClick">ＯＫ</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                            id="closeModal">キャンセル</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <button id="btnShowModal" type="button" data-bs-toggle="modal" hidden data-bs-target="#modalpopup"></button>
    @push('scripts')
        <script src="{{ mix('js/U0200/set-group.js') }}"></script>
        <script>
            $("input[role=datepicker]").datepicker();

        </script>
    @endpush
</x-layouts.app>
