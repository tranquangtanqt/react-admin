{{-- @include('U0200.SetComment')を追加しopenModalComment(receptionNo,id)を呼び出することができます --}}
<div class="modal fade U0204" id="u0204modalpopup" aria-hidden="true" >
    <div class="modal-dialog modal-dialog-centered" >
        <div class="modal-content" >
            <div class="modal-header border-bottom-0" >
                <h5 class="modal-title">コメント設定</h5>
                <button type="button" class="btn" data-bs-dismiss="modal" id="closeModalComment" aria-label="back">戻る</button>
            </div>
            <form id="frm">
                @csrf
                <input hidden name="id" id="txtId">
                <input hidden name="receptionNo" id="txtReceptionNo">
                <div class="modal-body">
                    <textarea name="comment"  class="w-100 form-control" style="resize: none;height: 130px;" maxlength="512" id="txtCommnent"></textarea>
                    <x-invalid-feedback id="commentValidError"></x-invalid-feedback>
                </div>
                <div class="modal-footer border-top-0 justify-content-center text-white d-flex" id="u0204-submit">
                    <x-submit-button type="button">確定</x-submit-button>
                </div>
            </form>
        </div>
    </div>
</div>
<button id="btnShowModal-U0204" type="button" data-bs-toggle="modal" hidden data-bs-target="#u0204modalpopup"></button>
@push('scripts')
    <script src="{{ mix('js/U0200/set-comment.js') }}"></script> 
@endpush
