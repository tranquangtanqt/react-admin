<?php

use App\Http\Controllers\ApiTestController;
use App\Http\Controllers\U0900\CoopAccountYearMonthController;
use App\Http\Controllers\U0900\CoopObjectController;
use App\Http\Controllers\U0900\CoopReceptionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// 受付情報連携API
Route::post('coopreception', [CoopReceptionController::class, 'index']);

// 物件情報連携API
Route::post('coopobject', [CoopObjectController::class, 'index']);

// 会計情報連携API
Route::post('coopaccountyearmonth', [CoopAccountYearMonthController::class, 'index']);
