<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\U0200\InfoController;
use App\Http\Controllers\U0200\SetCommentController;
use App\Http\Controllers\U0200\SetBillingController;
use App\Http\Controllers\U0200\MainInfoController;
use App\Http\Controllers\X0000\LoginController;
use App\Http\Controllers\U0100\OnHoldController;
use App\Http\Controllers\U0100\DashboardController;
use App\Http\Controllers\U0100\ErrorNotificationController;
use App\Http\Controllers\U0300\SetScheduleController;
use App\Http\Controllers\U0100\ScheduleWeeklyController;
use App\Http\Controllers\U0100\SearchReceptionController;
use App\Http\Controllers\U0200\SetAttachmentController;
use App\Http\Controllers\U0200\ReceptionFinanceController;
use App\Http\Controllers\U0300\SetScheduleCheckController;
use App\Http\Controllers\U0200\ReceptionScheduleController;
use App\Http\Controllers\U0300\SetGasInfoController;
use App\Http\Controllers\U0800\MainteUserController;
use App\Http\Controllers\U0800\SetMainteUserController;
use App\Http\Controllers\U0800\MainteAuthController;
use App\Http\Controllers\U0800\SetMainteAuthController;
use App\Http\Controllers\U0200\ImageListController;
use App\Http\Controllers\U0200\SetRemarkController;
use App\Http\Controllers\X0600\SetPasswordController;
use App\Http\Controllers\X0000\ForgotPasswordController;
use App\Http\Controllers\U0600\OutputDataController;
use App\Http\Controllers\U0200\SetGroupController;
use App\Http\Controllers\U0700\CoopManHourStopManualController;
use App\Http\Controllers\U0300\ResultInfoController;
use App\Http\Controllers\U0400\CheckCostController;
use App\Http\Controllers\U0800\MainteCodeClassController;
use App\Http\Controllers\U0800\SetMainteCodeClassController;
use App\Http\Controllers\U0200\SetDeviceController;
use App\Http\Controllers\U0200\SetProjectManagerController;
use App\Http\Controllers\U0200\SetStatusController;
use App\Http\Controllers\U0300\SetScheduleCheckConditionController;
use App\Http\Controllers\U0500\CertificateDeliveryController;
use App\Http\Controllers\U0400\SetCostController;
use App\Http\Controllers\U0300\SetWorkTypeController;
use App\Http\Controllers\U0300\SetPaymentTypeController;
use App\Http\Controllers\U0500\CheckCertificateCustomerController;
use App\Http\Controllers\U0500\CertificateCustomerController;
use App\Http\Controllers\X0600\SetUserInfoController;
use App\Http\Controllers\X0000\ImageController;
use App\Http\Controllers\U0500\CertificateInternalController;
use App\Http\Controllers\U0100\ScheduleWeeklySettingController;
use App\Http\Controllers\U0100\ScheduleSettingController;
use App\Http\Controllers\U0100\ScheduleListController;
use App\Http\Controllers\U0100\ScheduleListSettingController;
use App\Http\Controllers\U0300\SetResultController;
use App\Http\Controllers\U0400\SetQuotationController;
use App\Http\Controllers\U0300\OperationRecordController;
use App\Http\Controllers\U0300\SetOperationRecordController;
use App\Http\Controllers\U0300\SetSignController;
use App\Http\Controllers\U0300\SetSignFileController;

use App\Http\Controllers\X0000\GetLoginInfoController;
use App\Http\Controllers\U0300\SetManHourController;
use App\Http\Controllers\X0000\FileController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware('guest')->group(function () {
    /* ------------------ 認証（ログイン） ----------------- */
    Route::get('/login', [LoginController::class, 'show'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])->name('login');
    Route::get('/password/forgot', [ForgotPasswordController::class, 'index'])->name('password.forgot');
    //作業完了証明書（社内確認）
    Route::get('pdf', [CertificateInternalController::class, 'index']);

    // ログイン情報確認画面
    Route::get('/password-forgot', [GetLoginInfoController::class, 'index'])->name('password-forgot.index');
    Route::post('/password-forgot', [GetLoginInfoController::class, 'store'])->name('password-forgot.store');

    // パスワード再設定画面
    Route::get('/password-reset/{key}', [ForgotPasswordController::class, 'show'])->name('password-reset.show');
    Route::post('/password-reset', [ForgotPasswordController::class, 'update'])->name('password-reset.update');
});

Route::middleware('auth')->group(function () {

    // ログアウト
    Route::post('/logout', [LoginController::class, 'destroy'])
        ->name('logout');
    /* ------------------ パスワード設定 ----------------- */
    // パスワード設定(画面)
    Route::get('/set-password/edit', [SetPasswordController::class, 'edit'])
        ->name('set-password.edit');

    // パスワード設定(処理)
    Route::post('/set-password', [SetPasswordController::class, 'update'])
        ->name('set-password.update');

    /* ------------------ ダッシュボード組 ----------------- */
    // ダッシュボード
    Route::get('/', [DashboardController::class, 'index'])
        ->name('dashboard');

    // エラー通知画面
    Route::get('/error-notification/{processId}', [ErrorNotificationController::class, 'index'])
        ->name('error-notification.index');

    // エラー通知画面
    Route::post('/error-notification/update', [ErrorNotificationController::class, 'update'])
        ->name('error-notification.update');

    // 保留受付画面
    Route::get('/on-hold', [OnHoldController::class, 'index'])
        ->name('on-hold.index');

    // スケジュール週画面
    Route::match(['get', 'post'], '/schedule-weekly', [ScheduleWeeklyController::class, 'index'])
        ->name('schedule-weekly.index');

    // スケジュール週画面のピン留め
    Route::post('/schedule-weekly/toggle-pin/{reception}', [ScheduleWeeklyController::class, 'togglePin'])
        ->name('schedule-weekly.togglePin');

    // スケジュール表示設定画面（週間）
    Route::get('/schedule-weekly-setting', [ScheduleWeeklySettingController::class, 'show'])
        ->name('schedule-weekly-setting.show');

    // 通常予定設定画面 (登録)
    Route::get('/schedule-setting/create', [ScheduleSettingController::class, 'create'])
        ->name('schedule-setting.create');

    // 通常予定設定画面 (表示モード)
    Route::get('/schedule-setting/{schedule}', [ScheduleSettingController::class, 'show'])
        ->name('schedule-setting.show');

    // 通常予定設定処理 (登録)
    Route::post('/schedule-setting', [ScheduleSettingController::class, 'store'])
        ->name('schedule-setting.store');

    // 通常予定設定画面 (更新)
    Route::get('/schedule-setting/{schedule}/edit', [ScheduleSettingController::class, 'edit'])
        ->name('schedule-setting.edit');

    // 通常予定設定処理 (更新)
    Route::patch('/schedule-setting/{schedule}', [ScheduleSettingController::class, 'update'])
        ->name('schedule-setting.update');

    // 通常予定設定削除
    Route::delete('/schedule-setting/{schedule}', [ScheduleSettingController::class, 'delete'])
        ->name('schedule-setting.delete');

    // スケジュール画面（リスト）
    Route::match(['get', 'post'], '/schedule-list', [ScheduleListController::class, 'index'])
        ->name('schedule-list.index');

    // スケジュール表示設定画面（リスト）
    Route::match(['get', 'post'], '/schedule-list-setting', [ScheduleListSettingController::class, 'show'])
        ->name('schedule-list-setting.show');

    // スケジュール表示設定画面（リスト）のバリデーション
    Route::match(['get', 'post'], '/schedule-list-setting/validation', [ScheduleListSettingController::class, 'validateForm'])
        ->name('schedule-list-setting.validation');

    // 受付検索画面
    Route::match(['get', 'post'], '/search-reception', [SearchReceptionController::class, 'index'])
        ->name('search-reception.index');

    /* ------------------ 受付情報組 ----------------- */
    // 受付情報(基本情報タブ)
    Route::match(['get', 'post'], '/info/{reception}', [InfoController::class, 'show'])
        ->name('info.show');

    // コメント削除
    Route::delete('/comment/{comment}', [InfoController::class, 'destroyComment'])->name('comment.delete');

    // 画像削除
    Route::delete('/photo/{photo}', [InfoController::class, 'destroyPhoto'])->name('photo.delete');

    // 添付ファイル削除
    Route::delete('/attachment/{attachment}', [InfoController::class, 'destroyAttachment'])->name('attachment.delete');

    // 添付ファイル更新（公開非公開）
    Route::post('/attachment/{attachment}', [InfoController::class, 'updateAttachment'])->name('attachment.update');

    // 受付情報(訪問予定・実績タブ)
    Route::match(['get', 'post'], '/receptions/{reception}/schedule-result', [ReceptionScheduleController::class, 'show'])
        ->name('receptions.schedule-result.show');

    // 受付情報(金額タブ)
    Route::match(['get', 'post'], '/receptions/{reception}/finance', [ReceptionFinanceController::class, 'show'])
        ->name('receptions.finance.show');

    // 受付・計上担当者設定画面取得
    Route::get('/set-project-manager/{reception}', [SetProjectManagerController::class, 'edit'])
        ->name('set-project-manager.edit');

    // 受付・計上担当者設定画面取得
    Route::post('/set-project-manager/{reception}', [SetProjectManagerController::class, 'update'])
        ->name('set-project-manager.update');

    // 請求先編集
    Route::post('/receptions/{reception}/billing/', [SetBillingController::class, 'update'])
        ->name('billing.update');

    // 受付状態設定画面取得（表示）
    Route::get('/set-status/{status}', [SetStatusController::class, 'edit'])
        ->name('set-status.edit');

    // 受付状態設定処理
    Route::patch('/set-status/{status}', [SetStatusController::class, 'update'])
        ->name('set-status.update');

    // 受付状態引き戻し処理
    Route::patch('/set-status/{status}/restore', [SetStatusController::class, 'restore'])
        ->name('set-status.restore');

    // 備考編集
    Route::post('/receptions/{reception}/remark/', [SetRemarkController::class, 'updateRemark'])
        ->name('remark.update');

    // 作業完了証明書（社内確認）
    Route::get('/certificate-internal/{receptionNo}', [CertificateInternalController::class, 'index'])
        ->name('certificate-internal.index');
    /* ------------------ 画像関連 ----------------- */
    // 全ての画像一覧のデータを表示します。
    Route::get('/image-list/{reception}', [ImageListController::class, 'index'])
        ->name('image-list.index');

    // 新規で画像を登録します。
    Route::post('/image-list/store', [ImageListController::class, 'store'])
        ->name('image-list.store');

    // 該当する画像を削除します。
    Route::delete('/image-list/delete/{reception}/{id}', [ImageListController::class, 'delete'])
        ->name('image-list.delete');
    /* ------------------ 作業区分設定 ----------------- */
    /* ------------------データ出力----------------- */
    //データ出力情報を表示します。
    Route::post('/output-data/export', [OutputDataController::class, 'export'])
        ->name('output-data.export');
    Route::get('/output-data', [OutputDataController::class, 'show'])
        ->name('output-data.show');
    /* ------------------系統設定----------------- */
    // 該当する系統情報を表示します。
    Route::get('/set-group/{receptionNo}', [SetGroupController::class, 'show'])
        ->name('set-group.show');
    // 該当する系統情報を変更します。
    Route::post('/set-group/store', [SetGroupController::class, 'store'])
        ->name('set-group.store');


    /* ------------------ 権限マスタ ----------------- */
    // 全ての権限のデータを表示します。
    Route::get('/mainte-auth', [MainteAuthController::class, 'index'])
        ->name('mainte-auth.index');

    // 該当する権限情報を削除します。
    Route::delete('/mainte-auth/delete/{id}/{page?}', [MainteAuthController::class, 'delete'])
        ->name('mainte-auth.delete');

    // 該当する権限情報を表示します。
    Route::get('/set-mainte-auth/show/{id}', [SetMainteAuthController::class, 'show'])
        ->name('set-mainte-auth.show');

    // 該当する権限情報を変更します
    Route::patch('/set-mainte-auth/update', [SetMainteAuthController::class, 'update'])
        ->name('set-mainte-auth.update');
    /* ------------------ 工数連携停止----------------- */
    // 工数連携停止表示します。
    Route::get('/coop-man-hour-stop-manual', [CoopManHourStopManualController::class, 'index'])
        ->name('coop-man-hour-stop-manual.index');
    //
    Route::post('/coop-man-hour-stop-manual/update', [CoopManHourStopManualController::class, 'update'])
        ->name('coop-man-hour-stop-manual.update');
    //
    Route::post('/coop-man-hour-stop-manual/store', [CoopManHourStopManualController::class, 'store'])
        ->name('coop-man-hour-stop-manual.store');

    /* ------------------ マスタメンテナンス ----------------- */
    // ユーザー情報マスタメンテナンス
    Route::get('/mainte-user', [MainteUserController::class, 'index'])
        ->name('mainte-user.index');

    // 該当するユーザー情報を削除します。
    Route::delete('/mainte-user/delete/{id}/{page?}', [MainteUserController::class, 'delete'])
        ->name('mainte-user.delete');

    // 該当するユーザー情報を表示します
    Route::get('/set-mainte-user/show/{id?}', [SetMainteUserController::class, 'show'])
        ->name('set-mainte-user.show');

    // 新規でユーザー情報を登録します。
    Route::post('/set-mainte-user/store', [SetMainteUserController::class, 'store'])
        ->name('set-mainte-user.store');

    // 該当するユーザー情報を変更します
    Route::patch('/set-mainte-user/update/{id}', [SetMainteUserController::class, 'update'])
        ->name('set-mainte-user.update');
    /* ------------------機器情報設定----------------- */
    // 該当する機器情報を表示します。
    Route::get('/set-device/{receptionNo}', [SetDeviceController::class, 'show'])
        ->name('set-device.show');
    //該当する機器情報情報を変更します。
    Route::post('/set-device/store', [SetDeviceController::class, 'store'])
        ->name('set-device.store');

    /* ------------------コメント設定 ----------------- */
    // コメント設定テーブルに変更・新規追加する
    Route::post('/set-comment/store', [SetCommentController::class, 'store'])->name('set-comment.store');
    // 該当するコメント設定情報を表示します。
    Route::get('/set-comment/{id}', [SetCommentController::class, 'show'])->name('set-comment.show');

    /* ------------------ 作業区分設定 ----------------- */
    // 受付情報関連
    Route::match(['get', 'post'], '/receptions/{reception}', [InfoController::class, 'show'])
        ->name('receptions.show');

    /* ------------------ 添付設定 ----------------- */
    // 該当する添付情報を表示します。
    Route::get('/set-attachment/create/{reception}', [SetAttachmentController::class, 'create'])
        ->name('set-attachment.create');

    // 新規で添付情報を登録します。
    Route::post('/set-attachment/store', [SetAttachmentController::class, 'store'])
        ->name('set-attachment.store');

    /* ------------------作業区分設定 ----------------- */
    //該当する作業区分設定情報を表示します。
    Route::patch('/set-worktype/update', [SetWorkTypeController::class, 'update'])
        ->name('set-workType.update');
    //該当する作業区分設定情報を変更します。
    Route::get('/set-worktype/{receptionNo}', [SetWorkTypeController::class, 'show'])
        ->name('set-worktype.show');
    /* ------------------有償無償設定 ----------------- */
    //該当する有償無償設定情報を表示します。
    Route::patch('/set-paymenttype/update', [SetPaymentTypeController::class, 'update'])
        ->name('set-paymenttype.update');
    //該当する有償無償設定情報を変更します。
    Route::get('/set-paymenttype/{receptionNo}', [SetPaymentTypeController::class, 'show'])
        ->name('set-paymenttype.show');
    /* ------------------受付基本情報 ----------------- */
    // 該当する受付基本情報情報を表示します。
    Route::get('/main-info/{no}', [MainInfoController::class, 'show'])->name('main-info.show');

    /* ------------------ 作業実績情報 ----------------- */
    // 該当する作業実績情報情報を表示します。
    Route::get('/result-info/{scheduleId}/{visited?}', [ResultInfoController::class, 'index'])
        ->name('result-info.index');
    // 該当する作業実績情報情報を削除します。
    Route::delete('/result-info/work-result/delete/{receptionNo}/{scheduleId}', [ResultInfoController::class, 'deleteWorkResult'])
        ->name('result-info.work-result.delete');
    // 該当する工数情報を削除します。
    Route::delete('/result-info/manhour/delete/{manhourId}', [ResultInfoController::class, 'deleteManhour'])
        ->name('result-info.manhour.delete');

    // 該当する署名を削除します。
    Route::delete('/result-info/signature/delete/{signatureId}/{fileId}', [ResultInfoController::class, 'deleteSignature'])
        ->name('result-info.signature.delete');
    /* ------------------ ダッシュボード ----------------- */
    // 全ての原価チェックのデータを表示します。
    Route::get('/check-cost/{receptionNo}', [CheckCostController::class, 'index'])
        ->name('check-cost.index');
    // 該当する原価チェック情報を変更します。
    Route::post('/check-cost/update', [CheckCostController::class, 'update'])
        ->name('check-cost.update');
    /* ------------------ コード区分マスタ ----------------- */
    // 全てのコード区分のデータを表示します。
    Route::get('/mainte-code-class', [MainteCodeClassController::class, 'index'])
        ->name('mainte-code-class.index');

    // 該当するコード区分情報を表示します。
    Route::get('/mainte-code-class/show-identifier/{code}', [MainteCodeClassController::class, 'showIdentifier'])
        ->name('mainte-code-class.show-identifier');

    // 該当するコード区分情報を削除します。
    Route::delete('/mainte-code-class/delete/{id}/{page?}', [MainteCodeClassController::class, 'delete'])
        ->name('mainte-code-class.delete');

    // 該当するコード区分情報を表示します。
    Route::get('/set-mainte-code-class/show-code-class/{code}/{id?}', [SetMainteCodeClassController::class, 'showCodeClass'])
        ->name('set-mainte-code-class.show-code-class');

    // 新規でコード区分情報を登録します。
    Route::post('/set-mainte-code-class/store/{code}', [SetMainteCodeClassController::class, 'store'])
        ->name('set-mainte-code-class.store');

    // 該当するコード区分情報を変更します。
    Route::post('/set-mainte-code-class/update/{id}', [SetMainteCodeClassController::class, 'update'])
        ->name('set-mainte-code-class.update');
    // 訪問予定表示モーダル
    Route::get('/set-schedule/{schedule}', [SetScheduleController::class, 'show'])
        ->name('set-schedule.show');

    // 訪問予定追加モーダル
    Route::get('/set-schedule/{reception}/create', [SetScheduleController::class, 'create'])
        ->name('set-schedule.create');

    // 新規訪問予定設定
    Route::post('/set-schedule/{reception}', [SetScheduleController::class, 'store'])
        ->name('set-schedule.store');

    // 訪問予定編集モーダル
    Route::get('/set-schedule/{schedule}/edit', [SetScheduleController::class, 'edit'])
        ->name('set-schedule.edit');

    // 訪問予定編集処理
    Route::patch('/set-schedule/{schedule}', [SetScheduleController::class, 'update'])
        ->name('set-schedule.update');

    // 訪問予定削除処理
    Route::delete('/set-schedule/{schedule}', [SetScheduleController::class, 'delete'])
        ->name('set-schedule.delete');

    /* ------------------充塡回収情報設定----------------- */
    // 充塡回収情報設定変更します。
    Route::post('/set-gasinfo/store', [SetGasInfoController::class, 'store'])->name('set-gasinfo.store');

    // 充塡回収情報設定表示します。
    Route::post('/set-gasinfo', [SetGasInfoController::class, 'show'])->name('set-gasinfo.show');

    // 訪問予定確認条件設定モーダル
    Route::get('/set-schedule-check-condition', [SetScheduleCheckConditionController::class, 'index'])
        ->name('set-schedule-check-condition.index');

    // 訪問予定確認設定モーダル
    Route::match(['get', 'post'], '/set-schedule-check', [SetScheduleCheckController::class, 'index'])
        ->name('set-schedule-check.index');


    /* ------------------ 作業完了証明書（納品書） ----------------- */
    Route::get('/certificate-delivery/{receptionNo}', [CertificateDeliveryController::class, 'index'])
        ->name('certificate-delivery.index');
    /* ------------------ 原価設定 ----------------- */
    // 該当する原価設定情報を表示します。
    Route::get('/set-cost/{receptionNo}', [SetCostController::class, 'index'])
        ->name('set-cost.index');
    // 該当する原価設定情報を変更します。
    Route::post('/set-cost/change', [SetCostController::class, 'change'])
        ->name('set-cost.change');

    // 訪問予作業実績設定
    Route::get('/set-result/{scheduleId}', [SetResultController::class, 'show'])
        ->name('set-result.show');

    // 訪問予作業実績設定
    Route::post('/set-result/store', [SetResultController::class, 'store'])
        ->name('set-result.store');

    // 訪問予作業実績設定
    Route::patch('/set-result/update', [SetResultController::class, 'update'])
        ->name('set-result.update');
    // 訪問予署名ファイル設定画面
    Route::get('/set-sign-file/{scheduleId}', [SetSignFileController::class, 'show'])
        ->name('set-sign-file.show');

    // 訪問予署名ファイル
    Route::post('/set-sign-file', [SetSignFileController::class, 'store'])
        ->name('set-sign-file.store');
    // 訪問予工数設定画面
    Route::get('/set-man-hour/{scheduleId}', [SetManHourController::class, 'show'])
        ->name('set-man-hour.show');

    // 訪問予工数設定
    Route::post('/set-man-hour/sotre', [SetManHourController::class, 'store'])
        ->name('set-man-hour.store');

    // 訪問予工数設定
    Route::patch('/set-man-hour/update', [SetManHourController::class, 'update'])
        ->name('set-man-hour.update');

    // 訪問予運転記録情報画面
    Route::get('/operation-record/{receptionNo}', [OperationRecordController::class, 'show'])
        ->name('operation-record.show');

    // 訪問予運転記録設定
    Route::patch('/set-operation-record/update', [SetOperationRecordController::class, 'update'])
        ->name('set-operation-record.update');

    /* ------------------ 印刷関連 ----------------- */
    // 作業完了報告書（お客様控）確認
    Route::match(['get', 'post'], '/check-certificate-customer/{schedule}', [CheckCertificateCustomerController::class, 'show'])
        ->name('check-certificate-customer.show');

    /* ------------------ 印刷関連 ----------------- */
    // 作業完了報告書（お客様控）印刷
    Route::match(['get', 'post'], '/certificate-customer/{schedule}', [CertificateCustomerController::class, 'show'])
        ->name('certificate-customer.show');

    //ユーザー情報設定画面
    Route::get('/set-user-info/edit', [SetUserInfoController::class, 'edit'])
        ->name('set-user-info.edit');

    Route::patch('/set-user-info/update', [SetUserInfoController::class, 'update'])
        ->name('set-user-info.update');

    Route::delete('/set-user-info/delete', [SetUserInfoController::class, 'delete'])
        ->name('set-user-info.delete');
    /* ------------------ 画像関連 ----------------- */
    Route::get('/image/{file}', [ImageController::class, 'show'])
        ->name('image.show');

    /* ------------------ ファイルダウンロード ----------------- */
    Route::get('/file/download/{file}', [FileController::class, 'download'])
        ->name('file.download');

    // 訪問予定見積設定画面
    Route::get('/set-quotations/{receptionNo}', [SetQuotationController::class, 'show'])
        ->name('quotations.show');

    // 訪問予定見積設定
    Route::patch('/set-quotations/update', [SetQuotationController::class, 'update'])
        ->name('quotations.update');
    // 電子署名設定画面
    Route::get('/set-sign/{scheduleId}', [SetSignController::class, 'show'])
        ->name('set-sign.show');

    // 電子署名を登録し
    Route::post('/set-sign/store', [SetSignController::class, 'store'])
        ->name('set-sign.store');
});
