
<?php

/*
    |--------------------------------------------------------------------------
    | 定数の設定
    |--------------------------------------------------------------------------
    |
    | 定数の設定はこちらに記載。
    |
    */

return [

    // 識別コード
    'codes' => [
        'logs' => 'X001', // X0001 → ログ処理区分
        'coop' => 'X0002', // X0002 → 連携区分
        'batch' => 'X0003', // X0003　→ バッチ処理状態
        'password' => 'X0004', // X0004　→ パスワードポリシー
        'api_key' => 'X0005', // X0005　→ APIキー
        'slot' => 'U0001', // U0001　→ 時間帯区分
        'recept_display' => 'U0002', // U0002　→ 受付検索表示区分
        'status' => 'U0003', // U0003　→ 状態区分
        'status_detail' => 'U0004', // U0004　→ 状態詳細区分
        'payment' => 'U0005', // U0005　→ 有償無償区分
        'ky' => 'U0006', // U0006　→ ＫＹポイント区分
        'work' => 'U0007', // U0007　→ 作業区分
        'auth' => 'U0008', // U0008　→ 権限区分
        'cost' => 'U0009', // U0009　→ 原価種類区分
        'fill' => 'U0010', // U0010　→ 充塡区分
        'collect' => 'U0011', // U0011　→ 回収区分
        'fill_type' => 'U0012', // U0012　→ 充塡種類区分
        'collect_type' => 'U0013', // U0013　→ 回収種類区分
        'cost_reg' => 'U0014', // U0014　→ 原価登録区分 => cost_registration (cost_reg)
        'material_cost' => 'U0015', // U0015　→ 材料原価名称雛形 => material_cost_name (material_cost)
        'construct_cost' => 'U0016', // U0016　→ 工事原価名称雛形 => construction_cost_name (construct_name)
        'quot_unit' => 'U0017', // U0017　→ 見積単位雛形 => quotation_unit (quot_unit)
        'quot_work_name' => 'U0018', // U0018　→ 見積作業名・品名雛形 => quotation_work_name (quot_work_name)
        'work_content' => 'U0019', // U0019　→ 作業内容雛形
        'url' => 'U0020', // U0020　→ URL
        'default_setting' => 'U0021', // U0021　→ デフォルト設定
        'pe_schedule' => 'G0001', // G0001　→ PE予定区分
        'l2_work' => 'G0002', // G0002　→ L2建材作業区分
        'l2_work_class' => 'G0003', // G0003　→ L2建材作業分類区分
        'l2_work_detail' => 'G0004', // G0004　→ L2建材作業詳細区分
    ],

    // X0001 → ログ処理区分
    'logs' => [
        'login' => '0',
        'logout' => '1',
        'page_access' => '2',
        'data_insert' => '3',
        'data_update' => '4',
        'data_delete' => '5',
        'data_replace' => '6',
        'download' => '7',
        'internal_process' => '8',
        'api_access' => '9',
        'coop_process' => '10',
    ],

    // X0002 → 連携区分
    'coop' => [
        'yet' => '0', // 未連携
        'active' => '1', // 連携済
        'skip' => '2', // 連携スキップ
        'target' => '3', // 連携対象
        'stop' => '8', // 連携中止
        'except' => '9', // 対象外
    ],

    // X0003　→ バッチ処理状態
    'batch' => [
        'yet' => '0', // 未処理
        'processing' => '1', //	処理中
        'success_no_data' => '2', // 正常終了(データなし)
        'success' => '3', // 正常終了
        'failure' => '9', // 異常終了
    ],

    // X0004　→ パスワードポリシー
    'password' => [
        'exp_days' => '0', // パスワード更新期限 => expiration_days
        'min' => '1', // 最低文字数
        'mixed_case' => '2', // 大文字小文字混在強制
        'letters' => '3', // 英字強制
        'numbers' => '4', // 数字強制
        'symbols' => '5', // 記号強制
        'new' => '6', // 前回不一致 really new (different from previous)
    ],

    // X0005　→ APIキー
    'api_key' => [
        'coopreception' => 'coopreception', // 受付情報連携
        'coopobject' => 'coopobject', // 物件情報連携
        'coopaccountyearmonth' => 'coopaccountyearmonth', // 会計年月情報連携
    ],

    // U0001　→ 時間帯区分
    'slot' => [
        'morning' => '1', // 早朝
        'am1' => '2', // ＡＭ１
        'am2' => '3', // ＡＭ２
        'pm1' => '4', // ＰＭ１
        'pm2' => '5', // ＰＭ２
        'night' => '6', // 夜間
    ],

    // U0002　→ 受付検索表示区分
    'recept_display' => [
        'complete' => '0', // 完了
        'limit_1' => '1', // 日数経過１
        'limit_2' => '2', // 日数経過２
    ],

    // U0003　→ 状態区分
    'status' => [
        'new' => '0', // 新規受付
        'will_visit' => '1', // 訪問予定
        'visited' => '2', // 訪問済
        'on_hold' => '3', // 保留
        'work_done' => '4', // 作業完了
        'checked' => '5', // チェック済
        'completed' => '6', // 受付完了
    ],
    // U0004　→ 状態詳細区分
    'status_detail' => [
        'quotation' => '1', //見積保留
        'customer_scheduling' => '2', //日程調整中（お客様要因）
        'self_scheduling' => '3', //日程調整中 (自社要因)
        'observing' => '4', //様子見
        'parts_waiting' => '5', //部品待ち
        'interphase' => '6', //中間期
        'maker_support' => '7', //メーカー対応
        'periodic' => '8', //定期点検
    ],
    // U0005　→ 有償無償区分
    'payment' => [
        'none' => '0', //未設定
    ],
    // U0006　→ ＫＹポイント区分
    // U0007　→ 作業区分
    'work' => [
        'none' => '0', //未設定
    ],

    // U0008　→ 権限区分
    'auth' => [
        'system_admin' => '0', // システム管理者
        'manager' => '1', // 業務責任者 => bussiness manager
        'field_coordinator' => '2', // 現場調整担当
        'pic' => '3', // 担当 => person in charged (pic)
        'pic_external' => '4', // 担当（協力者）=> person in charged (pic) - collaborator (external)
        'input_support' => '5', // 入力支援
    ],

    // U0009　→ 原価種類区分
    'cost' => [
        'material' => '1',
        'construction' => '2',
    ],

    // U0010　→ 充塡区分
    // U0011　→ 回収区分
    // U0012　→ 充塡種類区分
    'fill_type' => [
        'others' => '0', //その他
    ],
    // U0013　→ 回収種類区分
    'collect_type' => [
        'others' => '0', //その他
    ],
    // U0014　→ 原価登録区分
    'cost_reg' => [
        'manual' => '1', // 手入力
        'fill' => '2', // 充塡情報
        'collect' => '3', // 回収情報
    ],

    // U0015　→ 材料原価名称雛形
    // U0016　→ 工事原価名称雛形
    // U0017　→ 見積単位雛形
    // U0018　→ 見積作業名・品名雛形
    // U0019　→ 作業内容雛形

    // U0020　→ URL
    'url' => [
        'qrcode' => 'qrcode', // QRコードのURL
    ],

    // U0021　→ デフォルト設定
    'default_setting' => [
        'cancelpjmgr' => 'cancelpjmgr', // キャンセル計上担当ログインID
    ],
    // G0001　→ PE予定区分
    'pe_schedule' => [
        'visit' => '7', // 訪問
    ],

    // G0002　→ L2建材作業区分
    'l2_work' => [
        'construction' => '1001', // 施工
    ],

    // G0003　→ L2建材作業分類区分
    // G0004　→ L2建材作業詳細区分

    // ▼ 以下システム定数
    // システムユーザーID
    'sys_userid' => [
        'batch_user' => '0', // バッチユーザー
    ],

    // アップロード最大サイズ(単位メガバイト)
    'upload_max_size' => [
        'profile_file' => '5',      // プロファイル
        'signature_file' => '5',    // 署名ファイル
        'photo_file' => '5',        // 写真ファイル
        'attached_file' => '100',   // 添付ファイル
    ],

    // 表示項目名
    'item_display_name' => [
        'external_company_code' => '会社コード',
        'external_user_code' => 'ユーザーコード',
    ],

    // スケージュール表示設定の日付間 ：スケジュール（リスト）
    'scheduleListTerm' => 30,

    // 予定確認条件設定の日付間：予定確認条件設定
    'scheduleCheckTerm' => 30,
];
